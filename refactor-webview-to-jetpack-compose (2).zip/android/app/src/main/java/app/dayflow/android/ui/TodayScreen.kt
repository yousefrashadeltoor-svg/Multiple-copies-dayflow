package app.dayflow.android.ui

import android.icu.text.DateFormat
import android.icu.util.ULocale
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.R
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.TaskEntry
import app.dayflow.android.data.displayTime
import app.dayflow.android.data.today
import app.dayflow.android.prayer.PrayerClock
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

@Composable
fun TodayScreen(data: AppData, go: (String) -> Unit) {
    val theme = LocalPack.current
    val repo = AppRepository.get(LocalContext.current)
    var now by remember { mutableStateOf(Instant.now()) }
    var taskTitle by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = Instant.now() } }
    val local = now.atZone(ZoneId.systemDefault())
    val city = PrayerClock.city(data)
    val times = remember(city, local.toLocalDate()) { PrayerClock.localTimes(city) }
    val (nextIndex, nextAt) = PrayerClock.next(city, now)
    val dayTasks = data.tasks.filter { it.date == today() }
    val done = dayTasks.count { it.done }
    val water = data.water[today()] ?: 0
    val nextAlarm = data.alarms.filter { it.enabled }.mapNotNull { a -> a.next(local)?.let { it to a } }.minByOrNull { it.first }
    val periodPhoto = when (local.hour) {
        in 4..7 -> R.drawable.dawn
        in 8..12 -> R.drawable.noon
        in 13..16 -> R.drawable.asr
        in 17..19 -> R.drawable.maghrib
        else -> R.drawable.night
    }
    val month = local.monthValue
    val heroPhoto = when (month) {
        in 3..5 -> R.drawable.spring
        in 6..8 -> R.drawable.summer
        in 9..11 -> R.drawable.autumn_tree
        else -> periodPhoto
    }
    val date = local.toLocalDate()
    val locale = if (data.lang == "ar") Locale("ar", "EG") else Locale.UK
    val greeting = when (local.hour) {
        in 5..11 -> label("Good morning", "صباح الخير")
        in 12..16 -> label("Good afternoon", "طاب يومك")
        in 17..23 -> label("Good evening", "مساء الخير")
        else -> label("Good night", "طابت ليلتك")
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(219.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xff123e47), Color(0xff376c60))))) {
                Image(painterResource(heroPhoto), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                    alpha = .43f)
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xb7214240), Color(0xd22f6f5e)))))
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Text("✧             ✦             ✧", color = Color(0xfff5dfb2),
                        modifier = Modifier.fillMaxWidth(), fontSize = 21.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Column {
                        Text(greeting, color = Color.White.copy(alpha = .86f), fontSize = 14.sp)
                        Text(date.format(DateTimeFormatter.ofPattern("EEEE d MMMM", locale)),
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp, maxLines = 1)
                        Text(calendarCaption(date), color = Color.White.copy(alpha = .85f), fontSize = 12.sp, maxLines = 1)
                        Spacer(Modifier.height(14.dp))
                        Text("DAYFLOW   ·   " + when (month) {
                            in 3..5 -> label("Spring", "الربيع")
                            in 6..8 -> label("Summer", "الصيف")
                            in 9..11 -> label("Autumn", "الخريف")
                            else -> label("Winter", "الشتاء")
                        }, modifier = Modifier.background(Color.White.copy(alpha = .17f), RoundedCornerShape(30.dp))
                            .padding(horizontal = 10.dp, vertical = 5.dp), color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            DFCard(onClick = { go("me/prayer") }) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${label("Prayer", "الصلاة")} · ${if (data.lang == "ar") city.ar else city.en}",
                            fontWeight = FontWeight.Bold, fontSize = 12.sp, color = theme.text)
                        Text("${label("Next", "القادمة")}: ${if (data.lang == "ar") PrayerClock.names[nextIndex] else PrayerClock.englishNames[nextIndex]} " +
                            displayTime(nextAt.atZone(city.zone).toLocalTime().toString(), data.lang),
                            fontSize = 10.sp, color = theme.accent, maxLines = 1)
                    }
                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        times.forEachIndexed { i, time ->
                            Column(Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                                .background(if (i == nextIndex) theme.accent else theme.soft)
                                .padding(vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text((if (data.lang == "ar") PrayerClock.names[i] else PrayerClock.englishNames[i]).take(5),
                                    color = if (i == nextIndex) Color.White else theme.text, fontSize = 9.sp, maxLines = 1)
                                Text(displayTime(time.toString(), data.lang),
                                    color = if (i == nextIndex) Color.White else theme.text,
                                    fontWeight = FontWeight.Bold, fontSize = 8.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DFCard(Modifier.weight(1f), onClick = { go("alarms") }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(label("Next alarm", "المنبه التالي"), color = theme.muted, fontSize = 12.sp)
                        Text(nextAlarm?.let { displayTime(it.second.time, data.lang) }
                            ?: label("No alarms on", "لا منبهات مفعّلة"),
                            color = theme.text, fontWeight = FontWeight.Bold,
                            fontSize = if (nextAlarm == null) 14.sp else 26.sp,
                            modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                        if (nextAlarm != null) Text(nextAlarm.second.label, color = theme.muted, fontSize = 11.sp)
                    }
                }
                DFCard(Modifier.weight(1f)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProgressRing(if (dayTasks.isEmpty()) 0f else done.toFloat() / dayTasks.size, Modifier.size(55.dp))
                        Column {
                            Text(label("Day", "اليوم"), color = theme.muted, fontSize = 12.sp)
                            Text("$done/${dayTasks.size}", fontSize = 17.sp, color = theme.text, fontWeight = FontWeight.Bold)
                            Text(label("tasks", "مهام"), color = theme.muted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item {
            DFCard(onClick = { go("downloads") }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(theme.accent), contentAlignment = Alignment.Center) {
                        Text("↓", color = Color.White, fontSize = 27.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(label("Downloader", "التحميل"), color = theme.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(label("Paste or share any link - video, audio, images, files", "الصق أو شارك أي رابط - فيديو، صوت، صور، ملفات"),
                            color = theme.muted, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
        item {
            DFCard {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label("Today's tasks", "مهام اليوم"), color = theme.text, fontWeight = FontWeight.Bold)
                        Text(label("All", "الكل"), color = theme.accent, fontSize = 12.sp,
                            modifier = Modifier.clickable { go("tools/tasks") })
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                        DFField(taskTitle, { taskTitle = it }, label("Add a task for today...", "ضيف مهمة للنهاردة..."), Modifier.weight(1f))
                        DFButton("+", { repo.update { it.copy(tasks = listOf(TaskEntry(title = taskTitle.trim())) + it.tasks) }; taskTitle = "" },
                            enabled = taskTitle.isNotBlank())
                    }
                    if (dayTasks.isEmpty()) DFEmpty(label("A clear day", "يوم فاضي وهادي"),
                        label("Nothing planned yet.", "لسه مفيش حاجة متخططة."))
                    else dayTasks.forEach { task ->
                        Row(Modifier.fillMaxWidth().clickable { repo.update { s -> s.copy(tasks = s.tasks.map {
                            if (it.id == task.id) it.copy(done = !it.done) else it
                        }) } }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(if (task.done) "☑" else "□", color = theme.accent, fontSize = 22.sp)
                            Text(task.title, color = if (task.done) theme.muted else theme.text, fontSize = 14.sp,
                                modifier = Modifier.weight(1f), maxLines = 2)
                        }
                    }
                    HorizontalDivider(color = theme.accent.copy(alpha = .23f))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DFCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(label("Water", "الماء"), color = theme.muted, fontSize = 12.sp)
                        Text("${"%.2f".format(Locale.US, water / 1000f)} / ${data.waterGoal / 1000f} L",
                            color = theme.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Spacer(Modifier.height(7.dp))
                        Box(Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(6.dp)).background(theme.soft)) {
                            Box(Modifier.fillMaxWidth((water.toFloat() / data.waterGoal).coerceIn(0f, 1f))
                                .height(7.dp).background(Color(0xff3aa0ff)))
                        }
                        Spacer(Modifier.height(9.dp))
                        DFButton("+250 ml", { repo.update { s -> s.copy(water = s.water +
                            (today() to ((s.water[today()] ?: 0) + 250))) } }, Modifier.fillMaxWidth(), soft = true)
                    }
                }
                DFCard(Modifier.weight(1f), onClick = { go("tools/habits") }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(label("Habits", "العادات"), color = theme.muted, fontSize = 12.sp)
                        data.habits.take(4).forEach { habit ->
                            Text("${if (today() in habit.log) "●" else "○"}  ${habit.title}",
                                color = if (today() in habit.log) theme.accent else theme.text,
                                fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
                        }
                        if (data.habits.isEmpty()) Text(label("Start a habit", "ابدأ عادة"),
                            color = theme.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}

fun calendarCaption(date: LocalDate): String = runCatching {
    val d = Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant())
    val hijri = DateFormat.getDateInstance(DateFormat.MEDIUM, ULocale("ar_EG@calendar=islamic-umalqura")).format(d)
    val coptic = DateFormat.getDateInstance(DateFormat.MEDIUM, ULocale("ar_EG@calendar=coptic")).format(d)
    "$hijri · $coptic"
}.getOrDefault("")

@Composable
fun ProgressRing(value: Float, modifier: Modifier = Modifier) {
    val theme = LocalPack.current
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(theme.soft, 0f, 360f, false, style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round))
            drawArc(theme.accent, -90f, 360f * value.coerceIn(0f, 1f), false,
                style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round))
        }
        Text("${(value * 100).toInt()}%", fontSize = 10.sp, color = theme.text, fontWeight = FontWeight.Bold)
    }
}