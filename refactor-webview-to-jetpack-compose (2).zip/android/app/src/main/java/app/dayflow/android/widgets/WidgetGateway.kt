package app.dayflow.android.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.AlarmEntry
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.Catalog
import app.dayflow.android.data.WidgetDesign
import app.dayflow.android.data.displayTime
import app.dayflow.android.data.today
import app.dayflow.android.prayer.PrayerClock
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.min

open class WidgetGateway : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) =
        ids.forEach { render(context, manager, it) }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, newOptions: Bundle) =
        render(context, manager, id)

    override fun onDeleted(context: Context, ids: IntArray) {
        val edit = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE).edit()
        ids.forEach { edit.remove("widget_$it") }
        edit.apply()
    }

    override fun onRestored(context: Context, oldWidgetIds: IntArray, newWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE)
        val edit = prefs.edit()
        oldWidgetIds.zip(newWidgetIds).forEach { (old, new) ->
            prefs.getString("widget_$old", null)?.let { edit.putString("widget_$new", it) }
            edit.remove("widget_$old")
        }
        edit.apply()
        refreshAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_WIDGET_ACTION) return
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val design = configuration(context, id)?.first ?: return
        val repository = AppRepository.get(context)
        when {
            design.id.contains("water") -> repository.update { s -> s.copy(water = s.water +
                (today() to ((s.water[today()] ?: 0) + 250))) }
            design.category == "tasks" || design.category == "plan" -> {
                repository.state.value.tasks.firstOrNull { !it.done && it.date == today() }?.id?.let { taskId ->
                    repository.update { s -> s.copy(tasks = s.tasks.map { if (it.id == taskId) it.copy(done = true) else it }) }
                }
            }
            design.category == "habits" -> {
                repository.state.value.habits.firstOrNull { today() !in it.log }?.id?.let { habitId ->
                    repository.update { s -> s.copy(habits = s.habits.map {
                        if (it.id == habitId) it.copy(log = it.log + today()) else it
                    }) }
                }
            }
        }
        render(context, AppWidgetManager.getInstance(context), id)
    }

    companion object {
        const val ACTION_WIDGET_ACTION = "app.dayflow.WIDGET_ACTION"
        val gateways = listOf(
            GatewaySmall::class.java, GatewayWide::class.java, GatewayMedium::class.java,
            GatewayBanner::class.java, GatewayLarge::class.java, GatewayXL::class.java
        )

        fun formFor(context: Context, id: Int): String {
            val manager = AppWidgetManager.getInstance(context)
            val name = manager.getAppWidgetInfo(id)?.provider?.className ?: return "2x2"
            return when {
                name.endsWith("GatewaySmall") -> "1x1"
                name.endsWith("GatewayWide") -> "2x1"
                name.endsWith("GatewayMedium") -> "2x2"
                name.endsWith("GatewayBanner") -> "4x1"
                name.endsWith("GatewayLarge") -> "4x2"
                else -> "4x4"
            }
        }

        fun configuration(context: Context, id: Int): Pair<WidgetDesign, String>? {
            if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return null
            val raw = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE)
                .getString("widget_$id", null) ?: return null
            val j = runCatching { JSONObject(raw) }.getOrNull() ?: return null
            val design = Catalog.widgets(context).firstOrNull { it.id == j.optString("design") } ?: return null
            return design to j.optString("style", "oneui")
        }

        fun save(context: Context, id: Int, design: WidgetDesign, style: String): Boolean {
            require(id != AppWidgetManager.INVALID_APPWIDGET_ID)
            val raw = JSONObject().put("design", design.id).put("style", style).toString()
            val saved = context.getSharedPreferences("dayflow_widgets", Context.MODE_PRIVATE)
                .edit().putString("widget_$id", raw).commit()
            if (saved) render(context, AppWidgetManager.getInstance(context), id)
            return saved
        }

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            gateways.forEach { provider -> manager.getAppWidgetIds(ComponentName(context, provider))
                .forEach { render(context, manager, it) } }
        }

        fun requestPin(context: Context, form: String): Boolean {
            if (Build.VERSION.SDK_INT < 26) return false
            val manager = AppWidgetManager.getInstance(context)
            if (!manager.isRequestPinAppWidgetSupported) return false
            val index = Catalog.forms.indexOf(form).coerceAtLeast(0)
            return manager.requestPinAppWidget(ComponentName(context, gateways[index]), null, null)
        }

        fun render(context: Context, manager: AppWidgetManager, id: Int) {
            val config = configuration(context, id)
            val options = manager.getAppWidgetOptions(id)
            val density = context.resources.displayMetrics.density
            val fallback = when (formFor(context, id)) {
                "1x1" -> 70 to 70; "2x1" -> 142 to 70; "2x2" -> 142 to 142
                "4x1" -> 282 to 70; "4x2" -> 282 to 142; else -> 282 to 282
            }
            val widthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH).takeIf { it > 35 } ?: fallback.first
            val heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT).takeIf { it > 35 } ?: fallback.second
            val width = (widthDp * density).toInt().coerceIn(92, 480)
            val height = (heightDp * density).toInt().coerceIn(92, 460)
            val views = RemoteViews(context.packageName, R.layout.widget_shell)
            views.setImageViewBitmap(R.id.widget_image, WidgetArtwork.draw(context, width, height, config))
            val open = PendingIntent.getActivity(context, id,
                Intent(context, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_ROUTE, if (config == null) "me/widgets" else when (config.first.category) {
                        "clock", "prayer" -> "me/prayer"
                        "alarms" -> "alarms"; "tasks", "plan" -> "tools/tasks"
                        "habits" -> "tools/habits"; "media" -> "downloads"
                        else -> "today"
                    })
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, open)
            if (config?.first?.category == "clock" || config?.first?.archetype in setOf("digital", "flip", "world")) {
                views.setViewVisibility(R.id.widget_live_clock, View.VISIBLE)
                views.setTextColor(R.id.widget_live_clock,
                    if (config?.second in setOf("amoled", "neon", "seasonal", "outline")) Color.WHITE else Color.rgb(25, 30, 32))
                views.setTextViewTextSize(R.id.widget_live_clock, TypedValue.COMPLEX_UNIT_SP,
                    (widthDp / 5).coerceIn(18, 42).toFloat())
            } else views.setViewVisibility(R.id.widget_live_clock, View.GONE)
            val action = when {
                config?.first?.id?.contains("water") == true -> "+250"
                config?.first?.interactive == true && config.first.category == "habits" -> "✓"
                config?.first?.interactive == true && config.first.category in setOf("tasks", "plan") -> "تم"
                else -> null
            }
            views.setViewVisibility(R.id.widget_action, if (action == null) View.GONE else View.VISIBLE)
            if (action != null) {
                views.setTextViewText(R.id.widget_action, action)
                views.setOnClickPendingIntent(R.id.widget_action, PendingIntent.getBroadcast(context, id,
                    Intent(context, manager.getAppWidgetInfo(id)?.provider?.className?.let { name ->
                        gateways.firstOrNull { it.name == name }
                    } ?: GatewaySmall::class.java).setAction(ACTION_WIDGET_ACTION)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            manager.updateAppWidget(id, views)
        }
    }
}

class GatewaySmall : WidgetGateway()
class GatewayWide : WidgetGateway()
class GatewayMedium : WidgetGateway()
class GatewayBanner : WidgetGateway()
class GatewayLarge : WidgetGateway()
class GatewayXL : WidgetGateway()

object WidgetArtwork {
    fun draw(context: Context, width: Int, height: Int, config: Pair<WidgetDesign, String>?): Bitmap {
        val design = config?.first
        val style = config?.second ?: "oneui"
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val dark = style in setOf("neon", "amoled", "seasonal", "outline")
        val bg = when (style) {
            "neon" -> 0xff0b0820.toInt(); "amoled" -> Color.BLACK; "seasonal" -> 0xff215445.toInt()
            "paper" -> 0xfff4ecd8.toInt(); "clay" -> 0xffece6dd.toInt(); "editorial" -> 0xfffaf7f0.toInt()
            "material" -> 0xffdfece7.toInt(); "ios" -> 0xfff6f6f7.toInt(); "outline" -> 0xff183f3a.toInt()
            else -> 0xffecf0f3.toInt()
        }
        val fg = if (dark) Color.WHITE else 0xff172222.toInt()
        val accent = if (dark) 0xffd8bf78.toInt() else 0xff2f6f5e.toInt()
        paint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), bg,
            if (style == "seasonal") 0xff426b73.toInt() else bg, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 28f, 28f, paint)
        paint.shader = null
        val unit = min(width, height).toFloat()
        val margin = (unit * .13f).coerceIn(11f, 22f)
        paint.color = accent
        paint.textSize = (unit * .11f).coerceIn(11f, 20f)
        paint.isFakeBoldText = true
        paint.textAlign = Paint.Align.RIGHT
        val title = design?.ar ?: "DAYFLOW"
        val safeTitle = if (paint.measureText(title) > width - margin * 2) title.take(16) else title
        canvas.drawText(safeTitle, width - margin, margin + paint.textSize, paint)
        paint.textAlign = Paint.Align.LEFT
        paint.isFakeBoldText = false
        paint.color = fg
        val state = AppRepository.get(context).state.value
        val data = when (design?.category) {
            "clock" -> ""
            "alarms" -> state.alarms.asSequence().filter { it.enabled }
                .mapNotNull { a -> a.next(java.time.ZonedDateTime.now())?.let { it to a } }
                .minByOrNull { it.first }?.second?.let { displayTime(it.time, state.lang) } ?: "لا منبهات مفعلة"
            "calendar", "occasions" -> LocalDate.now().toString()
            "tasks", "plan" -> "${state.tasks.count { it.date == today() && it.done }}/${state.tasks.count { it.date == today() }} مهام"
            "habits" -> "${state.habits.count { today() in it.log }}/${state.habits.size} عادات"
            "utility" -> when {
                design.id.contains("prayer") || design.id.contains("mosque") || design.id.contains("fajr") -> {
                    val city = PrayerClock.city(state)
                    val (next, instant) = PrayerClock.next(city)
                    "${PrayerClock.names[next]}  ${displayTime(instant.atZone(city.zone).toLocalTime().toString(), state.lang)}"
                }
                design.id.contains("water") -> "${state.water[today()] ?: 0} / ${state.waterGoal} ml"
                design.id.contains("tasbih") -> "${state.tasbih}"
                else -> "DAYFLOW"
            }
            "media" -> "التحميل"
            "review" -> "${state.tasks.count { it.done }} مهمة مكتملة"
            "focus" -> "ابدأ التركيز"
            "companion" -> "رفيقك معك"
            else -> "يومك بهدوء"
        }
        paint.textSize = (unit * .18f).coerceIn(14f, 31f)
        paint.isFakeBoldText = true
        paint.textAlign = if (state.lang == "ar") Paint.Align.RIGHT else Paint.Align.LEFT
        val tx = if (state.lang == "ar") width - margin else margin
        val y = (height * .57f).coerceAtLeast(margin + 30f)
        canvas.drawText(data.take(28), tx, y, paint)
        if (height > 150 && design?.category in setOf("tasks", "plan", "habits")) {
            paint.color = if (dark) 0xffd0dfdc.toInt() else 0xff61716d.toInt()
            paint.textSize = (unit * .08f).coerceIn(12f, 18f)
            paint.isFakeBoldText = false
            val lines = when (design.category) {
                "habits" -> state.habits.map { it.title }
                else -> state.tasks.filter { it.date == today() && !it.done }.map { it.title }
            }
            lines.take(2).forEachIndexed { i, line -> canvas.drawText(line.take(28), tx, y + paint.textSize * (i + 1) * 1.45f, paint) }
        }
        paint.color = accent
        paint.textSize = (unit * .09f).coerceIn(10f, 16f)
        paint.textAlign = Paint.Align.LEFT
        canvas.drawText("DAYFLOW", margin, height - margin * .55f, paint)
        return bitmap
    }
}