package app.dayflow.android.data

import android.content.Context
import android.util.Log
import app.dayflow.android.widgets.WidgetGateway
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.Locale
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()
fun today(): String = LocalDate.now().toString()

fun displayTime(value: String, lang: String = "ar"): String {
    val time = runCatching { LocalTime.parse(value) }.getOrNull() ?: return "--"
    val hour = time.hour % 12
    val raw = "${if (hour == 0) 12 else hour}:${time.minute.toString().padStart(2, '0')}"
    return if (lang == "ar") raw.map { c -> if (c in '0'..'9') "٠١٢٣٤٥٦٧٨٩"[c - '0'] else c }.joinToString("") +
        if (time.hour < 12) " ص" else " م"
    else raw + if (time.hour < 12) " AM" else " PM"
}

data class AlarmEntry(
    val id: String = newId(), val time: String = "07:00", val date: String? = null,
    val days: Set<Int> = setOf(0, 1, 2, 3, 4), val label: String = "",
    val enabled: Boolean = true, val soundTitle: String = "منبه الجهاز الافتراضي",
    val soundUri: String = "", val vibrate: Boolean = true, val snooze: Int = 10,
    val gentle: Boolean = true
) {
    fun next(after: ZonedDateTime): ZonedDateTime? {
        val clock = runCatching { LocalTime.parse(time) }.getOrNull() ?: return null
        val zone = after.zone
        val start = after.toLocalDate()
        if (days.isEmpty()) {
            val day = runCatching { LocalDate.parse(date) }.getOrNull() ?: return null
            return day.atTime(clock).atZone(zone).takeIf { it.toInstant().isAfter(after.toInstant()) }
        }
        for (i in 0..7L) {
            val day = start.plusDays(i)
            if (day.dayOfWeek.value % 7 !in days || (date != null && day.isBefore(runCatching { LocalDate.parse(date) }.getOrNull() ?: return null))) continue
            val candidate = day.atTime(clock).atZone(zone)
            if (candidate.toInstant().isAfter(after.toInstant())) return candidate
        }
        return null
    }
    fun json() = JSONObject().put("id", id).put("time", time).put("date", date)
        .put("days", JSONArray(days.sorted())).put("label", label).put("enabled", enabled)
        .put("soundTitle", soundTitle).put("soundUri", soundUri).put("vibrate", vibrate)
        .put("snooze", snooze).put("gentle", gentle)
    companion object {
        fun from(j: JSONObject) = AlarmEntry(
            id = j.optString("id").ifBlank { newId() }, time = j.optString("time", "07:00"),
            date = j.optString("date").takeIf { it.isNotEmpty() && it != "null" },
            days = j.optJSONArray("days")?.let { arr -> (0 until arr.length()).map { arr.optInt(it, -1) }.filter { it in 0..6 }.toSet() } ?: emptySet(),
            label = j.optString("label"), enabled = j.optBoolean("enabled", true),
            soundTitle = j.optString("soundTitle").ifBlank { j.optJSONObject("sound")?.optString("title") ?: "منبه الجهاز الافتراضي" },
            soundUri = j.optString("soundUri"), vibrate = j.optBoolean("vibrate", true),
            snooze = j.optInt("snooze", 10).coerceIn(1, 60), gentle = j.optBoolean("gentle", true)
        )
    }
}

data class TaskEntry(
    val id: String = newId(), val title: String, val date: String = today(),
    val dueTime: String = "", val done: Boolean = false,
    val urgent: Boolean = false, val important: Boolean = true, val status: String = "todo"
) {
    fun json() = JSONObject().put("id", id).put("title", title).put("date", date)
        .put("dueTime", dueTime).put("done", done).put("urgent", urgent).put("important", important).put("status", status)
    companion object {
        fun from(j: JSONObject) = TaskEntry(j.optString("id").ifBlank { newId() },
            j.optString("title"), j.optString("date", today()), j.optString("dueTime"),
            j.optBoolean("done"), j.optBoolean("urgent"), j.optBoolean("important", true), j.optString("status", "todo"))
    }
}

data class HabitEntry(
    val id: String = newId(), val title: String, val days: Set<Int> = (0..6).toSet(),
    val log: Set<String> = emptySet(), val reminder: String = "", val color: String = "#2fa36b",
    val type: String = "build", val target: Int = 1, val unit: String = "",
    val details: String = "", val icon: String = "", val startDate: String? = null
) {
    fun json() = JSONObject().put("id", id).put("en", title).put("days", JSONArray(days.sorted()))
        .put("log", JSONArray(log.sorted())).put("reminder", reminder).put("color", color)
        .put("type", type).put("target", target).put("unit", unit).put("details", details)
        .put("emoji", icon).put("startDate", startDate)
    companion object {
        fun from(j: JSONObject) = HabitEntry(j.optString("id").ifBlank { newId() }, j.optString("en"),
            j.optJSONArray("days")?.let { a -> (0 until a.length()).map { a.optInt(it) }.toSet() } ?: (0..6).toSet(),
            j.optJSONArray("log")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() } ?: emptySet(),
            j.optString("reminder"), j.optString("color", "#2fa36b"), j.optString("type", "build"),
            j.optInt("target", 1), j.optString("unit"), j.optString("details"), j.optString("emoji"),
            j.optString("startDate").takeIf { it.isNotBlank() && it != "null" })
    }
}

data class NoteEntry(val id: String = newId(), val text: String, val pinned: Boolean = false) {
    fun json() = JSONObject().put("id", id).put("text", text).put("pinned", pinned)
    companion object { fun from(j: JSONObject) = NoteEntry(j.optString("id").ifBlank { newId() }, j.optString("text"), j.optBoolean("pinned")) }
}

data class ReminderEntry(
    val id: String = newId(), val title: String, val date: String,
    val time: String, val completed: Boolean = false, val days: Set<Int> = emptySet()
) {
    fun json() = JSONObject().put("id", id).put("title", title).put("date", date)
        .put("time", time).put("completed", completed).put("days", JSONArray(days.sorted()))
    companion object { fun from(j: JSONObject) = ReminderEntry(j.optString("id").ifBlank { newId() }, j.optString("title"), j.optString("date"), j.optString("time"), j.optBoolean("completed"),
        j.optJSONArray("days")?.let { a -> (0 until a.length()).map { a.optInt(it) }.toSet() } ?: emptySet()) }
}

data class CountdownEntry(val id: String = newId(), val title: String, val date: String) {
    fun json() = JSONObject().put("id", id).put("title", title).put("date", date)
    companion object { fun from(j: JSONObject) = CountdownEntry(j.optString("id").ifBlank { newId() }, j.optString("title"), j.optString("date")) }
}

data class JournalEntry(val id: String = newId(), val date: String = today(), val mood: Int, val text: String) {
    fun json() = JSONObject().put("id", id).put("date", date).put("mood", mood).put("text", text)
    companion object { fun from(j: JSONObject) = JournalEntry(j.optString("id").ifBlank { newId() }, j.optString("date", today()), j.optInt("mood", 3), j.optString("text")) }
}

data class MedEntry(val id: String = newId(), val name: String, val time: String, val taken: Set<String> = emptySet()) {
    fun json() = JSONObject().put("id", id).put("name", name).put("times", JSONArray(listOf(time)))
        .put("takenDates", JSONArray(taken.sorted()))
    companion object { fun from(j: JSONObject) = MedEntry(j.optString("id").ifBlank { newId() }, j.optString("name"),
        j.optJSONArray("times")?.optString(0) ?: j.optString("time", "09:00"),
        j.optJSONArray("takenDates")?.let { a -> (0 until a.length()).map { a.optString(it) }.toSet() }
            ?: j.optJSONObject("taken")?.let { obj -> obj.keys().asSequence().filter { (obj.optJSONArray(it)?.length() ?: 0) > 0 }.toSet() } ?: emptySet()) }
}

data class WorkoutEntry(val id: String = newId(), val title: String, val minutes: Int, val date: String = today()) {
    fun json() = JSONObject().put("id", id).put("title", title).put("minutes", minutes).put("date", date)
    companion object { fun from(j: JSONObject) = WorkoutEntry(j.optString("id").ifBlank { newId() }, j.optString("title"), j.optInt("minutes"), j.optString("date", today())) }
}

data class ChatMessage(val role: String, val text: String, val at: Long = System.currentTimeMillis()) {
    fun json() = JSONObject().put("role", role).put("text", text).put("at", at)
    companion object { fun from(j: JSONObject) = ChatMessage(j.optString("role"), j.optString("text"), j.optLong("at")) }
}

data class AppData(
    val lang: String = "ar", val themeId: String = "paper-white", val autoTimeTheme: Boolean = true,
    val cityId: String = "cairo", val useLocation: Boolean = false,
    val latitude: Double? = null, val longitude: Double? = null,
    val companionEnabled: Boolean = true, val companionVisible: Boolean = true,
    val companionSize: Float = 1f, val companionOpacity: Float = 1f,
    val companionMood: String = "idle", val companionOutfit: String = "auto",
    val companionBubbles: Boolean = true,
    val notificationPreview: Boolean = true, val quietHours: Boolean = false,
    val notificationSound: Boolean = true, val notificationVibrate: Boolean = true,
    val alarms: List<AlarmEntry> = emptyList(), val tasks: List<TaskEntry> = emptyList(),
    val habits: List<HabitEntry> = emptyList(), val notes: List<NoteEntry> = emptyList(),
    val reminders: List<ReminderEntry> = emptyList(), val water: Map<String, Int> = emptyMap(),
    val countdowns: List<CountdownEntry> = emptyList(), val journal: List<JournalEntry> = emptyList(),
    val meds: List<MedEntry> = emptyList(), val workouts: List<WorkoutEntry> = emptyList(),
    val waterGoal: Int = 2500, val tasbih: Int = 0, val khatma: Int = 0,
    val dailyReview: String = "21:30", val weeklyReview: Boolean = false,
    val decorIntensity: String = "subtle", val alarmLayout: String = "ornate",
    val alarmGradient: Boolean = true, val alarmSeconds: Boolean = false,
    val chat: List<ChatMessage> = emptyList(), val reduceMotion: Boolean = false
) {
    fun json() = JSONObject().put("lang", lang).put("themeId", themeId)
        .put("autoTimeTheme", autoTimeTheme).put("cityId", cityId)
        .put("useLocation", useLocation).put("latitude", latitude).put("longitude", longitude)
        .put("companionEnabled", companionEnabled).put("companionVisible", companionVisible)
        .put("companionSize", companionSize.toDouble()).put("companionOpacity", companionOpacity.toDouble())
        .put("companionMood", companionMood).put("companionOutfit", companionOutfit)
        .put("companionBubbles", companionBubbles)
        .put("notificationPreview", notificationPreview).put("quietHours", quietHours)
        .put("notificationSound", notificationSound).put("notificationVibrate", notificationVibrate)
        .put("alarms", JSONArray(alarms.map { it.json() })).put("tasks", JSONArray(tasks.map { it.json() }))
        .put("habits", JSONArray(habits.map { it.json() })).put("notes", JSONArray(notes.map { it.json() }))
        .put("reminders", JSONArray(reminders.map { it.json() })).put("water", JSONObject(water))
        .put("countdowns", JSONArray(countdowns.map { it.json() }))
        .put("journal", JSONArray(journal.map { it.json() }))
        .put("meds", JSONArray(meds.map { it.json() }))
        .put("workouts", JSONArray(workouts.map { it.json() }))
        .put("waterGoal", waterGoal).put("tasbih", tasbih).put("khatma", khatma)
        .put("dailyReview", dailyReview).put("weeklyReview", weeklyReview)
        .put("decorIntensity", decorIntensity).put("alarmLayout", alarmLayout)
        .put("alarmGradient", alarmGradient).put("alarmSeconds", alarmSeconds)
        .put("chat", JSONArray(chat.map { it.json() })).put("reduceMotion", reduceMotion)

    companion object {
        private fun <T> arr(j: JSONObject, key: String, parse: (JSONObject) -> T): List<T> =
            j.optJSONArray(key)?.let { a -> (0 until a.length()).mapNotNull { i ->
                a.optJSONObject(i)?.let { runCatching { parse(it) }.getOrNull() }
            } } ?: emptyList()
        fun from(j: JSONObject): AppData {
            val companion = j.optJSONObject("companion")
            val notif = j.optJSONObject("notif")
            val water = j.optJSONObject("water")
            return AppData(
                lang = j.optString("lang", "ar"), themeId = j.optString("themeId", "paper-white"),
                autoTimeTheme = j.optBoolean("autoTimeTheme", true),
                cityId = j.optString("cityId").ifBlank { listOf("cairo", "alexandria", "luxor", "aswan", "suez", "sharm", "makkah", "madinah", "dubai", "london").getOrElse(j.optInt("cityIndex")) { "cairo" } },
                useLocation = j.optBoolean("useLocation"),
                latitude = if (j.has("latitude") && !j.isNull("latitude")) j.optDouble("latitude") else null,
                longitude = if (j.has("longitude") && !j.isNull("longitude")) j.optDouble("longitude") else null,
                companionEnabled = companion?.optBoolean("enabled") ?: j.optBoolean("companionEnabled", true),
                companionVisible = !(companion?.optBoolean("hidden") ?: !j.optBoolean("companionVisible", true)),
                companionSize = (companion?.optDouble("size") ?: j.optDouble("companionSize", 1.0)).toFloat().coerceIn(.7f, 1.5f),
                companionOpacity = (companion?.optDouble("opacity") ?: j.optDouble("companionOpacity", 1.0)).toFloat().coerceIn(.35f, 1f),
                companionMood = companion?.optString("emotion") ?: j.optString("companionMood", "idle"),
                companionOutfit = companion?.optString("outfit") ?: j.optString("companionOutfit", "auto"),
                companionBubbles = companion?.optBoolean("bubbles") ?: j.optBoolean("companionBubbles", true),
                notificationPreview = notif?.optBoolean("preview") ?: j.optBoolean("notificationPreview", true),
                quietHours = notif?.optBoolean("quiet") ?: j.optBoolean("quietHours"),
                notificationSound = notif?.optBoolean("sound") ?: j.optBoolean("notificationSound", true),
                notificationVibrate = notif?.optBoolean("vibrate") ?: j.optBoolean("notificationVibrate", true),
                alarms = arr(j, "alarms", AlarmEntry::from), tasks = arr(j, "tasks", TaskEntry::from),
                habits = arr(j, "habits", HabitEntry::from), notes = arr(j, "notes", NoteEntry::from),
                reminders = arr(j, "reminders", ReminderEntry::from),
                water = water?.keys()?.asSequence()?.associateWith { water.optInt(it) } ?: emptyMap(),
                countdowns = arr(j, "countdowns", CountdownEntry::from),
                journal = arr(j, "journal", JournalEntry::from),
                meds = arr(j, "meds", MedEntry::from),
                workouts = arr(j, "workouts", WorkoutEntry::from),
                waterGoal = j.optInt("waterGoal", 2500).coerceAtLeast(500),
                tasbih = j.optInt("tasbih"), khatma = j.optInt("khatma"),
                dailyReview = notif?.optString("dailyReview") ?: j.optString("dailyReview", "21:30"),
                weeklyReview = notif?.optBoolean("weeklyReview") ?: j.optBoolean("weeklyReview"),
                decorIntensity = j.optString("decorIntensity").ifBlank { j.optString("intensity", "subtle") },
                alarmLayout = j.optString("alarmLayout").ifBlank { j.optJSONObject("alarmLook")?.optString("layout") ?: "ornate" },
                alarmGradient = j.optJSONObject("alarmLook")?.optBoolean("gradient") ?: j.optBoolean("alarmGradient", true),
                alarmSeconds = j.optJSONObject("alarmLook")?.optBoolean("showSeconds") ?: j.optBoolean("alarmSeconds"),
                chat = arr(j, "chat", ChatMessage::from), reduceMotion = j.optBoolean("reduceMotion")
            )
        }
    }
}

class AppRepository private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("dayflow_native_v1", Context.MODE_PRIVATE)
    private val initial = runCatching {
        prefs.getString("state", null)?.let { AppData.from(JSONObject(it)) }
    }.onFailure {
        Log.e("DAYFLOW", "Preserved unreadable state for recovery", it)
        prefs.getString("state", null)?.let { raw -> prefs.edit().putString("state_corrupt_backup", raw).commit() }
    }.getOrNull() ?: AppData(lang = if (Locale.getDefault().language == "ar") "ar" else "en")
    private val _state = MutableStateFlow(initial)
    val state = _state.asStateFlow()
    val hasCorruptBackup get() = prefs.contains("state_corrupt_backup")

    @Synchronized fun update(change: (AppData) -> AppData) {
        val next = change(_state.value)
        if (!prefs.edit().putString("state", next.json().toString()).commit()) throw IllegalStateException("Unable to save local data")
        _state.value = next
        WidgetGateway.refreshAll(context)
    }

    fun export(): String = JSONObject().put("version", 1).put("state", _state.value.json())
        .apply { prefs.getString("legacy_state_backup", null)?.let { put("originalWebBackup", it) } }.toString(2)
    fun import(raw: String) {
        val obj = JSONObject(raw)
        val state = obj.optJSONObject("state") ?: throw IllegalArgumentException("Not a DAYFLOW backup")
        require(state.has("tasks") && state.has("alarms")) { "Not a DAYFLOW backup" }
        update { AppData.from(state) }
        prefs.edit().putString("legacy_state_backup", raw).apply()
    }

    companion object {
        @Volatile private var instance: AppRepository? = null
        fun get(context: Context): AppRepository = instance ?: synchronized(this) {
            instance ?: AppRepository(context.applicationContext).also { instance = it }
        }
    }
}