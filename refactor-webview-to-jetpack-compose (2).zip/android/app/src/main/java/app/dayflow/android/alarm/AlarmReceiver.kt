package app.dayflow.android.alarm

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import app.dayflow.android.R
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.ReminderEntry
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val repo = AppRepository.get(context)
        val alarm = repo.state.value.alarms.firstOrNull { it.id == id } ?: return
        when (intent.action) {
            DISMISS, SNOOZE -> {
                if (intent.action == SNOOZE) AlarmScheduler.snooze(context, id, alarm.snooze)
                context.stopService(Intent(context, AlarmRingingService::class.java))
                context.sendBroadcast(Intent(AlarmRingActivity.ACTION_STOP).setPackage(context.packageName))
                context.getSystemService(NotificationManager::class.java).cancel(RING_NOTIFICATION)
                return
            }
        }
        if (!alarm.enabled && !intent.getBooleanExtra("snoozed", false)) return
        if (!intent.getBooleanExtra("snoozed", false)) {
            if (alarm.days.isEmpty()) repo.update { it.copy(alarms = it.alarms.map { item ->
                if (item.id == id) item.copy(enabled = false) else item
            }) }
            else runCatching { AlarmScheduler.schedule(context, alarm, Instant.now().plusSeconds(2)) }
        }
        val service = Intent(context, AlarmRingingService::class.java).putExtra("id", id)
        try { ContextCompat.startForegroundService(context, service) }
        catch (_: Exception) {
            // Android can reject a background service start. Still show the alarm notification.
            NotificationCenter.setup(context)
            if (NotificationCenter.canPost(context)) {
                val open = NotificationCenter.open(context, "alarms", RING_NOTIFICATION)
                context.getSystemService(NotificationManager::class.java).notify(RING_NOTIFICATION,
                    Notification.Builder(context, NotificationCenter.ALARMS)
                        .setSmallIcon(R.drawable.dayflow_icon).setContentTitle("DAYFLOW")
                        .setContentText(alarm.label.ifBlank { "المنبه" }).setContentIntent(open).build())
            }
        }
    }
    companion object {
        const val DISMISS = "app.dayflow.DISMISS_ALARM"
        const val SNOOZE = "app.dayflow.SNOOZE_ALARM"
        const val RING_NOTIFICATION = 51410
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val repo = AppRepository.get(context)
        val state = repo.state.value
        val reminder = state.reminders.firstOrNull { it.id == id }
            ?: state.tasks.firstOrNull { it.id == id && !it.done }?.let { ReminderEntry(it.id, it.title, it.date, it.dueTime) }
            ?: state.habits.firstOrNull { it.id == id }?.let { ReminderEntry(it.id, it.title,
                it.startDate ?: LocalDate.now().toString(), it.reminder, days = it.days.ifEmpty { (0..6).toSet() }) }
            ?: state.meds.firstOrNull { it.id == id }?.let { ReminderEntry(it.id, it.name,
                LocalDate.now().toString(), it.time, days = (0..6).toSet()) }
            ?: if (id == "review_daily" || id == "review_weekly") ReminderEntry(id,
                if (id == "review_daily") "مراجعة اليوم" else "المراجعة الأسبوعية",
                LocalDate.now().toString(), state.dailyReview, days = if (id == "review_daily") (0..6).toSet() else setOf(5)) else null
            ?: return
        when (intent.action) {
            COMPLETE -> {
                repo.update { s -> s.copy(
                    reminders = s.reminders.map { if (it.id == id && it.days.isEmpty()) it.copy(completed = true) else it },
                    tasks = s.tasks.map { if (it.id == id) it.copy(done = true) else it },
                    habits = s.habits.map { if (it.id == id) it.copy(log = it.log + LocalDate.now().toString()) else it },
                    meds = s.meds.map { if (it.id == id) it.copy(taken = it.taken + LocalDate.now().toString()) else it }
                ) }
                if (reminder.days.isEmpty()) ReminderScheduler.cancel(context, id)
                else ReminderScheduler.schedule(context, reminder)
                context.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
                return
            }
            SNOOZE -> {
                val tenMinutes = java.time.ZonedDateTime.now().plusMinutes(10)
                ReminderScheduler.schedule(context, reminder.copy(date = tenMinutes.toLocalDate().toString(),
                    time = tenMinutes.toLocalTime().withSecond(0).withNano(0).toString(), days = emptySet()))
                context.getSystemService(NotificationManager::class.java).cancel(id.hashCode())
                return
            }
        }
        if (!NotificationCenter.canPost(context)) return
        NotificationCenter.setup(context)
        val open = NotificationCenter.open(context, "tools/tasks", id.hashCode())
        fun action(code: Int, name: String): PendingIntent = PendingIntent.getBroadcast(context,
            (id.hashCode() xor code), Intent(context, ReminderReceiver::class.java).setAction(name).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(context, NotificationCenter.reminderChannel(context))
            .setSmallIcon(R.drawable.dayflow_icon).setContentTitle("DAYFLOW")
            .setContentText(if (state.notificationPreview) reminder.title else "لديك تذكير")
            .setContentIntent(open).setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "تم", action(0x100000, COMPLETE))
            .addAction(android.R.drawable.ic_lock_idle_alarm, "غفوة", action(0x200000, SNOOZE))
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id.hashCode(), notification)
        if (reminder.days.isNotEmpty()) ReminderScheduler.schedule(context, reminder)
    }
    companion object {
        const val COMPLETE = "app.dayflow.REMINDER_COMPLETE"
        const val SNOOZE = "app.dayflow.REMINDER_SNOOZE"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
                Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED,
                "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED")) {
            AlarmScheduler.restore(context)
        }
    }
}