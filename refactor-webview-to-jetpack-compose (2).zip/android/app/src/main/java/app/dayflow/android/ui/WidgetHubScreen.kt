package app.dayflow.android.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.data.AppData
import app.dayflow.android.data.Catalog
import app.dayflow.android.data.WidgetDesign
import app.dayflow.android.widgets.WidgetArtwork
import app.dayflow.android.widgets.WidgetGateway

@Composable
fun WidgetHubScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val all = remember { Catalog.widgets(activity) }
    val widgetId = activity.widgetToConfigure()
    val configuring = widgetId != AppWidgetManager.INVALID_APPWIDGET_ID
    val fixedForm = if (configuring) WidgetGateway.formFor(activity, widgetId) else null
    var mode by remember { mutableStateOf("catalog") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("all") }
    var form by remember(fixedForm) { mutableStateOf(fixedForm ?: "any") }
    var style by remember { mutableStateOf("oneui") }
    var selected by remember { mutableStateOf<WidgetDesign?>(null) }
    val list = remember(search, category, form, all) {
        all.filter { (category == "all" || it.category == category) &&
            (form == "any" || form in it.forms) &&
            (search.isBlank() || (it.en + it.ar).contains(search, ignoreCase = true)) }
    }
    val manager = AppWidgetManager.getInstance(activity)
    val actualWidgetIds = remember(mode, data) { WidgetGateway.gateways.flatMap { cls ->
        manager.getAppWidgetIds(ComponentName(activity, cls)).toList()
    } }
    Column {
        DFHeader(label("Widgets", "الودجات"),
            label("${all.size} designs · resize for each shape", "${all.size} تصميمًا · يتغير الشكل مع الحجم"),
            onBack = { if (configuring) activity.finish() else activity.go("me") })
        if (configuring) DFCard(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
            Text("اختر تصميمًا لودجت $fixedForm لإضافته إلى شاشة هاتفك الرئيسية.",
                modifier = Modifier.padding(13.dp), color = theme.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            DFChip(label("Catalog", "الكتالوج"), mode == "catalog") { mode = "catalog" }
            if (!configuring) DFChip(label("On home screen", "على الشاشة (${actualWidgetIds.size})"), mode == "board") { mode = "board" }
        }
        if (mode == "catalog") {
            Spacer(Modifier.height(8.dp))
            DFField(search, { search = it }, label("Search widgets", "ابحث في الودجات"), Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DFChip(label("All", "الكل"), category == "all") { category = "all" }
                Catalog.widgetCategories.forEachIndexed { i, cat ->
                    DFChip(if (data.lang == "ar") Catalog.widgetCategoryNames[i] else cat,
                        category == cat) { category = cat }
                }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (!configuring) DFChip(label("Any size", "أي حجم"), form == "any") { form = "any" }
                Catalog.forms.filter { !configuring || it == fixedForm }.forEach { f ->
                    DFChip(f.replace('x', '×'), form == f) { form = f }
                }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Catalog.widgetStyles.forEachIndexed { i, st -> DFChip(
                    if (data.lang == "ar") Catalog.widgetStyleNames[i] else st,
                    style == st) { style = st }
                }
            }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 120.dp)) {
            if (mode == "catalog") {
                Catalog.widgetCategories.forEachIndexed { i, cat ->
                    val itemsInCategory = list.filter { it.category == cat }
                    if (itemsInCategory.isNotEmpty()) {
                        item {
                            Text(if (data.lang == "ar") Catalog.widgetCategoryNames[i] else cat,
                                color = theme.text, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 19.dp, bottom = 8.dp))
                        }
                        item {
                            LazyRow(Modifier.fillMaxWidth().background(Brush.linearGradient(
                                listOf(androidx.compose.ui.graphics.Color(0xff5479a2),
                                    androidx.compose.ui.graphics.Color(0xffa16e73),
                                    androidx.compose.ui.graphics.Color(0xff304e64))))
                                .padding(vertical = 14.dp), contentPadding = PaddingValues(horizontal = 14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(itemsInCategory.size) { index ->
                                    val w = itemsInCategory[index]
                                    val image = remember(w.id, style, form, data.tasks.size, data.alarms.size, data.water) {
                                        WidgetArtwork.draw(activity, 126, 120, w to style).asImageBitmap()
                                    }
                                    Column(Modifier.width(126.dp).clickable { selected = w }) {
                                        Image(image, null, Modifier.size(126.dp, 120.dp).clip(RoundedCornerShape(22.dp)))
                                        Text(if (data.lang == "ar") w.ar else w.en,
                                            color = androidx.compose.ui.graphics.Color.White,
                                            fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.padding(top = 6.dp))
                                        Text("${w.forms.size} ${label("forms", "أشكال")}",
                                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = .7f), fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (actualWidgetIds.isEmpty()) item {
                    DFEmpty(label("No widgets yet", "لا توجد ودجات على الهاتف"),
                        label("Add a DAYFLOW gateway from your home screen.", "أضف ودجت DAYFLOW من شاشة هاتفك الرئيسية."))
                }
                actualWidgetIds.forEach { id ->
                    val config = WidgetGateway.configuration(activity, id)
                    if (config != null) item {
                        DFCard(Modifier.fillMaxWidth().padding(top = 9.dp), onClick = { selected = config.first }) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Image(remember(id, data) { WidgetArtwork.draw(activity, 94, 84, config).asImageBitmap() },
                                    null, Modifier.size(94.dp, 84.dp))
                                Column {
                                    Text(if (data.lang == "ar") config.first.ar else config.first.en,
                                        color = theme.text, fontWeight = FontWeight.Bold)
                                    Text("${WidgetGateway.formFor(activity, id)} · ${config.second}", color = theme.muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    selected?.let { def ->
        WidgetDetail(def, data, activity, fixedForm, style, onClose = { selected = null })
    }
}

@Composable
private fun WidgetDetail(def: WidgetDesign, data: AppData, activity: MainActivity,
                         fixedForm: String?, initialStyle: String, onClose: () -> Unit) {
    val theme = LocalPack.current
    var form by remember(def.id, fixedForm) { mutableStateOf(fixedForm ?: if ("2x2" in def.forms) "2x2" else def.forms.first()) }
    var style by remember(def.id) { mutableStateOf(initialStyle) }
    val image = remember(def.id, form, style, data) { WidgetArtwork.draw(activity, 280, 220, def to style).asImageBitmap() }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = theme.surface) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(if (data.lang == "ar") def.ar else def.en, color = theme.text,
                fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Box(Modifier.fillMaxWidth().height(270.dp).background(theme.soft, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center) { Image(image, null, Modifier.size(280.dp, 220.dp)) }
            Text(label("Form (resize)", "الشكل (تغيير الحجم)"), color = theme.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                def.forms.filter { fixedForm == null || fixedForm == it }.forEach { f ->
                    DFChip(f.replace('x', '×'), form == f) { form = f }
                }
            }
            Text(label("Style", "النمط"), color = theme.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Catalog.widgetStyles.forEachIndexed { i, st ->
                    DFChip(if (data.lang == "ar") Catalog.widgetStyleNames[i] else st, style == st) { style = st }
                }
            }
            DFButton(if (fixedForm == null) label("Add to home screen", "أضف للشاشة الرئيسية")
                else label("Use this widget", "استخدم هذا الودجت"), {
                if (fixedForm != null) {
                    if (!activity.selectWidget(def, style)) activity.notifyUser("تعذر إكمال إعداد الودجت")
                } else {
                    if (!WidgetGateway.requestPin(activity, form))
                        activity.notifyUser("مشغل الشاشة لا يدعم طلب تثبيت الودجت؛ أضفه من قائمة ودجات الهاتف")
                    onClose()
                }
            }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(17.dp))
        }
    }
}