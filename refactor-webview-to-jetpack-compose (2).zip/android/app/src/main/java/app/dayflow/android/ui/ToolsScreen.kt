package app.dayflow.android.ui

import android.app.DownloadManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.alarm.ReminderScheduler
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.CountdownEntry
import app.dayflow.android.data.HabitEntry
import app.dayflow.android.data.JournalEntry
import app.dayflow.android.data.MedEntry
import app.dayflow.android.data.NoteEntry
import app.dayflow.android.data.ReminderEntry
import app.dayflow.android.data.TaskEntry
import app.dayflow.android.data.WorkoutEntry
import app.dayflow.android.data.displayTime
import app.dayflow.android.data.today
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit
import java.util.Locale

private val tools = listOf(
    Triple("tasks", "Tasks", "المهام"), Triple("habits", "Habits", "العادات"),
    Triple("focus", "Focus", "التركيز"), Triple("study", "Study", "الدراسة"),
    Triple("workout", "Workout", "التمارين"), Triple("water", "Water", "الماء"),
    Triple("notes", "Notes", "الملاحظات"), Triple("media", "Media Hub", "مركز الوسائط"),
    Triple("countdowns", "Countdowns", "العد التنازلي"), Triple("convert", "Converters", "المحولات"),
    Triple("tasbih", "Tasbih & Khatma", "التسبيح والختمة"), Triple("datecalc", "Date calculator", "حاسبة التاريخ"),
    Triple("journal", "Journal & mood", "اليوميات والمزاج"), Triple("meds", "Medication", "الأدوية"),
    Triple("bedside", "Bedside clock", "ساعة السرير"), Triple("qr", "QR generator", "صانع QR"),
    Triple("imgtools", "Image converter", "محول وضغط الصور"), Triple("breath", "Breathing", "تمارين التنفس"),
    Triple("texttools", "Text & counter", "عدّاد النصوص"), Triple("stopwatch", "Stopwatch", "ساعة إيقاف")
)

@Composable
fun ToolsScreen(sub: String, data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    var query by remember { mutableStateOf("") }
    if (sub.isBlank()) {
        LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(bottom = 110.dp),
            horizontalArrangement = Arrangement.spacedBy(11.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(3) }) {
                Column {
                    DFHeader(label("Tools", "الأدوات"))
                    DFField(query, { query = it }, label("Search tools", "ابحث في الأدوات"), Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                }
            }
            items(tools.filter { query.isBlank() || (it.second + it.third).contains(query, true) }) { (id, en, ar) ->
                DFCard(Modifier.fillMaxWidth().height(110.dp), onClick = { activity.go("tools/$id") }) {
                    Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center) {
                        Box(Modifier.size(43.dp).background(theme.soft, RoundedCornerShape(15.dp)),
                            contentAlignment = Alignment.Center) {
                            Text(when (id) {
                                "tasks", "notes", "journal" -> "✎"
                                "habits", "water", "workout" -> "◌"
                                "media", "qr" -> "⌁"
                                "focus", "study", "bedside", "stopwatch" -> "◷"
                                else -> "✦"
                            }, color = theme.accent, fontSize = 24.sp)
                        }
                        Text(if (data.lang == "ar") ar else en, color = theme.text, fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, lineHeight = 15.sp,
                            modifier = Modifier.padding(top = 7.dp), maxLines = 2)
                    }
                }
            }
        }
    } else {
        if (sub == "bedside") { BedsideScreen(data, activity); return }
        if (sub == "media") { DownloadsScreen(activity, ""); return }
        if (sub == "habits") { HabitsTool(data, activity); return }
        Column {
            DFHeader(tools.firstOrNull { it.first == sub }?.let { if (data.lang == "ar") it.third else it.second } ?: sub,
                onBack = { activity.go("tools") })
            when (sub) {
                "tasks" -> TasksTool(data, activity)
                "focus", "study" -> FocusTool(sub == "study", activity)
                "workout" -> WorkoutTool(data, activity)
                "water" -> WaterTool(data, activity)
                "notes" -> NotesTool(data, activity)
                "countdowns" -> CountdownTool(data, activity)
                "convert" -> ConvertTool()
                "tasbih" -> TasbihTool(data, activity)
                "datecalc" -> DateCalcTool(activity)
                "journal" -> JournalTool(data, activity)
                "meds" -> MedicationTool(data, activity)
                "qr" -> QrTool()
                "imgtools" -> ImageTool(activity)
                "breath" -> BreathTool()
                "texttools" -> TextTool()
                "stopwatch" -> StopwatchTool()
            }
        }
    }
}

@Composable
private fun TasksTool(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var text by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }
    var due by remember { mutableStateOf("") }
    var urgent by remember { mutableStateOf(false) }
    var important by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf("list") }
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("list" to label("List", "قائمة"), "matrix" to label("Matrix", "المصفوفة"),
                    "kanban" to "Kanban").forEach { (id, title) -> DFChip(title, mode == id) { mode = id } }
            }
        }
        item {
            DFField(text, { text = it }, label("New task", "مهمة جديدة"), Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                DFButton(date, { activity.showDate(date) { date = it } }, Modifier.weight(1f), soft = true)
                DFButton(if (due.isBlank()) label("Time (optional)", "ساعة (اختياري)") else displayTime(due, data.lang),
                    { activity.showTime(due.ifBlank { "18:00" }) { due = it } }, Modifier.weight(1f), soft = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                DFChip(label("Urgent", "عاجل"), urgent) { urgent = !urgent }
                DFChip(label("Important", "مهم"), important) { important = !important }
            }
            DFButton(label("Add", "إضافة"), {
                val task = TaskEntry(title = text.trim(), date = date, dueTime = due, urgent = urgent, important = important)
                repo.update { s -> s.copy(tasks = listOf(task) + s.tasks) }
                if (due.isNotBlank() && !ReminderScheduler.schedule(activity, ReminderEntry(task.id, task.title, task.date, task.dueTime)))
                    activity.notifyUser("لم يُجدول التذكير: وقت المهمة قد مر")
                else if (due.isNotBlank()) activity.requestNotifications()
                text = ""
            }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
        }
        if (mode == "matrix") {
            listOf(true to true to "نفّذ الآن", false to true to "جدول", true to false to "فوّض", false to false to "احذف")
                .forEach { (flags, title) -> item {
                    DFCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                        Text(title, color = theme.accent, fontWeight = FontWeight.Bold)
                        data.tasks.filter { it.urgent == flags.first && it.important == flags.second && !it.done }.forEach { task ->
                            Text("○ ${task.title}", color = theme.text, fontSize = 14.sp,
                                modifier = Modifier.fillMaxWidth().clickable { toggleTask(activity, task) }.padding(7.dp))
                        }
                    } }
                } }
        } else if (mode == "kanban") {
            listOf("todo", "doing", "done").forEach { stage -> item {
                DFCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                    Text(stage.uppercase(), color = theme.accent, fontWeight = FontWeight.Bold)
                    data.tasks.filter { it.status == stage }.forEach { task -> DFRow(task.title, onClick = {
                        repo.update { s -> s.copy(tasks = s.tasks.map { if (it.id == task.id)
                            it.copy(status = if (stage == "todo") "doing" else if (stage == "doing") "done" else "todo",
                                done = stage == "doing") else it }) }
                    }) }
                } }
            } }
        } else {
            if (data.tasks.isEmpty()) item { DFEmpty(label("No tasks", "لا مهام"), label("Add a task above.", "ضيف مهمة فوق.")) }
            items(data.tasks.size) { index ->
                val task = data.tasks[index]
                DFCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        Text(if (task.done) "☑" else "□", color = theme.accent, fontSize = 23.sp,
                            modifier = Modifier.clickable { toggleTask(activity, task) })
                        Column(Modifier.weight(1f)) {
                            Text(task.title, color = if (task.done) theme.muted else theme.text, fontSize = 15.sp)
                            Text(task.date + if (task.dueTime.isNotBlank()) " · ${displayTime(task.dueTime, data.lang)}" else "",
                                color = theme.muted, fontSize = 11.sp)
                        }
                        Text("×", color = theme.muted, fontSize = 22.sp, modifier = Modifier.clickable {
                            ReminderScheduler.cancel(activity, task.id)
                            repo.update { it.copy(tasks = it.tasks.filterNot { t -> t.id == task.id }) }
                        })
                    }
                }
            }
        }
    }
}

private fun toggleTask(activity: MainActivity, task: TaskEntry) {
    val repo = AppRepository.get(activity)
    val done = !task.done
    repo.update { s -> s.copy(tasks = s.tasks.map { if (it.id == task.id)
        it.copy(done = done, status = if (done) "done" else "todo") else it }) }
    if (done) ReminderScheduler.cancel(activity, task.id)
    else if (task.dueTime.isNotBlank()) ReminderScheduler.schedule(activity,
        ReminderEntry(task.id, task.title, task.date, task.dueTime))
}

@Composable
private fun HabitsTool(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var selected by remember { mutableStateOf<HabitEntry?>(null) }
    var editor by remember { mutableStateOf(false) }
    Column {
        DFHeader(label("Habits", "العادات"), label("Name, days, type, target - all yours", "الاسم والأيام والنوع والهدف - كل حاجة بإيدك"),
            onBack = { activity.go("tools") }, action = {
                DFButton(label("New", "جديدة"), { selected = null; editor = true })
            })
        LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            if (data.habits.isEmpty()) item { DFEmpty(label("Start one small habit", "ابدأ بعادة صغيرة"),
                label("20 minutes, 3 days a week - that's enough.", "٢٠ دقيقة، ٣ أيام في الأسبوع - كفاية.")) }
            items(data.habits.size) { index ->
                val habit = data.habits[index]
                val completed = today() in habit.log
                DFCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(if (completed) "●" else "○", color = theme.accent, fontSize = 34.sp,
                                modifier = Modifier.clickable { repo.update { s -> s.copy(habits = s.habits.map {
                                    if (it.id == habit.id) it.copy(log = if (completed) it.log - today() else it.log + today()) else it
                                }) } })
                            Column(Modifier.weight(1f)) {
                                Text(habit.title, color = theme.text, fontWeight = FontWeight.SemiBold)
                                Text(habit.days.sorted().joinToString(" ") { listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")[it] } +
                                    if (habit.reminder.isNotBlank()) " · ${displayTime(habit.reminder, data.lang)}" else "",
                                    color = theme.muted, fontSize = 11.sp)
                            }
                            Text("✎", color = theme.accent, modifier = Modifier.clickable { selected = habit; editor = true })
                            Text("×", color = theme.muted, modifier = Modifier.clickable {
                                ReminderScheduler.cancel(activity, habit.id)
                                repo.update { it.copy(habits = it.habits.filterNot { h -> h.id == habit.id }) }
                            })
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            repeat(14) { d ->
                                val day = LocalDate.now().minusDays((13 - d).toLong()).toString()
                                Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(3.dp))
                                    .background(if (day in habit.log) theme.accent else theme.soft)
                                    .clickable { repo.update { s -> s.copy(habits = s.habits.map {
                                        if (it.id == habit.id) it.copy(log = if (day in it.log) it.log - day else it.log + day) else it
                                    }) } })
                            }
                        }
                    }
                }
            }
        }
    }
    if (editor) HabitEditor(selected, activity, onClose = { editor = false })
}

@Composable
private fun HabitEditor(initial: HabitEntry?, activity: MainActivity, onClose: () -> Unit) {
    val theme = LocalPack.current
    var habit by remember(initial?.id) { mutableStateOf(initial ?: HabitEntry(title = "")) }
    var error by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onClose, containerColor = theme.surface) {
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { DFHeader(if (initial == null) label("New habit", "عادة جديدة") else label("Edit habit", "تعديل العادة")) }
            item { DFField(habit.title, { habit = habit.copy(title = it) }, label("Habit name", "اسم العادة"), Modifier.fillMaxWidth()) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("build" to "بناء", "quit" to "إقلاع", "count" to "عدد", "timer" to "مدة")
                        .forEach { (kind, title) -> DFChip(title, kind == habit.type) { habit = habit.copy(type = kind) } }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (0..6).forEach { d -> DFChip(listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")[d], d in habit.days) {
                        habit = habit.copy(days = if (d in habit.days) habit.days - d else habit.days + d)
                    } }
                }
            }
            if (habit.type in setOf("count", "timer")) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DFField(habit.target.toString(), { habit = habit.copy(target = it.toIntOrNull() ?: 1) }, "الهدف", Modifier.weight(1f))
                    DFField(habit.unit, { habit = habit.copy(unit = it) }, "الوحدة", Modifier.weight(1f))
                }
            }
            item {
                DFButton(if (habit.reminder.isBlank()) label("Reminder (optional)", "تذكير (اختياري)")
                    else displayTime(habit.reminder), { activity.showTime(habit.reminder.ifBlank { "09:00" }) {
                        habit = habit.copy(reminder = it)
                    } }, Modifier.fillMaxWidth(), soft = true)
            }
            item { DFField(habit.details, { habit = habit.copy(details = it) }, "التفاصيل (اختياري)", Modifier.fillMaxWidth(), singleLine = false) }
            item { if (error.isNotBlank()) Text(error, color = Color(0xffbf4545), fontSize = 12.sp) }
            item { DFButton(label("Save", "حفظ"), {
                if (habit.title.isBlank() || habit.days.isEmpty()) { error = "أدخل الاسم واختر يومًا على الأقل"; return@DFButton }
                val repo = AppRepository.get(activity)
                repo.update { it.copy(habits = if (initial != null) it.habits.map { h -> if (h.id == habit.id) habit else h }
                    else it.habits + habit) }
                if (habit.reminder.isNotBlank()) {
                    ReminderScheduler.schedule(activity, ReminderEntry(habit.id, habit.title,
                        habit.startDate ?: today(), habit.reminder, days = habit.days))
                    activity.requestNotifications()
                } else ReminderScheduler.cancel(activity, habit.id)
                onClose()
            }, Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
private fun FocusTool(study: Boolean, activity: MainActivity) {
    val theme = LocalPack.current
    var duration by remember { mutableIntStateOf(25) }
    var remaining by remember { mutableLongStateOf(25 * 60L) }
    var running by remember { mutableStateOf(false) }
    var end by remember { mutableLongStateOf(0L) }
    var subject by remember { mutableStateOf("") }
    LaunchedEffect(running) {
        while (running) {
            remaining = ((end - SystemClock.elapsedRealtime()) / 1000L).coerceAtLeast(0)
            if (remaining <= 0) { running = false; activity.notifyUser("اكتملت جلسة التركيز"); break }
            delay(1000)
        }
    }
    Column(Modifier.fillMaxWidth().padding(top = 20.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(17.dp)) {
        if (study) DFField(subject, { subject = it }, "المادة (مثل الفيزياء)", Modifier.fillMaxWidth())
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            ProgressRing(1f - remaining.toFloat() / (duration * 60), Modifier.fillMaxSize())
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(remaining / 60).toString().padStart(2, '0')}:${(remaining % 60).toString().padStart(2, '0')}",
                    color = theme.text, fontSize = 46.sp, fontWeight = FontWeight.Light)
                Text(if (study) subject.ifBlank { "دراسة" } else "تركيز", color = theme.muted)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(15, 25, 45, 60).forEach { min -> DFChip("$min′", duration == min) {
                duration = min; remaining = min * 60L; running = false
            } }
        }
        DFButton(if (running) "إيقاف" else "ابدأ", {
            if (running) running = false else { end = SystemClock.elapsedRealtime() + remaining * 1000; running = true }
        })
        DFButton("إعادة ضبط", { running = false; remaining = duration * 60L }, soft = true)
    }
}

@Composable
private fun WaterTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    val water = data.water[today()] ?: 0
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
            ProgressRing(water.toFloat() / data.waterGoal, Modifier.fillMaxSize())
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${water / 1000f}", fontWeight = FontWeight.Bold, fontSize = 37.sp, color = theme.text)
                Text("/ ${data.waterGoal / 1000f} L", color = theme.muted)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(150, 250, 500).forEach { amount -> DFButton("+$amount ml", {
                repo.update { it.copy(water = it.water + (today() to (water + amount))) }
            }, soft = true) }
        }
        DFButton("تراجع 250 ml", { repo.update { it.copy(water = it.water + (today() to (water - 250).coerceAtLeast(0))) } }, soft = true)
        DFButton("الهدف اليومي: ${data.waterGoal} ml", {
            repo.update { it.copy(waterGoal = if (it.waterGoal >= 4000) 1500 else it.waterGoal + 250) }
        }, soft = true)
    }
}

@Composable
private fun NotesTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var text by remember { mutableStateOf("") }
    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            DFField(text, { text = it }, label("Write a note...", "اكتب ملاحظة..."), Modifier.fillMaxWidth(), singleLine = false)
            DFButton(label("Save note", "حفظ"), {
                repo.update { it.copy(notes = listOf(NoteEntry(text = text.trim())) + it.notes) }; text = ""
            }, Modifier.fillMaxWidth(), enabled = text.isNotBlank())
        }
        items(data.notes.size) { index ->
            val note = data.notes.sortedByDescending { it.pinned }[index]
            DFCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(note.text, color = theme.text)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        DFChip(if (note.pinned) "ثُبتت" else "تثبيت") {
                            repo.update { s -> s.copy(notes = s.notes.map { if (it.id == note.id) it.copy(pinned = !it.pinned) else it }) }
                        }
                        DFChip("حذف") { repo.update { it.copy(notes = it.notes.filterNot { n -> n.id == note.id }) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun CountdownTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var name by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().plusDays(30).toString()) }
    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            DFField(name, { name = it }, "الحدث", Modifier.fillMaxWidth())
            DFButton(date, { activity.showDate(date) { date = it } }, Modifier.fillMaxWidth(), soft = true)
            DFButton("إضافة", {
                repo.update { it.copy(countdowns = it.countdowns + CountdownEntry(title = name.trim(), date = date)) }
                name = ""
            }, Modifier.fillMaxWidth(), enabled = name.isNotBlank())
        }
        items(data.countdowns.size) { index ->
            val event = data.countdowns[index]
            DFCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(event.date)).toString(),
                        color = theme.accent, fontWeight = FontWeight.Bold, fontSize = 30.sp)
                    Column(Modifier.weight(1f)) {
                        Text(event.title, color = theme.text)
                        Text(event.date, color = theme.muted, fontSize = 12.sp)
                    }
                    Text("×", color = theme.muted, modifier = Modifier.clickable {
                        repo.update { it.copy(countdowns = it.countdowns.filterNot { c -> c.id == event.id }) }
                    })
                }
            }
        }
    }
}

@Composable
private fun WorkoutTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var title by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("20") }
    val done = data.workouts.filter { it.date == today() }.sumOf { it.minutes }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        DFCard(Modifier.fillMaxWidth()) { Text("اليوم: $done / 30 دقيقة", color = theme.text,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(17.dp)) }
        DFField(title, { title = it }, "النشاط (مشي، جيم...)", Modifier.fillMaxWidth())
        DFField(minutes, { minutes = it }, "الدقائق", Modifier.fillMaxWidth())
        DFButton("إضافة", {
            repo.update { it.copy(workouts = it.workouts + WorkoutEntry(title = title.trim(), minutes = minutes.toIntOrNull() ?: 0)) }
            title = ""
        }, enabled = title.isNotBlank() && (minutes.toIntOrNull() ?: 0) > 0)
        data.workouts.filter { it.date == today() }.forEach { entry -> DFRow(entry.title, "${entry.minutes} دقيقة", trailing = {
            Text("×", color = theme.muted, modifier = Modifier.clickable {
                repo.update { it.copy(workouts = it.workouts.filterNot { w -> w.id == entry.id }) }
            })
        }) }
    }
}

@Composable
private fun TasbihTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var target by remember { mutableIntStateOf(33) }
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(220.dp).background(theme.surface, CircleShape).clickable {
            repo.update { it.copy(tasbih = it.tasbih + 1) }
        }, contentAlignment = Alignment.Center) {
            ProgressRing((data.tasbih % target).toFloat() / target, Modifier.fillMaxSize())
            Text(data.tasbih.toString(), color = theme.text, fontSize = 56.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(33, 99, 100).forEach { number -> DFChip(number.toString(), target == number) { target = number } }
            DFChip("إعادة") { repo.update { it.copy(tasbih = 0) } }
        }
        DFCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(13.dp)) {
                Text("متتبع الختمة  ${data.khatma} / 30", color = theme.text, fontWeight = FontWeight.Bold)
                (0 until 3).forEach { row -> Row {
                    (1..10).forEach { col ->
                        val part = row * 10 + col
                        Text(part.toString(), modifier = Modifier.weight(1f).clickable {
                            repo.update { it.copy(khatma = if (it.khatma == part) part - 1 else part) }
                        }.padding(vertical = 9.dp), color = if (part <= data.khatma) theme.accent else theme.muted,
                            fontSize = 12.sp)
                    }
                } }
            }
        }
    }
}

@Composable
private fun JournalTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var text by remember { mutableStateOf("") }
    var mood by remember { mutableIntStateOf(3) }
    LazyColumn(contentPadding = PaddingValues(bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            DFCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("كيف حالك اليوم؟", color = theme.text, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (1..5).forEach { n ->
                    DFChip(n.toString(), mood == n) { mood = n }
                } }
                DFField(text, { text = it }, "بضع كلمات (خاصة على هذا الجهاز)", Modifier.fillMaxWidth(), singleLine = false)
                DFButton("حفظ", { repo.update { it.copy(journal = listOf(JournalEntry(mood = mood, text = text)) + it.journal) }; text = "" },
                    Modifier.fillMaxWidth(), enabled = text.isNotBlank())
            } }
        }
        items(data.journal.size) { i -> val entry = data.journal[i]
            DFCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("${entry.date} · ${entry.mood}/5", color = theme.muted, fontSize = 12.sp)
                Text(entry.text, color = theme.text)
            } }
        }
    }
}

@Composable
private fun MedicationTool(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    val theme = LocalPack.current
    var name by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("09:00") }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        DFField(name, { name = it }, "دواء أو مكمل", Modifier.fillMaxWidth())
        DFButton(displayTime(time, data.lang), { activity.showTime(time) { time = it } }, Modifier.fillMaxWidth(), soft = true)
        DFButton("إضافة", {
            val med = MedEntry(name = name.trim(), time = time)
            repo.update { it.copy(meds = it.meds + med) }
            ReminderScheduler.schedule(activity, ReminderEntry(med.id, med.name, today(), med.time, days = (0..6).toSet()))
            activity.requestNotifications()
            name = ""
        }, Modifier.fillMaxWidth(), enabled = name.isNotBlank())
        data.meds.forEach { med -> DFCard(Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(med.name, color = theme.text, fontWeight = FontWeight.SemiBold)
                    Text(displayTime(med.time, data.lang), color = theme.muted, fontSize = 12.sp)
                }
                DFChip(if (today() in med.taken) "أُخذ" else "تم") {
                    repo.update { s -> s.copy(meds = s.meds.map { if (it.id == med.id)
                        it.copy(taken = if (today() in it.taken) it.taken - today() else it.taken + today()) else it }) }
                }
                Text("×", color = theme.muted, modifier = Modifier.clickable {
                    ReminderScheduler.cancel(activity, med.id)
                    repo.update { it.copy(meds = it.meds.filterNot { m -> m.id == med.id }) }
                })
            }
        } }
        Text("تذكيرات معلوماتية فقط وليست نصيحة طبية.", color = theme.muted, fontSize = 12.sp)
    }
}

@Composable
private fun ConvertTool() {
    val theme = LocalPack.current
    val units = mapOf("length" to mapOf("m" to 1.0, "km" to 1000.0, "cm" to .01, "mi" to 1609.344),
        "weight" to mapOf("kg" to 1.0, "g" to .001, "lb" to .45359237),
        "volume" to mapOf("L" to 1.0, "ml" to .001, "gal" to 3.78541))
    var kind by remember { mutableStateOf("length") }
    var value by remember { mutableStateOf("1") }
    var from by remember { mutableStateOf("km") }
    var to by remember { mutableStateOf("m") }
    var temp by remember { mutableStateOf("25") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            units.keys.forEach { key -> DFChip(key, key == kind) {
                kind = key; from = units[key]!!.keys.first(); to = units[key]!!.keys.last()
            } }
        }
        DFCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            DFField(value, { value = it }, "القيمة", Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                units[kind]!!.keys.forEach { key -> DFChip(key, key == from) { from = key } }
            }
            Text("= ${"%.4f".format(Locale.US, (value.toDoubleOrNull() ?: 0.0) *
                (units[kind]?.get(from) ?: 1.0) / (units[kind]?.get(to) ?: 1.0))} $to",
                color = theme.accent, fontSize = 24.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                units[kind]!!.keys.forEach { key -> DFChip(key, key == to) { to = key } }
            }
        } }
        DFField(temp, { temp = it }, "درجة الحرارة °C", Modifier.fillMaxWidth())
        Text("${(temp.toDoubleOrNull() ?: 0.0) * 9 / 5 + 32} °F", color = theme.text)
    }
}

@Composable
private fun DateCalcTool(activity: MainActivity) {
    val theme = LocalPack.current
    var start by remember { mutableStateOf(today()) }
    var end by remember { mutableStateOf(LocalDate.now().plusDays(30).toString()) }
    var offset by remember { mutableStateOf("40") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        DFButton(start, { activity.showDate(start) { start = it } }, Modifier.fillMaxWidth(), soft = true)
        DFButton(end, { activity.showDate(end) { end = it } }, Modifier.fillMaxWidth(), soft = true)
        Text("${ChronoUnit.DAYS.between(LocalDate.parse(start), LocalDate.parse(end))} يوم", color = theme.accent, fontSize = 29.sp)
        DFField(offset, { offset = it }, "إضافة أيام", Modifier.fillMaxWidth())
        Text(LocalDate.parse(start).plusDays(offset.toLongOrNull() ?: 0).toString(), color = theme.text)
        Text(calendarCaption(LocalDate.parse(start)), color = theme.muted)
    }
}

@Composable
private fun BedsideScreen(data: AppData, activity: MainActivity) {
    var clock by remember { mutableStateOf(LocalTime.now()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); clock = LocalTime.now() } }
    BackHandler { activity.go("tools") }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { activity.go("tools") }, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("✦", color = Color.White.copy(alpha = .5f), fontSize = 36.sp)
            Text(displayTime(clock.toString(), data.lang), color = Color.White.copy(alpha = .8f),
                fontSize = 66.sp, fontWeight = FontWeight.ExtraLight)
            Text(LocalDate.now().toString(), color = Color.White.copy(alpha = .6f))
        }
    }
}

@Composable
private fun QrTool() {
    val theme = LocalPack.current
    var value by remember { mutableStateOf("") }
    val bitmap = remember(value) { runCatching {
        if (value.isBlank()) null else QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 512, 512).let { matrix ->
            Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888).apply {
                for (x in 0 until 512) for (y in 0 until 512) setPixel(x, y,
                    if (matrix.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
    }.getOrNull() }
    Column(verticalArrangement = Arrangement.spacedBy(11.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        DFField(value, { value = it }, "رابط أو نص", Modifier.fillMaxWidth(), singleLine = false)
        if (bitmap != null) Image(bitmap.asImageBitmap(), "QR code", Modifier.size(260.dp))
        else Text("أدخل محتوى صالحًا لإنشاء QR", color = theme.muted)
    }
}

@Composable
private fun ImageTool(activity: MainActivity) {
    val theme = LocalPack.current
    var source by remember { mutableStateOf<android.net.Uri?>(null) }
    var format by remember { mutableStateOf("WebP") }
    var quality by remember { mutableStateOf(.85f) }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { source = it }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(
        if (format == "PNG") "image/png" else if (format == "JPG") "image/jpeg" else "image/webp")) { target ->
        if (target != null && source != null) runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            activity.contentResolver.openInputStream(source!!)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val sample = (bounds.outWidth / 1600).coerceAtLeast(1)
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = activity.contentResolver.openInputStream(source!!)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: error("Unable to read image")
            activity.contentResolver.openOutputStream(target)?.use { stream ->
                val type = when (format) {
                    "PNG" -> Bitmap.CompressFormat.PNG
                    "JPG" -> Bitmap.CompressFormat.JPEG
                    else -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY
                        else @Suppress("DEPRECATION") Bitmap.CompressFormat.WEBP
                }
                check(bitmap.compress(type, (quality * 100).toInt(), stream))
            }
            bitmap.recycle()
            activity.notifyUser("تم حفظ الصورة المحولة")
        }.onFailure { activity.notifyUser("تعذر تحويل الصورة: ${it.message}") }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DFButton("اختر صورة", { open.launch(arrayOf("image/*")) }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("WebP", "JPG", "PNG").forEach { type -> DFChip(type, format == type) { format = type } }
        }
        Text("الجودة: ${(quality * 100).toInt()}%", color = theme.text)
        Slider(value = quality, onValueChange = { quality = it }, valueRange = .2f..1f)
        DFButton("حفظ الصورة المحولة", { if (source != null) save.launch("dayflow.${format.lowercase()}") },
            Modifier.fillMaxWidth(), enabled = source != null)
    }
}

@Composable
private fun BreathTool() {
    val theme = LocalPack.current
    var mode by remember { mutableStateOf("478") }
    var running by remember { mutableStateOf(false) }
    var second by remember { mutableIntStateOf(0) }
    val sequence = if (mode == "478") listOf("شهيق" to 4, "احبس النفس" to 7, "زفير" to 8)
        else listOf("شهيق" to 4, "احبس" to 4, "زفير" to 4, "احبس" to 4)
    LaunchedEffect(running, mode) { while (running) { delay(1000); second = (second + 1) % sequence.sumOf { it.second } } }
    val elapsed = second
    var total = 0
    val current = sequence.firstOrNull { total += it.second; elapsed < total } ?: sequence.first()
    Column(Modifier.fillMaxWidth().padding(top = 30.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DFChip("4-7-8", mode == "478") { mode = "478"; second = 0 }
            DFChip("مربع 4×4", mode == "box") { mode = "box"; second = 0 }
        }
        Box(Modifier.size(210.dp).background(theme.soft, CircleShape), contentAlignment = Alignment.Center) {
            Text("${current.first}\n${total - elapsed}", color = theme.text, fontSize = 24.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
        DFButton(if (running) "إيقاف" else "ابدأ", { running = !running })
    }
}

@Composable
private fun TextTool() {
    val theme = LocalPack.current
    var text by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        DFField(text, { text = it }, "الصق أو اكتب نص هنا...", Modifier.fillMaxWidth(), singleLine = false)
        val words = if (text.isBlank()) 0 else text.trim().split(Regex("\\s+")).size
        Text("كلمات $words   ·   حروف ${text.length}   ·   سطور ${if (text.isEmpty()) 0 else text.lines().size}", color = theme.accent)
        DFButton("إزالة التشكيل", { text = text.replace(Regex("[\\u064B-\\u065F\\u0670]"), "") }, soft = true)
        DFButton("تنظيف المسافات", { text = text.replace(Regex("[ \\t]+"), " ").trim() }, soft = true)
        DFButton("مسح", { text = "" }, soft = true)
    }
}

@Composable
private fun StopwatchTool() {
    val theme = LocalPack.current
    var running by remember { mutableStateOf(false) }
    var elapsed by remember { mutableLongStateOf(0L) }
    var end by remember { mutableLongStateOf(0L) }
    var laps by remember { mutableStateOf<List<Long>>(emptyList()) }
    LaunchedEffect(running) { while (running) { elapsed = SystemClock.elapsedRealtime() - end; delay(50) } }
    fun fmt(millis: Long) = "${(millis / 60_000).toString().padStart(2, '0')}:" +
        "${((millis / 1000) % 60).toString().padStart(2, '0')}." +
        "${((millis % 1000) / 10).toString().padStart(2, '0')}"
    Column(Modifier.fillMaxWidth().padding(top = 35.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(19.dp)) {
        Text(fmt(elapsed), color = theme.text, fontSize = 46.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DFButton(if (running) "إيقاف" else "ابدأ", {
                if (running) running = false else { end = SystemClock.elapsedRealtime() - elapsed; running = true }
            })
            DFButton("لفة", { laps = listOf(elapsed) + laps }, soft = true)
            DFButton("إعادة", { running = false; elapsed = 0; laps = emptyList() }, soft = true)
        }
        laps.forEachIndexed { i, lap -> DFRow("#${laps.size - i}", fmt(lap)) }
    }
}