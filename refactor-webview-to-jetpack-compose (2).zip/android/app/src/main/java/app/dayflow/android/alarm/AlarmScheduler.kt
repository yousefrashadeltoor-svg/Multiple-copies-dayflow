package app.dayflow.android.alarm

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.media.RingtoneManager
import android.media.AudioAttributes
import androidx.core.content.ContextCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.AlarmEntry
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.ReminderEntry
import app.dayflow.android.widgets.WidgetGateway
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

object AlarmScheduler {
    private const val ALARM_ACTION = "app.dayflow.ALARM"
    private const val SNOOZE_ACTION = "app.dayflow.SNOOZED_ALARM"
    private const val ALARM_MASK = 0x1770000
    private const val SNOOZE_MASK = 0x2770000

    private fun manager(context: Context) = context.getSystemService(AlarmManager::class.java)
    fun canSchedule(context: Context) = Build.VERSION.SDK_INT < 31 || manager(context).canScheduleExactAlarms()
    fun canShowFullScreen(context: Context) = Build.VERSION.SDK_INT < 34 ||
        context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    fun exactSettingsIntent(context: Context) = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
        android.net.Uri.parse("package:${context.packageName}"))

    private fun pending(context: Context, id: String, snoozed: Boolean, flags: Int): PendingIntent? {
        val action = if (snoozed) SNOOZE_ACTION else ALARM_ACTION
        val code = (id.hashCode() and 0x00ffffff) xor (if (snoozed) SNOOZE_MASK else ALARM_MASK)
        return PendingIntent.getBroadcast(context, code,
            Intent(context, AlarmReceiver::class.java).setAction(action).putExtra("id", id).putExtra("snoozed", snoozed),
            flags or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(context: Context, alarm: AlarmEntry, from: Instant = Instant.now()): Boolean {
        cancelPending(context, alarm.id, false)
        if (!alarm.enabled) return true
        if (!canSchedule(context)) return false
        val instant = alarm.next(from.atZone(ZoneId.systemDefault()))?.toInstant() ?: return false
        val signal = pending(context, alarm.id, false, PendingIntent.FLAG_UPDATE_CURRENT) ?: return false
        val show = PendingIntent.getActivity(context, (alarm.id.hashCode() and 0x00ffffff) xor 0x3770000,
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_ROUTE, "alarms"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager(context).setAlarmClock(AlarmManager.AlarmClockInfo(instant.toEpochMilli(), show), signal)
        return true
    }

    private fun cancelPending(context: Context, id: String, snoozed: Boolean) {
        pending(context, id, snoozed, PendingIntent.FLAG_NO_CREATE)?.let { manager(context).cancel(it); it.cancel() }
    }

    fun cancel(context: Context, id: String) {
        cancelPending(context, id, false)
        cancelPending(context, id, true)
    }

    fun snooze(context: Context, id: String, minutes: Int) {
        if (!canSchedule(context)) return
        val signal = pending(context, id, true, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        val show = PendingIntent.getActivity(context, (id.hashCode() and 0x00ffffff) xor 0x4770000,
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_ROUTE, "alarms"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager(context).setAlarmClock(
            AlarmManager.AlarmClockInfo(System.currentTimeMillis() + minutes.coerceIn(1, 60) * 60_000L, show), signal)
    }

    fun restore(context: Context) {
        val repo = AppRepository.get(context)
        repo.state.value.alarms.filter { it.enabled }.forEach { alarm ->
            runCatching { schedule(context, alarm) }
        }
        ReminderScheduler.restore(context)
        WidgetGateway.refreshAll(context)
    }
}

object NotificationCenter {
    const val ALARMS = "dayflow_alarm_v2"
    const val REMINDERS = "dayflow_reminders"
    const val COMPANION = "dayflow_companion"

    fun setup(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val alarm = NotificationChannel(ALARMS, "DAYFLOW alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Ringing alarms"
            setSound(null, null) // The ringing service plays the user's selected URI, not the channel.
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val companion = NotificationChannel(COMPANION, "DAYFLOW companion", NotificationManager.IMPORTANCE_LOW)
        val reminders = (0..3).map { mask ->
            val sound = mask and 1 != 0
            val vibrate = mask and 2 != 0
            NotificationChannel("${REMINDERS}_$mask", "DAYFLOW reminders${if (mask == 0) " (quiet)" else ""}",
                NotificationManager.IMPORTANCE_DEFAULT).apply {
                if (sound) setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build())
                else setSound(null, null)
                enableVibration(vibrate)
            }
        }
        manager.createNotificationChannels(listOf(alarm, companion) + reminders)
    }

    fun reminderChannel(context: Context): String {
        val state = AppRepository.get(context).state.value
        val mask = (if (state.notificationSound) 1 else 0) + (if (state.notificationVibrate) 2 else 0)
        return "${REMINDERS}_$mask"
    }

    fun canPost(context: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun open(context: Context, route: String, id: Int): PendingIntent = PendingIntent.getActivity(
        context, id, Intent(context, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_ROUTE, route)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun test(context: Context): Boolean {
        if (!canPost(context)) return false
        setup(context)
        val notification = Notification.Builder(context, reminderChannel(context))
            .setSmallIcon(R.drawable.dayflow_icon).setContentTitle("DAYFLOW")
            .setContentText("اختبار إشعار حقيقي").setAutoCancel(true)
            .setContentIntent(open(context, "me/notifs", 9379)).build()
        context.getSystemService(NotificationManager::class.java).notify(9379, notification)
        return true
    }
}

object ReminderScheduler {
    private const val ACTION = "app.dayflow.REMINDER"
    private fun code(id: String) = (id.hashCode() and 0x00ffffff) xor 0x5770000
    private fun pending(context: Context, id: String, flags: Int): PendingIntent? = PendingIntent.getBroadcast(
        context, code(id), Intent(context, ReminderReceiver::class.java).setAction(ACTION).putExtra("id", id),
        flags or PendingIntent.FLAG_IMMUTABLE)

    fun cancel(context: Context, id: String) {
        val manager = context.getSystemService(AlarmManager::class.java)
        pending(context, id, PendingIntent.FLAG_NO_CREATE)?.let { manager.cancel(it); it.cancel() }
    }

    fun schedule(context: Context, reminder: ReminderEntry): Boolean {
        cancel(context, reminder.id)
        if (reminder.completed) return true
        val date = runCatching { LocalDate.parse(reminder.date) }.getOrNull() ?: return false
        val time = runCatching { LocalTime.parse(reminder.time) }.getOrNull() ?: return false
        val zone = ZoneId.systemDefault()
        val nextDate = if (reminder.days.isEmpty()) date else (0..7).map { LocalDate.now().plusDays(it.toLong()) }
            .firstOrNull { day -> !day.isBefore(date) && day.dayOfWeek.value % 7 in reminder.days &&
                day.atTime(time).atZone(zone).toInstant().isAfter(Instant.now()) } ?: return false
        var instant = nextDate.atTime(time).atZone(zone)
        if (instant.toInstant().isBefore(Instant.now())) return false
        if (AppRepository.get(context).state.value.quietHours && (time.hour >= 23 || time.hour < 7)) {
            instant = (if (time.hour >= 23) nextDate.plusDays(1) else nextDate).atTime(7, 0).atZone(zone)
        }
        val signal = pending(context, reminder.id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return false
        val manager = context.getSystemService(AlarmManager::class.java)
        if (AlarmScheduler.canSchedule(context)) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, instant.toInstant().toEpochMilli(), signal)
        else manager.setWindow(AlarmManager.RTC_WAKEUP, instant.toInstant().toEpochMilli(), 15 * 60_000L, signal)
        return true
    }

    fun restore(context: Context) {
        val state = AppRepository.get(context).state.value
        state.reminders.forEach { schedule(context, it) }
        state.tasks.filter { !it.done && it.dueTime.isNotBlank() }.forEach {
            schedule(context, ReminderEntry(it.id, it.title, it.date, it.dueTime))
        }
        state.habits.filter { it.reminder.isNotBlank() }.forEach { habit ->
            runCatching { schedule(context, ReminderEntry(habit.id, habit.title,
                habit.startDate ?: LocalDate.now().toString(), habit.reminder,
                days = habit.days.ifEmpty { (0..6).toSet() })) }
        }
        state.meds.forEach { med -> runCatching { schedule(context, ReminderEntry(med.id, med.name,
            LocalDate.now().toString(), med.time, days = (0..6).toSet())) } }
        runCatching { schedule(context, ReminderEntry("review_daily", "مراجعة اليوم",
            LocalDate.now().toString(), state.dailyReview, days = (0..6).toSet())) }
        if (state.weeklyReview) runCatching { schedule(context, ReminderEntry("review_weekly", "المراجعة الأسبوعية",
            LocalDate.now().toString(), state.dailyReview, days = setOf(5))) }
    }
}