package app.dayflow.android.downloads

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class DownloadEntry(
    val id: Long, val title: String, val url: String, val mime: String,
    val status: Int = DownloadManager.STATUS_PENDING, val bytes: Long = 0,
    val total: Long = 0, val reason: Int = 0
) {
    fun json() = JSONObject().put("id", id).put("title", title).put("url", url).put("mime", mime)
        .put("status", status).put("bytes", bytes).put("total", total).put("reason", reason)
    companion object { fun from(j: JSONObject) = DownloadEntry(j.getLong("id"), j.optString("title"),
        j.optString("url"), j.optString("mime"), j.optInt("status", DownloadManager.STATUS_PENDING),
        j.optLong("bytes"), j.optLong("total"), j.optInt("reason")) }
}

class DownloadRepository private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("dayflow_downloads_native", Context.MODE_PRIVATE)
    private val manager = context.getSystemService(DownloadManager::class.java)
    private val initial = runCatching { JSONArray(prefs.getString("items", "[]")) }.getOrNull()?.let { a ->
        (0 until a.length()).mapNotNull { a.optJSONObject(it)?.let { j -> runCatching { DownloadEntry.from(j) }.getOrNull() } }
    } ?: emptyList()
    private val _items = MutableStateFlow(initial)
    val items = _items.asStateFlow()

    @Synchronized private fun save(next: List<DownloadEntry>) {
        prefs.edit().putString("items", JSONArray(next.map { it.json() }).toString()).apply()
        _items.value = next
    }

    fun enqueue(preview: LinkPreview, format: NativeFormat): Long {
        require(preview.formats.any { it.url == format.url && it.id == format.id }) { "الصيغة غير موجودة في المعاينة المتحققة" }
        val filename = LinkAnalyzer.filename(null, format.url).let { candidate ->
            if (candidate == "download" && preview.filename != null) preview.filename else candidate
        }
        val request = DownloadManager.Request(Uri.parse(format.url))
            .setTitle(filename).setMimeType(format.mime)
            .setDescription(preview.title)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DAYFLOW/$filename")
        val id = manager.enqueue(request)
        save(listOf(DownloadEntry(id, filename, format.url, format.mime)) + _items.value)
        return id
    }

    suspend fun refresh() = withContext(Dispatchers.IO) {
        val next = _items.value.map { item ->
            manager.query(DownloadManager.Query().setFilterById(item.id))?.use { cursor ->
                if (cursor.moveToFirst()) item.copy(
                    status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)),
                    bytes = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)),
                    total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)),
                    reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                ) else item.copy(status = DownloadManager.STATUS_FAILED)
            } ?: item
        }
        save(next)
    }

    fun cancel(id: Long) { manager.remove(id); save(_items.value.filterNot { it.id == id }) }
    fun open(id: Long): Boolean {
        val item = _items.value.firstOrNull { it.id == id && it.status == DownloadManager.STATUS_SUCCESSFUL } ?: return false
        val uri = manager.getUriForDownloadedFile(id) ?: return false
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent); true }.getOrDefault(false)
    }

    companion object {
        @Volatile private var instance: DownloadRepository? = null
        fun get(context: Context): DownloadRepository = instance ?: synchronized(this) {
            instance ?: DownloadRepository(context.applicationContext).also { instance = it }
        }
    }
}

class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (DownloadRepository.get(context).items.value.none { it.id == id }) return
        val pending = goAsync()
        Thread { try {
            kotlinx.coroutines.runBlocking { DownloadRepository.get(context).refresh() }
        } finally { pending.finish() } }.start()
    }
}