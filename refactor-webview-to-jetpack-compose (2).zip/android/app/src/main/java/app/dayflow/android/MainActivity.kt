package app.dayflow.android

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.NotificationCenter
import app.dayflow.android.alarm.ReminderScheduler
import app.dayflow.android.companion.CompanionOverlayService
import app.dayflow.android.companion.RobotView
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.Catalog
import app.dayflow.android.data.NoteEntry
import app.dayflow.android.data.ReminderEntry
import app.dayflow.android.data.TaskEntry
import app.dayflow.android.data.today
import app.dayflow.android.ui.AIScreen
import app.dayflow.android.ui.AlarmsScreen
import app.dayflow.android.ui.CalendarScreen
import app.dayflow.android.ui.DFButton
import app.dayflow.android.ui.DFCard
import app.dayflow.android.ui.DFField
import app.dayflow.android.ui.DFHeader
import app.dayflow.android.ui.DownloadsScreen
import app.dayflow.android.ui.LocalLang
import app.dayflow.android.ui.LocalPack
import app.dayflow.android.ui.MeScreen
import app.dayflow.android.ui.TodayScreen
import app.dayflow.android.ui.ToolsScreen
import app.dayflow.android.ui.WidgetHubScreen
import app.dayflow.android.widgets.WidgetGateway
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.roundToInt

open class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_ROUTE = "app.dayflow.ROUTE" }
    internal val route = mutableStateOf("today")
    internal val shared = mutableStateOf("")
    private val widgetId = mutableIntStateOf(AppWidgetManager.INVALID_APPWIDGET_ID)
    internal val message = mutableStateOf("")
    private val repository by lazy { AppRepository.get(this) }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (!it) message.value = "إذن الإشعارات مرفوض. فعله من إعدادات الهاتف لاستقبال التذكيرات."
    }
    private val exactAlarmAccess = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (AlarmScheduler.canSchedule(this)) AlarmScheduler.restore(this)
        else message.value = "لم يُمنح إذن المنبهات الدقيقة. لن نعدك برنين منبه غير مجدول."
    }
    private val overlayAccess = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(this)) startOverlay()
        else message.value = "امنح إذن الظهور فوق التطبيقات لتشغيل الرفيق العائم."
    }
    private val locationAccess = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) fetchCurrentLocation()
        else message.value = "إذن الموقع مرفوض؛ المدينة التي اخترتها يدويًا ما زالت مستخدمة."
    }
    private val importBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Missing file")
            repository.import(raw)
            AlarmScheduler.restore(this)
            message.value = "تم استيراد البيانات وجدولة المنبهات المحفوظة."
        }.onFailure { message.value = "تعذر الاستيراد. تحقق من ملف DAYFLOW الاحتياطي." }
    }
    private val exportBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(repository.export()) }
            message.value = "تم حفظ النسخة الاحتياطية."
        }.onFailure { message.value = "تعذر حفظ النسخة الاحتياطية." }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationCenter.setup(this)
        handleIntent(intent)
        setContent { DayflowApplication(this) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent) }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == AppWidgetManager.ACTION_APPWIDGET_CONFIGURE) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            if (id == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
            widgetId.intValue = id
            setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
            route.value = "me/widgets"
        } else if (intent?.action == Intent.ACTION_SEND) {
            shared.value = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            route.value = "downloads"
        } else intent?.getStringExtra(EXTRA_ROUTE)?.let { route.value = it }
    }

    fun go(destination: String) { route.value = destination }
    fun notifyUser(text: String) { message.value = text }
    fun widgetToConfigure(): Int = widgetId.intValue
    fun selectWidget(design: app.dayflow.android.data.WidgetDesign, style: String): Boolean {
        val id = widgetId.intValue
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return false
        if (!WidgetGateway.save(this, id, design, style)) return false
        setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        widgetId.intValue = AppWidgetManager.INVALID_APPWIDGET_ID
        finish()
        return true
    }
    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !NotificationCenter.canPost(this))
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    fun requestExactAlarms() {
        if (AlarmScheduler.canSchedule(this)) return
        exactAlarmAccess.launch(AlarmScheduler.exactSettingsIntent(this))
    }
    fun requestOverlay() {
        if (Settings.canDrawOverlays(this)) { startOverlay(); return }
        overlayAccess.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }
    fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) { requestOverlay(); return }
        repository.update { it.copy(companionEnabled = true, companionVisible = true) }
        runCatching { ContextCompat.startForegroundService(this, Intent(this, CompanionOverlayService::class.java)) }
            .onFailure { message.value = "النظام لم يسمح بتشغيل النافذة العائمة الآن؛ افتح التطبيق وحاول مجددًا." }
    }
    fun stopOverlay() { stopService(Intent(this, CompanionOverlayService::class.java)) }
    fun requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            fetchCurrentLocation()
        else locationAccess.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
    }
    private fun fetchCurrentLocation() {
        try {
            val manager = getSystemService(LocationManager::class.java)
            val provider = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                .firstOrNull { manager.isProviderEnabled(it) }
            if (provider == null) { message.value = "فعّل خدمات الموقع أو اختر مدينة يدويًا."; return }
            fun save(location: Location?) {
                if (location == null) { message.value = "لم يتوفر موقع دقيق الآن؛ اختر مدينة يدويًا."; return }
                repository.update { it.copy(useLocation = true, latitude = location.latitude, longitude = location.longitude) }
            }
            if (Build.VERSION.SDK_INT >= 30) manager.getCurrentLocation(provider, null, mainExecutor, ::save)
            else @Suppress("DEPRECATION") manager.requestSingleUpdate(provider, object : LocationListener {
                override fun onLocationChanged(location: Location) = save(location)
            }, Looper.getMainLooper())
        } catch (_: SecurityException) { message.value = "إذن الموقع غير متاح. اختر مدينة يدويًا." }
    }
    fun openImport() = importBackup.launch(arrayOf("application/json", "text/plain"))
    fun openExport() = exportBackup.launch("dayflow-backup-${today()}.json")
    fun showTime(initial: String, onChosen: (String) -> Unit) {
        val time = runCatching { LocalTime.parse(initial) }.getOrDefault(LocalTime.of(7, 0))
        TimePickerDialog(this, { _, hour, minute -> onChosen("%02d:%02d".format(hour, minute)) },
            time.hour, time.minute, false).show()
    }
    fun showDate(initial: String, onChosen: (String) -> Unit) {
        val date = runCatching { LocalDate.parse(initial) }.getOrDefault(LocalDate.now())
        DatePickerDialog(this, { _, y, m, d -> onChosen(LocalDate.of(y, m + 1, d).toString()) },
            date.year, date.monthValue - 1, date.dayOfMonth).show()
    }
}

class WidgetConfigureActivity : MainActivity()

@Composable
private fun DayflowApplication(activity: MainActivity) {
    val state by AppRepository.get(activity).state.collectAsState()
    val nav by activity.route
    val themes = remember { Catalog.themes(activity) }
    val theme = themes.firstOrNull { it.id == state.themeId } ?: themes.first()
    val palette = if (theme.mode == "dark") darkColorScheme(primary = theme.accent, background = theme.bg,
        surface = theme.surface, onSurface = theme.text, onBackground = theme.text)
        else lightColorScheme(primary = theme.accent, background = theme.bg,
            surface = theme.surface, onSurface = theme.text, onBackground = theme.text)
    val direction = if (state.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr
    SideEffect {
        @Suppress("DEPRECATION")
        activity.window.statusBarColor = theme.bg.toArgb()
        @Suppress("DEPRECATION")
        activity.window.navigationBarColor = theme.bg.toArgb()
    }
    CompositionLocalProvider(LocalPack provides theme, LocalLang provides state.lang,
        LocalLayoutDirection provides direction) {
        MaterialTheme(colorScheme = palette) {
            var quick by remember { mutableStateOf(false) }
            var robotPanel by remember { mutableStateOf(false) }
            var robotOffsetX by remember { mutableStateOf(0f) }
            var robotOffsetY by remember { mutableStateOf(0f) }
            val snackbar = remember { SnackbarHostState() }
            val scope = rememberCoroutineScope()
            val incoming = activity.message.value
            LaunchedEffect(incoming) {
                if (incoming.isNotBlank()) {
                    snackbar.showSnackbar(incoming)
                    activity.message.value = ""
                }
            }
            BackHandler(enabled = nav != "today" || activity.widgetToConfigure() != AppWidgetManager.INVALID_APPWIDGET_ID) {
                if (activity.widgetToConfigure() != AppWidgetManager.INVALID_APPWIDGET_ID) activity.finish()
                else if (nav.contains('/')) activity.go(nav.substringBefore('/'))
                else activity.go("today")
            }
            val tabs = listOf(
                Triple("today", if (state.lang == "ar") "النهاردة" else "Today", Icons.Outlined.WbSunny),
                Triple("calendar", if (state.lang == "ar") "التقويم" else "Calendar", Icons.Outlined.CalendarMonth),
                Triple("alarms", if (state.lang == "ar") "المنبهات" else "Alarms", Icons.Outlined.Alarm),
                Triple("tools", if (state.lang == "ar") "أدوات" else "Tools", Icons.Outlined.Dashboard),
                Triple("ai", if (state.lang == "ar") "الذكاء" else "AI", Icons.Outlined.AutoAwesome),
                Triple("downloads", if (state.lang == "ar") "التحميل" else "Download", Icons.Outlined.Download),
                Triple("me", if (state.lang == "ar") "أنا" else "Me", Icons.Outlined.PersonOutline)
            )
            Scaffold(containerColor = theme.bg, snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    Row(Modifier.fillMaxWidth().background(theme.surface.copy(alpha = .96f))
                        .padding(WindowInsets.navigationBars.asPaddingValues())
                        .height(62.dp), verticalAlignment = Alignment.CenterVertically) {
                        tabs.forEach { (id, title, icon) ->
                            val active = nav.substringBefore('/') == id
                            Column(Modifier.weight(1f).fillMaxSize().clickable { activity.go(id) }
                                .padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(width = 40.dp, height = 28.dp)
                                    .background(if (active) theme.soft else Color.Transparent, CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Icon(icon, title, Modifier.size(20.dp), tint = if (active) theme.accent else theme.muted)
                                }
                                Text(title, fontSize = 10.sp, color = if (active) theme.accent else theme.muted,
                                    maxLines = 1)
                            }
                        }
                    }
                }) { insets ->
                Box(Modifier.fillMaxSize().padding(insets)) {
                    Box(Modifier.fillMaxSize().widthIn(max = 672.dp).align(Alignment.Center)
                        .padding(horizontal = 16.dp, vertical = 2.dp)) {
                        when (nav.substringBefore('/')) {
                            "today" -> TodayScreen(state, activity::go)
                            "calendar" -> CalendarScreen(state, activity)
                            "alarms" -> AlarmsScreen(state, activity)
                            "tools" -> ToolsScreen(nav.substringAfter('/', ""), state, activity)
                            "ai" -> AIScreen(state, activity)
                            "downloads" -> DownloadsScreen(activity, activity.shared.value)
                            "me" -> if (nav == "me/widgets") WidgetHubScreen(state, activity)
                                else MeScreen(nav.substringAfter('/', ""), state, activity)
                        }
                    }
                    if (state.companionEnabled && state.companionVisible) {
                        AndroidView(factory = { RobotView(it) }, update = {
                            it.mood = state.companionMood
                            it.outfit = state.companionOutfit
                        }, modifier = Modifier.align(Alignment.BottomEnd)
                            .padding(end = 6.dp, bottom = 16.dp)
                            .size(90.dp, 116.dp)
                            .offset { IntOffset(robotOffsetX.roundToInt(), robotOffsetY.roundToInt()) }
                            .pointerInput(Unit) {
                                detectDragGestures(onDragEnd = { }) { change, amount ->
                                    robotOffsetX += amount.x; robotOffsetY += amount.y; change.consume()
                                }
                            }.clickable { robotPanel = true })
                    }
                    FloatingActionButton(onClick = { quick = true }, modifier = Modifier.align(Alignment.BottomCenter)
                        .padding(bottom = 15.dp).size(56.dp).shadow(8.dp, CircleShape),
                        shape = CircleShape, containerColor = theme.accent, contentColor = Color.White) {
                        Icon(Icons.Outlined.Add, contentDescription = "اعمل جديد")
                    }
                }
            }
            if (quick) QuickCreate(activity, onDismiss = { quick = false })
            if (robotPanel) ModalBottomSheet(onDismissRequest = { robotPanel = false }, containerColor = theme.surface) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الرفيق", color = theme.text, fontSize = 19.sp)
                    DFButton("اسألني", { robotPanel = false; activity.go("ai") }, Modifier.fillMaxWidth())
                    DFButton("مهامي", { robotPanel = false; activity.go("tools/tasks") }, Modifier.fillMaxWidth(), soft = true)
                    DFButton("المنبهات", { robotPanel = false; activity.go("alarms") }, Modifier.fillMaxWidth(), soft = true)
                    DFButton("اعرضه فوق التطبيقات", { robotPanel = false; activity.requestOverlay() }, Modifier.fillMaxWidth(), soft = true)
                }
            }
        }
    }
}

@Composable
private fun QuickCreate(activity: MainActivity, onDismiss: () -> Unit) {
    val repo = remember { AppRepository.get(activity) }
    val state by repo.state.collectAsState()
    val theme = LocalPack.current
    var kind by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }
    var time by remember { mutableStateOf("18:00") }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = theme.surface) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)) {
            DFHeader(if (state.lang == "ar") "اعمل جديد" else "Create")
            if (kind.isEmpty()) {
                listOf("alarm" to "منبه", "task" to "مهمة", "habit" to "عادة",
                    "note" to "ملاحظة", "reminder" to "تذكير", "widgets" to "ودجت")
                    .chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (id, name) -> DFCard(Modifier.weight(1f).height(88.dp), onClick = {
                            if (id in setOf("alarm", "habit", "widgets")) {
                                onDismiss(); activity.go(when (id) { "alarm" -> "alarms"; "habit" -> "tools/habits"; else -> "me/widgets" })
                            } else kind = id
                        }) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(name, color = theme.text) } } }
                    } }
            } else {
                DFField(title, { title = it }, when (kind) {
                    "note" -> "اكتب ملاحظة..."; "task" -> "ما المطلوب إنجازه؟"; else -> "ذكّرني بـ..."
                }, Modifier.fillMaxWidth(), singleLine = kind != "note")
                if (kind == "reminder") {
                    DFButton("${date} · ${app.dayflow.android.data.displayTime(time, state.lang)}", {
                        activity.showDate(date) { date = it }
                    }, Modifier.fillMaxWidth(), soft = true)
                    DFButton("تغيير الساعة", { activity.showTime(time) { time = it } }, Modifier.fillMaxWidth(), soft = true)
                }
                DFButton("حفظ", {
                    if (title.isNotBlank()) {
                        when (kind) {
                            "task" -> repo.update { it.copy(tasks = listOf(TaskEntry(title = title.trim())) + it.tasks) }
                            "note" -> repo.update { it.copy(notes = listOf(NoteEntry(text = title.trim())) + it.notes) }
                            "reminder" -> {
                                val reminder = ReminderEntry(title = title.trim(), date = date, time = time)
                                if (LocalDate.parse(date).atTime(LocalTime.parse(time)).isAfter(java.time.LocalDateTime.now())) {
                                    repo.update { it.copy(reminders = listOf(reminder) + it.reminders) }
                                    if (!ReminderScheduler.schedule(activity, reminder)) activity.notifyUser("لم يمكن جدولة التذكير. اختر وقتًا آخر.")
                                    activity.requestNotifications()
                                } else activity.notifyUser("اختر موعدًا في المستقبل")
                            }
                        }
                        onDismiss()
                    }
                }, Modifier.fillMaxWidth(), enabled = title.isNotBlank())
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}