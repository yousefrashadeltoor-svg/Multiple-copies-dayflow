package app.dayflow.android.data

import android.content.Context
import android.graphics.Color as AndroidColor
import androidx.compose.ui.graphics.Color
import org.json.JSONArray

data class ThemePack(
    val id: String, val en: String, val ar: String, val category: String, val mode: String,
    val bg: Color, val surface: Color, val text: Color, val accent: Color, val accent2: Color,
    val material: String, val shape: String, val font: String, val ornament: String
) {
    val muted get() = text.copy(alpha = .55f)
    val soft get() = Color(
        red = accent.red * .12f + surface.red * .88f,
        green = accent.green * .12f + surface.green * .88f,
        blue = accent.blue * .12f + surface.blue * .88f
    )
}

data class WidgetDesign(
    val id: String, val en: String, val ar: String, val category: String,
    val archetype: String, val variant: Int, val interactive: Boolean,
    val forms: List<String>
)

object Catalog {
    private var themesCache: List<ThemePack>? = null
    private var widgetsCache: List<WidgetDesign>? = null
    val widgetStyles = listOf("oneui", "material", "ios", "editorial", "neon", "paper", "clay", "outline", "amoled", "seasonal")
    val widgetStyleNames = listOf("زجاج One UI", "Material You", "مستوحى من iOS", "تحريري", "نيون", "ورق", "صلصال", "خطوط بسيطة", "أموليد", "موسمي")
    val widgetCategories = listOf("clock", "alarms", "calendar", "occasions", "plan", "tasks", "habits", "focus", "review", "media", "utility", "companion")
    val widgetCategoryNames = listOf("الساعة", "المنبهات", "التقويم", "المناسبات", "الخطة واليوم", "المهام والملاحظات", "العادات والصحة", "التركيز والدراسة", "المراجعة والإحصاءات", "مركز الوسائط", "أدوات", "الرفيق")
    val forms = listOf("1x1", "2x1", "2x2", "4x1", "4x2", "4x4")

    fun themes(ctx: Context): List<ThemePack> = themesCache ?: synchronized(this) {
        themesCache ?: JSONArray(ctx.assets.open("themes.json").bufferedReader().use { it.readText() }).let { a ->
            (0 until a.length()).map { a.getJSONObject(it) }.map { j ->
                fun color(k: String) = Color(AndroidColor.parseColor(j.getString(k)))
                ThemePack(j.getString("id"), j.getString("en"), j.getString("ar"), j.getString("cat"),
                    j.getString("mode"), color("bg"), color("surface"), color("text"),
                    color("accent"), color("accent2"), j.getString("material"), j.getString("shape"),
                    j.getString("font"), j.getString("ornament"))
            }
        }.also { themesCache = it }
    }

    fun widgets(ctx: Context): List<WidgetDesign> = widgetsCache ?: synchronized(this) {
        widgetsCache ?: JSONArray(ctx.assets.open("widgets.json").bufferedReader().use { it.readText() }).let { a ->
            (0 until a.length()).map { a.getJSONObject(it) }.map { j ->
                val forms = j.getJSONArray("forms")
                WidgetDesign(j.getString("id"), j.getString("en"), j.getString("ar"), j.getString("cat"),
                    j.getString("arche"), j.getInt("variant"), j.getBoolean("interactive"),
                    (0 until forms.length()).map { forms.getString(it) })
            }
        }.also { widgetsCache = it }
    }
}