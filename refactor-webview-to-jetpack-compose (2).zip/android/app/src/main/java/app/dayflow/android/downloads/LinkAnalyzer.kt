package app.dayflow.android.downloads

import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URI
import java.net.URLDecoder
import java.util.concurrent.TimeUnit

data class NativeFormat(
    val id: String, val label: String, val detail: String, val url: String,
    val mime: String, val size: Long?
)

data class LinkPreview(
    val url: String, val host: String, val title: String, val author: String?, val description: String?,
    val thumbnail: String?, val durationSeconds: Long?, val filename: String?, val mime: String?,
    val size: Long?, val formats: List<NativeFormat>, val notice: String?
)

object LinkAnalyzer {
    private val guardedDns = Dns { host ->
        Dns.SYSTEM.lookup(host).also { addresses ->
            if (addresses.isEmpty() || addresses.any { address ->
                    address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress ||
                        address.isSiteLocalAddress || address.isMulticastAddress ||
                        (address is Inet6Address && address.address[0].toInt() and 0xfe == 0xfc)
                }) throw SecurityException("Local or private network addresses are not allowed")
        }
    }
    private val client = OkHttpClient.Builder().dns(guardedDns)
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(18, TimeUnit.SECONDS).followRedirects(true).followSslRedirects(false)
        .build()

    fun normalize(raw: String): String {
        val text = raw.trim().substringBefore(' ').trimEnd('.', ',', '،', ')', ']')
        val uri = URI(if (text.startsWith("www.", true)) "https://$text" else text)
        require(uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank()) { "أدخل رابط HTTP أو HTTPS صالحًا" }
        require(uri.userInfo == null && uri.port in -1..65535) { "الرابط غير صالح" }
        return uri.toASCIIString()
    }

    suspend fun analyze(raw: String): LinkPreview = withContext(Dispatchers.IO) {
        val url = normalize(raw)
        val req = Request.Builder().url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            .header("Accept", "text/html,application/xhtml+xml,image/*,video/*,audio/*,*/*;q=0.8")
            .header("Range", "bytes=0-786431").build()
        try {
            client.newCall(req).execute().use { response ->
                if (response.code !in 200..299) throw IllegalStateException("HTTP ${response.code} من الموقع")
                val final = response.request.url.toString()
                val host = response.request.url.host
                val contentType = response.body?.contentType()?.let { "${it.type}/${it.subtype}" }
                val direct = contentType != null && !contentType.contains("html") &&
                    !contentType.contains("json") && !contentType.contains("xml") &&
                    !contentType.contains("mpegurl") && !contentType.contains("dash+xml")
                if (direct) {
                    val name = filename(response.header("Content-Disposition"), final)
                    val fullSize = response.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                        ?: response.header("Content-Length")?.toLongOrNull()?.takeIf { response.code == 200 }
                    val type = contentType ?: "application/octet-stream"
                    val format = NativeFormat("original", name.substringAfterLast('.', "FILE").uppercase(),
                        type, final, type, fullSize)
                    return@withContext LinkPreview(final, host, name, null, null,
                        if (type.startsWith("image/")) final else null, null, name, type,
                        fullSize, listOf(format), null)
                }
                if (contentType?.contains("mpegurl") == true || final.substringBefore('?').endsWith(".m3u8", true)) {
                    return@withContext LinkPreview(final, host, filename(null, final), null, null, null,
                        null, null, contentType, null, emptyList(), "هذا رابط بث HLS. لا تتوفر أداة استخراج البث في هذا الإصدار، ولن تُعرض صيغة غير حقيقية.")
                }
                val bytes = response.body?.byteStream()?.use { stream ->
                    val out = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(16384)
                    while (out.size() < 786432) {
                        val n = stream.read(buf, 0, minOf(buf.size, 786432 - out.size()))
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                    out.toByteArray()
                } ?: ByteArray(0)
                val charset = response.body?.contentType()?.charset(Charsets.UTF_8) ?: Charsets.UTF_8
                val page = Jsoup.parse(String(bytes, charset), final)
                val title = meta(page, "og:title", "twitter:title", "title")
                    ?: page.title().takeIf { it.isNotBlank() }
                    ?: host
                val image = meta(page, "og:image", "og:image:secure_url", "twitter:image")
                    ?.let { absolute(page, it) }
                val author = meta(page, "article:author", "author", "twitter:creator", "og:site_name")
                val description = meta(page, "og:description", "twitter:description", "description")
                val duration = meta(page, "video:duration", "og:video:duration")?.toLongOrNull()
                val embedded = meta(page, "og:video:url", "og:video", "og:audio:url")
                    ?.let { absolute(page, it) }
                val formats = embedded?.let { inspectDirect(it) }?.let { listOf(it) } ?: emptyList()
                val notice = if (formats.isEmpty())
                    "المعاينة من الصفحة نفسها. هذا الموقع لم يكشف رابط ملف مباشر قابل للتحقق؛ لا توجد صيغ للتنزيل دون مستخرج وسائط حقيقي أو إذن من الموقع."
                    else null
                LinkPreview(final, host, title, author, description, image, duration, null,
                    contentType, null, formats, notice)
            }
        } catch (original: Exception) {
            val embed = oEmbed(url)
            embed ?: throw original
        }
    }

    private fun meta(page: Document, vararg keys: String): String? {
        for (key in keys) {
            val value = page.selectFirst("meta[property=$key], meta[name=$key]")?.attr("content")
            if (!value.isNullOrBlank()) return value.trim().take(600)
        }
        return null
    }

    private fun absolute(page: Document, value: String): String? = runCatching {
        normalize(URI(page.baseUri()).resolve(value.trim()).toString()).takeIf { URI(it).scheme == "https" }
    }.getOrNull()

    private fun inspectDirect(url: String): NativeFormat? = runCatching {
        val req = Request.Builder().url(url).head().build()
        client.newCall(req).execute().use { response ->
            if (!response.isSuccessful) return@use null
            val mime = response.body?.contentType()?.let { "${it.type}/${it.subtype}" } ?: return@use null
            if (!mime.startsWith("video/") && !mime.startsWith("audio/") && !mime.startsWith("image/")) return@use null
            val final = response.request.url.toString()
            NativeFormat("original", filename(response.header("Content-Disposition"), final)
                .substringAfterLast('.', mime.substringAfterLast('/')).uppercase(), mime, final, mime,
                response.header("Content-Length")?.toLongOrNull())
        }
    }.getOrNull()

    private fun oEmbed(url: String): LinkPreview? = runCatching {
        val host = URI(url).host.lowercase().removePrefix("www.")
        val endpoint = when {
            host == "youtube.com" || host == "youtu.be" || host == "m.youtube.com" -> "https://www.youtube.com/oembed?format=json&url="
            host.endsWith("vimeo.com") -> "https://vimeo.com/api/oembed.json?url="
            host.endsWith("soundcloud.com") -> "https://soundcloud.com/oembed?format=json&url="
            host.endsWith("tiktok.com") -> "https://www.tiktok.com/oembed?url="
            else -> return null
        }
        val encoded = java.net.URLEncoder.encode(url, "UTF-8")
        client.newCall(Request.Builder().url(endpoint + encoded).build()).execute().use { response ->
            if (!response.isSuccessful) return@use null
            val json = JSONObject(response.body?.string() ?: "{}")
            val title = json.optString("title").takeIf { it.isNotBlank() } ?: host
            LinkPreview(url, host, title, json.optString("author_name").ifBlank { null }, null,
                json.optString("thumbnail_url").takeIf { it.startsWith("https://") }, null,
                null, "text/html", null, emptyList(),
                "المعاينة من بيانات الموقع العامة. لم يقدم الموقع رابطًا مباشرًا أو صيغًا يمكن تنزيلها.")
        }
    }.getOrNull()

    fun filename(disposition: String?, url: String): String {
        val encoded = Regex("filename\\*=(?:UTF-8'')?([^;]+)", RegexOption.IGNORE_CASE)
            .find(disposition.orEmpty())?.groupValues?.get(1)
        val plain = Regex("filename=\\\"?([^\\\";]+)", RegexOption.IGNORE_CASE)
            .find(disposition.orEmpty())?.groupValues?.get(1)
        val raw = encoded?.let { runCatching { URLDecoder.decode(it.trim('"'), "UTF-8") }.getOrNull() }
            ?: plain ?: URI(url).path.substringAfterLast('/').ifBlank { "download" }
        return raw.replace(Regex("[\\u0000-\\u001f\\u007f<>:\\"/\\\\|?*]"), "")
            .trim().take(120).ifBlank { "download" }
    }
}