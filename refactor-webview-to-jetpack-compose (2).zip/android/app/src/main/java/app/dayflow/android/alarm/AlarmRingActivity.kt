package app.dayflow.android.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.displayTime
import app.dayflow.android.prayer.PrayerClock
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class AlarmRingActivity : ComponentActivity() {
    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val id = intent.getStringExtra("id") ?: run { finish(); return }
        val alarm = AppRepository.get(this).state.value.alarms.firstOrNull { it.id == id }
            ?: run { finish(); return }
        setContent {
            AlarmFace(alarm.label, alarm.time, alarm.snooze, onAction = { action ->
                sendBroadcast(Intent(this, AlarmReceiver::class.java).setAction(action).putExtra("id", id))
                finish()
            })
        }
    }

    override fun onStart() {
        super.onStart()
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stopReceiver, IntentFilter(ACTION_STOP), RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(stopReceiver, IntentFilter(ACTION_STOP))
    }
    override fun onStop() { unregisterReceiver(stopReceiver); super.onStop() }
    companion object { const val ACTION_STOP = "app.dayflow.ALARM_STOPPED" }
}

@Composable
private fun AlarmFace(label: String, time: String, snooze: Int, onAction: (String) -> Unit) {
    var slide by remember { mutableFloatStateOf(0f) }
    val gold = Color(0xffc9a24a)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xff17322d), Color(0xff0b0f1a))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("✦      DAYFLOW      ✦", color = gold, letterSpacing = 4.sp, fontSize = 16.sp)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("المنبه يرن", color = Color.White.copy(alpha = .7f), letterSpacing = 3.sp, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Text(displayTime(time, "ar"), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.ExtraLight,
                    maxLines = 1, textAlign = TextAlign.Center)
                Text(label.ifBlank { "منبه" }, color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE، d MMMM", Locale("ar", "EG"))),
                    color = Color.White.copy(alpha = .65f), fontSize = 13.sp)
            }
            Box(Modifier.height(144.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.height(136.dp).fillMaxWidth(.42f).background(Color.White.copy(alpha = .1f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text("✦", color = gold, fontSize = 74.sp)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Button(onClick = { onAction(AlarmReceiver.SNOOZE) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = .14f)),
                    shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Text("غفوة ${snooze} دقائق", color = Color.White, fontSize = 17.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text("← اسحب للإيقاف", color = Color.White.copy(alpha = .85f))
                Slider(value = slide, onValueChange = { slide = it }, onValueChangeFinished = {
                    if (slide >= .95f) onAction(AlarmReceiver.DISMISS) else slide = 0f
                }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}