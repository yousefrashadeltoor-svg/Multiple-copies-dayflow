package app.dayflow.android.companion

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.sin

/** The same 120 x 154 articulated body proportions used by the original SVG robot. */
class RobotView(context: Context) : View(context) {
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG)
    var mood: String = "idle"
        set(value) { field = value; invalidate() }
    var outfit: String = "auto"
        set(value) { field = value; invalidate() }
    private var frame = 0f

    fun advance() { frame += .085f; invalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.scale(width / 120f, height / 154f)
        ink.shader = null
        ink.style = Paint.Style.FILL
        ink.color = 0x30000000
        canvas.drawOval(RectF(34f, 142f, 86f, 150f), ink)

        ink.color = 0xffabb9cb.toInt()
        ink.strokeWidth = 8f
        ink.strokeCap = Paint.Cap.ROUND
        ink.strokeJoin = Paint.Join.ROUND
        ink.style = Paint.Style.STROKE
        val sway = sin(frame) * 2.5f
        stroke(canvas, 34f, 78f, 24f + sway, 98f, 20f + sway, 114f)
        stroke(canvas, 86f, 78f, 96f - sway, 98f, 100f - sway, 114f)
        ink.strokeWidth = 9f
        stroke(canvas, 48f, 116f, 46f + sway, 134f)
        stroke(canvas, 72f, 116f, 74f - sway, 134f)

        ink.style = Paint.Style.FILL
        ink.shader = LinearGradient(35f, 66f, 86f, 120f,
            intArrayOf(Color.WHITE, 0xffd9e2ee.toInt(), 0xff8d9bb0.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(34f, 66f, 86f, 122f), 18f, 18f, ink)
        ink.shader = null
        ink.color = 0xff0f1a2c.toInt()
        canvas.drawRoundRect(RectF(47f, 80f, 73f, 96f), 5f, 5f, ink)
        ink.color = 0xff2f6f5e.toInt()
        canvas.drawCircle(60f, 88f, 4f, ink)
        ink.color = 0xffe7edf5.toInt()
        canvas.drawCircle(20f + sway, 114f, 5.5f, ink)
        canvas.drawCircle(100f - sway, 114f, 5.5f, ink)

        ink.style = Paint.Style.STROKE
        ink.color = 0xff7d8aa0.toInt()
        ink.strokeWidth = 2.5f
        stroke(canvas, 50f, 23f, 44f, 10f, 40f + sway * .4f, 2f)
        stroke(canvas, 70f, 23f, 76f, 10f, 80f - sway * .4f, 2f)
        ink.style = Paint.Style.FILL
        ink.color = 0xffc9a24a.toInt()
        canvas.drawCircle(40f + sway * .4f, 2f, 4f, ink)
        canvas.drawCircle(80f - sway * .4f, 2f, 4f, ink)

        canvas.save()
        canvas.rotate(sin(frame * .4f) * 2.5f, 60f, 64f)
        ink.shader = LinearGradient(30f, 20f, 90f, 68f,
            intArrayOf(Color.WHITE, 0xffd9e2ee.toInt(), 0xff8d9bb0.toInt()), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(30f, 20f, 90f, 66f), 20f, 20f, ink)
        ink.shader = LinearGradient(37f, 29f, 83f, 57f,
            0xff3a4a66.toInt(), 0xff0d1424.toInt(), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(37f, 29f, 83f, 57f), 13f, 13f, ink)
        ink.shader = null
        ink.color = 0xff7fd6ff.toInt()
        if (mood == "sleep" || mood == "wink" || sin(frame * .63f) > .993f) {
            ink.style = Paint.Style.STROKE
            ink.strokeWidth = 2.5f
            stroke(canvas, 46f, 44f, 50f, 47f, 54f, 44f)
            if (mood == "wink") stroke(canvas, 66f, 44f, 74f, 44f)
            else stroke(canvas, 66f, 44f, 70f, 47f, 74f, 44f)
            ink.style = Paint.Style.FILL
        } else if (mood == "happy" || mood == "celebrate") {
            ink.style = Paint.Style.STROKE
            ink.strokeWidth = 2.5f
            stroke(canvas, 46f, 47f, 50f, 42f, 54f, 47f)
            stroke(canvas, 66f, 47f, 70f, 42f, 74f, 47f)
            ink.style = Paint.Style.FILL
        } else {
            canvas.drawOval(RectF(46f, 38f, 54f, 48f), ink)
            canvas.drawOval(RectF(66f, 38f, 74f, 48f), ink)
        }
        ink.color = 0x90ffffff.toInt()
        canvas.drawOval(RectF(37f, 23f, 53f, 29f), ink)
        canvas.restore()

        val season = when (outfit) {
            "gold" -> "ramadan"
            "snow" -> "winter"
            "national" -> "national"
            "none" -> "none"
            else -> when (java.time.LocalDate.now().monthValue) {
                12, 1, 2 -> "winter"
                3, 4, 5 -> "spring"
                9, 10, 11 -> "autumn"
                else -> "nile"
            }
        }
        when (season) {
            "winter" -> {
                ink.color = 0xffc8453b.toInt()
                val scarf = Path().apply { moveTo(42f, 64f); quadTo(60f, 74f, 78f, 64f); lineTo(82f, 78f); quadTo(60f, 88f, 38f, 78f); close() }
                canvas.drawPath(scarf, ink)
                canvas.drawRoundRect(RectF(70f, 80f, 77f, 106f), 3f, 3f, ink)
            }
            "national" -> {
                ink.style = Paint.Style.STROKE
                ink.strokeWidth = 5f
                ink.color = 0xffce1126.toInt(); stroke(canvas, 40f, 70f, 82f, 100f)
                ink.color = Color.WHITE; stroke(canvas, 40f, 75f, 80f, 104f)
                ink.color = Color.BLACK; stroke(canvas, 40f, 80f, 78f, 108f)
                ink.style = Paint.Style.FILL
            }
            "ramadan" -> { ink.color = 0xffc9a24a.toInt(); canvas.drawRoundRect(RectF(91f, 101f, 106f, 120f), 3f, 3f, ink) }
        }
        canvas.restore()
    }

    private fun stroke(canvas: Canvas, vararg points: Float) {
        val path = Path().apply { moveTo(points[0], points[1]); for (i in 2 until points.size step 2) lineTo(points[i], points[i + 1]) }
        canvas.drawPath(path, ink)
    }
}