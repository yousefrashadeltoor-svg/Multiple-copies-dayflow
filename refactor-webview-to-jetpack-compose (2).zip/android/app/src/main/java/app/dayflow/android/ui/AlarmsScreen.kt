package app.dayflow.android.ui

import android.app.PendingIntent
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.AlarmEntry
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.displayTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.Locale

private val week = listOf(6, 0, 1, 2, 3, 4, 5)
private val arDays = listOf("ح", "ن", "ث", "ر", "خ", "ج", "س")
private val enDays = listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")

@Composable
fun AlarmsScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var editing by remember { mutableStateOf<AlarmEntry?>(null) }
    val next = data.alarms.filter { it.enabled }
        .mapNotNull { a -> a.next(ZonedDateTime.now())?.let { it to a } }
        .minByOrNull { it.first }
    Column {
        DFHeader(label("Alarms", "المنبهات"),
            next?.let { "${label("Next", "التالي")}: ${it.first.dayOfMonth}/${it.first.monthValue} · ${displayTime(it.second.time, data.lang)}" }
                ?: label("No alarms on", "لا منبهات مفعّلة"),
            action = { DFButton(label("New", "جديد"), { editing = AlarmEntry() }) })
        LazyColumn(contentPadding = PaddingValues(bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (data.alarms.isEmpty()) item {
                DFEmpty(label("No alarms yet", "مفيش منبهات لسه"),
                    label("Create one in a few seconds.", "أنشئ منبهًا في ثوانٍ.")) {
                    DFButton(label("Create alarm", "اعمل منبه"), { editing = AlarmEntry() })
                }
            }
            items(data.alarms.size) { index ->
                val alarm = data.alarms.sortedBy { it.time }[index]
                DFCard(Modifier.fillMaxWidth(), onClick = { editing = alarm }) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text(displayTime(alarm.time, data.lang), color = if (alarm.enabled) theme.text else theme.muted,
                                fontSize = 36.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(alarm.label.ifBlank { label("Alarm", "منبه") }, color = theme.text, fontSize = 14.sp)
                            Text(daysLabel(alarm, data.lang) + " · " + alarm.soundTitle,
                                color = theme.muted, fontSize = 12.sp, maxLines = 2)
                        }
                        DFToggle(alarm.enabled) { enabled ->
                            if (enabled) {
                                if (!AlarmScheduler.canSchedule(activity)) activity.requestExactAlarms()
                                else if (AlarmScheduler.schedule(activity, alarm.copy(enabled = true)))
                                    repo.update { s -> s.copy(alarms = s.alarms.map {
                                        if (it.id == alarm.id) it.copy(enabled = true) else it }) }
                                else activity.notifyUser("تاريخ المنبه قد مر. عدّل الموعد أولًا.")
                            } else {
                                AlarmScheduler.cancel(activity, alarm.id)
                                repo.update { s -> s.copy(alarms = s.alarms.map {
                                    if (it.id == alarm.id) it.copy(enabled = false) else it }) }
                            }
                        }
                    }
                }
            }
            if (!AlarmScheduler.canSchedule(activity)) item {
                DFCard { Text("المنبهات الدقيقة غير مسموح بها. افتح الإذن لتعمل المنبهات والهاتف مغلق.",
                    Modifier.fillMaxWidth().clickable { activity.requestExactAlarms() }.padding(14.dp), color = theme.accent, fontSize = 13.sp) }
            }
            if (!AlarmScheduler.canShowFullScreen(activity)) item {
                DFCard { Text("اسمح بعرض التنبيه على شاشة القفل من إعدادات أندرويد.",
                    Modifier.fillMaxWidth().clickable {
                        if (Build.VERSION.SDK_INT >= 34) activity.startActivity(
                            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:${activity.packageName}")))
                    }.padding(14.dp), color = theme.accent, fontSize = 13.sp) }
            }
        }
    }
    if (editing != null) AlarmEditor(editing!!, data, activity, onDismiss = { editing = null })
}

private fun daysLabel(a: AlarmEntry, lang: String): String = when {
    a.days.isEmpty() -> a.date ?: if (lang == "ar") "مرة واحدة" else "Once"
    a.days.size == 7 -> if (lang == "ar") "كل يوم" else "Every day"
    else -> week.filter { it in a.days }.joinToString(" · ") { if (lang == "ar") arDays[it] else enDays[it] }
}

@Composable
private fun AlarmEditor(initial: AlarmEntry, data: AppData, activity: MainActivity, onDismiss: () -> Unit) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var alarm by remember(initial.id) { mutableStateOf(initial) }
    var picker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = theme.surface) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            DFHeader(if (data.alarms.any { it.id == initial.id }) label("Edit alarm", "تعديل المنبه")
                else label("New alarm", "منبه جديد"))
            if (picker) {
                SoundPicker(alarm, activity, onPick = { title, uri ->
                    alarm = alarm.copy(soundTitle = title, soundUri = uri)
                    picker = false
                }, onBack = { picker = false })
            } else {
                DFCard(Modifier.fillMaxWidth(), onClick = { activity.showTime(alarm.time) { alarm = alarm.copy(time = it) } }) {
                    Text(displayTime(alarm.time, data.lang), color = theme.text, fontSize = 49.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth().padding(17.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    DFChip(label("One date", "يوم معيّن"), alarm.days.isEmpty()) {
                        val whenDate = if (LocalTime.parse(alarm.time).isAfter(LocalTime.now())) LocalDate.now() else LocalDate.now().plusDays(1)
                        alarm = alarm.copy(date = alarm.date ?: whenDate.toString(), days = emptySet())
                    }
                    DFChip(label("Sun-Thu", "الأحد-الخميس"), alarm.days == (0..4).toSet()) {
                        alarm = alarm.copy(days = (0..4).toSet(), date = null)
                    }
                    DFChip(label("Every day", "كل يوم"), alarm.days.size == 7) {
                        alarm = alarm.copy(days = (0..6).toSet(), date = null)
                    }
                }
                if (alarm.days.isEmpty()) DFButton(alarm.date ?: label("Choose date", "اختار يوم"), {
                    activity.showDate(alarm.date ?: LocalDate.now().toString()) { alarm = alarm.copy(date = it) }
                }, Modifier.fillMaxWidth(), soft = true)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    week.forEach { day -> DFChip(if (data.lang == "ar") arDays[day] else enDays[day], day in alarm.days) {
                        alarm = alarm.copy(days = if (day in alarm.days) alarm.days - day else alarm.days + day, date = null)
                    } }
                }
                DFField(alarm.label, { alarm = alarm.copy(label = it) }, label("Label (optional)", "الاسم (اختياري)"), Modifier.fillMaxWidth())
                DFCard(Modifier.fillMaxWidth(), onClick = { picker = true }) {
                    Column(Modifier.padding(14.dp)) {
                        Text(label("Sound", "الصوت"), color = theme.text)
                        Text(alarm.soundTitle, color = theme.muted, fontSize = 12.sp)
                    }
                }
                DFCard(Modifier.fillMaxWidth()) {
                    Column {
                        DFRow(label("Vibrate", "اهتزاز"), trailing = {
                            DFToggle(alarm.vibrate) { alarm = alarm.copy(vibrate = it) }
                        })
                        DFRow(label("Gentle wake", "استيقاظ لطيف"),
                            label("Volume rises over 60 seconds", "يرتفع الصوت خلال ٦٠ ثانية"), trailing = {
                            DFToggle(alarm.gentle) { alarm = alarm.copy(gentle = it) }
                        })
                        Row(Modifier.fillMaxWidth().padding(13.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label("Snooze", "الغفوة"), color = theme.text)
                            Text("${alarm.snooze} ${label("min", "د")}", color = theme.accent,
                                modifier = Modifier.clickable {
                                    alarm = alarm.copy(snooze = listOf(5, 10, 15, 20).let { list ->
                                        list[(list.indexOf(alarm.snooze) + 1).coerceAtLeast(0) % list.size]
                                    })
                                })
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = ColorRed, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (data.alarms.any { it.id == initial.id }) DFButton(label("Delete", "حذف"), {
                        AlarmScheduler.cancel(activity, alarm.id)
                        repo.update { it.copy(alarms = it.alarms.filterNot { a -> a.id == alarm.id }) }
                        onDismiss()
                    }, soft = true)
                    DFButton(label("Save", "حفظ"), {
                        val day = runCatching { LocalDate.parse(alarm.date) }.getOrNull()
                        if (alarm.days.isEmpty() && (day == null || !day.atTime(LocalTime.parse(alarm.time)).isAfter(java.time.LocalDateTime.now()))) {
                            error = "اختار تاريخًا ووقتًا في المستقبل"; return@DFButton
                        }
                        if (alarm.enabled && !AlarmScheduler.canSchedule(activity)) {
                            error = "اسمح بالمنبهات الدقيقة من إعدادات الهاتف ثم اضغط حفظ"
                            activity.requestExactAlarms(); return@DFButton
                        }
                        if (alarm.enabled && !AlarmScheduler.schedule(activity, alarm)) {
                            error = "تعذر جدولة هذا الموعد. اختر موعدًا في المستقبل."; return@DFButton
                        }
                        if (!alarm.enabled) AlarmScheduler.cancel(activity, alarm.id)
                        repo.update { s -> s.copy(alarms = if (s.alarms.any { it.id == alarm.id })
                            s.alarms.map { if (it.id == alarm.id) alarm else it } else s.alarms + alarm) }
                        activity.requestNotifications()
                        onDismiss()
                    }, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(22.dp))
        }
    }
}

private val ColorRed = androidx.compose.ui.graphics.Color(0xffbf4545)
private data class Tone(val title: String, val uri: String)

@Composable
private fun SoundPicker(alarm: AlarmEntry, activity: MainActivity,
                        onPick: (String, String) -> Unit, onBack: () -> Unit) {
    val theme = LocalPack.current
    var tones by remember { mutableStateOf<List<Tone>>(emptyList()) }
    var playing by remember { mutableStateOf<Ringtone?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { activity.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            onPick(uri.lastPathSegment?.substringAfterLast('/') ?: "ملف صوتي", uri.toString())
        }
    }
    LaunchedEffect(Unit) {
        tones = withContext(Dispatchers.IO) {
            val list = mutableListOf<Tone>()
            val manager = RingtoneManager(activity).apply {
                setType(RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_NOTIFICATION)
            }
            manager.cursor?.use { c ->
                var index = 0
                while (c.moveToNext()) {
                    val uri = manager.getRingtoneUri(index++) ?: continue
                    list += Tone(c.getString(RingtoneManager.TITLE_COLUMN_INDEX), uri.toString())
                }
            }
            list.distinctBy { it.uri }
        }
    }
    DisposableEffect(Unit) { onDispose { playing?.stop() } }
    DFHeader(label("Choose a sound", "اختر صوتًا"), onBack = onBack)
    DFChip(label("My files", "ملفاتي")) { picker.launch(arrayOf("audio/*")) }
    Text(label("Device tones", "نغمات الجهاز"), color = theme.muted, fontSize = 12.sp)
    LazyColumn(Modifier.fillMaxWidth().height(330.dp)) {
        val defaults = listOf(Tone("منبه الجهاز الافتراضي", ""))
        items(defaults.size + tones.size) { index ->
            val tone = (defaults + tones)[index]
            DFRow(tone.title, onClick = { playing?.stop(); onPick(tone.title, tone.uri) },
                trailing = {
                    Text("▷", modifier = Modifier.clickable {
                        playing?.stop()
                        if (tone.uri.isNotBlank()) playing = RingtoneManager.getRingtone(activity, Uri.parse(tone.uri))
                            ?.also { it.play() }
                    }, color = theme.accent)
                })
        }
    }
}