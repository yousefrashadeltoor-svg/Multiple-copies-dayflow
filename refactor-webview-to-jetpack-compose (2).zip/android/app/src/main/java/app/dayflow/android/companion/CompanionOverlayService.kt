package app.dayflow.android.companion

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.NotificationCenter
import app.dayflow.android.data.AppRepository
import kotlin.math.abs

class CompanionOverlayService : Service() {
    private lateinit var windows: WindowManager
    private var robot: RobotView? = null
    private var params: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val frame = object : Runnable {
        override fun run() {
            if (!AppRepository.get(this@CompanionOverlayService).state.value.reduceMotion) robot?.advance()
            if (robot != null) handler.postDelayed(this, 40)
        }
    }

    override fun onCreate() {
        super.onCreate()
        NotificationCenter.setup(this)
        startForeground(8352, statusNotification())
    }

    private fun statusNotification(): Notification {
        val stop = PendingIntent.getBroadcast(this, 8352,
            Intent(this, CompanionActionReceiver::class.java).setAction(CompanionActionReceiver.STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, NotificationCenter.COMPANION)
            .setSmallIcon(R.drawable.dayflow_icon)
            .setContentTitle("DAYFLOW")
            .setContentText("الرفيق العائم مفعل")
            .setContentIntent(NotificationCenter.open(this, "me/companion", 8352))
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إخفاء", stop).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val state = AppRepository.get(this).state.value
        if (intent?.action == CompanionActionReceiver.STOP || !state.companionEnabled || !state.companionVisible ||
            !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val size = (112 * state.companionSize * resources.displayMetrics.density).toInt().coerceAtLeast(72)
        val height = (154 * state.companionSize * resources.displayMetrics.density).toInt().coerceAtLeast(98)
        if (robot == null) attach(size, height, state.companionOpacity)
        else {
            params?.apply { width = size; this.height = height }
            robot?.alpha = state.companionOpacity
            robot?.mood = state.companionMood
            robot?.outfit = state.companionOutfit
            runCatching { windows.updateViewLayout(robot, params) }
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attach(width: Int, height: Int, opacity: Float) {
        windows = getSystemService(WindowManager::class.java)
        val prefs = getSharedPreferences("dayflow_overlay_position", Context.MODE_PRIVATE)
        val screen = resources.displayMetrics
        val p = WindowManager.LayoutParams(width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", screen.widthPixels - width - 10).coerceIn(0, (screen.widthPixels - width).coerceAtLeast(0))
            y = prefs.getInt("y", screen.heightPixels - height - 150).coerceIn(0, (screen.heightPixels - height).coerceAtLeast(0))
        }
        val view = RobotView(this).apply {
            alpha = opacity
            mood = AppRepository.get(this@CompanionOverlayService).state.value.companionMood
            outfit = AppRepository.get(this@CompanionOverlayService).state.value.companionOutfit
            contentDescription = "رفيق DAYFLOW. اضغط لفتح التطبيق، اسحب لتحريكه"
            setOnClickListener {
                startActivity(Intent(this@CompanionOverlayService, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_ROUTE, "ai")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
        }
        view.setOnTouchListener(object : View.OnTouchListener {
            var touchX = 0f; var touchY = 0f; var initialX = 0; var initialY = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { touchX = e.rawX; touchY = e.rawY; initialX = p.x; initialY = p.y; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - touchX) + abs(e.rawY - touchY) > 9) moved = true
                        if (moved) {
                            p.x = (initialX + (e.rawX - touchX).toInt()).coerceIn(0, (screen.widthPixels - p.width).coerceAtLeast(0))
                            p.y = (initialY + (e.rawY - touchY).toInt()).coerceIn(0, (screen.heightPixels - p.height).coerceAtLeast(0))
                            windows.updateViewLayout(view, p)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) v.performClick()
                        else prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
                        return true
                    }
                }
                return true
            }
        })
        params = p
        try { windows.addView(view, p); robot = view; handler.post(frame) }
        catch (_: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        robot?.let { runCatching { windows.removeView(it) } }
        robot = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

class CompanionActionReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != STOP) return
        AppRepository.get(context).update { it.copy(companionVisible = false) }
        context.stopService(Intent(context, CompanionOverlayService::class.java))
    }
    companion object { const val STOP = "app.dayflow.STOP_COMPANION" }
}