package app.dayflow.android.ui

import android.Manifest
import android.appwidget.AppWidgetManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.NotificationCenter
import app.dayflow.android.alarm.ReminderScheduler
import app.dayflow.android.companion.RobotView
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.Catalog
import app.dayflow.android.data.displayTime
import app.dayflow.android.prayer.PrayerClock
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.util.Locale

@Composable
fun MeScreen(sub: String, data: AppData, activity: MainActivity) {
    when (sub) {
        "themes" -> ThemesScreen(data, activity)
        "prayer" -> PrayerScreen(data, activity)
        "companion" -> CompanionSettings(data, activity)
        "notifs" -> NotificationSettings(data, activity)
        "decor" -> DecorationSettings(data, activity)
        "sounds" -> SoundsScreen(activity)
        "settings" -> SettingsScreen(data, activity)
        "backup" -> BackupScreen(activity)
        "review" -> ReviewScreen(data, activity)
        "alarmlook" -> AlarmLookSettings(data, activity)
        "widgetlook" -> WidgetLookSettings(activity)
        "ledger" -> LedgerScreen(activity)
        "about" -> AboutScreen(activity)
        else -> MeHome(data, activity)
    }
}

@Composable
private fun MeHome(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val packs = remember { Catalog.themes(activity) }
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
        item { DFHeader(label("Me", "أنا")) }
        item {
            DFCard(Modifier.fillMaxWidth().padding(bottom = 17.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    AndroidView(factory = { RobotView(it) }, update = {
                        it.mood = data.companionMood; it.outfit = data.companionOutfit
                    }, modifier = Modifier.size(52.dp, 65.dp))
                    Column {
                        Text("DAYFLOW", color = theme.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(label("Private · offline · on this device", "خاص · دون اتصال · على هذا الجهاز"),
                            color = theme.muted, fontSize = 12.sp)
                        Text((if (data.lang == "ar") theme.ar else theme.en), color = theme.accent, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            DFGroup(label("Insight", "رؤى")) {
                DFRow(label("Review", "المراجعة"), label("Daily, weekly and yearly", "يومي وأسبوعي وسنوي"),
                    onClick = { activity.go("me/review") })
                DFRow(label("AI assistant & API keys", "مساعد الذكاء ومفاتيح API"),
                    onClick = { activity.go("ai") })
            }
        }
        item {
            DFGroup(label("Look & feel", "المظهر")) {
                DFRow(label("Themes", "السمات"), "${packs.size} ${label("packs", "حزمة")}",
                    onClick = { activity.go("me/themes") })
                DFRow(label("Seasons & decoration", "المواسم والزينة"),
                    onClick = { activity.go("me/decor") })
                DFRow(label("Widgets", "الودجات"), "${Catalog.widgets(activity).size} ${label("designs", "تصميمًا")}",
                    onClick = { activity.go("me/widgets") })
                DFRow(label("Notifications", "الإشعارات"), onClick = { activity.go("me/notifs") })
                DFRow(label("Alarm screen", "شاشة المنبه"), onClick = { activity.go("me/alarmlook") })
                DFRow(label("Prayer times & city", "مواقيت الصلاة والمدينة"), onClick = { activity.go("me/prayer") })
                DFRow(label("Widget fonts & ornaments", "خطوط وزخارف الودجات"),
                    onClick = { activity.go("me/widgetlook") })
                DFRow(label("Sounds", "الأصوات"), onClick = { activity.go("me/sounds") })
                DFRow(label("Companion", "الرفيق"), onClick = { activity.go("me/companion") }, trailing = {
                    DFToggle(data.companionEnabled) { enabled ->
                        AppRepository.get(activity).update { it.copy(companionEnabled = enabled, companionVisible = enabled) }
                        if (enabled) activity.requestOverlay() else activity.stopOverlay()
                    }
                })
            }
        }
        item {
            DFGroup(label("Data & app", "البيانات والتطبيق")) {
                DFRow(label("Backup & restore", "النسخ الاحتياطي"), onClick = { activity.go("me/backup") })
                DFRow(label("Settings", "الإعدادات"), onClick = { activity.go("me/settings") })
                DFRow(label("Verification ledger", "سجل التحقق"), onClick = { activity.go("me/ledger") })
                DFRow(label("About & credits", "حول والاعتمادات"), onClick = { activity.go("me/about") })
            }
        }
    }
}

@Composable
private fun ThemesScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val packs = remember { Catalog.themes(activity) }
    var filter by remember { mutableStateOf("all") }
    val categories = listOf("all", "light", "dark", "egypt", "islamic", "nature", "glass", "tech", "warm", "playful")
    Column {
        DFHeader(label("Themes", "السمات"), "${packs.size} ${label("packs", "حزمة")}", onBack = { activity.go("me") })
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.forEach { cat -> DFChip(cat, filter == cat) { filter = cat } }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(packs.filter { filter == "all" || it.category == filter }) { pack ->
                DFCard(Modifier.fillMaxWidth(), onClick = {
                    AppRepository.get(activity).update { it.copy(themeId = pack.id, autoTimeTheme = false) }
                }) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(Modifier.size(55.dp).clip(RoundedCornerShape(15.dp))) {
                            Box(Modifier.weight(1f).height(55.dp).background(pack.bg))
                            Box(Modifier.weight(1f).height(55.dp).background(pack.accent))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(if (data.lang == "ar") pack.ar else pack.en,
                                color = theme.text, fontWeight = FontWeight.Bold)
                            Text("${pack.material} · ${pack.mode}", color = theme.muted, fontSize = 12.sp)
                        }
                        if (data.themeId == pack.id) Text("✓", color = theme.accent, fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun PrayerScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    val city = PrayerClock.city(data)
    val date = LocalDate.now(city.zone)
    val times = remember(city, date) { PrayerClock.localTimes(city, date) }
    val next = PrayerClock.next(city)
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item { DFHeader(label("Prayer times", "مواقيت الصلاة"), if (data.lang == "ar") city.ar else city.en,
            onBack = { activity.go("me") }) }
        item {
            DFCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(15.dp)) {
                    Text(label("Next prayer", "الصلاة القادمة"), color = theme.muted, fontSize = 12.sp)
                    Text("${if (data.lang == "ar") PrayerClock.names[next.first] else PrayerClock.englishNames[next.first]} · " +
                        displayTime(next.second.atZone(city.zone).toLocalTime().toString(), data.lang),
                        color = theme.text, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Spacer(Modifier.height(8.dp))
                    PrayerClock.names.forEachIndexed { i, name ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (data.lang == "ar") name else PrayerClock.englishNames[i], color = theme.text, fontSize = 13.sp)
                            Text(displayTime(times[i].toString(), data.lang), color = theme.text,
                                fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
        item {
            Text(label("City", "المدينة"), color = theme.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            PrayerClock.cities.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                    row.forEach { c -> DFChip(if (data.lang == "ar") c.ar else c.en,
                        !data.useLocation && data.cityId == c.id) {
                        repo.update { it.copy(cityId = c.id, useLocation = false) }
                    } }
                }
            }
        }
        item {
            DFButton(label("Use phone location", "استخدم موقع الهاتف"), { activity.requestLocation() }, Modifier.fillMaxWidth(), soft = true)
            if (data.useLocation) DFButton(label("Back to manual city", "العودة للمدينة المختارة"), {
                repo.update { it.copy(useLocation = false) }
            }, Modifier.fillMaxWidth(), soft = true)
        }
        item {
            Text(label("Egyptian General Authority of Survey: Fajr 19.5°, Isha 17.5°, Shafi'i Asr. " +
                "Uses the selected city's coordinates and time-zone database including daylight saving. Confirm with your local mosque if minutes differ.",
                "الهيئة المصرية العامة للمساحة: الفجر ١٩٫٥°، العشاء ١٧٫٥°، العصر الشافعي. تُستخدم إحداثيات المدينة وتوقيت المنطقة بما فيه الصيفي. راجع مسجدك المحلي عند اختلاف الدقائق."),
                color = theme.muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun CompanionSettings(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DFHeader(label("Companion", "الرفيق"), onBack = { activity.go("me") }) }
        item {
            DFCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AndroidView(factory = { RobotView(it) }, update = {
                        it.mood = data.companionMood; it.outfit = data.companionOutfit
                    }, modifier = Modifier.size(110.dp, 140.dp))
                    Text("DAYFLOW", color = theme.accent, fontSize = 12.sp)
                }
            }
        }
        item {
            DFGroup(label("Behaviour", "سلوكه")) {
                DFRow(label("Enable companion", "تفعيل الرفيق"), trailing = {
                    DFToggle(data.companionEnabled) { enabled ->
                        repo.update { it.copy(companionEnabled = enabled, companionVisible = enabled) }
                        if (enabled) activity.requestOverlay() else activity.stopOverlay()
                    }
                })
                DFRow(label("Temporarily hide", "إخفاء مؤقت"), trailing = {
                    DFToggle(!data.companionVisible) { hidden ->
                        repo.update { it.copy(companionVisible = !hidden) }
                        if (hidden) activity.stopOverlay() else activity.requestOverlay()
                    }
                })
                DFRow(label("Reminder messages", "رسائل التذكير"), trailing = {
                    DFToggle(data.companionBubbles) { value -> repo.update { it.copy(companionBubbles = value) } }
                })
            }
        }
        item {
            DFButton(label("Float over other apps", "اعرضه فوق كل الهاتف"), {
                activity.requestOverlay()
            }, Modifier.fillMaxWidth())
        }
        item {
            Text(label("Size", "الحجم"), color = theme.text, fontSize = 14.sp)
            Slider(value = data.companionSize, onValueChange = { size ->
                repo.update { it.copy(companionSize = size) }
            }, onValueChangeFinished = {
                if (Settings.canDrawOverlays(activity) && data.companionEnabled) activity.startOverlay()
            }, valueRange = .7f..1.5f)
            Text(label("Opacity", "الشفافية"), color = theme.text, fontSize = 14.sp)
            Slider(value = data.companionOpacity, onValueChange = { opacity ->
                repo.update { it.copy(companionOpacity = opacity) }
            }, onValueChangeFinished = {
                if (Settings.canDrawOverlays(activity) && data.companionEnabled) activity.startOverlay()
            }, valueRange = .35f..1f)
        }
        item {
            Text(label("Emotions", "الأحاسيس"), color = theme.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("idle" to "عادي", "happy" to "فرحان", "sad" to "زعلان", "cold" to "بردان",
                    "welcome" to "أهلا", "celebrate" to "مبسوط", "think" to "بيفكر", "wink" to "بيبصلك", "sleep" to "نايم")
                    .forEach { (id, name) -> DFChip(name, data.companionMood == id) {
                        repo.update { it.copy(companionMood = id) }
                        if (Settings.canDrawOverlays(activity) && data.companionEnabled) activity.startOverlay()
                    } }
            }
        }
        item {
            Text(label("Outfits", "الملابس والزينة"), color = theme.muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("auto" to "تلقائي موسمي", "gold" to "فانوس رمضان", "snow" to "شال الشتاء",
                    "national" to "شريط وطني", "none" to "بدون")
                    .forEach { (id, name) -> DFChip(name, data.companionOutfit == id) {
                        repo.update { it.copy(companionOutfit = id) }
                        if (Settings.canDrawOverlays(activity) && data.companionEnabled) activity.startOverlay()
                    } }
            }
        }
    }
}

@Composable
private fun NotificationSettings(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    Column {
        DFHeader(label("Notifications", "الإشعارات"), onBack = { activity.go("me") })
        LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
            item {
                DFGroup(label("Look", "الشكل")) {
                    DFRow(label("Show content in notification", "إظهار المحتوى في الإشعار"), trailing = {
                        DFToggle(data.notificationPreview) { value -> repo.update { it.copy(notificationPreview = value) } }
                    })
                    DFRow(label("Sound", "الصوت"), trailing = {
                        DFToggle(data.notificationSound) { value -> repo.update { it.copy(notificationSound = value) } }
                    })
                    DFRow(label("Vibration", "اهتزاز"), trailing = {
                        DFToggle(data.notificationVibrate) { value -> repo.update { it.copy(notificationVibrate = value) } }
                    })
                    DFRow(label("Quiet hours", "ساعات الهدوء"), "من ١١ مساء إلى ٧ صباحًا؛ لا تؤخر المنبهات", trailing = {
                        DFToggle(data.quietHours) { value ->
                            repo.update { it.copy(quietHours = value) }; ReminderScheduler.restore(activity)
                        }
                    })
                }
            }
            item {
                DFGroup(label("Review reminders", "تذكيرات المراجعة")) {
                    DFRow(label("Evening daily review", "مراجعة المسا"), trailing = {
                        Text(displayTime(data.dailyReview, data.lang), color = theme.accent,
                            modifier = Modifier.clickable { activity.showTime(data.dailyReview) { time ->
                                repo.update { it.copy(dailyReview = time) }; ReminderScheduler.restore(activity)
                            } })
                    })
                    DFRow(label("Weekly review", "المراجعة الأسبوعية (الجمعة)"), trailing = {
                        DFToggle(data.weeklyReview) { value ->
                            repo.update { it.copy(weeklyReview = value) }
                            if (!value) ReminderScheduler.cancel(activity, "review_weekly")
                            else ReminderScheduler.restore(activity)
                        }
                    })
                }
            }
            item {
                if (!NotificationCenter.canPost(activity)) DFButton(label("Enable notification permission", "اسمح بالإشعارات"),
                    { activity.requestNotifications() }, Modifier.fillMaxWidth(), soft = true)
                DFButton(label("Send a real test notification", "ابعت إشعار تجربة حقيقي"), {
                    if (!NotificationCenter.test(activity)) activity.requestNotifications()
                    else activity.notifyUser("تم إرسال الإشعار الحقيقي")
                }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun DecorationSettings(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var season by remember { mutableStateOf("spring") }
    val photos = mapOf("winter" to R.drawable.snow, "spring" to R.drawable.spring,
        "summer" to R.drawable.summer, "autumn" to R.drawable.autumn_tree,
        "ramadan" to R.drawable.fanous, "nile" to R.drawable.cairo_night)
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { DFHeader(label("Seasons & decoration", "المواسم والزينة"), onBack = { activity.go("me") }) }
        item {
            Text(label("Intensity", "الشدة"), color = theme.muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("off" to "إيقاف", "subtle" to "هادئ", "rich" to "غني", "festival" to "احتفالي")
                    .forEach { (id, name) -> DFChip(name, data.decorIntensity == id) {
                        repo.update { it.copy(decorIntensity = id) }
                    } }
            }
        }
        item {
            Text(label("Realistic season photography", "صور المواسم الحقيقية"), color = theme.text, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                photos.keys.forEach { name -> DFChip(name, name == season) { season = name } }
            }
        }
        item {
            Image(painterResource(photos[season]!!), null,
                Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop)
        }
        item {
            Text("الصور مُضمّنة داخل التطبيق وتعمل دون اتصال. تبقى أشكال الواجهة وألوانها من السمات الأصلية.",
                color = theme.muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingsScreen(data: AppData, activity: MainActivity) {
    val repo = AppRepository.get(activity)
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
        item { DFHeader(label("Settings", "الإعدادات"), onBack = { activity.go("me") }) }
        item {
            DFGroup(label("General", "عام")) {
                DFRow(label("Language", "اللغة"), trailing = {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        DFChip("EN", data.lang == "en") { repo.update { it.copy(lang = "en") } }
                        DFChip("ع", data.lang == "ar") { repo.update { it.copy(lang = "ar") } }
                    }
                })
                DFRow(label("12-hour clock", "الساعة بنظام ١٢ ساعة"),
                    label("Always on; saved schedules retain 24-hour internal time", "صيغة العرض الوحيدة؛ المواعيد تُحفظ داخليًا دون تغيير"),
                    trailing = { Text("ص / م", color = LocalPack.current.accent) })
                DFRow(label("Automatic time-of-day theme", "سمة الوقت التلقائية"), trailing = {
                    DFToggle(data.autoTimeTheme) { value -> repo.update { it.copy(autoTimeTheme = value) } }
                })
            }
        }
        item {
            DFGroup(label("Accessibility", "إمكانية الوصول")) {
                DFRow(label("Reduce motion", "تقليل الحركة"), trailing = {
                    DFToggle(data.reduceMotion) { value -> repo.update { it.copy(reduceMotion = value) } }
                })
            }
        }
    }
}

@Composable
private fun AlarmLookSettings(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DFHeader(label("Alarm screen", "شاشة المنبه"), onBack = { activity.go("me") })
        DFCard(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().height(250.dp), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center) {
                Text("المنبه", color = theme.muted)
                Text(displayTime("06:30", data.lang), color = theme.text, fontSize = 48.sp)
                Text("أيام العمل · استيقاظ لطيف", color = theme.muted, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("ornate" to "مزخرف", "midnight" to "ليل", "minimal" to "بسيط", "glass" to "زجاج")
                .forEach { (id, title) -> DFChip(title, data.alarmLayout == id) {
                    repo.update { it.copy(alarmLayout = id) }
                } }
        }
        DFGroup {
            DFRow(label("Show seconds", "إظهار الثواني"), trailing = {
                DFToggle(data.alarmSeconds) { value -> repo.update { it.copy(alarmSeconds = value) } }
            })
            DFRow(label("Seasonal gradient", "تدرج موسمي"), trailing = {
                DFToggle(data.alarmGradient) { value -> repo.update { it.copy(alarmGradient = value) } }
            })
        }
    }
}

@Composable
private fun SoundsScreen(activity: MainActivity) {
    val theme = LocalPack.current
    Column {
        DFHeader(label("Sounds", "الأصوات"), onBack = { activity.go("me") })
        DFGroup(label("Sources in the picker", "المصادر في المنتقي")) {
            DFRow(label("Device tones", "نغمات الجهاز"),
                label("RingtoneManager lists actual alarm/ringtone/notification sounds", "يعرض Android نغمات الجهاز الفعلية"),
                onClick = { activity.go("alarms") })
            DFRow(label("My files", "ملفاتي"), "منتقي ملفات أندرويد SAF؛ يحتفظ بإذن الوصول للنغمة",
                onClick = { activity.go("alarms") })
            DFRow(label("DAYFLOW library", "مكتبة DAYFLOW"), "٠ نغمات مضمّنة حتى مراجعة تراخيص الملفات")
        }
        Text("اختر النغمة من تعديل المنبه. لا تُنسخ نغمات الشركة المصنّعة إلى التطبيق.",
            color = theme.muted, fontSize = 12.sp)
    }
}

@Composable
private fun BackupScreen(activity: MainActivity) {
    val theme = LocalPack.current
    val repository = AppRepository.get(activity)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DFHeader(label("Backup & restore", "النسخ الاحتياطي"), onBack = { activity.go("me") })
        DFButton(label("Export backup", "تصدير نسخة احتياطية"), { activity.openExport() }, Modifier.fillMaxWidth())
        DFButton(label("Restore from file", "استعادة من ملف"), { activity.openImport() }, Modifier.fillMaxWidth(), soft = true)
        Text("يمكن استيراد ملف JSON الذي صدّرته من التطبيق القديم. تُحفظ البيانات الأصلية الكاملة ضمن النسخة الاحتياطية الجديدة لضمان عدم ضياع الحقول التي لم تُنقل بعد.",
            color = theme.muted, fontSize = 12.sp, lineHeight = 18.sp)
        if (repository.hasCorruptBackup) Text("احتُفظ بنسخة من البيانات التي تعذر قراءتها. لا تمسح التطبيق قبل تصديرها.",
            color = Color(0xffaa5555), fontSize = 12.sp)
    }
}

@Composable
private fun ReviewScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val tasks = data.tasks.filter { it.date == LocalDate.now().toString() }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        DFHeader(label("Review", "المراجعة"), onBack = { activity.go("me") })
        DFCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(17.dp)) {
                Text("اليوم", color = theme.accent, fontWeight = FontWeight.Bold)
                Text("${tasks.count { it.done }} / ${tasks.size} مهام مكتملة", color = theme.text, fontSize = 24.sp)
                Text("${data.habits.count { LocalDate.now().toString() in it.log }} / ${data.habits.size} عادات", color = theme.muted)
                Text("${data.water[LocalDate.now().toString()] ?: 0} ml ماء", color = theme.muted)
            }
        }
        Text("الملخص يعتمد على بياناتك الحقيقية على هذا الجهاز، ولا تُعرض درجة مراجعة مُولدة دون خوارزمية مكافئة للأصل.",
            color = theme.muted, fontSize = 12.sp)
    }
}

@Composable
private fun WidgetLookSettings(activity: MainActivity) {
    val theme = LocalPack.current
    Column {
        DFHeader(label("Widget fonts & ornaments", "خطوط وزخارف الودجات"), onBack = { activity.go("me") })
        DFCard(Modifier.fillMaxWidth()) { Text("خط الهاتف الأصلي · الوقت دائمًا بصيغة ١٢ ساعة.\nيختار Android الخط المتاح للودجت؛ الخطوط الإضافية تتطلب ملفات خطوط مرخّصة داخل التطبيق.",
            modifier = Modifier.padding(16.dp), color = theme.text, fontSize = 14.sp) }
    }
}

@Composable
private fun LedgerScreen(activity: MainActivity) {
    val theme = LocalPack.current
    Column {
        DFHeader(label("Verification ledger", "سجل التحقق"), onBack = { activity.go("me") })
        Text("المشروع الأصلي مرجع بصري. واجهة أندرويد الأساسية Jetpack Compose، وليست WebView.", color = theme.text)
        Text("راجع ANDROID_AUDIT_AR.md لمعرفة المنجز فعليًا وما يحتاج اختبارًا على هاتف حقيقي.",
            color = theme.muted, fontSize = 12.sp)
    }
}

@Composable
private fun AboutScreen(activity: MainActivity) {
    val theme = LocalPack.current
    Column {
        DFHeader(label("About & credits", "حول والاعتمادات"), onBack = { activity.go("me") })
        Text("DAYFLOW · Kotlin · Jetpack Compose · Android AlarmManager · Android App Widgets · DownloadManager · Adhan · Jsoup · OkHttp · Pexels photography · Noto Emoji (CC BY 4.0).",
            color = theme.text, fontSize = 14.sp)
    }
}