package app.dayflow.android.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.alarm.ReminderScheduler
import app.dayflow.android.data.AlarmEntry
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.ChatMessage
import app.dayflow.android.data.TaskEntry
import app.dayflow.android.data.today
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun AIScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        DFHeader(label("AI assistant", "مساعد DAYFLOW"),
            label("Local commands on this device", "أوامر محلية على هذا الجهاز"),
            action = { DFChip(label("New chat", "محادثة جديدة")) { repo.update { it.copy(chat = emptyList()) } } })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (data.chat.isEmpty()) item {
                DFCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("DAYFLOW", color = theme.accent, fontWeight = FontWeight.Bold)
                        Text("اسأل عن مهامك أو اكتب: ضيف مهمة قراءة، سجّل ٢٥٠ مل ماء. للمنبه حدّد اليوم والوقت صباحًا أو مساءً.",
                            color = theme.muted, fontSize = 13.sp)
                    }
                }
            }
            items(data.chat) { message ->
                DFCard(Modifier.fillMaxWidth(if (message.role == "user") .88f else 1f)) {
                    Text(message.text, Modifier.padding(13.dp), color = theme.text, fontSize = 14.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 11.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DFField(input, { input = it }, label("Say something...", "قول أي حاجة..."), Modifier.weight(1f), singleLine = false)
            DFButton(label("Send", "إرسال"), {
                val request = input.trim()
                if (request.isNotBlank()) {
                    val answer = localAnswer(request, data, activity)
                    repo.update { it.copy(chat = (it.chat + ChatMessage("user", request) + ChatMessage("assistant", answer)).takeLast(80)) }
                    input = ""
                }
            }, enabled = input.isNotBlank())
        }
    }
}

private fun normalizedDigits(text: String): String = text.map { c -> when (c) {
    in '٠'..'٩' -> ('0' + (c - '٠'))
    in '۰'..'۹' -> ('0' + (c - '۰'))
    else -> c
} }.joinToString("")

private fun localAnswer(raw: String, data: AppData, activity: MainActivity): String {
    val text = normalizedDigits(raw)
    val repo = AppRepository.get(activity)
    if (text.contains("مهامي") || text.contains("كم مهمة")) {
        val tasks = data.tasks.filter { it.date == today() }
        return "عندك ${tasks.count { !it.done }} مهام لسه للنهاردة من أصل ${tasks.size}."
    }
    if (text.contains("ماء") || text.contains("ماية") || text.contains("مايه")) {
        val amount = Regex("(\\d{2,4})").find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 250
        if (amount !in 1..5000) return "حدد كمية صحيحة من ١ إلى ٥٠٠٠ مل."
        repo.update { s -> s.copy(water = s.water + (today() to ((s.water[today()] ?: 0) + amount))) }
        return "سجّلت $amount مل ماء في يومك."
    }
    if (text.contains("منبه") || text.contains("المنبه")) {
        val match = Regex("(\\d{1,2})(?::(\\d{1,2}))?\\s*(صباح|الصبح|ص|مساء|بالليل|م|AM|PM)", RegexOption.IGNORE_CASE)
            .find(text) ?: return "عايز المنبه الساعة كام؟ اكتب مثلًا: منبه بكرة ٧ صباحًا أو ٧ مساءً."
        val hour = match.groupValues[1].toInt()
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        if (hour !in 1..12 || minute !in 0..59) return "الساعة لازم تكون من ١ إلى ١٢ والدقيقة من ٠ إلى ٥٩."
        val pm = match.groupValues[3].lowercase() in setOf("مساء", "بالليل", "م", "pm")
        val h24 = hour % 12 + if (pm) 12 else 0
        val date = when {
            text.contains("بكرة") || text.contains("غدا") || text.contains("غدًا") -> LocalDate.now().plusDays(1)
            text.contains("النهاردة") || text.contains("اليوم") -> LocalDate.now()
            text.contains("كل يوم") -> null
            else -> return "المنبه ده أنهي يوم؟ قول النهاردة أو بكرة أو كل يوم؛ مش هحفظ موعدًا تخمينيًا."
        }
        val time = LocalTime.of(h24, minute)
        if (date != null && !date.atTime(time).isAfter(java.time.LocalDateTime.now()))
            return "الميعاد ده فات؛ اختار يوم وساعة لسه جايين."
        if (!AlarmScheduler.canSchedule(activity)) {
            activity.requestExactAlarms()
            return "لازم تمنح إذن المنبهات الدقيقة الأول؛ لم يُحفظ المنبه عشان ما أقولش إنه اتعمل وهو مش مجدول."
        }
        val alarm = AlarmEntry(time = time.toString(), date = date?.toString(),
            days = if (date == null) (0..6).toSet() else emptySet(),
            label = "منبه من DAYFLOW", enabled = true)
        if (!AlarmScheduler.schedule(activity, alarm)) return "تعذر جدولة هذا الموعد."
        repo.update { it.copy(alarms = it.alarms + alarm) }
        activity.requestNotifications()
        return "اتعمل المنبه فعليًا وجُدول في أندرويد: ${app.dayflow.android.data.displayTime(time.toString())}${if (date != null) " يوم $date" else " كل يوم"}."
    }
    if (text.startsWith("ضيف مهمة") || text.startsWith("أضف مهمة") || text.startsWith("اعمل مهمة")) {
        val title = text.substringAfter("مهمة").trim()
        if (title.isBlank()) return "قولّي اسم المهمة عشان أسجلها."
        repo.update { it.copy(tasks = listOf(TaskEntry(title = title)) + it.tasks) }
        return "سجلت مهمة «$title» للنهاردة في المهام الفعلية."
    }
    return "أقدر أساعدك في المهام والمياه والمنبهات مباشرة على جهازك. طلبك ده محتاج نموذج ذكاء خارجي؛ لم أشغّل نموذجًا أو مفتاح API من غير إذنك."
}