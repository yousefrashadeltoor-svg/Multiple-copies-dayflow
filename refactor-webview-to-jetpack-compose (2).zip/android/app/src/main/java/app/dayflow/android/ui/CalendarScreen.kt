package app.dayflow.android.ui

import android.icu.text.DateFormat
import android.icu.util.ULocale
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.data.AppData
import app.dayflow.android.data.AppRepository
import app.dayflow.android.data.TaskEntry
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CalendarScreen(data: AppData, activity: MainActivity) {
    val theme = LocalPack.current
    val repo = AppRepository.get(activity)
    var month by remember { mutableStateOf(LocalDate.now().withDayOfMonth(1)) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    var entry by remember { mutableStateOf("") }
    val locale = if (data.lang == "ar") Locale("ar", "EG") else Locale.UK
    val offset = (month.dayOfWeek.value + 1) % 7
    val dates = List(offset) { null } + (1..month.lengthOfMonth()).map { month.withDayOfMonth(it) }
    LazyColumn(contentPadding = PaddingValues(bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            DFHeader(month.format(DateTimeFormatter.ofPattern("MMMM yyyy", locale)),
                action = {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        DFChip("‹") { month = month.minusMonths(1) }
                        DFChip(label("Today", "اليوم")) { month = LocalDate.now().withDayOfMonth(1) }
                        DFChip("›") { month = month.plusMonths(1) }
                    }
                })
        }
        item {
            DFCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        (0..6).forEach { day ->
                            Text(listOf("س", "ح", "ن", "ث", "ر", "خ", "ج")[day],
                                Modifier.weight(1f), color = theme.muted, fontSize = 11.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                    dates.chunked(7).forEach { week ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            (0..6).forEach { index ->
                                val day = week.getOrNull(index)
                                Box(Modifier.weight(1f).height(57.dp)
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(if (day == LocalDate.now()) theme.accent else if (day != null && day.monthValue == 9 && day.dayOfMonth == 11) theme.soft else Color.Transparent)
                                    .then(if (day != null) Modifier.clickable { selected = day } else Modifier),
                                    contentAlignment = Alignment.TopCenter) {
                                    if (day != null) Column(horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(top = 6.dp)) {
                                        Text(day.dayOfMonth.toString(), color = if (day == LocalDate.now()) Color.White else theme.text,
                                            fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                        Text(runCatching {
                                            java.time.chrono.HijrahDate.from(day).get(java.time.temporal.ChronoField.DAY_OF_MONTH).toString()
                                        }.getOrDefault(""), color = if (day == LocalDate.now()) Color.White.copy(alpha = .7f) else theme.muted,
                                            fontSize = 9.sp)
                                        if (data.tasks.any { it.date == day.toString() }) Text("•", color = theme.accent2, fontSize = 14.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(label("This month", "هذا الشهر"), color = theme.text, fontWeight = FontWeight.Bold)
            val holidays = listOf(1 to 1 to "رأس السنة الميلادية", 1 to 7 to "عيد الميلاد المجيد",
                4 to 25 to "عيد تحرير سيناء", 7 to 23 to "ثورة ٢٣ يوليو", 10 to 6 to "انتصارات أكتوبر")
            val current = holidays.filter { it.first.first == month.monthValue }
            if (current.isEmpty()) Text(label("No major occasions this month.", "لا مناسبات كبرى هذا الشهر."),
                fontSize = 14.sp, color = theme.muted)
            current.forEach { (md, name) -> DFCard(Modifier.fillMaxWidth().padding(top = 8.dp),
                onClick = { selected = month.withDayOfMonth(md.second) }) {
                Text("$name · ${md.second} ${month.format(DateTimeFormatter.ofPattern("MMMM", locale))}",
                    color = theme.text, modifier = Modifier.padding(15.dp))
            } }
        }
    }
    if (selected != null) ModalBottomSheet(onDismissRequest = { selected = null }, containerColor = theme.surface) {
        val day = selected!!
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(day.format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", locale)), color = theme.text,
                fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(calendarCaption(day), color = theme.muted, fontSize = 13.sp)
            Text(label("Tasks", "المهام"), color = theme.text, fontWeight = FontWeight.Bold)
            data.tasks.filter { it.date == day.toString() }.forEach { task ->
                Text("${if (task.done) "☑" else "□"}  ${task.title}", color = theme.text,
                    modifier = Modifier.fillMaxWidth().clickable { repo.update { s -> s.copy(tasks = s.tasks.map {
                        if (it.id == task.id) it.copy(done = !it.done) else it
                    }) } }.padding(9.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                DFField(entry, { entry = it }, label("Plan something for this day...", "خطط لشيء في هذا اليوم..."), Modifier.weight(1f))
                DFButton("+", { repo.update { it.copy(tasks = listOf(TaskEntry(title = entry.trim(), date = day.toString())) + it.tasks) }; entry = "" },
                    enabled = entry.isNotBlank())
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}