package app.dayflow.android.prayer

import app.dayflow.android.data.AppData
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

data class PrayerCity(
    val id: String, val ar: String, val en: String, val lat: Double, val lng: Double, val zone: ZoneId
)

object PrayerClock {
    val cities = listOf(
        PrayerCity("cairo", "القاهرة", "Cairo", 30.0444, 31.2357, ZoneId.of("Africa/Cairo")),
        PrayerCity("giza", "الجيزة", "Giza", 30.0131, 31.2089, ZoneId.of("Africa/Cairo")),
        PrayerCity("qalyubia", "القليوبية", "Qalyubia", 30.1786, 31.2064, ZoneId.of("Africa/Cairo")),
        PrayerCity("alexandria", "الإسكندرية", "Alexandria", 31.2001, 29.9187, ZoneId.of("Africa/Cairo")),
        PrayerCity("luxor", "الأقصر", "Luxor", 25.6872, 32.6396, ZoneId.of("Africa/Cairo")),
        PrayerCity("aswan", "أسوان", "Aswan", 24.0889, 32.8998, ZoneId.of("Africa/Cairo")),
        PrayerCity("suez", "السويس", "Suez", 29.9668, 32.5498, ZoneId.of("Africa/Cairo")),
        PrayerCity("sharm", "شرم الشيخ", "Sharm El-Sheikh", 27.9158, 34.3299, ZoneId.of("Africa/Cairo")),
        PrayerCity("makkah", "مكة المكرمة", "Makkah", 21.4225, 39.8262, ZoneId.of("Asia/Riyadh")),
        PrayerCity("madinah", "المدينة المنورة", "Madinah", 24.4686, 39.6142, ZoneId.of("Asia/Riyadh")),
        PrayerCity("dubai", "دبي", "Dubai", 25.2048, 55.2708, ZoneId.of("Asia/Dubai")),
        PrayerCity("london", "لندن", "London", 51.5074, -0.1278, ZoneId.of("Europe/London"))
    )
    val names = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
    val englishNames = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")

    fun city(data: AppData): PrayerCity {
        val manual = cities.firstOrNull { it.id == data.cityId } ?: cities.first()
        return if (data.useLocation && data.latitude != null && data.longitude != null &&
            data.latitude in -90.0..90.0 && data.longitude in -180.0..180.0
        ) PrayerCity("device", "موقعي", "My location", data.latitude, data.longitude, ZoneId.systemDefault())
        else manual
    }

    fun times(city: PrayerCity, date: LocalDate = LocalDate.now(city.zone)): List<Instant> {
        val params = CalculationMethod.EGYPTIAN.parameters.apply { madhab = Madhab.SHAFI }
        val clock = PrayerTimes(Coordinates(city.lat, city.lng),
            DateComponents(date.year, date.monthValue, date.dayOfMonth), params)
        return listOf(clock.fajr, clock.sunrise, clock.dhuhr, clock.asr, clock.maghrib, clock.isha)
            .map { it.toInstant() }
    }

    fun localTimes(city: PrayerCity, date: LocalDate = LocalDate.now(city.zone)): List<LocalTime> =
        times(city, date).map { it.atZone(city.zone).toLocalTime().withSecond(0).withNano(0) }

    fun next(city: PrayerCity, now: Instant = Instant.now()): Pair<Int, Instant> {
        val date = now.atZone(city.zone).toLocalDate()
        times(city, date).forEachIndexed { index, value -> if (value.isAfter(now)) return index to value }
        return 0 to times(city, date.plusDays(1)).first()
    }
}