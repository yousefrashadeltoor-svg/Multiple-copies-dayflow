package app.dayflow.android.alarm

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import app.dayflow.android.R
import app.dayflow.android.data.AlarmEntry
import app.dayflow.android.data.AppRepository

class AlarmRingingService : Service() {
    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var vibrator: Vibrator? = null
    private var focus: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id") ?: return START_NOT_STICKY
        val alarm = AppRepository.get(this).state.value.alarms.firstOrNull { it.id == id }
            ?: return START_NOT_STICKY
        NotificationCenter.setup(this)
        startForeground(AlarmReceiver.RING_NOTIFICATION, notification(alarm))
        stopAudio()
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DAYFLOW:alarm").apply { acquire(10 * 60_000L) }
        if (alarm.vibrate) {
            vibrator = if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
                else @Suppress("DEPRECATION") (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 550, 250, 550, 1000), 0))
        }
        startAudio(alarm)
        handler.postDelayed({ stopSelf() }, 10 * 60_000L)
        return START_NOT_STICKY
    }

    private fun notification(alarm: AlarmEntry): Notification {
        fun action(name: String, action: String, offset: Int): PendingIntent = PendingIntent.getBroadcast(
            this, alarm.id.hashCode() xor offset,
            Intent(this, AlarmReceiver::class.java).setAction(action).putExtra("id", alarm.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val ring = PendingIntent.getActivity(this, alarm.id.hashCode(),
            Intent(this, AlarmRingActivity::class.java).putExtra("id", alarm.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, NotificationCenter.ALARMS)
            .setSmallIcon(R.drawable.dayflow_icon)
            .setContentTitle("DAYFLOW")
            .setContentText(alarm.label.ifBlank { "المنبه يرن" })
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(ring)
            .apply { if (AlarmScheduler.canShowFullScreen(this@AlarmRingingService)) setFullScreenIntent(ring, true) }
            .addAction(android.R.drawable.ic_lock_idle_alarm, "غفوة", action("snooze", AlarmReceiver.SNOOZE, 9))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", action("dismiss", AlarmReceiver.DISMISS, 10))
            .build()
    }

    private fun startAudio(alarm: AlarmEntry) {
        val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        val audio = getSystemService(AudioManager::class.java)
        focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setAudioAttributes(attributes).build().also { audio.requestAudioFocus(it) }
        val selected = alarm.soundUri.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
        val default = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        for (uri in listOfNotNull(selected, default).distinct()) {
            try {
                player = MediaPlayer().apply {
                    setAudioAttributes(attributes)
                    setDataSource(this@AlarmRingingService, uri)
                    isLooping = true
                    prepare()
                    if (alarm.gentle) setVolume(.1f, .1f)
                    start()
                }
                if (alarm.gentle) {
                    val begun = System.currentTimeMillis()
                    fun rise() {
                        val volume = (.1f + .9f * ((System.currentTimeMillis() - begun) / 60_000f)).coerceAtMost(1f)
                        player?.setVolume(volume, volume)
                        if (volume < 1f && player?.isPlaying == true) handler.postDelayed(::rise, 1000)
                    }
                    handler.postDelayed(::rise, 1000)
                }
                return
            } catch (_: Exception) {
                player?.release()
                player = null
            }
        }
    }

    private fun stopAudio() {
        handler.removeCallbacksAndMessages(null)
        player?.runCatching { stop(); release() }
        player = null
        vibrator?.cancel()
        vibrator = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        focus?.let { getSystemService(AudioManager::class.java).abandonAudioFocusRequest(it) }
        focus = null
    }

    override fun onDestroy() {
        stopAudio()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}