package app.dayflow.android.ui

import android.app.DownloadManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.MainActivity
import app.dayflow.android.downloads.DownloadEntry
import app.dayflow.android.downloads.DownloadRepository
import app.dayflow.android.downloads.LinkAnalyzer
import app.dayflow.android.downloads.LinkPreview
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private fun bytes(value: Long?) = if (value == null || value <= 0) "" else when {
    value < 1_000_000 -> "${value / 1000} KB"
    value < 1_000_000_000 -> String.format(Locale.US, "%.1f MB", value / 1e6)
    else -> String.format(Locale.US, "%.2f GB", value / 1e9)
}

@Composable
fun DownloadsScreen(activity: MainActivity, sharedText: String) {
    val theme = LocalPack.current
    val repo = remember { DownloadRepository.get(activity) }
    val items by repo.items.collectAsState()
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<LinkPreview?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var selected by remember { mutableStateOf("") }

    fun analyze(text: String) {
        if (text.isBlank() || busy) return
        scope.launch {
            busy = true; error = ""; preview = null
            try {
                val result = LinkAnalyzer.analyze(text)
                preview = result
                selected = result.formats.firstOrNull()?.id.orEmpty()
            } catch (e: Exception) { error = "تعذر جلب المعاينة: ${e.message ?: "الموقع منع الطلب أو الشبكة غير متاحة"}" }
            finally { busy = false }
        }
    }
    LaunchedEffect(sharedText) {
        if (sharedText.isNotBlank()) {
            val incoming = Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(sharedText)?.value ?: sharedText
            url = incoming
            analyze(incoming)
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            repo.refresh()
            delay(if (items.any { it.status == DownloadManager.STATUS_RUNNING }) 1200 else 4000)
        }
    }
    val shown = items.filter { entry ->
        (search.isBlank() || (entry.title + entry.url).contains(search, true)) && when (filter) {
            "active" -> entry.status in setOf(DownloadManager.STATUS_PENDING, DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PAUSED)
            "done" -> entry.status == DownloadManager.STATUS_SUCCESSFUL
            "failed" -> entry.status == DownloadManager.STATUS_FAILED
            else -> true
        }
    }
    Column {
        DFHeader(label("Downloads", "التحميل"), "${items.size} ${label("items", "عنصر")}")
        LazyColumn(contentPadding = PaddingValues(bottom = 120.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            item {
                DFCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DFField(url, { url = it }, label("Paste a link...", "الصق الرابط..."), Modifier.weight(1f))
                            DFButton(label("Paste", "لصق"), {
                                val clip = activity.getSystemService(android.content.ClipboardManager::class.java)
                                    .primaryClip?.getItemAt(0)?.coerceToText(activity)?.toString().orEmpty()
                                if (clip.isNotBlank()) { url = clip; analyze(clip) }
                            }, soft = true)
                        }
                        DFButton(if (busy) label("Analyzing...", "جارٍ التحليل...") else label("Analyze", "تحليل"),
                            { analyze(url) }, Modifier.fillMaxWidth(), enabled = !busy && url.isNotBlank())
                        if (error.isNotBlank()) Text(error, color = androidx.compose.ui.graphics.Color(0xffbd4646), fontSize = 12.sp)
                        preview?.let { p ->
                            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (!p.thumbnail.isNullOrBlank()) AsyncImage(model = p.thumbnail,
                                    contentDescription = p.title, modifier = Modifier.size(90.dp),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                                Column(Modifier.weight(1f)) {
                                    Text(p.title, color = theme.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 3)
                                    Text(p.host, color = theme.muted, fontSize = 12.sp)
                                    p.author?.let { Text(it, color = theme.muted, fontSize = 12.sp) }
                                    p.size?.let { Text(bytes(it), color = theme.accent, fontSize = 11.sp) }
                                    p.durationSeconds?.let { Text("${it / 60}:${(it % 60).toString().padStart(2, '0')}",
                                        color = theme.muted, fontSize = 11.sp) }
                                }
                            }
                            p.description?.let { Text(it, color = theme.muted, fontSize = 12.sp,
                                maxLines = 4, overflow = TextOverflow.Ellipsis) }
                            p.filename?.let { Text("${label("File", "اسم الملف")}: $it", color = theme.muted, fontSize = 12.sp) }
                            p.mime?.let { Text("MIME: $it", color = theme.muted, fontSize = 11.sp) }
                            p.notice?.let { Text(it, color = theme.muted, fontSize = 12.sp) }
                            p.formats.forEach { f ->
                                DFCard(Modifier.fillMaxWidth(), onClick = { selected = f.id }) {
                                    Row(Modifier.fillMaxWidth().padding(9.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${if (selected == f.id) "◉" else "○"}  ${f.label} · ${f.detail}",
                                            color = theme.text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                        Text(bytes(f.size), color = theme.muted, fontSize = 11.sp)
                                    }
                                }
                            }
                            if (p.formats.isNotEmpty()) DFButton(label("Download", "تحميل"), {
                                val format = p.formats.firstOrNull { it.id == selected } ?: return@DFButton
                                runCatching { repo.enqueue(p, format) }
                                    .onSuccess { preview = null; url = ""; activity.notifyUser("بدأ تنزيل الملف فعليًا عبر مدير تنزيلات أندرويد") }
                                    .onFailure { activity.notifyUser("فشل بدء التنزيل: ${it.message}") }
                            }, Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            item { DFField(search, { search = it }, label("Search downloads", "ابحث في التنزيلات"), Modifier.fillMaxWidth()) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("all" to label("All", "الكل"), "active" to label("Active", "نشط"),
                        "done" to label("Done", "تم"), "failed" to label("Failed", "فشل"))
                        .forEach { (id, title) -> DFChip(title, filter == id) { filter = id } }
                }
            }
            if (shown.isEmpty()) item { DFEmpty(label("Nothing here yet", "لسه مفيش حاجة"),
                label("Paste or share a link to start.", "الصق رابط أو شاركه من أي تطبيق.")) }
            items(shown.size) { i -> DownloadRow(shown[i], repo, activity) }
        }
    }
}

@Composable
private fun DownloadRow(item: DownloadEntry, repo: DownloadRepository, activity: MainActivity) {
    val theme = LocalPack.current
    val status = when (item.status) {
        DownloadManager.STATUS_PENDING -> label("Queued", "في الانتظار")
        DownloadManager.STATUS_RUNNING -> label("Downloading", "بيتحمّل")
        DownloadManager.STATUS_PAUSED -> label("Waiting for network", "بانتظار الشبكة")
        DownloadManager.STATUS_SUCCESSFUL -> label("Done", "اكتمل")
        else -> label("Failed", "فشل")
    }
    DFCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(item.title, color = theme.text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2)
            Text(status + if (item.reason != 0 && item.status == DownloadManager.STATUS_FAILED) " · ${item.reason}" else "",
                color = theme.muted, fontSize = 11.sp)
            if (item.status in listOf(DownloadManager.STATUS_RUNNING, DownloadManager.STATUS_PAUSED)) {
                LinearProgressIndicator(progress = { if (item.total > 0) (item.bytes.toFloat() / item.total).coerceIn(0f, 1f) else 0f },
                    modifier = Modifier.fillMaxWidth(), color = theme.accent, trackColor = theme.soft)
                Text("${bytes(item.bytes)}${item.total.takeIf { it > 0 }?.let { " / " + bytes(it) } ?: ""}",
                    color = theme.muted, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (item.status == DownloadManager.STATUS_SUCCESSFUL) DFButton(label("Open", "فتح"), {
                    if (!repo.open(item.id)) activity.notifyUser("لا يوجد تطبيق يستطيع فتح هذا النوع من الملفات")
                }, soft = true)
                if (item.status == DownloadManager.STATUS_FAILED) DFButton(label("Retry", "إعادة المحاولة"), {
                    activity.notifyUser("الصيغة تحتاج تحليلًا جديدًا للتحقق من الرابط المنتهي. الصق الرابط مجددًا.")
                }, soft = true)
                DFButton(label("Remove", "إزالة"), { repo.cancel(item.id) }, soft = true)
            }
        }
    }
}