package app.dayflow.android.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.ThemePack

val LocalPack = compositionLocalOf<ThemePack> { error("DAYFLOW theme not provided") }
val LocalLang = compositionLocalOf { "ar" }

@Composable fun label(en: String, ar: String) = if (LocalLang.current == "ar") ar else en

@Composable
fun DFCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val theme = LocalPack.current
    val border = if (theme.material == "flat" || theme.material == "matte") null
        else BorderStroke(1.dp, theme.text.copy(alpha = .09f))
    Surface(modifier = modifier, color = theme.surface, contentColor = theme.text,
        shape = RoundedCornerShape(24.dp), border = border, onClick = onClick ?: {},
        enabled = onClick != null, content = content)
}

@Composable
fun DFHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null,
             action: (@Composable () -> Unit)? = null) {
    val theme = LocalPack.current
    Row(Modifier.fillMaxWidth().background(theme.bg.copy(alpha = .96f))
        .padding(top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        if (onBack != null) IconButton(onClick = onBack, modifier = Modifier.size(38.dp)) {
            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = label("Back", "رجوع"), tint = theme.text)
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrBlank()) Text(subtitle, fontSize = 12.sp, color = theme.muted,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        action?.invoke()
    }
}

@Composable
fun DFButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
             soft: Boolean = false, enabled: Boolean = true) {
    val theme = LocalPack.current
    Button(onClick = onClick, modifier = modifier.height(44.dp), enabled = enabled,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (soft) theme.soft else theme.accent,
            contentColor = if (soft) theme.text else Color.White,
            disabledContainerColor = theme.soft, disabledContentColor = theme.muted),
        elevation = null) { Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
fun DFChip(text: String, active: Boolean = false, onClick: () -> Unit) {
    val theme = LocalPack.current
    Surface(onClick = onClick, shape = CircleShape, color = if (active) theme.accent else theme.surface,
        border = if (active) null else BorderStroke(1.dp, theme.text.copy(alpha = .12f))) {
        Text(text, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            color = if (active) Color.White else theme.text, maxLines = 1)
    }
}

@Composable
fun DFField(value: String, onValueChange: (String) -> Unit, hint: String,
            modifier: Modifier = Modifier, singleLine: Boolean = true) {
    val theme = LocalPack.current
    OutlinedTextField(value = value, onValueChange = onValueChange, modifier = modifier,
        singleLine = singleLine, placeholder = { Text(hint, color = theme.muted, fontSize = 14.sp) },
        textStyle = androidx.compose.ui.text.TextStyle(color = theme.text, fontSize = 15.sp),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = theme.soft, unfocusedContainerColor = theme.soft,
            focusedBorderColor = theme.accent, unfocusedBorderColor = theme.text.copy(alpha = .1f),
            cursorColor = theme.accent))
}

@Composable
fun DFToggle(value: Boolean, onChange: (Boolean) -> Unit) {
    val theme = LocalPack.current
    Switch(value, onChange, colors = SwitchDefaults.colors(
        checkedTrackColor = theme.accent, checkedThumbColor = Color.White,
        uncheckedTrackColor = theme.soft, uncheckedThumbColor = Color.White,
        uncheckedBorderColor = theme.text.copy(alpha = .16f)))
}

@Composable
fun DFGroup(title: String? = null, content: @Composable () -> Unit) {
    val theme = LocalPack.current
    Column(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
        if (title != null) Text(title, color = theme.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        DFCard(Modifier.fillMaxWidth()) { Column { content() } }
    }
}

@Composable
fun DFRow(title: String, hint: String? = null, onClick: (() -> Unit)? = null,
          trailing: (@Composable () -> Unit)? = null) {
    val theme = LocalPack.current
    Row(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
        .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, color = theme.text, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            if (!hint.isNullOrBlank()) Text(hint, color = theme.muted, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (trailing != null) trailing()
        else if (onClick != null) Icon(Icons.Outlined.ChevronLeft, null, tint = theme.muted, modifier = Modifier.size(18.dp))
    }
    HorizontalDivider(color = theme.text.copy(alpha = .07f), thickness = .5.dp)
}

@Composable
fun DFEmpty(title: String, hint: String, action: (@Composable () -> Unit)? = null) {
    val theme = LocalPack.current
    Column(Modifier.fillMaxWidth().padding(vertical = 36.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("✦", color = theme.accent2, fontSize = 62.sp)
        Text(title, color = theme.text, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(hint, color = theme.muted, fontSize = 14.sp)
        if (action != null) { Spacer(Modifier.height(16.dp)); action() }
    }
}