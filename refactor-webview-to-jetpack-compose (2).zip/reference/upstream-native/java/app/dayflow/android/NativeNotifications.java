package app.dayflow.android;
import android.app.*;
import android.content.*;
import android.os.Build;
public final class NativeNotifications {
 private NativeNotifications() {}
 static void channel(Context c,String id,String name,int importance) {
  if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm.getNotificationChannel(id)==null) nm.createNotificationChannel(new NotificationChannel(id,name,importance)); }
 }
 public static void show(Context c,String title,String body,String channel,int id){
  channel(c,channel,"DAYFLOW reminders",NotificationManager.IMPORTANCE_DEFAULT);
  Intent open=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
  PendingIntent pi=open==null?null:PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
  b.setSmallIcon(c.getApplicationInfo().icon).setContentTitle(title).setContentText(body).setAutoCancel(true);
  if(pi!=null)b.setContentIntent(pi);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
 }
 public static void showAlarm(Context c,String label,String id){
  channel(c,"dayflow_alarms","DAYFLOW alarms",NotificationManager.IMPORTANCE_HIGH);
  Intent open=new Intent(c,AlarmRingActivity.class).putExtra("label",label).putExtra("alarmId",id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
  PendingIntent pi=PendingIntent.getActivity(c,(id==null?0:id.hashCode()),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"dayflow_alarms"):new Notification.Builder(c);
  b.setSmallIcon(c.getApplicationInfo().icon).setContentTitle(label).setContentText("Alarm is ringing").setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setFullScreenIntent(pi,true).setContentIntent(pi).setOngoing(true);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id==null?7100:id.hashCode(),b.build());
 }
}
