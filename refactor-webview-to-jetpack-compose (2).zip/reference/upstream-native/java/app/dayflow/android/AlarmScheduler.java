package app.dayflow.android;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public final class AlarmScheduler {
    private AlarmScheduler() {}
    static void saveAndSchedule(Context c, JSONObject data) throws Exception {
        String id = data.getString("id");
        c.getSharedPreferences("dayflow_native", 0).edit().putString("alarm_" + id, data.toString()).apply();
        schedule(c, data);
    }
    static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, id, null, PendingIntent.FLAG_NO_CREATE);
        if (pi != null) { am.cancel(pi); pi.cancel(); }
        c.getSharedPreferences("dayflow_native", 0).edit().remove("alarm_" + id).apply();
    }
    static void schedule(Context c, JSONObject data) throws Exception {
        String id = data.getString("id");
        if (!data.optBoolean("enabled", true)) { cancel(c, id); return; }
        Calendar next = nextTime(data);
        Intent intent = new Intent(c, AlarmReceiver.class).putExtra("id", id).putExtra("label", data.optString("label", "DAYFLOW alarm"))
                .putExtra("vibrate", data.optBoolean("vibrate", true)).putExtra("snooze", data.optInt("snooze", 10))
                .putExtra("soundUri", data.optString("soundUri", ""));
        PendingIntent pi = pending(c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) {
            AlarmManager.AlarmClockInfo info = new AlarmManager.AlarmClockInfo(next.getTimeInMillis(), pi);
            am.setAlarmClock(info, pi);
        } else am.setExact(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
    }
    private static PendingIntent pending(Context c, String id, Intent intent, int flags) {
        int request = id.hashCode() & 0x7fffffff;
        return PendingIntent.getBroadcast(c, request, intent == null ? new Intent(c, AlarmReceiver.class).putExtra("id", id) : intent, flags);
    }
    static Calendar nextTime(JSONObject data) throws Exception {
        String[] hm = data.getString("time").split(":");
        Calendar now = Calendar.getInstance(); Calendar candidate = Calendar.getInstance();
        candidate.set(Calendar.SECOND, 0); candidate.set(Calendar.MILLISECOND, 0);
        candidate.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hm[0])); candidate.set(Calendar.MINUTE, Integer.parseInt(hm[1]));
        String date = data.optString("date", "");
        JSONArray days = data.optJSONArray("days");
        if (!date.isEmpty() && (days == null || days.length() == 0)) {
            String[] ymd = date.split("-"); candidate.set(Integer.parseInt(ymd[0]), Integer.parseInt(ymd[1])-1, Integer.parseInt(ymd[2]));
            if (!candidate.after(now)) throw new IllegalArgumentException("Alarm time has passed");
            return candidate;
        }
        if (days == null || days.length() == 0) throw new IllegalArgumentException("One-time alarm needs a date");
        for (int add = 0; add <= 7; add++) {
            Calendar c = (Calendar)candidate.clone(); c.add(Calendar.DAY_OF_YEAR, add);
            int jsDay = c.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY;
            boolean match = false;
            for (int i=0;i<days.length();i++) if (days.optInt(i,-1)==jsDay) match=true;
            if (match && c.after(now)) return c;
        }
        throw new IllegalArgumentException("No next alarm occurrence found");
    }
    static void reschedule(Context c, String id) {
        String raw = c.getSharedPreferences("dayflow_native",0).getString("alarm_"+id,null);
        if (raw == null) return;
        try { schedule(c,new JSONObject(raw)); } catch (Exception ignored) {}
    }
    static void restoreAll(Context c) {
        for (String key : c.getSharedPreferences("dayflow_native",0).getAll().keySet()) {
            if (!key.startsWith("alarm_")) continue;
            String raw = c.getSharedPreferences("dayflow_native",0).getString(key,null);
            try { if (raw != null) schedule(c,new JSONObject(raw)); } catch (Exception ignored) {}
        }
    }
}
