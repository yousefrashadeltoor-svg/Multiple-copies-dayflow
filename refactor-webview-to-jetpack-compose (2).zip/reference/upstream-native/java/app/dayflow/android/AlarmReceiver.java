package app.dayflow.android;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class AlarmReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context, Intent intent) {
  String id=intent.getStringExtra("id"), label=intent.getStringExtra("label");
  NativeNotifications.showAlarm(context, label == null ? "DAYFLOW alarm" : label, id);
  if (id != null) AlarmScheduler.reschedule(context,id);
 }
}
