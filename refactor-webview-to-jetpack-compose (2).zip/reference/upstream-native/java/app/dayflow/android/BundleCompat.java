package app.dayflow.android;
import android.content.Context;
public final class BundleCompat {
    private BundleCompat() {}
    public static void putString(Context context, String key, String value) { context.getSharedPreferences("dayflow_native", Context.MODE_PRIVATE).edit().putString(key, value).apply(); }
}
