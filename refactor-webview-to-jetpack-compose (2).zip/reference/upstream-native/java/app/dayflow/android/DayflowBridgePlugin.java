package app.dayflow.android;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AppWidgetManager;
import android.app.DownloadManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.webkit.URLUtil;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Locale;

@CapacitorPlugin(name = "DayflowBridge")
public class DayflowBridgePlugin extends Plugin {
    private static final String PREFS = "dayflow_native";

    @PluginMethod public void scheduleAlarm(PluginCall call) {
        try {
            JSONObject data = call.getData();
            AlarmScheduler.saveAndSchedule(getContext(), data);
            JSObject out = new JSObject(); out.put("scheduled", true); call.resolve(out);
        } catch (SecurityException e) {
            call.reject("Exact alarm permission is not granted", "EXACT_ALARM_PERMISSION", e);
        } catch (Exception e) { call.reject("Unable to schedule alarm: " + e.getMessage(), e); }
    }

    @PluginMethod public void cancelAlarm(PluginCall call) {
        String id = call.getString("id", "");
        AlarmScheduler.cancel(getContext(), id);
        JSObject out = new JSObject(); out.put("cancelled", true); call.resolve(out);
    }

    @PluginMethod public void getDeviceTones(PluginCall call) {
        JSArray tones = new JSArray();
        RingtoneManager manager = new RingtoneManager(getContext());
        manager.setType(RingtoneManager.TYPE_ALARM | RingtoneManager.TYPE_RINGTONE | RingtoneManager.TYPE_NOTIFICATION);
        Cursor cursor = manager.getCursor();
        if (cursor != null) {
            int index = 0;
            while (cursor.moveToNext()) {
                Uri uri = manager.getRingtoneUri(index++);
                if (uri == null) continue;
                JSObject item = new JSObject();
                item.put("title", cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX));
                item.put("uri", uri.toString());
                item.put("type", "device");
                tones.put(item);
            }
            cursor.close();
        }
        JSObject out = new JSObject(); out.put("tones", tones); call.resolve(out);
    }

    @PluginMethod public void requestOverlayPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(getContext())) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getContext().getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(intent);
        }
        call.resolve();
    }

    @PluginMethod public void startCompanionOverlay(PluginCall call) {
        boolean enabled = call.getBoolean("enabled", true);
        if (!enabled) {
            getContext().stopService(new Intent(getContext(), CompanionOverlayService.class));
            JSObject out = new JSObject(); out.put("hasPermission", true); call.resolve(out); return;
        }
        boolean allowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(getContext());
        JSObject out = new JSObject(); out.put("hasPermission", allowed);
        if (allowed) {
            Intent intent = new Intent(getContext(), CompanionOverlayService.class);
            intent.putExtra("size", call.getInt("size", 100));
            intent.putExtra("opacity", call.getDouble("opacity", 1.0));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getContext().startForegroundService(intent); else getContext().startService(intent);
        }
        call.resolve(out);
    }

    @PluginMethod public void pinWidget(PluginCall call) {
        JSObject out = new JSObject();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AppWidgetManager manager = AppWidgetManager.getInstance(getContext());
            android.content.ComponentName provider = new android.content.ComponentName(getContext(), DayflowWidgetProvider.class);
            boolean supported = manager.isRequestPinAppWidgetSupported();
            if (supported) {
                BundleCompat.putString(getContext(), "widget_design", call.getString("designId", "today"));
                out.put("pinned", manager.requestPinAppWidget(provider, null, null));
            } else out.put("pinned", false);
        } else out.put("pinned", false);
        call.resolve(out);
    }

    @PluginMethod public void openWidgetHub(PluginCall call) { call.resolve(); }

    @PluginMethod public void analyzeLink(PluginCall call) {
        String raw = call.getString("url", "");
        if (raw.isEmpty()) { call.reject("URL is required"); return; }
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(raw);
                connection = (HttpURLConnection) url.openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
                connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,*/*;q=0.8");
                int status = connection.getResponseCode();
                String type = connection.getContentType();
                String disposition = connection.getHeaderField("Content-Disposition");
                long length = connection.getContentLengthLong();
                String finalUrl = connection.getURL().toString();
                String title = URLUtil.guessFileName(finalUrl, disposition, type);
                String image = "", description = "", site = "";
                if (type != null && type.toLowerCase(Locale.ROOT).contains("text/html") && status >= 200 && status < 400) {
                    StringBuilder html = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                        String line; int total = 0;
                        while ((line = reader.readLine()) != null && total < 700000) { html.append(line).append('\n'); total += line.length(); }
                    }
                    String page = html.toString();
                    title = meta(page, "og:title"); if (title.isEmpty()) title = tag(page, "title");
                    image = meta(page, "og:image"); if (image.isEmpty()) image = meta(page, "twitter:image");
                    description = meta(page, "og:description"); if (description.isEmpty()) description = meta(page, "description");
                    site = meta(page, "og:site_name");
                }
                JSONObject result = new JSONObject();
                result.put("url", finalUrl); result.put("title", title); result.put("thumbnail", image);
                result.put("description", description); result.put("site", site); result.put("mimeType", type == null ? "" : type);
                result.put("size", length); result.put("status", status); result.put("direct", type != null && !type.toLowerCase(Locale.ROOT).contains("text/html"));
                JSObject out = new JSObject(); out.put("json", result.toString()); call.resolve(out);
            } catch (Exception e) { call.reject("Link analysis failed: " + e.getMessage(), e); }
            finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private String meta(String html, String key) {
        String[] patterns = {"(?is)<meta[^>]+property=[\\\"']" + key + "[\\\"'][^>]+content=[\\\"']([^\\\"']*)", "(?is)<meta[^>]+name=[\\\"']" + key + "[\\\"'][^>]+content=[\\\"']([^\\\"']*)"};
        for (String p : patterns) { java.util.regex.Matcher m = java.util.regex.Pattern.compile(p).matcher(html); if (m.find()) return android.text.Html.fromHtml(m.group(1), 0).toString().trim(); }
        return "";
    }
    private String tag(String html, String name) { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?is)<" + name + "[^>]*>(.*?)</" + name + ">").matcher(html); return m.find() ? android.text.Html.fromHtml(m.group(1), 0).toString().trim() : ""; }

    @PluginMethod public void enqueueDownload(PluginCall call) { directDownload(call); }
    @PluginMethod public void startDownload(PluginCall call) { directDownload(call); }
    private void directDownload(PluginCall call) {
        String url = call.getString("url", "");
        String name = call.getString("name", "download");
        if (url.isEmpty()) { call.reject("URL is required"); return; }
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(name); request.setDescription("DAYFLOW download");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true); request.setAllowedOverRoaming(false);
            request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, name);
            long id = ((DownloadManager)getContext().getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(request);
            JSObject out = new JSObject(); out.put("downloadId", id); out.put("queued", true); call.resolve(out);
        } catch (Exception e) { call.reject("Android could not queue this direct file: " + e.getMessage(), e); }
    }
    @PluginMethod public void pauseDownload(PluginCall call) { call.reject("Pause is not supported by Android DownloadManager for this item"); }
    @PluginMethod public void cancelDownload(PluginCall call) { call.resolve(); }
    @PluginMethod public void updateEngines(PluginCall call) { call.reject("Media extraction engines are not bundled in this build; no engine update was performed"); }
    @PluginMethod public void openSniffer(PluginCall call) { call.reject("In-app media sniffing is not implemented in this native build"); }
    @PluginMethod public void showNotification(PluginCall call) {
        String title = call.getString("title", "DAYFLOW"); String body = call.getString("body", "You have a reminder");
        NativeNotifications.show(getContext(), title, body, "dayflow_reminders", 4101);
        call.resolve();
    }
    @PluginMethod public void getPendingShare(PluginCall call) { JSObject out = new JSObject(); out.put("text", ""); call.resolve(out); }
    @PluginMethod public void syncState(PluginCall call) {
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("state", call.getString("json", "{}")).apply();
        call.resolve();
    }
}
