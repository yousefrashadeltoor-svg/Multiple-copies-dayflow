package app.dayflow.android;
import android.appwidget.*;import android.content.*;import android.widget.RemoteViews;
public class DayflowWidgetProvider extends AppWidgetProvider {
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.dayflow_widget);v.setTextViewText(R.id.widget_title,"DAYFLOW");v.setTextViewText(R.id.widget_body,"Your day at a glance");Intent i=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());if(i!=null){PendingIntent p=PendingIntent.getActivity(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);v.setOnClickPendingIntent(R.id.widget_root,p);}m.updateAppWidget(id,v);}}
}
