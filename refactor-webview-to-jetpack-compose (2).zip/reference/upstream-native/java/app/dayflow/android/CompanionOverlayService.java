package app.dayflow.android;
import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

public class CompanionOverlayService extends Service {
 private WindowManager wm; private View bubble;
 @Override public void onCreate(){super.onCreate(); startForeground(9201,foreground());}
 private Notification foreground(){
  if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("dayflow_companion","DAYFLOW companion",NotificationManager.IMPORTANCE_LOW));}
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"dayflow_companion"):new Notification.Builder(this);
  b.setSmallIcon(getApplicationInfo().icon).setContentTitle("DAYFLOW companion").setContentText("Floating companion is active").setOngoing(true);
  return b.build();
 }
 @Override public int onStartCommand(Intent intent,int flags,int startId){
  if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
  if(bubble==null) createBubble(intent); return START_STICKY;
 }
 private void createBubble(Intent intent){
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  int size=intent==null?100:intent.getIntExtra("size",100);
  float opacity=intent==null?1f:(float)intent.getDoubleExtra("opacity",1.0);
  TextView v=new TextView(this); v.setText("DAYFLOW");v.setTextColor(0xffffffff);v.setTextSize(12);v.setGravity(17);v.setBackgroundColor(0xdd20242b);v.setAlpha(Math.max(.25f,Math.min(1f,opacity)));
  WindowManager.LayoutParams p=new WindowManager.LayoutParams(Math.max(72,Math.min(180,size)),Math.max(56,Math.min(180,size)),Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
  p.gravity=Gravity.TOP|Gravity.END;p.x=16;p.y=220;
  v.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View view,MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;return true;}if(e.getAction()==2){p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(v,p);return true;}if(e.getAction()==1){if(Math.abs(e.getRawX()-sx)<12&&Math.abs(e.getRawY()-sy)<12){Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}}return true;}return false;}});
  bubble=v;wm.addView(bubble,p);
 }
 @Override public void onDestroy(){if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
