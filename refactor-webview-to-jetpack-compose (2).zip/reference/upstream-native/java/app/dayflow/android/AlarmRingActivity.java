package app.dayflow.android;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;
public class AlarmRingActivity extends Activity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags( WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);String label=getIntent().getStringExtra("label");LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setGravity(Gravity.CENTER);l.setPadding(32,32,32,32);TextView t=new TextView(this);t.setText(label==null?"DAYFLOW":label);t.setTextSize(28);Button stop=new Button(this);stop.setText("Dismiss");stop.setOnClickListener(v->{finish();});l.addView(t);l.addView(stop);setContentView(l);}
}
