package app.dayflow.android.domain

import app.dayflow.android.R
import app.dayflow.android.data.Intensity
import app.dayflow.android.data.Lang
import app.dayflow.android.data.UserDay
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import kotlin.math.floor

enum class DecorFamily(
    val id: String,
    val c1: Long,
    val c2: Long,
    val c3: Long,
    val en: String,
    val ar: String,
    val motion: String, // fall | float | drift
    val sprites: List<Int>,
    val cornerRes: Int,
    val backdropRes: Int?
) {
    AUTUMN(
        "autumn", 0xFFC25B28, 0xFFE39E46, 0xFFFAEAD4, "Autumn leaves", "أوراق الخريف", "fall",
        listOf(R.drawable.decor_maple, R.drawable.decor_fallen, R.drawable.decor_acorn, R.drawable.decor_wind),
        R.drawable.decor_maple, R.drawable.photo_autumn_tree
    ),
    WINTER(
        "winter", 0xFF3E6F9C, 0xFF8BB5D9, 0xFFE6F1FA, "Snowflakes", "بلورات الثلج", "fall",
        listOf(R.drawable.decor_snow, R.drawable.decor_pine, R.drawable.decor_snow, R.drawable.decor_sparkle),
        R.drawable.decor_snowman, R.drawable.photo_snow
    ),
    SPRING(
        "spring", 0xFFD95B82, 0xFFF2A2BA, 0xFFFCE8EF, "Spring blossoms", "تفتح الربيع", "drift",
        listOf(R.drawable.decor_blossom, R.drawable.decor_tulip, R.drawable.decor_herb, R.drawable.decor_blossom),
        R.drawable.decor_tulip, R.drawable.photo_spring_blossom
    ),
    SUMMER(
        "summer", 0xFF1883A8, 0xFF63C5DA, 0xFFE1F6FA, "Sea waves", "موج الصيف", "float",
        listOf(R.drawable.decor_wave, R.drawable.decor_sparkle, R.drawable.decor_star),
        R.drawable.decor_wave, R.drawable.photo_noon
    ),
    RAMADAN(
        "ramadan", 0xFFD49B2A, 0xFF1F4E5F, 0xFFF9EED2, "Ramadan lantern", "فانوس رمضان", "float",
        listOf(R.drawable.decor_fanous, R.drawable.decor_crescent, R.drawable.decor_star, R.drawable.decor_sparkle),
        R.drawable.decor_fanous, R.drawable.art_fanous
    ),
    ISLAMIC(
        "islamic", 0xFF1D6F5E, 0xFFC9A24A, 0xFFE7F3EF, "Islamic geometry", "هندسة إسلامية", "float",
        listOf(R.drawable.decor_star, R.drawable.decor_crescent, R.drawable.decor_sparkle),
        R.drawable.decor_crescent, R.drawable.art_cairo_night
    ),
    FRIDAY(
        "friday", 0xFF2E7D6B, 0xFF9BC4B6, 0xFFE6F2EE, "Friday accent", "لمسة الجمعة", "float",
        listOf(R.drawable.decor_dove, R.drawable.decor_star, R.drawable.decor_sparkle),
        R.drawable.decor_dove, R.drawable.art_cairo_night
    ),
    EID(
        "eid", 0xFFD98A2B, 0xFF2E8B6E, 0xFFFFF3DC, "Eid celebration", "بهجة العيد", "float",
        listOf(R.drawable.decor_balloon, R.drawable.decor_gift, R.drawable.decor_confetti, R.drawable.decor_fanous),
        R.drawable.decor_gift, R.drawable.art_fanous
    ),
    NATIONAL(
        "national", 0xFFCE1126, 0xFFC09300, 0xFFFCE8EA, "Egyptian national", "وطني مصري", "drift",
        listOf(R.drawable.decor_dove, R.drawable.decor_confetti, R.drawable.decor_sparkle),
        R.drawable.decor_dove, R.drawable.art_cairo_night
    ),
    NILE(
        "nile", 0xFF1B6CA8, 0xFF2FA37E, 0xFFE4F2FA, "Nile lotus", "لوتس النيل", "drift",
        listOf(R.drawable.decor_lotus, R.drawable.decor_wave, R.drawable.decor_herb),
        R.drawable.decor_lotus, R.drawable.art_cairo_night
    ),
    COPTIC(
        "coptic", 0xFF8C5A2B, 0xFFD4A84A, 0xFFFAF0E1, "Coptic heritage", "تراث قبطي", "float",
        listOf(R.drawable.decor_coptic_cross, R.drawable.decor_dove, R.drawable.decor_sparkle),
        R.drawable.decor_coptic_cross, null
    ),
    LOVE(
        "love", 0xFFD6456B, 0xFFF08FA8, 0xFFFDE4EA, "Hearts & roses", "قلوب وزهور", "float",
        listOf(R.drawable.decor_heart, R.drawable.decor_blossom, R.drawable.decor_tulip),
        R.drawable.decor_heart, R.drawable.photo_spring_blossom
    ),
    STUDY(
        "study", 0xFF4F6BD8, 0xFF7A8FE0, 0xFFE8ECFB, "Study", "دراسة", "float",
        listOf(R.drawable.decor_books, R.drawable.decor_sparkle, R.drawable.decor_star),
        R.drawable.decor_books, null
    ),
    BIRTHDAY(
        "birthday", 0xFFE0A020, 0xFFD6456B, 0xFFFFF2D6, "Birthday sparkle", "بريق الميلاد", "float",
        listOf(R.drawable.decor_balloon, R.drawable.decor_confetti, R.drawable.decor_gift, R.drawable.decor_sparkle),
        R.drawable.decor_balloon, null
    ),
    NEWYEAR(
        "newyear", 0xFFC9A227, 0xFF3B3F8F, 0xFFF5EFD9, "New Year", "العام الجديد", "fall",
        listOf(R.drawable.decor_confetti, R.drawable.decor_sparkle, R.drawable.decor_star, R.drawable.decor_balloon),
        R.drawable.decor_sparkle, null
    );

    companion object {
        fun fromId(id: String?): DecorFamily = entries.firstOrNull { it.id == id } ?: ISLAMIC
    }
}

data class CalParts(val y: Int, val m: Int, val d: Int)

data class Occasion(
    val id: String,
    val en: String,
    val ar: String,
    val family: DecorFamily,
    val priority: Int,
    val kind: String,
    val phase: String? = null,
    val strength: Float = 1f
)

data class DecorLayerInfo(
    val source: String,
    val family: DecorFamily,
    val en: String,
    val ar: String,
    val strength: Float
)

data class DecorStack(
    val layers: List<DecorLayerInfo>,
    val primary: DecorFamily,
    val occasions: List<Occasion>
)

object CalendarAndDecor {
    val HIJRI_MONTHS_EN = listOf(
        "Muharram", "Safar", "Rabi' I", "Rabi' II", "Jumada I", "Jumada II",
        "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    )
    val HIJRI_MONTHS_AR = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    val COPTIC_MONTHS_EN = listOf(
        "Thout", "Paopi", "Hathor", "Koiak", "Tobi", "Meshir", "Paremhat",
        "Parmouti", "Pashons", "Paoni", "Epip", "Mesori", "Nasie"
    )
    val COPTIC_MONTHS_AR = listOf(
        "توت", "بابه", "هاتور", "كيهك", "طوبة", "أمشير", "برمهات",
        "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "نسيء"
    )

    fun hijriMonthName(m: Int, lang: Lang): String {
        val idx = (m - 1).coerceIn(0, 11)
        return if (lang == Lang.AR) HIJRI_MONTHS_AR[idx] else HIJRI_MONTHS_EN[idx]
    }

    fun copticMonthName(m: Int, lang: Lang): String {
        val idx = (m - 1).coerceIn(0, 12)
        return if (lang == Lang.AR) COPTIC_MONTHS_AR[idx] else COPTIC_MONTHS_EN[idx]
    }

    fun dayKey(date: LocalDate = LocalDate.now()): String =
        "%04d-%02d-%02d".format(date.year, date.monthValue, date.dayOfMonth)

    fun fromKey(key: String): LocalDate = try {
        val parts = key.split("-")
        LocalDate.of(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
    } catch (_: Exception) {
        LocalDate.now()
    }

    fun hijri(date: LocalDate): CalParts = try {
        val h = HijrahDate.from(date)
        CalParts(
            y = h.get(ChronoField.YEAR_OF_ERA),
            m = h.get(ChronoField.MONTH_OF_YEAR),
            d = h.get(ChronoField.DAY_OF_MONTH)
        )
    } catch (_: Exception) {
        CalParts(1447, 1, 1)
    }

    /** Exact Julian Day -> Coptic (Alexandrian) calendar conversion. */
    fun coptic(date: LocalDate): CalParts {
        var y = date.year
        var m = date.monthValue
        val d = date.dayOfMonth
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = y / 100
        val b = 2 - a + a / 4
        val jd = floor(365.25 * (y + 4716)).toLong() + floor(30.6001 * (m + 1)).toLong() + d + b - 1524L
        val r = (jd - 1825030L) % 1461L
        val n = (r % 365L) + 365L * (r / 1460L)
        val cy = (4L * ((jd - 1825030L) / 1461L) + (r / 365L) - (r / 1460L) + 1L).toInt()
        val cm = ((n / 30L) + 1L).toInt().coerceIn(1, 13)
        val cd = ((n % 30L) + 1L).toInt().coerceIn(1, 30)
        return CalParts(cy, cm, cd)
    }

    fun orthodoxEaster(year: Int): LocalDate {
        val a = year % 4
        val b = year % 7
        val c = year % 19
        val d = (19 * c + 15) % 30
        val e = (2 * a + 4 * b - d + 34) % 7
        val month = (d + e + 114) / 31
        val day = ((d + e + 114) % 31) + 1
        return LocalDate.of(year, month, day).plusDays(13)
    }

    private data class FixedOcc(val m: Int, val d: Int, val occ: Occasion)
    private val FIXED = listOf(
        FixedOcc(1, 1, Occasion("newyear", "New Year", "رأس السنة الميلادية", DecorFamily.NEWYEAR, 70, "civil")),
        FixedOcc(1, 7, Occasion("coptic-christmas", "Coptic Christmas", "عيد الميلاد المجيد", DecorFamily.COPTIC, 80, "coptic")),
        FixedOcc(1, 19, Occasion("epiphany", "Epiphany", "عيد الغطاس", DecorFamily.COPTIC, 70, "coptic")),
        FixedOcc(1, 25, Occasion("jan25", "25 January", "ثورة ٢٥ يناير وعيد الشرطة", DecorFamily.NATIONAL, 75, "national")),
        FixedOcc(2, 14, Occasion("valentine", "Valentine's Day", "عيد الحب", DecorFamily.LOVE, 35, "civil")),
        FixedOcc(3, 21, Occasion("mothers", "Mother's Day", "عيد الأم", DecorFamily.LOVE, 80, "civil")),
        FixedOcc(4, 25, Occasion("sinai", "Sinai Liberation Day", "عيد تحرير سيناء", DecorFamily.NATIONAL, 85, "national")),
        FixedOcc(5, 1, Occasion("labour", "Labour Day", "عيد العمال", DecorFamily.NATIONAL, 50, "civil")),
        FixedOcc(6, 30, Occasion("jun30", "June 30 Revolution", "ثورة ٣٠ يونيو", DecorFamily.NATIONAL, 80, "national")),
        FixedOcc(7, 23, Occasion("jul23", "July 23 Revolution", "ثورة ٢٣ يوليو", DecorFamily.NATIONAL, 80, "national")),
        FixedOcc(8, 15, Occasion("wafaa", "Wafaa El-Nil", "عيد وفاء النيل", DecorFamily.NILE, 75, "national")),
        FixedOcc(9, 11, Occasion("nayrouz", "Nayrouz (Coptic New Year)", "عيد النيروز", DecorFamily.COPTIC, 75, "coptic")),
        FixedOcc(12, 31, Occasion("nye", "New Year's Eve", "ليلة رأس السنة", DecorFamily.NEWYEAR, 70, "civil"))
    )

    private data class HijriOcc(val m: Int, val d: Int, val len: Int, val occ: Occasion)
    private val HIJRI_OCC = listOf(
        HijriOcc(1, 1, 1, Occasion("hijri-ny", "Islamic New Year", "رأس السنة الهجرية", DecorFamily.ISLAMIC, 85, "islamic")),
        HijriOcc(1, 10, 1, Occasion("ashura", "Ashura", "يوم عاشوراء", DecorFamily.ISLAMIC, 80, "islamic")),
        HijriOcc(3, 12, 1, Occasion("mawlid", "Mawlid al-Nabi", "المولد النبوي الشريف", DecorFamily.ISLAMIC, 90, "islamic")),
        HijriOcc(7, 27, 1, Occasion("isra", "Isra' and Mi'raj", "الإسراء والمعراج", DecorFamily.ISLAMIC, 85, "islamic")),
        HijriOcc(8, 15, 1, Occasion("midshaban", "Mid-Sha'ban", "ليلة النصف من شعبان", DecorFamily.ISLAMIC, 80, "islamic")),
        HijriOcc(9, 27, 1, Occasion("qadr", "Laylat al-Qadr (27th night)", "ليلة القدر (ليلة ٢٧)", DecorFamily.RAMADAN, 95, "islamic")),
        HijriOcc(10, 1, 3, Occasion("eid-fitr", "Eid al-Fitr", "عيد الفطر المبارك", DecorFamily.EID, 100, "islamic")),
        HijriOcc(12, 9, 1, Occasion("arafah", "Day of Arafah", "يوم عرفة", DecorFamily.ISLAMIC, 95, "islamic")),
        HijriOcc(12, 10, 4, Occasion("eid-adha", "Eid al-Adha", "عيد الأضحى المبارك", DecorFamily.EID, 100, "islamic"))
    )

    fun occasionsOn(date: LocalDate): List<Occasion> {
        val out = mutableListOf<Occasion>()
        val m = date.monthValue
        val d = date.dayOfMonth
        for (f in FIXED) if (f.m == m && f.d == d) out.add(f.occ)
        if (m == 10 && d in 6..24) {
            val strength = if (d == 6) 1f else if (d == 24) 0.7f else maxOf(0.25f, 1f - (d - 6) / 18f)
            out.add(
                Occasion(
                    id = "october",
                    en = if (d == 6) "October Victory" else if (d == 24) "Suez National Day" else "October Victory season",
                    ar = if (d == 6) "انتصارات أكتوبر" else if (d == 24) "العيد القومي للسويس" else "موسم انتصارات أكتوبر",
                    family = DecorFamily.NATIONAL,
                    priority = if (d == 6) 90 else 45,
                    kind = "national",
                    strength = strength
                )
            )
        }
        val h = hijri(date)
        if (h.m == 9) {
            val phase = if (h.d <= 10) "early" else if (h.d <= 20) "middle" else "last-ten"
            out.add(
                Occasion(
                    id = "ramadan",
                    en = if (phase == "last-ten") "Ramadan · Last ten nights" else "Ramadan · Day ${h.d}",
                    ar = if (phase == "last-ten") "رمضان · العشر الأواخر" else "رمضان · اليوم ${h.d}",
                    family = DecorFamily.RAMADAN,
                    priority = 85,
                    kind = "islamic",
                    phase = phase,
                    strength = if (phase == "early") 0.55f else if (phase == "middle") 0.75f else 1f
                )
            )
        }
        for (ho in HIJRI_OCC) {
            if (h.m == ho.m && h.d >= ho.d && h.d < ho.d + ho.len) out.add(ho.occ)
        }
        val easter = orthodoxEaster(date.year)
        if (easter == date) out.add(Occasion("easter", "Easter", "عيد القيامة المجيد", DecorFamily.COPTIC, 75, "coptic"))
        if (easter.plusDays(1) == date) out.add(Occasion("sham", "Sham El-Nessim", "شم النسيم", DecorFamily.SPRING, 85, "national"))
        return out.sortedByDescending { it.priority }
    }

    fun climateSeason(date: LocalDate): Triple<DecorFamily, String, String> = when (date.monthValue) {
        12, 1, 2 -> Triple(DecorFamily.WINTER, "Winter", "الشتاء")
        3, 4, 5 -> Triple(DecorFamily.SPRING, "Spring", "الربيع")
        6, 7, 8 -> Triple(DecorFamily.SUMMER, "Summer", "الصيف")
        else -> Triple(DecorFamily.AUTUMN, "Autumn", "الخريف")
    }

    fun resolveDecor(
        date: LocalDate = LocalDate.now(),
        userDays: List<UserDay> = emptyList(),
        intensity: Intensity = Intensity.SUBTLE,
        examSeason: Boolean = false
    ): DecorStack {
        val budget = when (intensity) {
            Intensity.OFF -> 1
            Intensity.SUBTLE -> 2
            Intensity.RICH, Intensity.FESTIVAL -> 3
        }
        val occ = occasionsOn(date)
        val layers = mutableListOf<DecorLayerInfo>()
        for (o in occ) layers.add(DecorLayerInfo("occasion", o.family, o.en, o.ar, o.strength))
        val m = date.monthValue
        if (examSeason && (m == 1 || m == 5 || m == 6)) {
            layers.add(DecorLayerInfo("season", DecorFamily.STUDY, "Exam season", "موسم الامتحانات", 0.5f))
        }
        if ((m == 9 && date.dayOfMonth >= 15) || (m == 10 && date.dayOfMonth <= 5)) {
            layers.add(DecorLayerInfo("season", DecorFamily.STUDY, "Back to school", "العودة للمدارس", 0.4f))
        }
        if (date.dayOfWeek.value == 5) { // Friday
            layers.add(DecorLayerInfo("weekday", DecorFamily.FRIDAY, "Friday", "الجمعة", 0.35f))
        }
        val md = "%02d-%02d".format(date.monthValue, date.dayOfMonth)
        for (u in userDays) {
            if (u.date == md) layers.add(DecorLayerInfo("user", DecorFamily.fromId(u.family), u.en, u.ar, 0.9f))
        }
        val (cf, cen, car) = climateSeason(date)
        layers.add(DecorLayerInfo("climate", cf, cen, car, 0.3f))
        val seen = mutableSetOf<DecorFamily>()
        val dedup = layers.filter { seen.add(it.family) }.take(budget)
        return DecorStack(layers = dedup, primary = dedup.first().family, occasions = occ)
    }

    fun upcomingOccasions(from: LocalDate = LocalDate.now(), count: Int = 8): List<Pair<LocalDate, Occasion>> {
        val out = mutableListOf<Pair<LocalDate, Occasion>>()
        val seen = mutableSetOf<String>()
        var i = 0L
        while (i < 400L && out.size < count) {
            val d = from.plusDays(i)
            for (o in occasionsOn(d)) {
                val key = if (o.id == "ramadan" || o.id == "october") o.id else "${o.id}${d.year}"
                if (seen.add(key)) {
                    out.add(d to o)
                    if (out.size >= count) break
                }
            }
            i++
        }
        return out
    }
}
