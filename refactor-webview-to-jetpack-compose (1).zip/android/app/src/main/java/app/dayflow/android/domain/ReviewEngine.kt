package app.dayflow.android.domain

import app.dayflow.android.data.DayflowState
import java.time.LocalDate
import kotlin.math.roundToInt

data class ReviewDimMeta(
    val id: String,
    val en: String,
    val ar: String,
    val formulaEn: String,
    val formulaAr: String
)

data class DayFactRow(
    val date: String,
    val tasksTotal: Int,
    val tasksDone: Int,
    val importantDone: Int,
    val habitsDue: Int,
    val habitsDone: Int,
    val waterMl: Int,
    val waterGoal: Int,
    val workoutMin: Int,
    val focusMin: Int,
    val journalMood: Int?,
    val spiritualCount: Int,
    val isFriday: Boolean,
    val isRamadan: Boolean
)

data class DimEvaluation(
    val id: String,
    val score: Int?, // null = not counted
    val evidenceEn: String,
    val evidenceAr: String
)

data class DailyReviewResult(
    val date: String,
    val score: Int,
    val narrativeEn: String,
    val narrativeAr: String,
    val dims: List<DimEvaluation>,
    val wins: List<Pair<String, String>>,
    val suggestions: List<Triple<String, String, String>>,
    val priorityTomorrow: Pair<String, String>,
    val contextTags: List<String>
)

object ReviewEngine {
    val DIMS = listOf(
        ReviewDimMeta("tasks", "Task completion", "إنجاز المهام", "done ÷ planned × 100", "المنجز ÷ المخطط × ١٠٠"),
        ReviewDimMeta("priorities", "Important work", "الأولويات المهمة", "important done ÷ important planned", "المهم المنجز ÷ المهم المخطط"),
        ReviewDimMeta("consistency", "Habit consistency", "استمرارية العادات", "scheduled habits completed", "العادات المجدولة المنجزة"),
        ReviewDimMeta("hydration", "Hydration", "شرب الماء", "water ml ÷ daily goal", "الماء ÷ الهدف اليومي"),
        ReviewDimMeta("movement", "Movement", "الحركة والنشاط", "workout minutes ÷ 30m goal", "دقائق التمرين ÷ ٣٠ دقيقة"),
        ReviewDimMeta("focus", "Deep focus", "التركيز العميق", "focus minutes ÷ 50m benchmark", "دقائق التركيز ÷ ٥٠ دقيقة"),
        ReviewDimMeta("reflection", "Journaling", "التدوين والمزاج", "daily check-in recorded", "تسجيل تدوينة اليوم"),
        ReviewDimMeta("balance", "Schedule balance", "توازن الجدول", "avoids >8 overloaded tasks", "تجنب تكدس أكثر من ٨ مهام"),
        ReviewDimMeta("momentum", "3-day momentum", "الزخم المستمر", "rolling 3-day average", "متوسط آخر ٣ أيام"),
        ReviewDimMeta("recovery", "Rest & Friday ease", "الراحة والجمعة", "lighter load on rest days", "تخفيف الحمل في أيام الراحة"),
        ReviewDimMeta("spiritual", "Spiritual routine", "الورد الروحي", "tasbih / khatma progress (opt-in)", "التسبيح والختمة (اختياري)")
    )

    fun buildRealHistory(state: DayflowState, daysCount: Int = 60): List<DayFactRow> {
        val today = LocalDate.now()
        return (daysCount - 1 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            val key = CalendarAndDecor.dayKey(d)
            val hj = CalendarAndDecor.hijri(d)
            val dayTasks = state.tasks.filter { it.date == key }
            val dueHabits = state.habits.filter {
                (it.startDate == null || it.startDate <= key) &&
                    (it.days.isEmpty() || (d.dayOfWeek.value % 7) in it.days)
            }
            val doneHabits = dueHabits.count { key in it.log }
            val wMin = state.workout[key]?.sumOf { it.second } ?: 0
            val j = state.journal.firstOrNull { it.date == key }
            DayFactRow(
                date = key,
                tasksTotal = dayTasks.size,
                tasksDone = dayTasks.count { it.done },
                importantDone = dayTasks.count { it.done && it.important },
                habitsDue = dueHabits.size,
                habitsDone = doneHabits,
                waterMl = state.water[key] ?: 0,
                waterGoal = maxOf(500, state.waterGoal),
                workoutMin = wMin,
                focusMin = if (dayTasks.any { it.done }) 25 else 0,
                journalMood = j?.mood,
                spiritualCount = if (back == 0) state.tasbih else 0,
                isFriday = d.dayOfWeek.value == 5,
                isRamadan = hj.m == 9
            )
        }
    }

    fun sampleHistory(daysCount: Int = 120): List<DayFactRow> {
        val today = LocalDate.now()
        return (daysCount - 1 downTo 0).map { back ->
            val d = today.minusDays(back.toLong())
            val seed = d.dayOfYear * 37 + d.year
            val tot = 3 + (seed % 4)
            val dn = (tot - (seed % 2)).coerceAtLeast(1)
            val hj = CalendarAndDecor.hijri(d)
            DayFactRow(
                date = CalendarAndDecor.dayKey(d),
                tasksTotal = tot,
                tasksDone = dn,
                importantDone = (dn - 1).coerceAtLeast(1),
                habitsDue = 4,
                habitsDone = 2 + (seed % 3),
                waterMl = 1500 + (seed % 5) * 250,
                waterGoal = 2500,
                workoutMin = if (seed % 2 == 0) 25 else 10,
                focusMin = 25 + (seed % 3) * 15,
                journalMood = 3 + (seed % 3),
                spiritualCount = 33,
                isFriday = d.dayOfWeek.value == 5,
                isRamadan = hj.m == 9
            )
        }
    }

    fun evaluateAll(history: List<DayFactRow>, state: DayflowState): List<DailyReviewResult> {
        val out = mutableListOf<DailyReviewResult>()
        history.forEachIndexed { idx, row ->
            val tScore = if (row.tasksTotal > 0) ((row.tasksDone * 100.0) / row.tasksTotal).roundToInt().coerceIn(0, 100) else null
            val pScore = if (row.tasksTotal > 0) minOf(100, row.importantDone * 50 + 40) else null
            val hScore = if (row.habitsDue > 0) ((row.habitsDone * 100.0) / row.habitsDue).roundToInt().coerceIn(0, 100) else null
            val wScore = ((row.waterMl * 100.0) / row.waterGoal).roundToInt().coerceIn(0, 100)
            val mScore = if (row.workoutMin > 0) ((row.workoutMin * 100.0) / 30.0).roundToInt().coerceIn(0, 100) else null
            val fScore = if (row.focusMin > 0) ((row.focusMin * 100.0) / 50.0).roundToInt().coerceIn(0, 100) else null
            val rScore = if (row.journalMood != null) 100 else null
            val bScore = if (row.tasksTotal <= 8) 92 else maxOf(40, 100 - (row.tasksTotal - 8) * 10)
            val prev2 = out.takeLast(2).map { it.score }
            val baseActive = listOfNotNull(tScore, hScore, wScore, mScore, fScore, rScore, bScore)
            val rawAvg = if (baseActive.isNotEmpty()) baseActive.average().roundToInt() else 65
            val momScore = ((prev2 + rawAvg).average()).roundToInt()
            val recScore = if (row.isFriday) 95 else 85
            val spScore = if (state.spiritual) minOf(100, 50 + row.spiritualCount) else null

            val dims = listOf(
                DimEvaluation("tasks", tScore, "${row.tasksDone}/${row.tasksTotal} tasks done", "${row.tasksDone} من ${row.tasksTotal} مهام منجزة"),
                DimEvaluation("priorities", pScore, "${row.importantDone} important tasks finished", "${row.importantDone} مهام ذات أولوية أنجزت"),
                DimEvaluation("consistency", hScore, "${row.habitsDone}/${row.habitsDue} habits logged", "${row.habitsDone} من ${row.habitsDue} عادات مجدولة"),
                DimEvaluation("hydration", wScore, "${row.waterMl} / ${row.waterGoal} ml", "${row.waterMl} من ${row.waterGoal} مل ماء"),
                DimEvaluation("movement", mScore, "${row.workoutMin} min movement", "${row.workoutMin} دقيقة حركة"),
                DimEvaluation("focus", fScore, "${row.focusMin} min focus", "${row.focusMin} دقيقة تركيز"),
                DimEvaluation("reflection", rScore, if (row.journalMood != null) "Journal saved" else "No entry", if (row.journalMood != null) "تم التدوين" else "لا توجد تدوينة"),
                DimEvaluation("balance", bScore, "${row.tasksTotal} scheduled items", "${row.tasksTotal} عناصر في الجدول"),
                DimEvaluation("momentum", momScore, "3-day rolling score", "متوسط ٣ أيام متتالية"),
                DimEvaluation("recovery", recScore, if (row.isFriday) "Friday calm pace" else "Steady pace", if (row.isFriday) "إيقاع الجمعة الهادئ" else "إيقاع متوازن"),
                DimEvaluation("spiritual", spScore, "${row.spiritualCount} tasbih counts", "${row.spiritualCount} تسبيحة")
            )

            val counted = dims.mapNotNull { it.score }
            val finalScore = if (counted.isNotEmpty()) counted.average().roundToInt().coerceIn(0, 100) else 65

            val wins = mutableListOf<Pair<String, String>>()
            if ((tScore ?: 0) >= 75) wins.add("Completed ${row.tasksDone} tasks" to "أنجزت ${row.tasksDone} مهام بنجاح")
            if (wScore >= 80) wins.add("Strong hydration (${row.waterMl} ml)" to "ترطيب ممتاز (${row.waterMl} مل ماء)")
            if ((hScore ?: 0) >= 75) wins.add("Kept ${row.habitsDone} habits going" to "حافظت على ${row.habitsDone} عادات")

            val suggestions = mutableListOf<Triple<String, String, String>>()
            if (wScore < 70) suggestions.add(Triple("water", "Drink a 250 ml glass before noon.", "اشرب كوب ماء ٢٥٠ مل قبل الظهر."))
            if (row.tasksTotal > row.tasksDone) suggestions.add(Triple("tasks", "Pick 1 top priority first tomorrow morning.", "ابدأ غداً بمهمة واحدة فقط ذات أولوية."))

            val tags = mutableListOf<String>()
            if (row.isRamadan) tags.add("ramadan")
            if (row.isFriday) tags.add("friday")

            val narrativeAr = when {
                finalScore >= 80 -> "يوم متزن ومثمر؛ خطواتك الهادئة صنعت فارقاً حقيقياً."
                finalScore >= 60 -> "يوم جيد ومستقر؛ بعض الخطوات البسيطة غداً ترفع إيقاعك."
                else -> "يوم هادئ للالتقاط الأنفاس — غداً نبدأ بمهمة صغيرة واحدة."
            }
            val narrativeEn = when {
                finalScore >= 80 -> "A calm, productive day — steady effort paid off."
                finalScore >= 60 -> "Solid steady progress today with room for one small win tomorrow."
                else -> "A gentle reset day — start tomorrow with one small priority."
            }

            out.add(
                DailyReviewResult(
                    date = row.date,
                    score = finalScore,
                    narrativeEn = narrativeEn,
                    narrativeAr = narrativeAr,
                    dims = dims,
                    wins = wins,
                    suggestions = suggestions,
                    priorityTomorrow = "Complete your #1 important task early" to "إنجاز أهم مهمة مبكراً في بداية اليوم",
                    contextTags = tags
                )
            )
        }
        return out
    }
}
