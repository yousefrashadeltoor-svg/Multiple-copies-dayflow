package app.dayflow.android.domain

import app.dayflow.android.data.Lang
import java.time.LocalDateTime
import java.time.LocalTime
import java.util.Calendar

data class ClockParts12(
    val time: String,
    val suffix: String,
    val full: String,
    val hour12Val: Int,
    val minuteVal: Int,
    val isPm: Boolean
)

object Time12 {
    private val ARABIC_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    fun fmtNum(value: Any, lang: Lang): String {
        val raw = value.toString()
        if (lang != Lang.AR) return raw
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch in '0'..'9') sb.append(ARABIC_DIGITS[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun toWesternDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append((ch - '٠').digitToChar())
                in '۰'..'۹' -> sb.append((ch - '۰').digitToChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun partsFrom24(hhmm: String?, lang: Lang, showSeconds: Boolean = false, sec: Int = 0): ClockParts12 {
        if (hhmm.isNullOrBlank()) return ClockParts12("—", "", "—", 12, 0, false)
        val clean = toWesternDigits(hhmm.trim())
        val bits = clean.split(":")
        val h24 = bits.getOrNull(0)?.toIntOrNull() ?: return ClockParts12("—", "", "—", 12, 0, false)
        val m = bits.getOrNull(1)?.toIntOrNull() ?: 0
        val s = bits.getOrNull(2)?.toIntOrNull() ?: sec
        return buildParts(h24, m, s, lang, showSeconds)
    }

    fun partsFromNow(now: LocalDateTime = LocalDateTime.now(), lang: Lang, showSeconds: Boolean = false): ClockParts12 {
        return buildParts(now.hour, now.minute, now.second, lang, showSeconds)
    }

    fun partsFromCalendar(cal: Calendar, lang: Lang, showSeconds: Boolean = false): ClockParts12 {
        return buildParts(
            cal.get(Calendar.HOUR_OF_DAY),
            cal.get(Calendar.MINUTE),
            cal.get(Calendar.SECOND),
            lang,
            showSeconds
        )
    }

    private fun buildParts(h24Raw: Int, mRaw: Int, sRaw: Int, lang: Lang, showSeconds: Boolean): ClockParts12 {
        val h24 = ((h24Raw % 24) + 24) % 24
        val m = mRaw.coerceIn(0, 59)
        val s = sRaw.coerceIn(0, 59)
        val isPm = h24 >= 12
        val h12 = when (val mod = h24 % 12) {
            0 -> 12
            else -> mod
        }
        val mmStr = m.toString().padStart(2, '0')
        val ssStr = if (showSeconds) ":${s.toString().padStart(2, '0')}" else ""
        val timeRaw = "$h12:$mmStr$ssStr"
        val timeLocalized = fmtNum(timeRaw, lang)
        val suffix = if (lang == Lang.AR) {
            if (isPm) "م" else "ص"
        } else {
            if (isPm) "PM" else "AM"
        }
        return ClockParts12(
            time = timeLocalized,
            suffix = suffix,
            full = "$timeLocalized $suffix",
            hour12Val = h12,
            minuteVal = m,
            isPm = isPm
        )
    }

    fun format12(hhmm: String?, lang: Lang, showSeconds: Boolean = false): String =
        partsFrom24(hhmm, lang, showSeconds).full

    fun format12(time: LocalTime, lang: Lang, showSeconds: Boolean = false): String =
        buildParts(time.hour, time.minute, time.second, lang, showSeconds).full

    fun format12(dt: LocalDateTime, lang: Lang, showSeconds: Boolean = false): String =
        partsFromNow(dt, lang, showSeconds).full

    fun to24String(hour12: Int, minute: Int, isPm: Boolean): String {
        val h12 = hour12.coerceIn(1, 12)
        val h24 = when {
            isPm && h12 < 12 -> h12 + 12
            !isPm && h12 == 12 -> 0
            else -> h12
        }
        return "${h24.toString().padStart(2, '0')}:${minute.coerceIn(0, 59).toString().padStart(2, '0')}"
    }
}
