package app.dayflow.android.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import app.dayflow.android.domain.CalendarAndDecor
import app.dayflow.android.service.AlarmScheduler
import app.dayflow.android.service.CompanionOverlayService
import app.dayflow.android.service.ReminderScheduler
import app.dayflow.android.widget.DayflowWidgetUpdater
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

object DayflowRepository {
    private const val PREF_NAME = "dayflow_v2_native"
    private const val KEY_STATE = "dayflow_state_json"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow(DayflowState())
    val state: StateFlow<DayflowState> = _state.asStateFlow()

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        val prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_STATE, null)
            ?: migrateLegacyState(ctx)
        if (!raw.isNullOrBlank()) {
            runCatching { decodeState(JSONObject(raw)) }.getOrNull()?.let { loaded ->
                _state.value = loaded.copy(hour12 = true)
            }
        }
        syncSystemServices(ctx, _state.value)
    }

    private fun migrateLegacyState(ctx: Context): String? {
        val legacy = ctx.getSharedPreferences("dayflow_native", Context.MODE_PRIVATE).getString("state", null)
        if (!legacy.isNullOrBlank()) {
            ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().putString(KEY_STATE, legacy).apply()
            return legacy
        }
        return null
    }

    fun update(transform: (DayflowState) -> DayflowState) {
        val next = transform(_state.value).copy(hour12 = true)
        _state.value = next
        val ctx = appContext ?: return
        scope.launch {
            val json = encodeState(next).toString()
            ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_STATE, json)
                .apply()
            syncSystemServices(ctx, next)
        }
    }

    fun exportJson(): String = encodeState(_state.value).toString(2)

    fun importJson(raw: String): Boolean {
        return try {
            val root = JSONObject(raw)
            val stateObj = if (root.has("state")) root.getJSONObject("state") else root
            val parsed = decodeState(stateObj).copy(hour12 = true)
            update { parsed }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun eraseAll() {
        val ctx = appContext
        if (ctx != null) {
            _state.value.alarms.forEach { AlarmScheduler.cancel(ctx, it.id) }
            ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().clear().apply()
        }
        update { DayflowState(hour12 = true) }
    }

    private fun syncSystemServices(ctx: Context, s: DayflowState) {
        runCatching { ReminderScheduler.syncAll(ctx, s) }
        runCatching { DayflowWidgetUpdater.refreshAll(ctx) }
        runCatching { CompanionOverlayService.syncWithState(ctx, s) }
        runCatching { syncLauncherIcon(ctx, s.decorSurfaces.icon) }
    }

    private fun syncLauncherIcon(ctx: Context, seasonal: Boolean) {
        val pm = ctx.packageManager
        val defComp = ComponentName(ctx, "app.dayflow.android.MainActivityDefault")
        val seaComp = ComponentName(ctx, "app.dayflow.android.MainActivitySeasonal")
        val defTarget = if (seasonal) PackageManager.COMPONENT_ENABLED_STATE_DISABLED else PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        val seaTarget = if (seasonal) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        if (pm.getComponentEnabledSetting(seaComp) != seaTarget) {
            pm.setComponentEnabledSetting(seaComp, seaTarget, PackageManager.DONT_KILL_APP)
            pm.setComponentEnabledSetting(defComp, defTarget, PackageManager.DONT_KILL_APP)
        }
    }

    // ---- Convenient Domain Mutations ----
    fun addAlarm(alarm: AlarmItem): AlarmItem {
        update { s -> s.copy(alarms = s.alarms + alarm) }
        appContext?.let { ctx ->
            if (alarm.enabled) runCatching { AlarmScheduler.schedule(ctx, alarm) }
        }
        return alarm
    }

    fun updateAlarm(id: String, transform: (AlarmItem) -> AlarmItem) {
        var updated: AlarmItem? = null
        update { s ->
            s.copy(alarms = s.alarms.map {
                if (it.id == id) transform(it).also { u -> updated = u } else it
            })
        }
        val ctx = appContext ?: return
        updated?.let { a ->
            if (a.enabled) runCatching { AlarmScheduler.schedule(ctx, a) }
            else AlarmScheduler.cancel(ctx, a.id)
        }
    }

    fun removeAlarm(id: String) {
        appContext?.let { AlarmScheduler.cancel(it, id) }
        update { s -> s.copy(alarms = s.alarms.filterNot { it.id == id }) }
    }

    fun addTask(
        title: String,
        date: String = CalendarAndDecor.dayKey(),
        urgent: Boolean = false,
        important: Boolean = true,
        dueTime: String? = null
    ): TaskItem {
        val item = TaskItem(title = title.trim(), date = date, dueTime = dueTime, urgent = urgent, important = important)
        update { s -> s.copy(tasks = listOf(item) + s.tasks) }
        return item
    }

    fun toggleTask(id: String) {
        update { s ->
            s.copy(tasks = s.tasks.map {
                if (it.id == id) {
                    val nd = !it.done
                    it.copy(done = nd, status = if (nd) "done" else "todo")
                } else it
            })
        }
    }

    fun updateTaskStatus(id: String, status: String) {
        update { s ->
            s.copy(tasks = s.tasks.map {
                if (it.id == id) it.copy(status = status, done = status == "done") else it
            })
        }
    }

    fun removeTask(id: String) {
        update { s -> s.copy(tasks = s.tasks.filterNot { it.id == id }) }
    }

    fun addWater(ml: Int) {
        val today = CalendarAndDecor.dayKey()
        update { s ->
            val nextVal = maxOf(0, (s.water[today] ?: 0) + ml)
            s.copy(water = s.water + (today to nextVal))
        }
    }

    fun toggleHabit(id: String, day: String = CalendarAndDecor.dayKey()) {
        update { s ->
            s.copy(habits = s.habits.map { h ->
                if (h.id == id) {
                    val nextLog = if (day in h.log) h.log - day else h.log + day
                    h.copy(log = nextLog)
                } else h
            })
        }
    }

    fun executeActions(actions: List<Map<String, String>>, onNavigate: ((String, String?) -> Unit)? = null) {
        for (a in actions) {
            when (a["intent"]) {
                "addWater" -> addWater(a["ml"]?.toIntOrNull() ?: 250)
                "addTask" -> {
                    val title = a["title"]?.trim().orEmpty()
                    if (title.isNotEmpty()) {
                        addTask(
                            title = title,
                            date = a["date"] ?: CalendarAndDecor.dayKey(),
                            dueTime = a["time"]
                        )
                    }
                }
                "addAlarm" -> {
                    val time = a["time"] ?: continue
                    val days = a["days"]?.split(",")?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()
                    addAlarm(
                        AlarmItem(
                            time = time,
                            date = a["date"]?.takeIf { it.isNotBlank() },
                            days = days,
                            label = a["label"] ?: "منبه",
                            enabled = true
                        )
                    )
                }
                "addNote" -> {
                    val txt = a["text"]?.trim().orEmpty()
                    if (txt.isNotEmpty()) update { s -> s.copy(notes = listOf(NoteItem(text = txt)) + s.notes) }
                }
                "open" -> {
                    val tab = a["tab"] ?: "today"
                    onNavigate?.invoke(tab, a["sub"])
                }
            }
        }
    }

    // ---- JSON Serialization ----
    private fun encodeState(s: DayflowState): JSONObject = JSONObject().apply {
        put("lang", s.lang.code)
        put("themeId", s.themeId)
        put("favThemes", JSONArray(s.favThemes))
        put("intensity", s.intensity.id)
        put("decorLayer", s.decorLayer)
        put("powerMode", s.powerMode)
        put("reduceMotion", s.reduceMotion)
        put("reviewTone", s.reviewTone)
        put("spiritual", s.spiritual)
        put("examSeason", s.examSeason)
        put("sampleData", s.sampleData)
        put("hour12", true)
        put("aiShareContext", s.aiShareContext)
        put("waterGoal", s.waterGoal)
        put("tasbih", s.tasbih)
        put("khatma", s.khatma)
        put("clipboardWatch", s.clipboardWatch)
        put("activeKeyId", s.activeKeyId ?: "")
        put("activeModel", s.activeModel)
        put("aiReasoning", s.aiReasoning)
        put("widgetFont", s.widgetFont)
        put("cityIndex", s.cityIndex)
        put("useGpsLocation", s.useGpsLocation)
        if (s.gpsLat != null) put("gpsLat", s.gpsLat)
        if (s.gpsLng != null) put("gpsLng", s.gpsLng)
        put("gpsLabel", s.gpsLabel)
        put("autoTimeTheme", s.autoTimeTheme)
        put("ambientPhoto", s.ambientPhoto)

        put("decorSurfaces", JSONObject().apply {
            put("app", s.decorSurfaces.app)
            put("notifications", s.decorSurfaces.notifications)
            put("widgets", s.decorSurfaces.widgets)
            put("icon", s.decorSurfaces.icon)
            put("companion", s.decorSurfaces.companion)
        })

        put("companion", JSONObject().apply {
            put("enabled", s.companion.enabled)
            put("hidden", s.companion.hidden)
            put("notify", s.companion.notify)
            put("bubbles", s.companion.bubbles)
            put("emotion", s.companion.emotion.id)
            put("sound", s.companion.sound)
            put("size", s.companion.size.toDouble())
            put("opacity", s.companion.opacity.toDouble())
            put("outfit", s.companion.outfit)
            put("overlayEverywhere", s.companion.overlayEverywhere)
        })

        put("notif", JSONObject().apply {
            put("preview", s.notif.preview)
            put("style", s.notif.style)
            put("sound", s.notif.sound)
            put("vibrate", s.notif.vibrate)
            put("quiet", s.notif.quiet)
            put("dailyReview", s.notif.dailyReview)
            put("weeklyReview", s.notif.weeklyReview)
        })

        put("alarmLook", JSONObject().apply {
            put("layout", s.alarmLook.layout)
            put("showSeconds", s.alarmLook.showSeconds)
            put("gradient", s.alarmLook.gradient)
            put("weatherLine", s.alarmLook.weatherLine)
        })

        put("water", JSONObject().apply { s.water.forEach { (k, v) -> put(k, v) } })

        put("alarms", JSONArray().apply {
            s.alarms.forEach { a ->
                put(JSONObject().apply {
                    put("id", a.id)
                    put("time", a.time)
                    put("date", a.date ?: "")
                    put("days", JSONArray(a.days))
                    put("label", a.label)
                    put("enabled", a.enabled)
                    put("vibrate", a.vibrate)
                    put("snooze", a.snooze)
                    put("gentle", a.gentle)
                    put("sound", JSONObject().apply {
                        put("source", a.sound.source.id)
                        put("title", a.sound.title)
                        put("uri", a.sound.uri)
                    })
                })
            }
        })

        put("tasks", JSONArray().apply {
            s.tasks.forEach { t ->
                put(JSONObject().apply {
                    put("id", t.id); put("title", t.title); put("date", t.date)
                    put("dueTime", t.dueTime ?: ""); put("done", t.done)
                    put("urgent", t.urgent); put("important", t.important)
                    put("status", t.status); put("createdAt", t.createdAt)
                })
            }
        })

        put("notes", JSONArray().apply {
            s.notes.forEach { n ->
                put(JSONObject().apply {
                    put("id", n.id); put("text", n.text); put("pinned", n.pinned); put("at", n.at)
                })
            }
        })

        put("habits", JSONArray().apply {
            s.habits.forEach { h ->
                put(JSONObject().apply {
                    put("id", h.id); put("en", h.en); put("ar", h.ar ?: "")
                    put("log", JSONArray(h.log)); put("type", h.type.id)
                    put("days", JSONArray(h.days)); put("startDate", h.startDate ?: "")
                    put("target", h.target); put("unit", h.unit); put("details", h.details)
                    put("emoji", h.emoji); put("color", h.color); put("reminder", h.reminder ?: "")
                })
            }
        })

        put("placed", JSONArray().apply {
            s.placed.forEach { p ->
                put(JSONObject().apply {
                    put("id", p.id); put("appWidgetId", p.appWidgetId); put("designId", p.designId)
                    put("w", p.w); put("h", p.h); put("style", p.style); put("tapOpens", p.tapOpens)
                })
            }
        })

        put("journal", JSONArray().apply {
            s.journal.forEach { j ->
                put(JSONObject().apply {
                    put("id", j.id); put("date", j.date); put("mood", j.mood); put("text", j.text)
                })
            }
        })

        put("countdowns", JSONArray().apply {
            s.countdowns.forEach { c ->
                put(JSONObject().apply { put("id", c.id); put("title", c.title); put("date", c.date) })
            }
        })

        put("meds", JSONArray().apply {
            s.meds.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id); put("name", m.name); put("times", JSONArray(m.times))
                    put("taken", JSONObject().apply {
                        m.taken.forEach { (day, list) -> put(day, JSONArray(list)) }
                    })
                })
            }
        })

        put("userDays", JSONArray().apply {
            s.userDays.forEach { u ->
                put(JSONObject().apply {
                    put("id", u.id); put("date", u.date); put("en", u.en); put("ar", u.ar)
                    put("kind", u.kind); put("family", u.family)
                })
            }
        })

        put("apiKeys", JSONArray().apply {
            s.apiKeys.forEach { k ->
                put(JSONObject().apply {
                    put("id", k.id); put("provider", k.provider); put("label", k.label)
                    put("key", k.key); put("baseUrl", k.baseUrl); put("liveModels", JSONArray(k.liveModels))
                })
            }
        })

        put("convos", JSONArray().apply {
            s.convos.take(50).forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id); put("title", c.title); put("updatedAt", c.updatedAt)
                    put("messages", JSONArray().apply {
                        c.messages.forEach { m ->
                            put(JSONObject().apply {
                                put("id", m.id); put("role", m.role)
                                put("content", m.content); put("reasoning", m.reasoning); put("at", m.at)
                            })
                        }
                    })
                })
            }
        })

        put("downloads", JSONArray().apply {
            s.downloads.forEach { d ->
                put(JSONObject().apply {
                    put("id", d.id); put("url", d.url); put("variantUrl", d.variantUrl); put("name", d.name)
                    put("kind", d.kind); put("host", d.host); put("site", d.site); put("secure", d.secure)
                    put("thumb", d.thumb); put("quality", d.quality); put("formatId", d.formatId)
                    put("size", d.size); put("got", d.got)
                    put("state", if (d.state == "downloading") "paused" else d.state)
                    put("engine", d.engine); put("notices", JSONArray(d.notices)); put("error", d.error)
                    put("addedAt", d.addedAt); put("doneAt", d.doneAt); put("savedPath", d.savedPath); put("mime", d.mime)
                })
            }
        })
    }

    private fun decodeState(o: JSONObject): DayflowState {
        fun arrStrings(a: JSONArray?): List<String> =
            if (a == null) emptyList() else (0 until a.length()).mapNotNull { a.optString(it).takeIf { s -> s.isNotEmpty() } }

        fun arrInts(a: JSONArray?): List<Int> =
            if (a == null) emptyList() else (0 until a.length()).map { a.optInt(it) }

        val dsObj = o.optJSONObject("decorSurfaces")
        val compObj = o.optJSONObject("companion")
        val nfObj = o.optJSONObject("notif")
        val alObj = o.optJSONObject("alarmLook")

        val waterMap = mutableMapOf<String, Int>()
        o.optJSONObject("water")?.let { w ->
            w.keys().forEach { k -> waterMap[k] = w.optInt(k, 0) }
        }

        val alarms = mutableListOf<AlarmItem>()
        o.optJSONArray("alarms")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                val snd = x.optJSONObject("sound")
                alarms.add(
                    AlarmItem(
                        id = x.optString("id", newUid()),
                        time = x.optString("time", "07:00"),
                        date = x.optString("date", "").ifBlank { null },
                        days = arrInts(x.optJSONArray("days")),
                        label = x.optString("label", ""),
                        enabled = x.optBoolean("enabled", true),
                        vibrate = x.optBoolean("vibrate", true),
                        snooze = x.optInt("snooze", 10),
                        gentle = x.optBoolean("gentle", true),
                        sound = SoundSpec(
                            source = SoundSource.entries.firstOrNull { it.id == snd?.optString("source") } ?: SoundSource.DEVICE,
                            title = snd?.optString("title", "منبه الجهاز الافتراضي") ?: "منبه الجهاز الافتراضي",
                            uri = snd?.optString("uri", "") ?: ""
                        )
                    )
                )
            }
        }

        val tasks = mutableListOf<TaskItem>()
        o.optJSONArray("tasks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                tasks.add(
                    TaskItem(
                        id = x.optString("id", newUid()),
                        title = x.optString("title", ""),
                        date = x.optString("date", CalendarAndDecor.dayKey()),
                        dueTime = x.optString("dueTime", "").ifBlank { null },
                        done = x.optBoolean("done", false),
                        urgent = x.optBoolean("urgent", false),
                        important = x.optBoolean("important", true),
                        status = x.optString("status", "todo"),
                        createdAt = x.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        }

        val notes = mutableListOf<NoteItem>()
        o.optJSONArray("notes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                notes.add(NoteItem(x.optString("id", newUid()), x.optString("text", ""), x.optBoolean("pinned", false), x.optLong("at")))
            }
        }

        val habits = mutableListOf<HabitItem>()
        o.optJSONArray("habits")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                habits.add(
                    HabitItem(
                        id = x.optString("id", newUid()),
                        en = x.optString("en", ""),
                        ar = x.optString("ar", "").ifBlank { null },
                        log = arrStrings(x.optJSONArray("log")),
                        type = HabitType.entries.firstOrNull { it.id == x.optString("type") } ?: HabitType.BUILD,
                        days = arrInts(x.optJSONArray("days")).ifEmpty { listOf(0, 1, 2, 3, 4, 5, 6) },
                        startDate = x.optString("startDate", "").ifBlank { null },
                        target = x.optInt("target", 1),
                        unit = x.optString("unit", ""),
                        details = x.optString("details", ""),
                        emoji = x.optString("emoji", "🌅"),
                        color = x.optString("color", "#2fa36b"),
                        reminder = x.optString("reminder", "").ifBlank { null }
                    )
                )
            }
        }

        val placed = mutableListOf<PlacedWidget>()
        o.optJSONArray("placed")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                placed.add(
                    PlacedWidget(
                        id = x.optString("id", newUid()),
                        appWidgetId = x.optInt("appWidgetId", -1),
                        designId = x.optString("designId", "clock-minimal-digital"),
                        w = x.optInt("w", 2),
                        h = x.optInt("h", 2),
                        style = x.optString("style", "oneui"),
                        tapOpens = x.optBoolean("tapOpens", true)
                    )
                )
            }
        }

        val journal = mutableListOf<JournalEntry>()
        o.optJSONArray("journal")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                journal.add(JournalEntry(x.optString("id", newUid()), x.optString("date", ""), x.optInt("mood", 3), x.optString("text", "")))
            }
        }

        val countdowns = mutableListOf<CountdownItem>()
        o.optJSONArray("countdowns")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                countdowns.add(CountdownItem(x.optString("id", newUid()), x.optString("title", ""), x.optString("date", "")))
            }
        }

        val meds = mutableListOf<MedItem>()
        o.optJSONArray("meds")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                val tk = mutableMapOf<String, List<String>>()
                x.optJSONObject("taken")?.let { tObj ->
                    tObj.keys().forEach { day -> tk[day] = arrStrings(tObj.optJSONArray(day)) }
                }
                meds.add(MedItem(x.optString("id", newUid()), x.optString("name", ""), arrStrings(x.optJSONArray("times")), tk))
            }
        }

        val userDays = mutableListOf<UserDay>()
        o.optJSONArray("userDays")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                userDays.add(UserDay(x.optString("id", newUid()), x.optString("date", ""), x.optString("en", ""), x.optString("ar", ""), x.optString("kind", "custom"), x.optString("family", "birthday")))
            }
        }

        val apiKeys = mutableListOf<ApiKeyEntry>()
        o.optJSONArray("apiKeys")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                apiKeys.add(ApiKeyEntry(x.optString("id", newUid()), x.optString("provider", "openrouter"), x.optString("label", ""), x.optString("key", ""), x.optString("baseUrl", ""), arrStrings(x.optJSONArray("liveModels"))))
            }
        }

        val convos = mutableListOf<Conversation>()
        o.optJSONArray("convos")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                val msgs = mutableListOf<ChatMsg>()
                x.optJSONArray("messages")?.let { mArr ->
                    for (j in 0 until mArr.length()) {
                        val m = mArr.optJSONObject(j) ?: continue
                        msgs.add(ChatMsg(m.optString("id", newUid()), m.optString("role", "user"), m.optString("content", ""), m.optString("reasoning", ""), m.optLong("at")))
                    }
                }
                convos.add(Conversation(x.optString("id", newUid()), x.optString("title", ""), msgs, x.optLong("updatedAt")))
            }
        }

        val downloads = mutableListOf<DownloadTaskItem>()
        o.optJSONArray("downloads")?.let { arr ->
            for (i in 0 until arr.length()) {
                val x = arr.optJSONObject(i) ?: continue
                downloads.add(
                    DownloadTaskItem(
                        id = x.optString("id", newUid()),
                        url = x.optString("url", ""),
                        variantUrl = x.optString("variantUrl", ""),
                        name = x.optString("name", "download"),
                        kind = x.optString("kind", "file"),
                        host = x.optString("host", ""),
                        site = x.optString("site", "generic"),
                        secure = x.optBoolean("secure", true),
                        thumb = x.optString("thumb", ""),
                        quality = x.optString("quality", ""),
                        formatId = x.optString("formatId", ""),
                        size = x.optLong("size", 0L),
                        got = x.optLong("got", 0L),
                        state = x.optString("state", "paused"),
                        engine = x.optString("engine", "ytdlp"),
                        notices = arrStrings(x.optJSONArray("notices")),
                        error = x.optString("error", ""),
                        addedAt = x.optLong("addedAt", System.currentTimeMillis()),
                        doneAt = x.optLong("doneAt", 0L),
                        savedPath = x.optString("savedPath", ""),
                        mime = x.optString("mime", "")
                    )
                )
            }
        }

        return DayflowState(
            lang = if (o.optString("lang", "ar") == "en") Lang.EN else Lang.AR,
            themeId = o.optString("themeId", "paper-white"),
            favThemes = arrStrings(o.optJSONArray("favThemes")),
            intensity = Intensity.entries.firstOrNull { it.id == o.optString("intensity") } ?: Intensity.SUBTLE,
            decorLayer = o.optString("decorLayer", "behind"),
            powerMode = o.optBoolean("powerMode", false),
            reduceMotion = o.optBoolean("reduceMotion", false),
            reviewTone = o.optString("reviewTone", "balanced"),
            spiritual = o.optBoolean("spiritual", false),
            examSeason = o.optBoolean("examSeason", false),
            sampleData = o.optBoolean("sampleData", false),
            hour12 = true,
            aiShareContext = o.optBoolean("aiShareContext", false),
            waterGoal = o.optInt("waterGoal", 2500),
            water = waterMap,
            tasbih = o.optInt("tasbih", 0),
            khatma = o.optInt("khatma", 0),
            clipboardWatch = o.optBoolean("clipboardWatch", false),
            activeKeyId = o.optString("activeKeyId", "").ifBlank { null },
            activeModel = o.optString("activeModel", ""),
            aiReasoning = o.optBoolean("aiReasoning", true),
            widgetFont = o.optString("widgetFont", "sans"),
            cityIndex = o.optInt("cityIndex", 1),
            useGpsLocation = o.optBoolean("useGpsLocation", false),
            gpsLat = if (o.has("gpsLat")) o.optDouble("gpsLat") else null,
            gpsLng = if (o.has("gpsLng")) o.optDouble("gpsLng") else null,
            gpsLabel = o.optString("gpsLabel", ""),
            autoTimeTheme = o.optBoolean("autoTimeTheme", true),
            ambientPhoto = o.optBoolean("ambientPhoto", true),
            decorSurfaces = DecorSurfaces(
                app = dsObj?.optBoolean("app", true) ?: true,
                notifications = dsObj?.optBoolean("notifications", true) ?: true,
                widgets = dsObj?.optBoolean("widgets", true) ?: true,
                icon = dsObj?.optBoolean("icon", false) ?: false,
                companion = dsObj?.optBoolean("companion", true) ?: true
            ),
            companion = RobotPrefs(
                enabled = compObj?.optBoolean("enabled", true) ?: true,
                hidden = compObj?.optBoolean("hidden", false) ?: false,
                notify = compObj?.optBoolean("notify", true) ?: true,
                bubbles = compObj?.optBoolean("bubbles", true) ?: true,
                emotion = Mood.entries.firstOrNull { it.id == compObj?.optString("emotion") } ?: Mood.IDLE,
                sound = compObj?.optBoolean("sound", false) ?: false,
                size = compObj?.optDouble("size", 1.0)?.toFloat() ?: 1.0f,
                opacity = compObj?.optDouble("opacity", 1.0)?.toFloat() ?: 1.0f,
                outfit = compObj?.optString("outfit", "auto") ?: "auto",
                overlayEverywhere = compObj?.optBoolean("overlayEverywhere", true) ?: true
            ),
            notif = NotifPrefs(
                preview = nfObj?.optBoolean("preview", true) ?: true,
                style = nfObj?.optString("style", "detailed") ?: "detailed",
                sound = nfObj?.optBoolean("sound", true) ?: true,
                vibrate = nfObj?.optBoolean("vibrate", true) ?: true,
                quiet = nfObj?.optBoolean("quiet", false) ?: false,
                dailyReview = nfObj?.optString("dailyReview", "21:30") ?: "21:30",
                weeklyReview = nfObj?.optBoolean("weeklyReview", false) ?: false
            ),
            alarmLook = AlarmLook(
                layout = alObj?.optString("layout", "ornate") ?: "ornate",
                showSeconds = alObj?.optBoolean("showSeconds", false) ?: false,
                gradient = alObj?.optBoolean("gradient", true) ?: true,
                weatherLine = alObj?.optBoolean("weatherLine", false) ?: false
            ),
            alarms = alarms,
            tasks = tasks,
            notes = notes,
            habits = habits,
            placed = placed,
            journal = journal,
            countdowns = countdowns,
            meds = meds,
            userDays = userDays,
            apiKeys = apiKeys,
            convos = convos,
            downloads = downloads
        )
    }
}
