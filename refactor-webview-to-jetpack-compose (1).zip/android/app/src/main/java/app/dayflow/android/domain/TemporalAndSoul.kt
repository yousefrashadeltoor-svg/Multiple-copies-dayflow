package app.dayflow.android.domain

import app.dayflow.android.data.AlarmItem
import app.dayflow.android.data.Lang
import app.dayflow.android.data.Mood
import app.dayflow.android.data.TaskItem
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.random.Random

data class CompanionBubble(
    val id: String,
    val text: String,
    val kind: String, // reminder | mood | tip | reply
    val mood: Mood = Mood.IDLE,
    val actionTab: String? = null,
    val actionSub: String? = null
)

data class MiniBrainReply(
    val text: String,
    val mood: Mood,
    val actions: List<Map<String, String>> = emptyList(),
    val needsMoreInfo: Boolean = false
)

object TemporalAndSoul {
    private val GREET_MORNING = listOf(
        "صباح الفل يا صاحبي ☀️",
        "صباح الخير يا نجم، قوم بقى نعمل حاجة حلوة النهاردة",
        "صباحك سكر يا باشا، إيه خطة النهاردة؟",
        "النهاردة يوم جديد، يلا نبدأه صح",
        "صباح الجدعنة ☕",
        "صباح الورد، فنجان قهوة ونبدأ 💛"
    )
    private val GREET_EVENING = listOf(
        "مساء الجمال يا فندم 🌙",
        "إيه الأخبار؟ يومك كان عامل إيه؟",
        "مسا الخير، نلخص يومنا شوية؟",
        "بالليل بنرتاح ونحكي، إيه أخبارك؟",
        "مساء السكينة، إيه أحلى حاجة حصلت النهاردة؟"
    )
    private val WELCOME = listOf(
        "أهلاً بيك يا صاحبي 👋",
        "نوّرت، أقدر أساعدك في إيه؟",
        "تحت أمرك، اسأل أو قولي أعمل إيه",
        "أنا جاهز، اختار: مهمة، منبه، عادة، أو أي سؤال"
    )
    private val HAPPY = listOf(
        "كده عاجبني! استمر 👏",
        "برافو يا وحش 🔥",
        "أنا فخور بيك والله",
        "شغل نضيف، كمل كده ✨"
    )
    private val SAD = listOf(
        "عادي يا صاحبي، أيام وحشة بتيجي وبتعدي 🤍",
        "متزعلش من نفسك، انت بتحاول وده مهم",
        "خدها بالراحة النهاردة، مش مطلوب منك كل حاجة"
    )
    private val COLD = listOf(
        "الجو برد يا معلم، البس تقيل واشرب سخن ☕",
        "برد النهاردة! متنساش الشال والجاكيت"
    )
    private val CELEBRATE = listOf(
        "خلّصتها! جامد والله 🎉",
        "الله ينور، شغل عالي 🎊",
        "أنا مبسوط أكتر منك، بجد 👏"
    )

    fun nextAlarmOccurrence(alarms: List<AlarmItem>, from: LocalDateTime = LocalDateTime.now()): Pair<AlarmItem, LocalDateTime>? {
        var best: Pair<AlarmItem, LocalDateTime>? = null
        for (a in alarms) {
            if (!a.enabled) continue
            val parts = a.time.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: continue
            val m = parts.getOrNull(1)?.toIntOrNull() ?: continue
            if (h !in 0..23 || m !in 0..59) continue
            val lt = LocalTime.of(h, m)

            if (!a.date.isNullOrBlank() && a.days.isEmpty()) {
                val d = runCatching { LocalDate.parse(a.date) }.getOrNull() ?: continue
                val dt = LocalDateTime.of(d, lt)
                if (dt.isAfter(from) && (best == null || dt.isBefore(best!!.second))) {
                    best = a to dt
                }
                continue
            }
            if (a.days.isEmpty()) continue
            val anchorDate = if (!a.date.isNullOrBlank()) {
                val parsed = runCatching { LocalDate.parse(a.date) }.getOrNull() ?: from.toLocalDate()
                if (parsed.isAfter(from.toLocalDate())) parsed else from.toLocalDate()
            } else from.toLocalDate()

            for (offset in 0L..7L) {
                val d = anchorDate.plusDays(offset)
                val jsDow = d.dayOfWeek.value % 7 // Sunday = 0 .. Saturday = 6
                if (jsDow !in a.days) continue
                val dt = LocalDateTime.of(d, lt)
                if (!dt.isAfter(from)) continue
                if (best == null || dt.isBefore(best!!.second)) {
                    best = a to dt
                }
                break
            }
        }
        return best
    }

    fun greeting(lang: Lang, now: LocalDateTime = LocalDateTime.now()): String {
        if (lang == Lang.EN) {
            return when {
                now.hour < 12 -> "Morning, friend ☀️"
                now.hour >= 18 -> "Evening, friend 🌙"
                else -> "Ready when you are 👋"
            }
        }
        return when {
            now.hour < 12 -> GREET_MORNING.random()
            now.hour >= 18 -> GREET_EVENING.random()
            else -> WELCOME.random()
        }
    }

    fun moodFor(tasks: List<TaskItem>, now: LocalDateTime = LocalDateTime.now()): Mood {
        val today = CalendarAndDecor.dayKey(now.toLocalDate())
        val mine = tasks.filter { it.date == today }
        val done = mine.count { it.done }
        if (mine.isNotEmpty() && done == mine.size) return Mood.CELEBRATE
        if (now.monthValue in listOf(12, 1, 2)) return Mood.COLD
        if (now.hour < 5) return Mood.SLEEP
        if (done > 0) return Mood.HAPPY
        if (mine.size > 5 && done == 0) return Mood.WORRIED
        return Mood.IDLE
    }

    fun moodLine(mood: Mood, lang: Lang): String {
        if (lang == Lang.EN) {
            return when (mood) {
                Mood.HAPPY -> "Nice work!"
                Mood.SAD -> "It's okay, take it gently."
                Mood.COLD -> "Bundle up today."
                Mood.WELCOME -> "Welcome!"
                Mood.SLEEP -> "Zzz…"
                Mood.THINK -> "Thinking…"
                Mood.CELEBRATE -> "You finished everything!"
                Mood.WINK -> "On it."
                Mood.WORRIED -> "Lots on the plate — start small."
                Mood.IDLE -> "I'm right here if you need me."
            }
        }
        return when (mood) {
            Mood.HAPPY -> HAPPY[Random.nextInt(HAPPY.size)]
            Mood.SAD -> SAD[Random.nextInt(SAD.size)]
            Mood.COLD -> COLD[Random.nextInt(COLD.size)]
            Mood.WELCOME -> WELCOME[Random.nextInt(WELCOME.size)]
            Mood.SLEEP -> "أنا صاحي معاك بهدوء 😴"
            Mood.THINK -> "بفكر في خطوتك الجاية…"
            Mood.CELEBRATE -> CELEBRATE[Random.nextInt(CELEBRATE.size)]
            Mood.WINK -> "تحت أمرك 😉"
            Mood.WORRIED -> "عندك حاجات كتير، خلينا نبدأ بأصغر واحدة"
            Mood.IDLE -> "أنا هنا لو احتاجتني 👋"
        }
    }

    fun upcomingReminders(
        alarms: List<AlarmItem>,
        tasks: List<TaskItem>,
        lang: Lang,
        now: LocalDateTime = LocalDateTime.now()
    ): List<CompanionBubble> {
        val out = mutableListOf<CompanionBubble>()
        val today = CalendarAndDecor.dayKey(now.toLocalDate())
        nextAlarmOccurrence(alarms, now)?.let { (alarm, at) ->
            val mins = maxOf(1L, Duration.between(now, at).toMinutes())
            val hh = mins / 60
            val mm = mins % 60
            val t12 = Time12.format12(alarm.time, lang)
            val whenAr = if (hh > 0) "${Time12.fmtNum(hh, lang)} ساعة${if (mm > 0) " و${Time12.fmtNum(mm, lang)} دقيقة" else ""}" else "${Time12.fmtNum(mm, lang)} دقيقة"
            val whenEn = if (hh > 0) "${hh}h ${mm}m" else "${mm}m"
            out.add(
                CompanionBubble(
                    id = "alarm-${alarm.id}",
                    kind = "reminder",
                    mood = Mood.WORRIED,
                    actionTab = "alarms",
                    text = if (lang == Lang.AR) {
                        "فاضل $whenAr على منبه «${alarm.label.ifBlank { "المنبه" }}» ($t12) ⏰"
                    } else {
                        "Alarm “${alarm.label.ifBlank { "Alarm" }}” ($t12) in $whenEn ⏰"
                    }
                )
            )
        }

        val timed = tasks.filter { !it.done }
            .mapNotNull { t ->
                val d = runCatching { LocalDate.parse(t.date) }.getOrNull() ?: return@mapNotNull null
                val lt = t.dueTime?.let { raw ->
                    val p = raw.split(":")
                    val h = p.getOrNull(0)?.toIntOrNull()
                    val m = p.getOrNull(1)?.toIntOrNull()
                    if (h != null && m != null) LocalTime.of(h, m) else null
                } ?: LocalTime.of(12, 0)
                val dt = LocalDateTime.of(d, lt)
                val remMin = Duration.between(now, dt).toMinutes()
                if (remMin in 1..(48 * 60)) Triple(t, dt, remMin) else null
            }
            .minByOrNull { it.third }

        if (timed != null) {
            val (t, _, rem) = timed
            val due12 = t.dueTime?.let { Time12.format12(it, lang) }
            val left = when {
                rem >= 1440 -> "${Time12.fmtNum(rem / 1440, lang)} يوم"
                rem >= 60 -> "${Time12.fmtNum(rem / 60, lang)} ساعة"
                else -> "${Time12.fmtNum(rem, lang)} دقيقة"
            }
            out.add(
                CompanionBubble(
                    id = "task-${t.id}",
                    kind = "reminder",
                    mood = Mood.IDLE,
                    actionTab = "tools",
                    actionSub = "tasks",
                    text = if (lang == Lang.AR) {
                        "مهمة «${t.title}»${if (due12 != null) " الساعة $due12" else ""}، فاضل $left 📌"
                    } else {
                        "“${t.title}”${if (due12 != null) " at $due12" else ""} soon 📌"
                    }
                )
            )
        } else {
            val openToday = tasks.filter { it.date == today && !it.done }
            if (openToday.isNotEmpty()) {
                out.add(
                    CompanionBubble(
                        id = "task-${openToday.first().id}",
                        kind = "reminder",
                        mood = Mood.IDLE,
                        actionTab = "tools",
                        actionSub = "tasks",
                        text = if (lang == Lang.AR) {
                            "فاكر «${openToday.first().title}»؟ لسه مستنياك 📌"
                        } else {
                            "“${openToday.first().title}” is still waiting 📌"
                        }
                    )
                )
            }
        }

        CalendarAndDecor.upcomingOccasions(now.toLocalDate(), 1).firstOrNull()?.let { (d, occ) ->
            val days = Duration.between(now.toLocalDate().atStartOfDay(), d.atStartOfDay()).toDays()
            if (days in 0..30) {
                out.add(
                    CompanionBubble(
                        id = "occ-${occ.id}",
                        kind = "tip",
                        mood = Mood.HAPPY,
                        actionTab = "calendar",
                        text = if (lang == Lang.AR) {
                            if (days == 0L) "النهاردة ${occ.ar}! كل سنة وانت طيب 🌟"
                            else "فاضل ${Time12.fmtNum(days, lang)} يوم على ${occ.ar} 🎊"
                        } else {
                            "${occ.en} in $days days 🎊"
                        }
                    )
                )
            }
        }
        return out
    }

    /** Parses natural Arabic/English 12-hour or explicit time expressions -> HH:mm 24h internal format. */
    fun parseNaturalTime(raw: String): String? {
        val west = Time12.toWesternDigits(raw).lowercase()
        val m = Regex("""(\d{1,2})(?::(\d{2}))?\s*(ص|صباحا|صباحاً|الصبح|am|م|مساء|مساءً|بالليل|العصر|بليل|pm)?""").find(west)
            ?: return null
        val h0 = m.groupValues[1].toIntOrNull() ?: return null
        val mm = m.groupValues[2].toIntOrNull() ?: 0
        val mer = m.groupValues[3]
        if (mm !in 0..59) return null
        val h24 = when {
            mer.contains("م") || mer.contains("ليل") || mer.contains("عصر") || mer == "pm" -> {
                if (h0 in 1..11) h0 + 12 else if (h0 == 12) 12 else h0
            }
            mer.contains("ص") || mer == "am" -> {
                if (h0 == 12) 0 else h0
            }
            else -> if (h0 in 0..23) h0 else return null
        }
        if (h24 !in 0..23) return null
        return "%02d:%02d".format(h24, mm)
    }

    fun miniBrain(
        input: String,
        alarms: List<AlarmItem>,
        tasks: List<TaskItem>,
        habitsCount: Int,
        lang: Lang,
        now: LocalDateTime = LocalDateTime.now()
    ): MiniBrainReply {
        val west = Time12.toWesternDigits(input).trim()
        val q = west.lowercase()
        val ar = lang == Lang.AR
        val today = CalendarAndDecor.dayKey(now.toLocalDate())
        val tomorrow = CalendarAndDecor.dayKey(now.toLocalDate().plusDays(1))

        if (Regex("(منبه|نبهني|صحيني|alarm|wake)").containsMatchIn(q)) {
            val t24 = parseNaturalTime(q)
            if (t24 == null) {
                return MiniBrainReply(
                    text = if (ar) "أظبط المنبّه الساعة كام؟ قولّي مثلاً ٧ الصبح أو ٨:٣٠ بالليل." else "What time? e.g., 7:00 AM or 8:30 PM.",
                    mood = Mood.THINK,
                    needsMoreInfo = true
                )
            }
            val targetDate = if (q.contains("بكر") || q.contains("غد") || q.contains("tomorrow")) tomorrow else today
            val t12 = Time12.format12(t24, lang)
            return MiniBrainReply(
                text = if (ar) "تمام، ظبطتلك منبّه الساعة $t12 يوم $targetDate ⏰" else "Saved your alarm for $t12 on $targetDate ⏰",
                mood = Mood.HAPPY,
                actions = listOf(
                    mapOf(
                        "intent" to "addAlarm",
                        "time" to t24,
                        "date" to targetDate,
                        "label" to if (ar) "منبّه من المساعد" else "Assistant alarm"
                    )
                )
            )
        }

        if (Regex("(ماية|ماء|water|اشرب)").containsMatchIn(q)) {
            return MiniBrainReply(
                text = if (ar) "سجلتلك كوباية ٢٥٠ مل 💧 بالهنا والشفا!" else "Logged 250 ml of water 💧",
                mood = Mood.HAPPY,
                actions = listOf(mapOf("intent" to "addWater", "ml" to "250"))
            )
        }

        if (Regex("(مهمة|تاسك|ضيف|أضف|task|todo)").containsMatchIn(q)) {
            val cleaned = west
                .replace(Regex("(ضيف|أضف|اعمل|مهمة|تاسك|task|todo|بكرة|بكره|النهاردة|النهارده|اليوم|tomorrow|today)", RegexOption.IGNORE_CASE), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (cleaned.length < 2) {
                return MiniBrainReply(
                    text = if (ar) "قولي اسم المهمة وأنا أسجلها فوراً 📝" else "Tell me the task title 📝",
                    mood = Mood.THINK,
                    needsMoreInfo = true
                )
            }
            val date = if (q.contains("بكر") || q.contains("tomorrow")) tomorrow else today
            return MiniBrainReply(
                text = if (ar) "سجلت مهمة «$cleaned» ليوم $date ✅" else "Added task “$cleaned” for $date ✅",
                mood = Mood.HAPPY,
                actions = listOf(mapOf("intent" to "addTask", "title" to cleaned, "date" to date))
            )
        }

        if (Regex("(كام مهمة|مهامي|المهام|tasks)").containsMatchIn(q)) {
            val left = tasks.count { !it.done && it.date == today }
            return MiniBrainReply(
                text = if (ar) {
                    if (left == 0) "معندكش مهام متأخرة النهاردة، الله ينور 👏"
                    else "فاضل عندك ${Time12.fmtNum(left, lang)} مهام للنهاردة، نبدأ بأول واحدة؟"
                } else "$left tasks remaining today.",
                mood = if (left == 0) Mood.CELEBRATE else Mood.IDLE
            )
        }

        if (Regex("(تحميل|فيديو|رابط|لينك|download|media)").containsMatchIn(q)) {
            return MiniBrainReply(
                text = if (ar) "فتحتلك شاشة التحميل المباشر، الصق أي رابط وهيعرضلك الغلاف والعنوان والصيغ الحقيقية فوراً 📥" else "Opening Downloads — paste any link for instant native analysis 📥",
                mood = Mood.HAPPY,
                actions = listOf(mapOf("intent" to "open", "tab" to "downloads"))
            )
        }

        if (Regex("(منبهاتي|منبهات)").containsMatchIn(q)) {
            val onCount = alarms.count { it.enabled }
            return MiniBrainReply(
                text = if (ar) "عندك ${Time12.fmtNum(onCount, lang)} منبه شغّال دلوقتي." else "You have $onCount active alarms.",
                mood = Mood.IDLE,
                actions = listOf(mapOf("intent" to "open", "tab" to "alarms"))
            )
        }

        if (Regex("(صباح|مساء|ازيك|إزيك|اهلا|hello|hi)").containsMatchIn(q)) {
            return MiniBrainReply(text = greeting(lang, now), mood = Mood.HAPPY)
        }

        if (Regex("(مين انت|اسمك|who are you)").containsMatchIn(q)) {
            return MiniBrainReply(
                text = if (ar) "أنا رفيق DAYFLOW الأصلي على أندرويد، شغال معاك في الهاتف كله وبساعدك في منبهاتك ومهامك ويومك 🤖✨" else "I'm your native DAYFLOW Android companion 🤖✨",
                mood = Mood.WELCOME
            )
        }

        return MiniBrainReply(
            text = if (ar) "أنا معاك! تقدر تقولي: «اعمل منبه ٧ الصبح»، «ضيف مهمة مذاكرة»، «سجل ماية»، أو «مهامي كام؟»." else "Try: “Set alarm 7 AM”, “Add task read chapter”, or “Log water”.",
            mood = Mood.IDLE
        )
    }
}
