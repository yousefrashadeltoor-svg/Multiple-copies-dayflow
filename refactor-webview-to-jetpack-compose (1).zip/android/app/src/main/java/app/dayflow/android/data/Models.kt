package app.dayflow.android.data

import java.util.UUID

enum class Lang(val code: String) { EN("en"), AR("ar") }
enum class Intensity(val id: String) { OFF("off"), SUBTLE("subtle"), RICH("rich"), FESTIVAL("festival") }
enum class SoundSource(val id: String) { LIBRARY("library"), DEVICE("device"), FILES("files"), DOWNLOADED("downloaded") }
enum class HabitType(val id: String) { BUILD("build"), QUIT("quit"), COUNT("count"), TIMER("timer") }
enum class Mood(val id: String) {
    IDLE("idle"), HAPPY("happy"), SAD("sad"), COLD("cold"), WELCOME("welcome"),
    SLEEP("sleep"), THINK("think"), CELEBRATE("celebrate"), WINK("wink"), WORRIED("worried")
}

data class SoundSpec(
    val source: SoundSource = SoundSource.DEVICE,
    val title: String = "منبه الجهاز الافتراضي",
    val uri: String = ""
)

data class AlarmItem(
    val id: String = newUid(),
    val time: String = "07:00", // Stored internally as HH:mm, ALWAYS displayed/picked as 12-hour!
    val date: String? = null,
    val days: List<Int> = emptyList(), // 0=Sun .. 6=Sat
    val label: String = "",
    val enabled: Boolean = true,
    val sound: SoundSpec = SoundSpec(),
    val vibrate: Boolean = true,
    val snooze: Int = 10,
    val gentle: Boolean = true
)

data class TaskItem(
    val id: String = newUid(),
    val title: String,
    val date: String,
    val dueTime: String? = null,
    val done: Boolean = false,
    val urgent: Boolean = false,
    val important: Boolean = true,
    val status: String = "todo", // todo | doing | done
    val createdAt: Long = System.currentTimeMillis()
)

data class NoteItem(
    val id: String = newUid(),
    val text: String,
    val pinned: Boolean = false,
    val at: Long = System.currentTimeMillis()
)

data class HabitItem(
    val id: String = newUid(),
    val en: String,
    val ar: String? = null,
    val log: List<String> = emptyList(),
    val type: HabitType = HabitType.BUILD,
    val days: List<Int> = listOf(0, 1, 2, 3, 4, 5, 6),
    val startDate: String? = null,
    val target: Int = 1,
    val unit: String = "",
    val details: String = "",
    val emoji: String = "🌅",
    val color: String = "#2fa36b",
    val reminder: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class PlacedWidget(
    val id: String = newUid(),
    val appWidgetId: Int = -1,
    val designId: String = "clock-minimal-digital",
    val w: Int = 2,
    val h: Int = 2,
    val style: String = "oneui",
    val tapOpens: Boolean = true
)

data class JournalEntry(
    val id: String = newUid(),
    val date: String,
    val mood: Int = 3,
    val text: String = ""
)

data class CountdownItem(
    val id: String = newUid(),
    val title: String,
    val date: String
)

data class MedItem(
    val id: String = newUid(),
    val name: String,
    val times: List<String> = listOf("09:00"),
    val taken: Map<String, List<String>> = emptyMap()
)

data class UserDay(
    val id: String = newUid(),
    val date: String, // MM-DD
    val en: String,
    val ar: String,
    val kind: String = "custom",
    val family: String = "birthday"
)

data class NotifPrefs(
    val preview: Boolean = true,
    val style: String = "detailed", // minimal | detailed | occasion
    val sound: Boolean = true,
    val vibrate: Boolean = true,
    val quiet: Boolean = false,
    val dailyReview: String = "21:30",
    val weeklyReview: Boolean = false
)

data class AlarmLook(
    val layout: String = "ornate", // ornate | midnight | minimal | glass
    val showSeconds: Boolean = false,
    val gradient: Boolean = true,
    val weatherLine: Boolean = false
)

data class RobotPrefs(
    val enabled: Boolean = true,
    val hidden: Boolean = false,
    val notify: Boolean = true,
    val bubbles: Boolean = true,
    val emotion: Mood = Mood.IDLE,
    val sound: Boolean = false,
    val size: Float = 1.0f,
    val opacity: Float = 1.0f,
    val outfit: String = "auto", // auto | gold | snow | national | none
    val overlayEverywhere: Boolean = true
)

data class DecorSurfaces(
    val app: Boolean = true,
    val notifications: Boolean = true,
    val widgets: Boolean = true,
    val icon: Boolean = false,
    val companion: Boolean = true
)

data class ApiKeyEntry(
    val id: String = newUid(),
    val provider: String,
    val label: String = "",
    val key: String,
    val baseUrl: String = "",
    val liveModels: List<String> = emptyList()
)

data class ChatMsg(
    val id: String = newUid(),
    val role: String, // user | assistant
    val content: String,
    val reasoning: String = "",
    val at: Long = System.currentTimeMillis()
)

data class Conversation(
    val id: String = newUid(),
    val title: String,
    val messages: List<ChatMsg> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class CustomThemeData(
    val id: String = newUid(),
    val en: String,
    val ar: String,
    val mode: String = "light",
    val bg: String = "#f7f5f0",
    val surface: String = "#ffffff",
    val text: String = "#1d1c1a",
    val accent: String = "#2f6f5e",
    val accent2: String = "#c9a24a",
    val material: String = "paper",
    val shape: String = "round",
    val font: String = "sans",
    val motion: String = "calm",
    val texture: String = "grain",
    val ornament: String = "islamic"
)

data class DownloadFormatItem(
    val id: String,
    val label: String,
    val detail: String,
    val size: Long = 0L,
    val kind: String = "video", // video | audio | image | file
    val url: String = "",
    val height: Int = 0
)

data class LinkAnalysisResult(
    val url: String,
    val kind: String, // video | audio | image | hls | dash | file | page
    val host: String,
    val site: String,
    val secure: Boolean,
    val title: String,
    val thumb: String = "",
    val author: String = "",
    val description: String = "",
    val durationSec: Int = 0,
    val size: Long = 0L,
    val mime: String = "",
    val rangeOk: Boolean = false,
    val filename: String = "download",
    val formats: List<DownloadFormatItem> = emptyList(),
    val engines: List<String> = emptyList(),
    val engineNote: String = "",
    val direct: Boolean = false
)

data class DownloadTaskItem(
    val id: String = newUid(),
    val url: String,
    val variantUrl: String = "",
    val name: String,
    val kind: String = "file",
    val host: String = "",
    val site: String = "generic",
    val secure: Boolean = true,
    val thumb: String = "",
    val quality: String = "",
    val formatId: String = "",
    val size: Long = 0L,
    val got: Long = 0L,
    val state: String = "queued", // queued | downloading | paused | completed | failed | cancelled
    val engine: String = "ytdlp",
    val notices: List<String> = emptyList(),
    val error: String = "",
    val addedAt: Long = System.currentTimeMillis(),
    val doneAt: Long = 0L,
    val speed: Long = 0L,
    val etaSec: Long = 0L,
    val resumable: Boolean = true,
    val savedPath: String = "",
    val mime: String = ""
)

data class DownloadSettings(
    val order: List<String> = listOf("ytdlp", "newpipe", "aria2c", "hls-segments", "http-multipart"),
    val concurrent: Int = 3,
    val connections: Int = 6,
    val speedLimitKBps: Int = 0,
    val wifiOnly: Boolean = false,
    val autoResume: Boolean = true,
    val autoRetry: Int = 2,
    val autoPaste: Boolean = true,
    val nightOnly: Boolean = false,
    val saveDir: String = "Download/DayFlow"
)

data class DayflowState(
    val lang: Lang = Lang.AR,
    val themeId: String = "paper-white",
    val customThemes: List<CustomThemeData> = emptyList(),
    val favThemes: List<String> = emptyList(),
    val intensity: Intensity = Intensity.SUBTLE,
    val decorSurfaces: DecorSurfaces = DecorSurfaces(),
    val decorLayer: String = "behind",
    val powerMode: Boolean = false,
    val reduceMotion: Boolean = false,
    val reviewTone: String = "balanced",
    val spiritual: Boolean = false,
    val examSeason: Boolean = false,
    val sampleData: Boolean = false,
    val feedback: Map<String, Int> = emptyMap(),
    val hour12: Boolean = true, // STRICT 12-HOUR CLOCK ALWAYS!
    val aiShareContext: Boolean = false,
    val companion: RobotPrefs = RobotPrefs(),
    val alarms: List<AlarmItem> = emptyList(),
    val tasks: List<TaskItem> = emptyList(),
    val notes: List<NoteItem> = emptyList(),
    val habits: List<HabitItem> = emptyList(),
    val water: Map<String, Int> = emptyMap(),
    val waterGoal: Int = 2500,
    val workout: Map<String, List<Pair<String, Int>>> = emptyMap(),
    val userDays: List<UserDay> = emptyList(),
    val placed: List<PlacedWidget> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val countdowns: List<CountdownItem> = emptyList(),
    val meds: List<MedItem> = emptyList(),
    val tasbih: Int = 0,
    val khatma: Int = 0,
    val clipboardWatch: Boolean = false,
    val apiKeys: List<ApiKeyEntry> = emptyList(),
    val activeKeyId: String? = null,
    val activeModel: String = "",
    val aiReasoning: Boolean = true,
    val convos: List<Conversation> = emptyList(),
    val notif: NotifPrefs = NotifPrefs(),
    val alarmLook: AlarmLook = AlarmLook(),
    val widgetFont: String = "sans",
    val cityIndex: Int = 1, // Giza default (index 0 = Cairo, index 1 = Giza)
    val useGpsLocation: Boolean = false,
    val gpsLat: Double? = null,
    val gpsLng: Double? = null,
    val gpsLabel: String = "",
    val autoTimeTheme: Boolean = true,
    val ambientPhoto: Boolean = true,
    val periodThemes: Map<String, String> = emptyMap(),
    val downloads: List<DownloadTaskItem> = emptyList(),
    val downloadSettings: DownloadSettings = DownloadSettings()
)

fun newUid(): String = UUID.randomUUID().toString().replace("-", "").take(10)
