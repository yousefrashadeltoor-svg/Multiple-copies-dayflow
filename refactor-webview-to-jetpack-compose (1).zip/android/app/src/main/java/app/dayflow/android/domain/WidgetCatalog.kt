package app.dayflow.android.domain

data class WidgetDef(
    val id: String,
    val en: String,
    val ar: String,
    val cat: String,
    val arche: String,
    val variant: Int,
    val interactive: Boolean,
    val forms: List<String>
)

object WidgetCatalog {
    val FORMS = listOf("1x1", "2x1", "2x2", "4x1", "4x2", "4x4")

    val WCATS = listOf(
        Triple("clock", "Clock", "الساعة"),
        Triple("alarms", "Alarms", "المنبهات"),
        Triple("calendar", "Calendar", "التقويم"),
        Triple("occasions", "Occasions", "المناسبات"),
        Triple("plan", "Plan & today", "الخطة واليوم"),
        Triple("tasks", "Tasks & notes", "المهام والملاحظات"),
        Triple("habits", "Habits & health", "العادات والصحة"),
        Triple("focus", "Focus & study", "التركيز والدراسة"),
        Triple("review", "Review & stats", "المراجعة والإحصاءات"),
        Triple("media", "Media Hub", "مركز الوسائط"),
        Triple("utility", "Utility", "أدوات"),
        Triple("companion", "Companion", "الرفيق")
    )

    val WSTYLES = listOf(
        Triple("oneui", "One UI Glass", "زجاج One UI"),
        Triple("material", "Material You", "Material You"),
        Triple("ios", "iOS-inspired", "مستوحى من iOS"),
        Triple("editorial", "Editorial", "تحريري"),
        Triple("neon", "Neon", "نيون"),
        Triple("paper", "Paper", "ورق"),
        Triple("clay", "Soft Clay", "صلصال"),
        Triple("outline", "Minimal Outline", "خطوط بسيطة"),
        Triple("amoled", "AMOLED", "أموليد"),
        Triple("seasonal", "Seasonal", "موسمي")
    )

    val WIDGET_FONTS = listOf(
        Triple("sans", "System sans", "خط النظام"),
        Triple("naskh", "Naskh (serif)", "نسخ"),
        Triple("kufi", "Kufi", "كوفي"),
        Triple("cairo", "Cairo", "القاهرة"),
        Triple("rounded", "Rounded", "مستدير"),
        Triple("mono", "Mono numerals", "أرقام ثابتة")
    )

    private fun slug(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')

    private data class RawRow(val en: String, val ar: String, val arche: String, val inter: Boolean)

    private val RAW: Map<String, List<RawRow>> = linkedMapOf(
        "clock" to listOf(
            RawRow("Minimal digital", "رقمية بسيطة", "digital", false),
            RawRow("Bold block", "كتلة عريضة", "digital", false),
            RawRow("Split flap", "لوحة متقلبة", "flip", false),
            RawRow("Flip clock", "ساعة قلّابة", "flip", false),
            RawRow("Dot-matrix", "مصفوفة نقطية", "digital", false),
            RawRow("Stacked words", "كلمات متراصة", "digital", false),
            RawRow("Analog classic", "عقارب كلاسيكية", "analog", false),
            RawRow("Analog skeleton", "عقارب هيكلية", "analog", false),
            RawRow("Analog luxury", "عقارب فاخرة", "analog", false),
            RawRow("Analog minimal", "عقارب بسيطة", "analog", false),
            RawRow("Sun-arc clock", "ساعة قوس الشمس", "sunarc", false),
            RawRow("Orbit clock", "ساعة المدار", "analog", false),
            RawRow("World clock", "ساعة عالمية", "world", false),
            RawRow("Dual-time", "توقيت مزدوج", "world", false),
            RawRow("Clock + day summary", "ساعة + ملخص اليوم", "digital", false),
            RawRow("Bedside clock", "ساعة السرير", "digital", false)
        ),
        "alarms" to listOf(
            RawRow("Next alarm pill", "كبسولة المنبه التالي", "countdown", true),
            RawRow("Alarm ring-dial", "قرص المنبه", "dial", true),
            RawRow("Alarm list + toggles", "قائمة المنبهات", "checklist", true),
            RawRow("Alarm timeline strip", "شريط المنبهات الزمني", "timeline", false),
            RawRow("Alarm week grid", "شبكة أسبوع المنبهات", "week", false),
            RawRow("Countdown to alarm", "عد تنازلي للمنبه", "countdown", false),
            RawRow("Sleep-alarm combo", "النوم والمنبه", "dial", true),
            RawRow("Snooze tracker", "متتبع الغفوة", "bars", false)
        ),
        "calendar" to listOf(
            RawRow("Month compact", "شهر مدمج", "month", false),
            RawRow("Month with artwork", "شهر بالزخارف", "month", false),
            RawRow("Month heatmap", "خريطة حرارية شهرية", "heatmap", false),
            RawRow("Week strip", "شريط الأسبوع", "week", false),
            RawRow("Week columns", "أعمدة الأسبوع", "week", false),
            RawRow("Agenda list", "قائمة الأجندة", "list", false),
            RawRow("Agenda with artwork", "أجندة بالزخارف", "list", false),
            RawRow("Year dots", "نقاط السنة", "mosaic", false),
            RawRow("Hijri month", "الشهر الهجري", "month", false),
            RawRow("Coptic month", "الشهر القبطي", "month", false),
            RawRow("Tri-calendar date card", "بطاقة التقاويم الثلاثة", "tri", false),
            RawRow("Day ring", "حلقة اليوم", "ring", false),
            RawRow("Schedule river", "نهر الجدول", "timeline", false),
            RawRow("Date flip", "تاريخ قلاب", "flip", false)
        ),
        "occasions" to listOf(
            RawRow("Occasion hero", "بطل المناسبة", "hero", false),
            RawRow("Occasion countdown ring", "حلقة العد للمناسبة", "ring", false),
            RawRow("Upcoming carousel", "المناسبات القادمة", "list", false),
            RawRow("Ramadan imsakiya", "إمساكية رمضان", "list", false),
            RawRow("Iftar countdown", "العد للإفطار", "countdown", false),
            RawRow("Eid greeting card", "بطاقة تهنئة العيد", "hero", false),
            RawRow("Season greeting", "تحية الموسم", "hero", false),
            RawRow("Nile & Egyptian seasons", "النيل والمواسم المصرية", "hero", false),
            RawRow("National-day card", "بطاقة اليوم الوطني", "hero", false),
            RawRow("Friday card", "بطاقة الجمعة", "hero", false),
            RawRow("Hijri date card", "بطاقة التاريخ الهجري", "tri", false)
        ),
        "plan" to listOf(
            RawRow("Current activity", "النشاط الحالي", "timeline", false),
            RawRow("Now · Next · Later", "الآن · التالي · لاحقًا", "list", false),
            RawRow("Timeline vertical", "خط زمني رأسي", "timeline", false),
            RawRow("Timeline horizontal", "خط زمني أفقي", "timeline", false),
            RawRow("Free-time gauge", "مقياس الوقت الحر", "dial", false),
            RawRow("Day progress ring", "حلقة تقدم اليوم", "ring", false),
            RawRow("Daily brief", "موجز اليوم", "list", false),
            RawRow("Top priorities", "أهم الأولويات", "checklist", true),
            RawRow("Focus window", "نافذة التركيز", "timeline", false),
            RawRow("Plan board", "لوحة الخطة", "kanban", false),
            RawRow("Yesterday · Today · Tomorrow", "أمس · اليوم · غدًا", "week", false),
            RawRow("Schedule health", "صحة الجدول", "ring", false),
            RawRow("Routine checklist", "قائمة الروتين", "checklist", true)
        ),
        "tasks" to listOf(
            RawRow("Checklist", "قائمة تحقق", "checklist", true),
            RawRow("Task rings", "حلقات المهام", "ring", false),
            RawRow("Eisenhower matrix", "مصفوفة أيزنهاور", "matrix", true),
            RawRow("Kanban strip", "شريط كانبان", "kanban", false),
            RawRow("Quick-add bar", "شريط إضافة سريعة", "quick", true),
            RawRow("Pinned note paper", "ورقة ملاحظة مثبتة", "note", false),
            RawRow("Sticky-note stack", "كومة ملاحظات لاصقة", "note", false),
            RawRow("Notes grid", "شبكة الملاحظات", "mosaic", false),
            RawRow("Handwritten note", "ملاحظة بخط اليد", "note", false),
            RawRow("Checklist cards", "بطاقات تحقق", "checklist", true),
            RawRow("Overdue list", "المتأخرات", "list", false),
            RawRow("Subtasks tree", "شجرة المهام الفرعية", "list", true),
            RawRow("Shopping list", "قائمة التسوق", "checklist", true),
            RawRow("Voice-note button", "زر ملاحظة صوتية", "quick", true),
            RawRow("Journal prompt", "سؤال اليوميات", "note", false)
        ),
        "habits" to listOf(
            RawRow("Habit grid", "شبكة العادات", "heatmap", true),
            RawRow("Habit heatmap", "خريطة العادات", "heatmap", false),
            RawRow("Streak card", "بطاقة السلسلة", "counter", false),
            RawRow("Water drop", "قطرة ماء", "drop", true),
            RawRow("Water bottle", "زجاجة ماء", "drop", true),
            RawRow("Water cups", "أكواب الماء", "bars", true),
            RawRow("Sleep dial", "قرص النوم", "dial", false),
            RawRow("Bedtime countdown", "العد لوقت النوم", "countdown", false),
            RawRow("Workout today", "تمرين اليوم", "ring", true),
            RawRow("Workout week", "تمارين الأسبوع", "bars", false),
            RawRow("Medication schedule", "جدول الأدوية", "checklist", true),
            RawRow("Mood strip", "شريط المزاج", "mosaic", true)
        ),
        "focus" to listOf(
            RawRow("Focus timer ring", "حلقة مؤقت التركيز", "ring", true),
            RawRow("Pomodoro cycle", "دورة بومودورو", "dial", true),
            RawRow("Study planner", "مخطط الدراسة", "list", false),
            RawRow("Exam countdown stack", "عد الامتحانات", "countdown", false),
            RawRow("Subject progress", "تقدم المواد", "bars", false),
            RawRow("Deep-work block", "فترة عمل عميق", "timeline", false),
            RawRow("Break reminder", "تذكير الاستراحة", "countdown", false),
            RawRow("Study streak", "سلسلة الدراسة", "counter", false)
        ),
        "review" to listOf(
            RawRow("Daily score ring", "حلقة نتيجة اليوم", "ring", false),
            RawRow("Weekly radar", "رادار الأسبوع", "radar", false),
            RawRow("Yearly mosaic", "فسيفساء السنة", "mosaic", false),
            RawRow("Strengths card", "بطاقة نقاط القوة", "bars", false),
            RawRow("What you did", "ماذا أنجزت", "list", false),
            RawRow("Productivity sparkline", "خط الإنتاجية", "spark", false),
            RawRow("Time-budget donut", "دونات ميزانية الوقت", "donut", false),
            RawRow("Consistency calendar", "تقويم الاستمرارية", "heatmap", false),
            RawRow("Trend arrow", "سهم الاتجاه", "spark", false),
            RawRow("Milestone card", "بطاقة الإنجاز", "counter", false),
            RawRow("Personal records", "الأرقام الشخصية", "bars", false)
        ),
        "media" to listOf(
            RawRow("Active downloads", "التنزيلات النشطة", "download", true),
            RawRow("Paste-link tile", "بلاطة لصق الرابط", "quick", true),
            RawRow("Download history", "سجل التنزيلات", "list", false),
            RawRow("Recent audio", "أحدث الصوتيات", "list", false),
            RawRow("Recent video", "أحدث الفيديو", "mosaic", false),
            RawRow("Storage usage", "استخدام التخزين", "donut", false)
        ),
        "utility" to listOf(
            RawRow("Battery ring", "حلقة البطارية", "battery", false),
            RawRow("Battery detail", "تفاصيل البطارية", "battery", false),
            RawRow("Quick actions grid", "شبكة الإجراءات السريعة", "quick", true),
            RawRow("Stopwatch", "ساعة إيقاف", "digital", true),
            RawRow("Timer", "مؤقت", "ring", true),
            RawRow("Unit tile", "بلاطة الوحدات", "quick", false),
            RawRow("Tasbih counter", "عداد التسبيح", "counter", true),
            RawRow("Khatma tracker", "متتبع الختمة", "bars", true),
            RawRow("Prayer schedule", "جدول الصلوات", "prayer", false),
            RawRow("Qibla compass", "بوصلة القبلة", "compass", false),
            RawRow("Prayer times strip", "شريط مواقيت الصلاة", "prayer", false),
            RawRow("Next prayer", "الصلاة القادمة", "nextprayer", false),
            RawRow("Prayer times (ornate)", "المواقيت بالزخرفة", "prayer", false),
            RawRow("Next prayer ring", "حلقة الصلاة القادمة", "nextprayer", false),
            RawRow("Fajr & Maghrib card", "بطاقة الفجر والمغرب", "nextprayer", false),
            RawRow("Mosque board", "لوحة المسجد", "prayer", false),
            RawRow("Adhkar & Tasbih", "الأذكار والتسبيح", "counter", true),
            RawRow("Khatma + prayer", "الختمة والصلاة", "bars", false),
            RawRow("Countdown", "عد تنازلي", "countdown", false),
            RawRow("Anniversary card", "بطاقة الذكرى", "hero", false),
            RawRow("Date calculator", "حاسبة التاريخ", "tri", false),
            RawRow("QR quick scan", "مسح QR سريع", "quick", true)
        ),
        "companion" to listOf(
            RawRow("Companion portrait", "صورة الرفيق", "portrait", false),
            RawRow("Companion quick-actions", "إجراءات الرفيق", "quick", true),
            RawRow("Companion mood", "مزاج الرفيق", "portrait", false),
            RawRow("Companion tip", "نصيحة الرفيق", "portrait", false)
        )
    )

    val WIDGETS: List<WidgetDef> = RAW.flatMap { (cat, rows) ->
        rows.mapIndexed { idx, r ->
            val allowedForms = when (r.arche) {
                "matrix", "kanban", "month" -> listOf("2x2", "4x2", "4x4")
                "note" -> listOf("2x1", "2x2", "4x2", "4x4")
                else -> FORMS
            }
            WidgetDef(
                id = "$cat-${slug(r.en)}",
                en = r.en,
                ar = r.ar,
                cat = cat,
                arche = r.arche,
                variant = idx,
                interactive = r.inter,
                forms = allowedForms
            )
        }
    }

    fun formSize(f: String): Pair<Int, Int> {
        val p = f.split("x")
        return (p.getOrNull(0)?.toIntOrNull() ?: 2) to (p.getOrNull(1)?.toIntOrNull() ?: 2)
    }

    fun resolveForm(def: WidgetDef, w: Int, h: Int): String {
        var best = def.forms.first()
        var bestScore = Int.MIN_VALUE
        for (f in def.forms) {
            val (fw, fh) = formSize(f)
            if (fw > w || fh > h) continue
            val score = fw * fh * 10 - (w - fw) - (h - fh)
            if (score > bestScore) {
                bestScore = score
                best = f
            }
        }
        return best
    }
}
