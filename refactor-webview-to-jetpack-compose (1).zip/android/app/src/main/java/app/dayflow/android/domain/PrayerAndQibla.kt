package app.dayflow.android.domain

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Geocoder
import android.location.LocationManager
import app.dayflow.android.R
import app.dayflow.android.data.DayflowState
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

data class CityLocation(
    val lat: Double,
    val lng: Double,
    val cityEn: String,
    val cityAr: String,
    val zoneId: String = "Africa/Cairo",
    val fajrAngle: Double = 19.5,
    val ishaAngle: Double = 17.5
)

data class NextPrayerInfo(
    val key: String,
    val nameEn: String,
    val nameAr: String,
    val time24: String,
    val inMinutes: Int
)

data class PrayerSchedule(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val next: NextPrayerInfo,
    val qiblaDeg: Float,
    val locationEn: String,
    val locationAr: String
) {
    fun byKey(k: String): String = when (k) {
        "fajr" -> fajr
        "sunrise" -> sunrise
        "dhuhr" -> dhuhr
        "asr" -> asr
        "maghrib" -> maghrib
        "isha" -> isha
        else -> dhuhr
    }
}

enum class DayPeriod(
    val id: String,
    val en: String,
    val ar: String,
    val photoRes: Int,
    val defaultThemeId: String,
    val tintArgb: Long
) {
    FAJR("fajr", "Dawn", "الفجر", R.drawable.photo_dawn, "luxor-dawn", 0x59281E3C),
    MORNING("morning", "Morning", "الصباح", R.drawable.photo_noon, "paper-white", 0x2EFFFFFF),
    NOON("noon", "Noon", "الظهر", R.drawable.photo_noon, "nile-blue", 0x2E143C6E),
    ASR("asr", "Afternoon", "العصر", R.drawable.photo_asr, "desert-gold", 0x40784614),
    MAGHRIB("maghrib", "Sunset", "المغرب", R.drawable.photo_maghrib, "aswan-sunset", 0x613C141E),
    NIGHT("night", "Night", "الليل", R.drawable.photo_night, "cairo-night", 0x80050814)
}

object PrayerAndQibla {
    val PRAYER_META = listOf(
        arrayOf("fajr", "Fajr", "الفجر", "🌅"),
        arrayOf("sunrise", "Sunrise", "الشروق", "☀️"),
        arrayOf("dhuhr", "Dhuhr", "الظهر", "🕛"),
        arrayOf("asr", "Asr", "العصر", "🌤️"),
        arrayOf("maghrib", "Maghrib", "المغرب", "🌇"),
        arrayOf("isha", "Isha", "العشاء", "🌙")
    )

    val CITIES = listOf(
        CityLocation(30.0444, 31.2357, "Cairo", "القاهرة"),
        CityLocation(30.0131, 31.2089, "Giza", "الجيزة"),
        CityLocation(30.4660, 31.1848, "Qalyubia (Benha)", "القليوبية (بنها)"),
        CityLocation(31.2001, 29.9187, "Alexandria", "الإسكندرية"),
        CityLocation(31.0409, 31.3785, "Mansoura", "المنصورة"),
        CityLocation(30.7865, 31.0004, "Tanta", "طنطا"),
        CityLocation(30.5877, 31.5020, "Zagazig", "الزقازيق"),
        CityLocation(30.5503, 31.0106, "Shibin El-Kom", "شبين الكوم"),
        CityLocation(31.0379, 30.4726, "Damanhur", "دمنهور"),
        CityLocation(31.1107, 30.9388, "Kafr El-Sheikh", "كفر الشيخ"),
        CityLocation(31.4175, 31.8144, "Damietta", "دمياط"),
        CityLocation(31.2653, 32.3019, "Port Said", "بورسعيد"),
        CityLocation(30.5965, 32.2715, "Ismailia", "الإسماعيلية"),
        CityLocation(29.9668, 32.5498, "Suez", "السويس"),
        CityLocation(29.3084, 30.8428, "Fayoum", "الفيوم"),
        CityLocation(29.0661, 31.0994, "Beni Suef", "بني سويف"),
        CityLocation(28.1099, 30.7503, "Minya", "المنيا"),
        CityLocation(27.1810, 31.1837, "Assiut", "أسيوط"),
        CityLocation(26.5591, 31.6957, "Sohag", "سوهاج"),
        CityLocation(26.1551, 32.7160, "Qena", "قنا"),
        CityLocation(25.6872, 32.6396, "Luxor", "الأقصر"),
        CityLocation(24.0889, 32.8998, "Aswan", "أسوان"),
        CityLocation(27.2579, 33.8116, "Hurghada", "الغردقة"),
        CityLocation(27.9158, 34.3299, "Sharm El-Sheikh", "شرم الشيخ"),
        CityLocation(31.3543, 27.2373, "Marsa Matruh", "مرسى مطروح"),
        CityLocation(31.1321, 33.8033, "Arish", "العريش"),
        CityLocation(25.4514, 30.5463, "New Valley (Kharga)", "الوادي الجديد"),
        CityLocation(21.4225, 39.8262, "Makkah", "مكة المكرمة", "Asia/Riyadh", 18.5, 18.5),
        CityLocation(24.4686, 39.6142, "Madinah", "المدينة المنورة", "Asia/Riyadh", 18.5, 18.5),
        CityLocation(31.7780, 35.2354, "Al-Quds", "القدس", "Asia/Jerusalem", 18.0, 17.0),
        CityLocation(25.2048, 55.2708, "Dubai", "دبي", "Asia/Dubai", 18.2, 18.2),
        CityLocation(51.5074, -0.1278, "London", "لندن", "Europe/London", 18.0, 17.0)
    )

    private fun fixAngle(a: Double): Double = ((a % 360.0) + 360.0) % 360.0
    private fun fixHour(h: Double): Double = ((h % 24.0) + 24.0) % 24.0
    private fun rad(d: Double): Double = Math.toRadians(d)
    private fun deg(r: Double): Double = Math.toDegrees(r)

    private fun julianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(rad(g)) + 0.020 * sin(rad(2.0 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(deg(atan2(cos(rad(e)) * sin(rad(l)), cos(rad(l)))) / 15.0)
        val decl = deg(asin(sin(rad(e)) * sin(rad(l))))
        var eqt = q / 15.0 - ra
        if (eqt > 12.0) eqt -= 24.0 else if (eqt < -12.0) eqt += 24.0
        return decl to eqt
    }

    fun resolveLocation(state: DayflowState): CityLocation {
        if (state.useGpsLocation && state.gpsLat != null && state.gpsLng != null) {
            val label = state.gpsLabel.ifBlank { "موقعي الحالي" }
            return CityLocation(
                lat = state.gpsLat,
                lng = state.gpsLng,
                cityEn = state.gpsLabel.ifBlank { "My Location" },
                cityAr = label,
                zoneId = ZoneId.systemDefault().id
            )
        }
        return CITIES.getOrElse(state.cityIndex) { CITIES[1] }
    }

    /** Exact Great-Circle bearing from (lat,lng) to the Kaaba (21.422487° N, 39.826206° E). */
    fun qiblaAzimuth(lat: Double, lng: Double): Float {
        val kaabaLat = rad(21.422487)
        val kaabaLng = rad(39.826206)
        val phi = rad(lat)
        val dLambda = kaabaLng - rad(lng)
        val y = sin(dLambda)
        val x = cos(phi) * tan(kaabaLat) - sin(phi) * cos(dLambda)
        return fixAngle(deg(atan2(y, x))).toFloat()
    }

    fun compute(loc: CityLocation, instant: Instant = Instant.now()): PrayerSchedule {
        val zone = try { ZoneId.of(loc.zoneId) } catch (_: Exception) { ZoneId.of("Africa/Cairo") }
        val zdt: ZonedDateTime = instant.atZone(zone)
        val tzHours = zdt.offset.totalSeconds / 3600.0
        val jd = julianDay(zdt.year, zdt.monthValue, zdt.dayOfMonth) - loc.lng / (15.0 * 24.0)

        fun noonAt(portion: Double): Double {
            val (_, eqt) = sunPosition(jd + portion)
            return 12.0 + tzHours - loc.lng / 15.0 - eqt
        }

        fun angleTime(angle: Double, beforeNoon: Boolean, seedPortion: Double): Double? {
            var portion = seedPortion
            var res: Double? = null
            repeat(2) {
                val (decl, eqt) = sunPosition(jd + portion)
                val noon = 12.0 + tzHours - loc.lng / 15.0 - eqt
                val cosH = (-sin(rad(angle)) - sin(rad(loc.lat)) * sin(rad(decl))) /
                    (cos(rad(loc.lat)) * cos(rad(decl)))
                if (cosH < -1.0 || cosH > 1.0) return null
                val diff = deg(acos(cosH)) / 15.0
                res = if (beforeNoon) noon - diff else noon + diff
                portion = fixHour(res!!) / 24.0
            }
            return res
        }

        val dhuhrH = noonAt(0.5)
        val sunriseH = angleTime(0.8333, true, 6.0 / 24.0) ?: 6.0
        val maghribH = angleTime(0.8333, false, 18.0 / 24.0) ?: 18.0
        val nightLen = fixHour(sunriseH - maghribH)

        val fajrH = angleTime(loc.fajrAngle, true, 5.0 / 24.0)
            ?: (sunriseH - nightLen * (loc.fajrAngle / 60.0))
        val ishaH = angleTime(loc.ishaAngle, false, 19.5 / 24.0)
            ?: (maghribH + nightLen * (loc.ishaAngle / 60.0))

        // Asr (Shafi'i: shadow length = object length + noon shadow)
        var asrPortion = 15.5 / 24.0
        var asrH = 15.5
        repeat(2) {
            val (declAsr, eqtAsr) = sunPosition(jd + asrPortion)
            val noonAsr = 12.0 + tzHours - loc.lng / 15.0 - eqtAsr
            val asrAlt = -deg(atan(1.0 / (1.0 + tan(rad(abs(loc.lat - declAsr))))))
            val cosAsr = (-sin(rad(asrAlt)) - sin(rad(loc.lat)) * sin(rad(declAsr))) /
                (cos(rad(loc.lat)) * cos(rad(declAsr)))
            if (cosAsr in -1.0..1.0) {
                asrH = noonAsr + deg(acos(cosAsr)) / 15.0
                asrPortion = fixHour(asrH) / 24.0
            }
        }

        fun fmt24(h: Double): String {
            val totalMin = (fixHour(h) * 60.0).roundToInt()
            val hh = (totalMin / 60) % 24
            val mm = totalMin % 60
            return "%02d:%02d".format(hh, mm)
        }

        val fajr = fmt24(fajrH)
        val sunrise = fmt24(sunriseH)
        val dhuhr = fmt24(dhuhrH)
        val asr = fmt24(asrH)
        val maghrib = fmt24(maghribH)
        val isha = fmt24(ishaH)

        val nowMin = zdt.hour * 60 + zdt.minute
        val ordered = listOf(
            Triple("fajr", "Fajr" to "الفجر", fajr),
            Triple("sunrise", "Sunrise" to "الشروق", sunrise),
            Triple("dhuhr", "Dhuhr" to "الظهر", dhuhr),
            Triple("asr", "Asr" to "العصر", asr),
            Triple("maghrib", "Maghrib" to "المغرب", maghrib),
            Triple("isha", "Isha" to "العشاء", isha)
        )
        var nextInfo: NextPrayerInfo? = null
        for ((key, names, t24) in ordered) {
            val p = t24.split(":")
            val m = p[0].toInt() * 60 + p[1].toInt()
            val diff = m - nowMin
            if (diff > 0) {
                nextInfo = NextPrayerInfo(key, names.first, names.second, t24, diff)
                break
            }
        }
        if (nextInfo == null) {
            val p = fajr.split(":")
            val m = p[0].toInt() * 60 + p[1].toInt()
            nextInfo = NextPrayerInfo("fajr", "Fajr", "الفجر", fajr, 1440 - nowMin + m)
        }

        return PrayerSchedule(
            fajr = fajr,
            sunrise = sunrise,
            dhuhr = dhuhr,
            asr = asr,
            maghrib = maghrib,
            isha = isha,
            next = nextInfo,
            qiblaDeg = qiblaAzimuth(loc.lat, loc.lng),
            locationEn = loc.cityEn,
            locationAr = loc.cityAr
        )
    }

    fun periodAt(nowHour: Int, nowMin: Int, pr: PrayerSchedule): DayPeriod {
        fun mins(hhmm: String): Int {
            val s = hhmm.split(":")
            return (s.getOrNull(0)?.toIntOrNull() ?: 0) * 60 + (s.getOrNull(1)?.toIntOrNull() ?: 0)
        }
        val m = nowHour * 60 + nowMin
        val f = mins(pr.fajr)
        val sr = mins(pr.sunrise)
        val dh = mins(pr.dhuhr)
        val asr = mins(pr.asr)
        val mg = mins(pr.maghrib)
        val ish = mins(pr.isha)
        return when {
            m in f until (sr + 60) -> DayPeriod.FAJR
            m in (sr + 60) until (dh - 30) -> DayPeriod.MORNING
            m in (dh - 30) until asr -> DayPeriod.NOON
            m in asr until (mg - 20) -> DayPeriod.ASR
            m in (mg - 20) until (ish + 30) -> DayPeriod.MAGHRIB
            else -> DayPeriod.NIGHT
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun fetchDeviceLocation(context: Context): Triple<Double, Double, String>? = withContext(Dispatchers.IO) {
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            val loc = providers.mapNotNull { p ->
                runCatching { if (lm.isProviderEnabled(p)) lm.getLastKnownLocation(p) else null }.getOrNull()
            }.maxByOrNull { it.time } ?: return@withContext null

            val label = runCatching {
                @Suppress("DEPRECATION")
                val list = Geocoder(context, Locale("ar")).getFromLocation(loc.latitude, loc.longitude, 1)
                list?.firstOrNull()?.let { it.subAdminArea ?: it.locality ?: it.adminArea }
            }.getOrNull() ?: "موقعي الحالي (GPS)"

            Triple(loc.latitude, loc.longitude, label)
        } catch (_: Exception) {
            null
        }
    }

    /** Real-time device heading in degrees (0..360) from hardware rotation/magnetic sensors. */
    fun compassHeadingFlow(context: Context): Flow<Float?> = callbackFlow {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accel = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val mag = sm?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        if (sm == null || accel == null || mag == null) {
            trySend(null)
            awaitClose {}
            return@callbackFlow
        }
        val gravity = FloatArray(3)
        val geomagnetic = FloatArray(3)
        var hasG = false
        var hasM = false
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                    System.arraycopy(event.values, 0, gravity, 0, 3)
                    hasG = true
                } else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
                    System.arraycopy(event.values, 0, geomagnetic, 0, 3)
                    hasM = true
                }
                if (hasG && hasM) {
                    val r = FloatArray(9)
                    val i = FloatArray(9)
                    if (SensorManager.getRotationMatrix(r, i, gravity, geomagnetic)) {
                        val orient = FloatArray(3)
                        SensorManager.getOrientation(r, orient)
                        val degAzimuth = ((Math.toDegrees(orient[0].toDouble()) + 360.0) % 360.0).toFloat()
                        trySend(degAzimuth)
                    }
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_UI)
        sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_UI)
        awaitClose { sm.unregisterListener(listener) }
    }
}
