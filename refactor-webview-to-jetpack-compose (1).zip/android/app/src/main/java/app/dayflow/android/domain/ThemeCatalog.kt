package app.dayflow.android.domain

import app.dayflow.android.data.CustomThemeData
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

data class ThemePack(
    val id: String,
    val en: String,
    val ar: String,
    val cat: String,
    val mode: String, // light | dark
    val bg: String,
    val surface: String,
    val text: String,
    val accent: String,
    val accent2: String,
    val material: String,
    val shape: String,
    val font: String,
    val motion: String,
    val texture: String,
    val ornament: String,
    val custom: Boolean = false
)

data class ContrastEntry(val labelEn: String, val labelAr: String, val ratio: Double, val minRatio: Double)

object ThemeCatalog {
    val CATEGORIES = listOf(
        Triple("light", "Light editorial", "فاتح تحريري"),
        Triple("dark", "Dark", "داكن"),
        Triple("egypt", "Egyptian heritage", "تراث مصري"),
        Triple("islamic", "Islamic & geometric", "إسلامي وهندسي"),
        Triple("nature", "Nature", "طبيعة"),
        Triple("glass", "Glass & depth", "زجاج وعمق"),
        Triple("tech", "Tech", "تقني"),
        Triple("warm", "Warm", "دافئ"),
        Triple("playful", "Playful", "مرح"),
        Triple("custom", "My packs", "حزمي")
    )

    private fun slug(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')

    private fun row(
        en: String, ar: String, cat: String, m: String,
        bg: String, surf: String, txt: String, acc: String, acc2: String,
        mat: String, shp: String, fnt: String, mot: String, tex: String, orn: String
    ) = ThemePack(
        id = slug(en), en = en, ar = ar, cat = cat, mode = if (m == "l") "light" else "dark",
        bg = bg, surface = surf, text = txt, accent = acc, accent2 = acc2,
        material = mat, shape = shp, font = fnt, motion = mot, texture = tex, ornament = orn
    )

    val BUILTIN: List<ThemePack> = listOf(
        row("Paper White", "ورق أبيض", "light", "l", "#f7f5f0", "#ffffff", "#1d1c1a", "#2f6f5e", "#c9a24a", "paper", "round", "serif", "calm", "grain", "islamic"),
        row("Ivory Journal", "دفتر عاجي", "light", "l", "#f4eddc", "#fbf7ec", "#2b2418", "#8a5a2b", "#5c7a4d", "paper", "sharp", "serif", "calm", "lines", "coptic"),
        row("Linen", "كتان", "light", "l", "#efe9e1", "#f8f4ee", "#2d2a26", "#7b6a58", "#a0805d", "matte", "squircle", "sans", "calm", "grain", "spring"),
        row("Silver Mist", "ضباب فضي", "light", "l", "#e9edf1", "#f6f8fa", "#1c2530", "#4a6a8a", "#8aa0b6", "glass", "round", "sans", "calm", "mesh", "winter"),
        row("Arctic", "قطبي", "light", "l", "#eaf4f8", "#ffffff", "#0e2a36", "#1b8bb4", "#7cc6dd", "flat", "squircle", "rounded", "snappy", "none", "winter"),
        row("Porcelain", "بورسلين", "light", "l", "#f3f4f7", "#ffffff", "#20232b", "#3c5ccf", "#d64f7a", "glossy", "round", "sans", "springy", "none", "spring"),
        row("Newsprint", "ورق الصحف", "light", "l", "#ecebe6", "#f6f5f1", "#111111", "#111111", "#b3261e", "outlined", "sharp", "serif", "none", "lines", "islamic"),
        row("Library", "مكتبة", "light", "l", "#e8e1d3", "#f4efe4", "#2a2016", "#6b2d2d", "#2f5a45", "paper", "chamfer", "serif", "calm", "grain", "coptic"),
        row("Midnight", "منتصف الليل", "dark", "d", "#0d1220", "#161d30", "#e6e9f2", "#7aa2ff", "#c9a24a", "matte", "round", "sans", "calm", "dots", "islamic"),
        row("Graphite", "جرافيت", "dark", "d", "#1a1b1e", "#24262a", "#ececec", "#9fb4c7", "#d1a35c", "matte", "squircle", "sans", "snappy", "none", "winter"),
        row("AMOLED Black", "أسود أموليد", "dark", "d", "#000000", "#0b0b0b", "#f2f2f2", "#4fd1c5", "#f6ad55", "flat", "round", "sans", "snappy", "none", "friday"),
        row("Obsidian", "سبج", "dark", "d", "#0f0e12", "#1b1920", "#ece8f4", "#b392f0", "#5ad1a8", "glossy", "chamfer", "sans", "springy", "none", "islamic"),
        row("Slate", "أردواز", "dark", "d", "#1c232b", "#26303a", "#e3e9ef", "#5fb3b3", "#e0b45c", "matte", "squircle", "condensed", "calm", "lines", "nile"),
        row("Deep Ink", "حبر عميق", "dark", "d", "#0b1530", "#13204a", "#e5ebff", "#f0c24b", "#76a6ff", "paper", "round", "serif", "calm", "grain", "ramadan"),
        row("Carbon", "كربون", "dark", "d", "#121314", "#1d1f21", "#e8e8e8", "#ff6b4a", "#9aa5b1", "outlined", "sharp", "mono", "snappy", "grid", "national"),
        row("Nile Blue", "أزرق النيل", "egypt", "l", "#e7f0f8", "#f7fbff", "#0f2742", "#1f5fa8", "#2fa37e", "glass", "round", "sans", "calm", "pattern", "nile"),
        row("Desert Gold", "ذهب الصحراء", "egypt", "l", "#f3e7cf", "#fbf4e4", "#3a2a12", "#b07d1e", "#7a4a1d", "paper", "chamfer", "serif", "calm", "grain", "coptic"),
        row("Pharaonic Teal & Gold", "فيروزي وذهبي فرعوني", "egypt", "d", "#0c2b2e", "#123a3e", "#f3e9cc", "#d4a83a", "#3fb3a4", "glossy", "chamfer", "serif", "calm", "pattern", "nile"),
        row("Cairo Night", "ليل القاهرة", "egypt", "d", "#120f1c", "#1d1830", "#f1e8d6", "#e7b04a", "#8f7bd8", "glass", "squircle", "sans", "springy", "pattern", "islamic"),
        row("Khan El-Khalili", "خان الخليلي", "egypt", "d", "#2a160c", "#3a2014", "#f6e6cc", "#e39b2b", "#2c8c7a", "clay", "chamfer", "serif", "calm", "pattern", "ramadan"),
        row("Luxor Dawn", "فجر الأقصر", "egypt", "l", "#fbe9da", "#fff6ee", "#3b2318", "#d2693c", "#c9a24a", "glass", "round", "serif", "calm", "mesh", "nile"),
        row("Aswan Sunset", "غروب أسوان", "egypt", "d", "#2b1420", "#3b1c2c", "#fbe6dc", "#ff8a5b", "#ffc46b", "glossy", "round", "sans", "springy", "mesh", "nile"),
        row("Siwa Oasis", "واحة سيوة", "egypt", "l", "#efe6d2", "#faf5ea", "#2f2a1b", "#5b8a3c", "#c48a3a", "clay", "squircle", "rounded", "calm", "grain", "spring"),
        row("Alexandria Corniche", "كورنيش الإسكندرية", "egypt", "l", "#e3f1f6", "#f7fcfe", "#0b2c3a", "#167ea3", "#e3a64a", "flat", "round", "sans", "springy", "lines", "summer"),
        row("Sinai Granite", "جرانيت سيناء", "egypt", "d", "#231d1d", "#302828", "#eee3df", "#d07a5a", "#9db0a6", "matte", "chamfer", "condensed", "calm", "grain", "national"),
        row("Red Sea Reef", "شعاب البحر الأحمر", "egypt", "d", "#04263a", "#06344f", "#e2f6fb", "#ff7f6b", "#3fd3c3", "glass", "round", "rounded", "springy", "mesh", "summer"),
        row("Papyrus", "بردي", "egypt", "l", "#ece0bf", "#f6eed6", "#33291a", "#6f6230", "#a1442a", "paper", "sharp", "serif", "none", "lines", "nile"),
        row("Delta Green", "أخضر الدلتا", "egypt", "l", "#e5efe0", "#f5faf2", "#1c2d18", "#3f7f33", "#b8932f", "matte", "round", "sans", "calm", "grain", "spring"),
        row("Ramadan Lantern", "فانوس رمضان", "islamic", "d", "#0f1f2b", "#172d3d", "#f6ecd2", "#e1a93b", "#4fb39a", "glass", "squircle", "serif", "calm", "pattern", "ramadan"),
        row("Mamluk Geometry", "هندسة مملوكية", "islamic", "l", "#efe5d3", "#faf3e6", "#2a1d10", "#9b3b1f", "#1d5a6e", "paper", "chamfer", "serif", "calm", "pattern", "islamic"),
        row("Andalusian Tile", "زليج أندلسي", "islamic", "l", "#e8f0f3", "#ffffff", "#132a33", "#1b6f8a", "#c78a2b", "glossy", "chamfer", "serif", "springy", "pattern", "islamic"),
        row("Mihrab", "محراب", "islamic", "d", "#1a1410", "#2a2018", "#f3e7d0", "#c99a45", "#6fa38a", "clay", "round", "serif", "calm", "pattern", "islamic"),
        row("Arabesque Emerald", "أرابيسك زمردي", "islamic", "d", "#06221b", "#0c3128", "#e5f4ec", "#d7b65a", "#3cc18f", "glossy", "squircle", "serif", "calm", "pattern", "islamic"),
        row("Zellige", "زليج", "islamic", "l", "#e5f2ee", "#fbfffd", "#0f2a24", "#167a63", "#2d5fa8", "outlined", "chamfer", "sans", "snappy", "pattern", "friday"),
        row("Muqarnas Night", "مقرنصات الليل", "islamic", "d", "#101326", "#191d38", "#ece9fb", "#d9b25f", "#7f8cff", "glass", "chamfer", "serif", "calm", "pattern", "ramadan"),
        row("Sage", "مريمية", "nature", "l", "#e9eee6", "#f6f9f4", "#1f2a1e", "#5d7f5a", "#b49a6a", "matte", "squircle", "rounded", "calm", "grain", "spring"),
        row("Forest", "غابة", "nature", "d", "#0f1d16", "#173026", "#e2efe5", "#6fc28b", "#d9b46a", "matte", "round", "sans", "calm", "grain", "autumn"),
        row("Mint Fresh", "نعناع منعش", "nature", "l", "#e6f7f1", "#ffffff", "#103028", "#14a37f", "#ff8c6b", "flat", "round", "rounded", "springy", "dots", "spring"),
        row("Rain", "مطر", "nature", "d", "#141c24", "#1d2833", "#dfe8f0", "#6fa8dc", "#9fc5e8", "glass", "round", "sans", "calm", "lines", "winter"),
        row("Dune", "كثيب", "nature", "l", "#f1e3cc", "#fbf2e2", "#3b2c18", "#c27c3e", "#6a7f5a", "clay", "round", "sans", "calm", "grain", "summer"),
        row("Aurora", "شفق قطبي", "nature", "d", "#071422", "#0e2033", "#e3f3ff", "#58e0b0", "#b07bff", "glass", "round", "sans", "springy", "mesh", "winter"),
        row("Ocean Deep", "أعماق المحيط", "nature", "d", "#031a2b", "#08283f", "#dff1ff", "#2bb3e3", "#7ce0d2", "glossy", "round", "sans", "calm", "mesh", "summer"),
        row("Coral", "مرجان", "nature", "l", "#fdeee8", "#fff8f5", "#3a1d16", "#e2583e", "#2a9d8f", "flat", "squircle", "rounded", "springy", "none", "summer"),
        row("Meadow", "مرج", "nature", "l", "#eef5e2", "#fbfdf6", "#22301a", "#6a9a2e", "#e0a33a", "paper", "round", "rounded", "springy", "dots", "spring"),
        row("Snowfield", "حقل الثلج", "nature", "l", "#f2f6fa", "#ffffff", "#1b2733", "#5a7fa8", "#b0c4d8", "glass", "round", "sans", "calm", "pattern", "winter"),
        row("Soft Glass", "زجاج ناعم", "glass", "l", "#dfe7f3", "#ffffff", "#17202c", "#4f7cff", "#ff7aa8", "glass", "round", "sans", "springy", "mesh", "spring"),
        row("Frosted Premium", "زجاج مصنفر فاخر", "glass", "d", "#101418", "#1a2028", "#eef2f6", "#c8b48a", "#8fb3d9", "glass", "squircle", "sans", "calm", "mesh", "winter"),
        row("One UI Glass", "زجاج بأسلوب One UI", "glass", "l", "#e4ebf5", "#ffffff", "#141a22", "#3e7bfa", "#5ac8a8", "glass", "squircle", "rounded", "springy", "mesh", "friday"),
        row("Classic iOS-inspired", "كلاسيكي مستوحى من iOS", "glass", "l", "#f2f2f7", "#ffffff", "#000000", "#007aff", "#34c759", "glass", "squircle", "sans", "springy", "none", "spring"),
        row("Fluid Glass", "زجاج سائل", "glass", "d", "#0d1022", "#171b36", "#eef0ff", "#8ea2ff", "#ff9ad5", "glass", "round", "rounded", "springy", "mesh", "eid"),
        row("Soft Clay", "صلصال ناعم", "glass", "l", "#e8e3dc", "#efeae3", "#2d2924", "#c06c4a", "#6b8f7a", "clay", "round", "rounded", "springy", "none", "autumn"),
        row("Layered Depth", "عمق متعدد الطبقات", "glass", "d", "#15171c", "#20232a", "#eceef2", "#6ad1ff", "#ffcf6a", "glossy", "squircle", "sans", "springy", "dots", "newyear"),
        row("Neon Grid", "شبكة نيون", "tech", "d", "#0a0716", "#120d26", "#f0e9ff", "#ff3fd8", "#3ff0ff", "neon", "sharp", "mono", "snappy", "grid", "newyear"),
        row("Terminal", "طرفية", "tech", "d", "#050a05", "#0b140b", "#b6f5b6", "#39ff7a", "#ffd23f", "outlined", "sharp", "mono", "none", "lines", "study"),
        row("Synthwave Dusk", "غسق سينث", "tech", "d", "#1a0b2e", "#2a1145", "#ffe9f7", "#ff6ac1", "#ffb86b", "neon", "round", "condensed", "springy", "grid", "summer"),
        row("Blueprint", "مخطط أزرق", "tech", "d", "#0d3466", "#0f3c75", "#e6f0ff", "#ffffff", "#9fd0ff", "blueprint", "sharp", "mono", "snappy", "grid", "study"),
        row("Cyber Slate", "سليت رقمي", "tech", "d", "#0e141b", "#151e28", "#dce7f2", "#38bdf8", "#a78bfa", "matte", "chamfer", "mono", "snappy", "dots", "study"),
        row("Quantum Violet", "بنفسج كمي", "tech", "d", "#110d24", "#1b1538", "#ebe6ff", "#a78bfa", "#34d399", "glass", "squircle", "sans", "springy", "mesh", "newyear"),
        row("Terracotta", "تيراكوتا", "warm", "l", "#f5e6dc", "#fff7f2", "#382015", "#b85032", "#c8963e", "clay", "round", "serif", "calm", "grain", "autumn"),
        row("Espresso", "إسبريسو", "warm", "d", "#1c130e", "#2a1d16", "#f2e5dc", "#d99b66", "#8ab089", "matte", "round", "serif", "calm", "grain", "autumn"),
        row("Amber Hearth", "موقد كهرماني", "warm", "d", "#22140b", "#331e11", "#fae9d7", "#f59e0b", "#ef4444", "glossy", "squircle", "serif", "calm", "mesh", "autumn"),
        row("Saffron & Cardamom", "زعفران وهيل", "warm", "l", "#f8eed9", "#fffaf0", "#33240d", "#c77700", "#3d7a5a", "paper", "round", "serif", "calm", "grain", "eid"),
        row("Pomegranate", "رمان", "warm", "l", "#fae8eb", "#fff7f8", "#36141b", "#b02342", "#c99738", "glossy", "round", "serif", "springy", "none", "love"),
        row("Cinnamon", "قرفة", "warm", "l", "#f2e4d8", "#fcf6f0", "#331f14", "#9c4a24", "#5c7a58", "paper", "squircle", "rounded", "calm", "lines", "autumn"),
        row("Apricot Sun", "شمس المشمش", "warm", "l", "#fff0e0", "#ffffff", "#362210", "#d96326", "#2b8a78", "flat", "round", "rounded", "springy", "mesh", "summer"),
        row("Candy", "حلوى", "playful", "l", "#fff0f6", "#ffffff", "#3a1030", "#ff4fa3", "#7a5cff", "glossy", "round", "rounded", "springy", "dots", "birthday"),
        row("Pastel Cloud", "سحابة باستيل", "playful", "l", "#eef0ff", "#ffffff", "#232552", "#8a7bff", "#5fd3c0", "clay", "round", "rounded", "springy", "none", "spring"),
        row("Sticker Pop", "ملصقات", "playful", "l", "#fff7d6", "#ffffff", "#141414", "#ff5a36", "#2f7bff", "outlined", "round", "rounded", "springy", "dots", "birthday"),
        row("Arcade", "أركيد", "playful", "d", "#14092b", "#1f1040", "#fff4d6", "#ffd23f", "#3fd0ff", "neon", "sharp", "mono", "snappy", "grid", "newyear")
    )

    fun allThemes(custom: List<CustomThemeData>): List<ThemePack> =
        BUILTIN + custom.map {
            ThemePack(
                id = it.id, en = it.en, ar = it.ar, cat = "custom", mode = it.mode,
                bg = it.bg, surface = it.surface, text = it.text, accent = it.accent, accent2 = it.accent2,
                material = it.material, shape = it.shape, font = it.font, motion = it.motion,
                texture = it.texture, ornament = it.ornament, custom = true
            )
        }

    fun parseHexColor(hex: String): Long {
        val clean = hex.trim().removePrefix("#")
        val full = if (clean.length == 3) clean.map { "$it$it" }.joinToString("") else clean.padEnd(6, '0').take(6)
        return (0xFF000000L or (full.toLongOrNull(16) ?: 0xFFFFFFL))
    }

    private fun luminance(hex: String): Double {
        val argb = parseHexColor(hex)
        val r = ((argb shr 16) and 0xFF) / 255.0
        val g = ((argb shr 8) and 0xFF) / 255.0
        val b = (argb and 0xFF) / 255.0
        fun ch(c: Double) = if (c <= 0.03928) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
        return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)
    }

    fun contrast(a: String, b: String): Double {
        val l1 = luminance(a)
        val l2 = luminance(b)
        return (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)
    }

    fun inkOn(bg: String): String =
        if (contrast(bg, "#ffffff") >= contrast(bg, "#111111")) "#ffffff" else "#111111"

    fun contrastReport(t: ThemePack): List<ContrastEntry> = listOf(
        ContrastEntry("Text / background", "النص / الخلفية", contrast(t.text, t.bg), 4.5),
        ContrastEntry("Text / surface", "النص / السطح", contrast(t.text, t.surface), 4.5),
        ContrastEntry("Accent / surface (UI)", "اللون المميز / السطح", contrast(t.accent, t.surface), 3.0),
        ContrastEntry("Accent label ink", "حبر زر اللون المميز", contrast(inkOn(t.accent), t.accent), 4.5)
    )
}
