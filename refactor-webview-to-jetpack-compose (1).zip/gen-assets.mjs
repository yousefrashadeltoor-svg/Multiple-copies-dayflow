import sharp from "sharp";
import fs from "fs";

const S = 256;
const wrap = (inner) => `<svg xmlns="http://www.w3.org/2000/svg" width="${S}" height="${S}" viewBox="0 0 256 256">${inner}</svg>`;

const SPRITES = {
  // 1. Realistic Crimson Sugar Maple Leaf with veins & serrated lobes
  maple: wrap(`
    <defs>
      <linearGradient id="mg" x1="20%" y1="10%" x2="85%" y2="90%">
        <stop offset="0%" stop-color="#ff6b3d"/>
        <stop offset="45%" stop-color="#c92a1d"/>
        <stop offset="85%" stop-color="#7d1416"/>
        <stop offset="100%" stop-color="#4e0b0e"/>
      </linearGradient>
      <radialGradient id="mh" cx="38%" cy="32%" r="55%">
        <stop offset="0%" stop-color="#ffb36b" stop-opacity="0.55"/>
        <stop offset="100%" stop-color="#ffb36b" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <path d="M128 242 C126 214 127 192 128 176" stroke="#5a2614" stroke-width="5.5" stroke-linecap="round" fill="none"/>
    <path d="M128 18 L142 56 L160 46 L156 80 L198 62 L186 92 L226 90 L198 118 L218 134 L176 146 L190 168 L150 166 L156 184 L128 172 L100 184 L106 166 L66 168 L80 146 L38 134 L58 118 L30 90 L70 92 L58 62 L100 80 L96 46 L114 56 Z"
      fill="url(#mg)" stroke="#5c0f11" stroke-width="2" stroke-linejoin="round"/>
    <path d="M128 18 L142 56 L160 46 L156 80 L198 62 L186 92 L226 90 L198 118 L218 134 L176 146 L190 168 L150 166 L156 184 L128 172 L100 184 L106 166 L66 168 L80 146 L38 134 L58 118 L30 90 L70 92 L58 62 L100 80 L96 46 L114 56 Z"
      fill="url(#mh)"/>
    <g stroke="#f7b277" stroke-opacity="0.62" stroke-linecap="round" fill="none">
      <path d="M128 172 L128 28" stroke-width="3"/>
      <path d="M128 146 L196 86" stroke-width="2.4"/>
      <path d="M128 146 L60 86" stroke-width="2.4"/>
      <path d="M128 160 L182 158" stroke-width="2"/>
      <path d="M128 160 L74 158" stroke-width="2"/>
      <path d="M128 96 L154 54" stroke-width="1.6"/>
      <path d="M128 96 L102 54" stroke-width="1.6"/>
      <path d="M162 116 L206 124" stroke-width="1.4"/>
      <path d="M94 116 L50 124" stroke-width="1.4"/>
    </g>
  `),

  // 2. Realistic Golden-Amber Curled Oak/Beech Autumn Leaf
  fallen: wrap(`
    <defs>
      <linearGradient id="fg" x1="15%" y1="10%" x2="85%" y2="92%">
        <stop offset="0%" stop-color="#f7c948"/>
        <stop offset="48%" stop-color="#d97917"/>
        <stop offset="85%" stop-color="#8f3d12"/>
        <stop offset="100%" stop-color="#56220a"/>
      </linearGradient>
    </defs>
    <path d="M62 224 Q88 196 102 178" stroke="#5c2c10" stroke-width="5" stroke-linecap="round" fill="none"/>
    <path d="M196 28 C164 32 142 54 132 68 C114 60 94 74 96 96 C74 92 58 112 68 134 C50 140 48 164 72 174 C86 188 106 188 124 180 C142 192 168 184 172 162 C194 160 206 138 190 120 C210 108 212 82 192 72 C206 54 206 36 196 28 Z"
      fill="url(#fg)" stroke="#63290b" stroke-width="2.2"/>
    <g stroke="#ffe799" stroke-opacity="0.6" stroke-linecap="round" fill="none">
      <path d="M100 180 Q148 116 192 34" stroke-width="3"/>
      <path d="M124 148 L168 144" stroke-width="1.8"/>
      <path d="M118 152 L76 124" stroke-width="1.8"/>
      <path d="M144 116 L186 106" stroke-width="1.8"/>
      <path d="M140 118 L104 86" stroke-width="1.8"/>
      <path d="M164 82 L192 66" stroke-width="1.5"/>
    </g>
  `),

  // 3. Woodland Acorn
  acorn: wrap(`
    <defs>
      <radialGradient id="anut" cx="38%" cy="35%" r="65%">
        <stop offset="0%" stop-color="#d8914c"/>
        <stop offset="55%" stop-color="#8f4a1c"/>
        <stop offset="100%" stop-color="#4a2109"/>
      </radialGradient>
      <linearGradient id="acap" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#7c5333"/>
        <stop offset="100%" stop-color="#3f2614"/>
      </linearGradient>
    </defs>
    <path d="M128 32 Q134 16 146 18" stroke="#4a2b13" stroke-width="7" stroke-linecap="round" fill="none"/>
    <path d="M68 106 C64 168 94 214 128 232 C162 214 192 168 188 106 Z" fill="url(#anut)" stroke="#3e1b07" stroke-width="2.5"/>
    <ellipse cx="106" cy="148" rx="14" ry="34" transform="rotate(-12 106 148)" fill="#fff" opacity="0.22"/>
    <path d="M54 108 C54 62 88 42 128 42 C168 42 202 62 202 108 C178 122 78 122 54 108 Z" fill="url(#acap)" stroke="#2d1a0d" stroke-width="2.5"/>
    <g stroke="#a97c56" stroke-opacity="0.45" stroke-width="2">
      <path d="M72 68 L106 112 M96 52 L134 114 M126 46 L162 112 M156 54 L188 106"/>
      <path d="M184 68 L150 112 M160 52 L122 114 M130 46 L94 112 M100 54 L68 106"/>
    </g>
  `),

  // 4. Gossamer Wind Swirl with Leaf Specks
  wind: wrap(`
    <defs>
      <linearGradient id="wg" x1="0%" y1="50%" x2="100%" y2="50%">
        <stop offset="0%" stop-color="#dbeafe" stop-opacity="0.1"/>
        <stop offset="50%" stop-color="#93c5fd" stop-opacity="0.85"/>
        <stop offset="100%" stop-color="#e0f2fe" stop-opacity="0.2"/>
      </linearGradient>
    </defs>
    <path d="M22 138 C76 98 148 164 206 112 C226 94 214 62 186 72 C164 80 172 108 194 102" fill="none" stroke="url(#wg)" stroke-width="8" stroke-linecap="round"/>
    <path d="M38 174 C96 144 154 196 226 150" fill="none" stroke="url(#wg)" stroke-width="5" stroke-linecap="round"/>
    <ellipse cx="92" cy="112" rx="10" ry="5" transform="rotate(-28 92 112)" fill="#d97706" opacity="0.85"/>
    <ellipse cx="168" cy="158" rx="8" ry="4" transform="rotate(22 168 158)" fill="#dc2626" opacity="0.8"/>
  `),

  // 5. Macro Stellar Dendrite Ice Crystal Snowflake
  snow: wrap(`
    <defs>
      <radialGradient id="sg" cx="50%" cy="50%" r="52%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="65%" stop-color="#e0f4ff"/>
        <stop offset="100%" stop-color="#9bd4f5"/>
      </radialGradient>
    </defs>
    <g stroke="url(#sg)" stroke-linecap="round" stroke-linejoin="round" fill="none">
      ${[0, 60, 120, 180, 240, 300].map((ang) => `
        <g transform="rotate(${ang} 128 128)">
          <line x1="128" y1="128" x2="128" y2="20" stroke-width="5.5"/>
          <path d="M128 44 L106 28 M128 44 L150 28" stroke-width="3.8"/>
          <path d="M128 72 L96 50 M128 72 L160 50" stroke-width="4.2"/>
          <path d="M128 98 L104 80 M128 98 L152 80" stroke-width="3.5"/>
          <polygon points="128,104 136,116 128,128 120,116" fill="#ffffff" fill-opacity="0.55" stroke-width="2"/>
        </g>
      `).join("")}
      <circle cx="128" cy="128" r="14" fill="#ffffff" fill-opacity="0.8" stroke="#bae6fd" stroke-width="3"/>
    </g>
  `),

  // 6. Snow-dusted Pine Bough & Winter Holly Berries
  pine: wrap(`
    <g stroke="#1e4d3b" stroke-width="4" stroke-linecap="round">
      <path d="M36 196 Q124 128 216 64" stroke="#4a3520" stroke-width="6" fill="none"/>
      ${Array.from({ length: 14 }, (_, i) => {
        const t = i / 13;
        const x = 48 + t * 156, y = 186 - t * 114;
        return `<line x1="${x}" y1="${y}" x2="${x - 22}" y2="${y - 28}" stroke="#1f6347"/><line x1="${x}" y1="${y}" x2="${x + 28}" y2="${y + 16}" stroke="#164a34"/><line x1="${x}" y1="${y}" x2="${x - 10}" y2="${y - 34}" stroke="#348462"/>`;
      }).join("")}
    </g>
    <path d="M62 152 Q98 122 142 104" stroke="#ffffff" stroke-width="9" stroke-linecap="round" opacity="0.82" fill="none"/>
    <circle cx="118" cy="136" r="11" fill="#dc2626"/><circle cx="136" cy="144" r="10" fill="#b91c1c"/><circle cx="126" cy="122" r="9.5" fill="#ef4444"/>
    <circle cx="115" cy="133" r="3" fill="#fff" opacity="0.65"/>
  `),

  // 7. Crafted Frosted Snowman with Knitted Scarf
  snowman: wrap(`
    <defs>
      <radialGradient id="snb" cx="36%" cy="30%" r="68%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="70%" stop-color="#e2eff8"/>
        <stop offset="100%" stop-color="#b4cde0"/>
      </radialGradient>
    </defs>
    <circle cx="128" cy="176" r="56" fill="url(#snb)" stroke="#9ab8d1" stroke-width="2"/>
    <circle cx="128" cy="96" r="40" fill="url(#snb)" stroke="#9ab8d1" stroke-width="2"/>
    <path d="M90 120 Q128 136 166 120 L162 138 Q128 152 94 138 Z" fill="#c8332b"/>
    <path d="M144 128 L160 182 L140 184 L132 134 Z" fill="#b0251e"/>
    <circle cx="114" cy="86" r="4.5" fill="#1e293b"/><circle cx="142" cy="86" r="4.5" fill="#1e293b"/>
    <polygon points="128,92 162,99 128,103" fill="#ea580c"/>
    <circle cx="128" cy="158" r="4.5" fill="#334155"/><circle cx="128" cy="180" r="4.5" fill="#334155"/><circle cx="128" cy="202" r="4.5" fill="#334155"/>
    <rect x="96" y="48" width="64" height="10" rx="5" fill="#1e293b"/>
    <rect x="106" y="20" width="44" height="32" rx="6" fill="#1e293b"/>
    <rect x="106" y="42" width="44" height="6" fill="#c8332b"/>
  `),

  // 8. Realistic 5-Petal Sakura Cherry Blossom
  blossom: wrap(`
    <defs>
      <radialGradient id="bg" cx="50%" cy="50%" r="55%">
        <stop offset="0%" stop-color="#e11d74"/>
        <stop offset="28%" stop-color="#fbcfe8"/>
        <stop offset="78%" stop-color="#f9a8d4"/>
        <stop offset="100%" stop-color="#f472b6"/>
      </radialGradient>
    </defs>
    ${[0, 72, 144, 216, 288].map((a) => `
      <g transform="rotate(${a} 128 128)">
        <path d="M128 126 C98 98 88 52 114 28 C122 22 126 34 128 38 C130 34 134 22 142 28 C168 52 158 98 128 126 Z"
          fill="url(#bg)" stroke="#ec4899" stroke-opacity="0.45" stroke-width="1.8"/>
        <line x1="128" y1="120" x2="128" y2="68" stroke="#be185d" stroke-opacity="0.35" stroke-width="1.5"/>
      </g>
    `).join("")}
    <circle cx="128" cy="128" r="11" fill="#be185d"/>
    ${Array.from({ length: 10 }, (_, i) => {
      const r = (i * 36 * Math.PI) / 180;
      const x = 128 + Math.cos(r) * 26, y = 128 + Math.sin(r) * 26;
      return `<line x1="128" y1="128" x2="${x}" y2="${y}" stroke="#f43f5e" stroke-width="1.8"/><circle cx="${x}" cy="${y}" r="3.5" fill="#fde047"/>`;
    }).join("")}
  `),

  // 9. Botanical Cupped Tulip with Stem & Leaf
  tulip: wrap(`
    <defs>
      <linearGradient id="tg" x1="20%" y1="0%" x2="80%" y2="100%">
        <stop offset="0%" stop-color="#fb7185"/>
        <stop offset="55%" stop-color="#e11d48"/>
        <stop offset="100%" stop-color="#881337"/>
      </linearGradient>
    </defs>
    <path d="M128 142 Q126 192 122 238" stroke="#2f7a3e" stroke-width="8" stroke-linecap="round" fill="none"/>
    <path d="M124 224 C156 206 188 168 184 124 C160 148 138 182 124 214 Z" fill="#3b944b" stroke="#245c30" stroke-width="1.8"/>
    <path d="M128 32 C106 54 102 104 128 144 C154 104 150 54 128 32 Z" fill="#be123c"/>
    <path d="M84 46 C68 88 82 138 128 146 C126 102 110 66 84 46 Z" fill="url(#tg)" stroke="#9f1239" stroke-width="1.5"/>
    <path d="M172 46 C188 88 174 138 128 146 C130 102 146 66 172 46 Z" fill="url(#tg)" stroke="#9f1239" stroke-width="1.5"/>
    <ellipse cx="102" cy="88" rx="6" ry="18" transform="rotate(-14 102 88)" fill="#fff" opacity="0.28"/>
  `),

  // 10. Olive & Jasmine Botanical Sprig
  herb: wrap(`
    <path d="M44 214 Q118 134 208 46" stroke="#3f6212" stroke-width="5.5" stroke-linecap="round" fill="none"/>
    ${[
      [78, 178, -55], [108, 148, 35], [132, 120, -50], [160, 96, 38], [186, 68, -45], [92, 166, 40], [148, 108, -48],
    ].map(([x, y, rot]) => `
      <g transform="translate(${x} ${y}) rotate(${rot})">
        <path d="M0 0 C-14 -18 -14 -44 0 -62 C14 -44 14 -18 0 0 Z" fill="#4d8b31" stroke="#2d571b" stroke-width="1.6"/>
        <line x1="0" y1="-4" x2="0" y2="-56" stroke="#bef264" stroke-opacity="0.55" stroke-width="1.4"/>
      </g>
    `).join("")}
    <circle cx="146" cy="116" r="7" fill="#fefce8" stroke="#eab308" stroke-width="1.5"/>
    <circle cx="104" cy="154" r="6" fill="#fefce8" stroke="#eab308" stroke-width="1.5"/>
  `),

  // 11. Egyptian Blue & Gold Nile Lotus Blossom
  lotus: wrap(`
    <defs>
      <linearGradient id="lpad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#2dd4bf"/><stop offset="100%" stop-color="#115e59"/>
      </linearGradient>
      <linearGradient id="lpet" x1="50%" y1="0%" x2="50%" y2="100%">
        <stop offset="0%" stop-color="#93c5fd"/><stop offset="50%" stop-color="#3b82f6"/><stop offset="100%" stop-color="#1e3a8a"/>
      </linearGradient>
      <linearGradient id="lin" x1="50%" y1="0%" x2="50%" y2="100%">
        <stop offset="0%" stop-color="#fdf4ff"/><stop offset="65%" stop-color="#c084fc"/><stop offset="100%" stop-color="#581c87"/>
      </linearGradient>
    </defs>
    <ellipse cx="128" cy="192" rx="92" ry="24" fill="url(#lpad)" opacity="0.88"/>
    ${[-64, -38, -16, 16, 38, 64].map((a) => `
      <g transform="rotate(${a} 128 184)">
        <path d="M128 184 C106 142 108 78 128 42 C148 78 150 142 128 184 Z" fill="url(#lpet)" stroke="#dbeafe" stroke-opacity="0.45" stroke-width="1.5"/>
      </g>
    `).join("")}
    ${[-26, 0, 26].map((a) => `
      <g transform="rotate(${a} 128 184)">
        <path d="M128 184 C112 146 114 92 128 56 C142 92 144 146 128 184 Z" fill="url(#lin)" stroke="#fff" stroke-opacity="0.5" stroke-width="1.4"/>
      </g>
    `).join("")}
    <ellipse cx="128" cy="166" rx="22" ry="11" fill="#fbbf24"/>
    <circle cx="118" cy="160" r="3" fill="#fef08a"/><circle cx="128" cy="158" r="3.5" fill="#fef08a"/><circle cx="138" cy="160" r="3" fill="#fef08a"/>
  `),

  // 12. Mediterranean & Nile Cresting Turquoise Wave
  wave: wrap(`
    <defs>
      <linearGradient id="wv" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#67e8f9"/>
        <stop offset="55%" stop-color="#0284c7"/>
        <stop offset="100%" stop-color="#0c4a6e"/>
      </linearGradient>
    </defs>
    <path d="M18 176 C56 172 78 104 134 94 C176 86 198 114 176 132 C156 148 134 128 148 114 C122 114 102 152 144 166 C182 178 216 158 238 146 L238 206 L18 206 Z"
      fill="url(#wv)"/>
    <path d="M126 94 C162 82 198 102 184 128 C196 106 168 92 138 98 Z" fill="#ffffff" opacity="0.92"/>
    <circle cx="196" cy="92" r="6" fill="#ffffff" opacity="0.9"/>
    <circle cx="212" cy="108" r="4" fill="#e0f2fe" opacity="0.85"/>
    <circle cx="174" cy="78" r="4.5" fill="#ffffff" opacity="0.85"/>
  `),

  // 13. Ornate Egyptian Brass & Stained-Glass Ramadan Fanous Lantern
  fanous: wrap(`
    <defs>
      <linearGradient id="brass" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#fde68a"/><stop offset="45%" stop-color="#d97706"/><stop offset="100%" stop-color="#78350f"/>
      </linearGradient>
      <radialGradient id="glow" cx="50%" cy="52%" r="48%">
        <stop offset="0%" stop-color="#fffbeb"/><stop offset="40%" stop-color="#fbbf24"/><stop offset="85%" stop-color="#dc2626" stop-opacity="0.85"/><stop offset="100%" stop-color="#1e1b4b" stop-opacity="0.9"/>
      </radialGradient>
    </defs>
    <circle cx="128" cy="24" r="11" fill="none" stroke="url(#brass)" stroke-width="5"/>
    <path d="M104 58 C108 38 148 38 152 58 Z" fill="url(#brass)"/>
    <polygon points="82,66 174,66 184,80 72,80" fill="url(#brass)"/>
    <polygon points="78,80 178,80 192,142 166,198 90,198 64,142" fill="url(#glow)" stroke="url(#brass)" stroke-width="5" stroke-linejoin="round"/>
    <line x1="110" y1="80" x2="104" y2="198" stroke="url(#brass)" stroke-width="4"/>
    <line x1="146" y1="80" x2="152" y2="198" stroke="url(#brass)" stroke-width="4"/>
    <path d="M128 118 C136 132 138 148 128 158 C118 148 120 132 128 118 Z" fill="#ffffff"/>
    <polygon points="84,198 172,198 184,218 72,218" fill="url(#brass)"/>
    <polygon points="104,218 152,218 128,238" fill="url(#brass)"/>
  `),

  // 14. Burnished 3D Gold Crescent Moon & Star
  crescent: wrap(`
    <defs>
      <linearGradient id="cg" x1="15%" y1="10%" x2="85%" y2="90%">
        <stop offset="0%" stop-color="#fef9c3"/>
        <stop offset="45%" stop-color="#f59e0b"/>
        <stop offset="100%" stop-color="#92400e"/>
      </linearGradient>
    </defs>
    <path d="M154 34 A94 94 0 1 0 218 174 A76 76 0 1 1 154 34 Z" fill="url(#cg)" stroke="#fde68a" stroke-width="2"/>
    <polygon points="178,76 185,94 205,96 190,109 194,128 178,118 162,128 166,109 151,96 171,94" fill="url(#cg)" stroke="#fef3c7" stroke-width="1.5"/>
  `),

  // 15. Mamluk 8-Pointed Gold & Turquoise Star Medallion
  star: wrap(`
    <defs>
      <radialGradient id="stg" cx="40%" cy="35%" r="65%">
        <stop offset="0%" stop-color="#fef9c3"/>
        <stop offset="50%" stop-color="#eab308"/>
        <stop offset="100%" stop-color="#854d0e"/>
      </radialGradient>
    </defs>
    <g transform="translate(128 128)">
      <rect x="-66" y="-66" width="132" height="132" rx="10" fill="url(#stg)" stroke="#fef08a" stroke-width="3"/>
      <rect x="-66" y="-66" width="132" height="132" rx="10" transform="rotate(45)" fill="url(#stg)" stroke="#fef08a" stroke-width="3"/>
      <circle cx="0" cy="0" r="36" fill="#0d9488" stroke="#fef08a" stroke-width="3"/>
      <polygon points="0,-24 6,-6 24,0 6,6 0,24 -6,6 -24,0 -6,-6" fill="#fef9c3"/>
    </g>
  `),

  // 16. Golden Optical Starburst Sparkle
  sparkle: wrap(`
    <defs>
      <radialGradient id="spg" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="35%" stop-color="#fef08a"/>
        <stop offset="100%" stop-color="#f59e0b" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <circle cx="128" cy="128" r="84" fill="url(#spg)"/>
    <path d="M128 18 Q134 122 238 128 Q134 134 128 238 Q122 134 18 128 Q122 122 128 18 Z" fill="#fffbeb" stroke="#fbbf24" stroke-width="2"/>
    <circle cx="192" cy="66" r="8" fill="#fef08a"/>
    <circle cx="66" cy="186" r="6" fill="#fef08a"/>
  `),

  // 17. Graceful White Peace Dove with Olive Branch
  dove: wrap(`
    <defs>
      <linearGradient id="dvg" x1="20%" y1="10%" x2="85%" y2="90%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="70%" stop-color="#e2e8f0"/>
        <stop offset="100%" stop-color="#94a3b8"/>
      </linearGradient>
    </defs>
    <path d="M96 124 C68 82 54 38 92 28 C118 46 132 82 138 108 Z" fill="#cbd5e1"/>
    <path d="M114 134 C76 96 34 62 28 96 C42 126 78 144 108 148 Z" fill="url(#dvg)" stroke="#94a3b8" stroke-width="1.8"/>
    <path d="M54 166 C94 176 154 168 186 132 C202 114 210 92 198 82 C186 72 168 84 156 102 C132 128 92 134 42 188 Z" fill="url(#dvg)" stroke="#94a3b8" stroke-width="2"/>
    <polygon points="204,86 224,92 204,98" fill="#f59e0b"/>
    <circle cx="192" cy="88" r="3" fill="#1e293b"/>
    <path d="M216 94 Q236 112 242 134" stroke="#4d7c0f" stroke-width="3" fill="none"/>
    <ellipse cx="232" cy="108" rx="7" ry="3.5" transform="rotate(25 232 108)" fill="#65a30d"/>
    <ellipse cx="238" cy="124" rx="7" ry="3.5" transform="rotate(-20 238 124)" fill="#65a30d"/>
  `),

  // 18. Pearlized Festive Balloon with Silk Ribbon
  balloon: wrap(`
    <defs>
      <radialGradient id="blg" cx="35%" cy="28%" r="68%">
        <stop offset="0%" stop-color="#fda4af"/>
        <stop offset="45%" stop-color="#e11d48"/>
        <stop offset="100%" stop-color="#881337"/>
      </radialGradient>
    </defs>
    <path d="M128 184 C118 206 144 218 124 244" stroke="#f59e0b" stroke-width="3.5" stroke-linecap="round" fill="none"/>
    <polygon points="120,184 136,184 128,172" fill="#9f1239"/>
    <path d="M128 22 C76 22 48 64 48 108 C48 148 92 176 128 176 C164 176 208 148 208 108 C208 64 180 22 128 22 Z" fill="url(#blg)"/>
    <ellipse cx="94" cy="68" rx="16" ry="32" transform="rotate(-22 94 68)" fill="#ffffff" opacity="0.45"/>
  `),

  // 19. Satin-Bow Wrapped Festive Gift Box
  gift: wrap(`
    <defs>
      <linearGradient id="gbox" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ef4444"/><stop offset="100%" stop-color="#991b1b"/>
      </linearGradient>
      <linearGradient id="grib" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#fde68a"/><stop offset="100%" stop-color="#d97706"/>
      </linearGradient>
    </defs>
    <rect x="48" y="96" width="160" height="128" rx="14" fill="url(#gbox)" stroke="#7f1d1d" stroke-width="2.5"/>
    <rect x="38" y="68" width="180" height="34" rx="10" fill="#dc2626" stroke="#7f1d1d" stroke-width="2.5"/>
    <rect x="114" y="68" width="28" height="156" fill="url(#grib)"/>
    <rect x="48" y="142" width="160" height="24" fill="url(#grib)"/>
    <path d="M128 68 C96 28 62 42 78 68 Z" fill="url(#grib)" stroke="#92400e" stroke-width="2"/>
    <path d="M128 68 C160 28 194 42 178 68 Z" fill="url(#grib)" stroke="#92400e" stroke-width="2"/>
  `),

  // 20. Metallic Curling Silk Confetti Streamers
  confetti: wrap(`
    <path d="M54 34 C92 68 42 114 84 152 C116 180 78 214 98 232" stroke="#f59e0b" stroke-width="10" stroke-linecap="round" fill="none"/>
    <path d="M164 28 C196 64 146 106 184 148 C212 178 176 212 196 228" stroke="#10b981" stroke-width="9" stroke-linecap="round" fill="none"/>
    <rect x="116" y="54" width="18" height="18" rx="3" transform="rotate(28 125 63)" fill="#ec4899"/>
    <rect x="132" y="168" width="16" height="16" rx="3" transform="rotate(-18 140 176)" fill="#3b82f6"/>
    <circle cx="52" cy="186" r="8" fill="#fbbf24"/>
  `),

  // 21. Velvet Rose Heart
  heart: wrap(`
    <defs>
      <radialGradient id="hg" cx="35%" cy="28%" r="70%">
        <stop offset="0%" stop-color="#fda4af"/>
        <stop offset="45%" stop-color="#e11d48"/>
        <stop offset="100%" stop-color="#881337"/>
      </radialGradient>
    </defs>
    <path d="M128 222 C128 222 30 158 30 90 C30 52 60 28 92 28 C112 28 124 40 128 54 C132 40 144 28 164 28 C196 28 226 52 226 90 C226 158 128 222 128 222 Z"
      fill="url(#hg)" stroke="#881337" stroke-width="2"/>
    <ellipse cx="82" cy="72" rx="18" ry="10" transform="rotate(-32 82 72)" fill="#ffffff" opacity="0.38"/>
  `),

  // 22. Leather-Bound Stacked Study Books with Silk Bookmark
  books: wrap(`
    <g>
      <rect x="36" y="156" width="184" height="44" rx="8" fill="#1e3a8a" stroke="#172554" stroke-width="2.5"/>
      <rect x="44" y="164" width="168" height="28" rx="4" fill="#fef3c7"/>
      <rect x="36" y="156" width="28" height="44" rx="6" fill="#1d4ed8"/>
      <rect x="46" y="108" width="172" height="44" rx="8" fill="#991b1b" stroke="#450a0a" stroke-width="2.5"/>
      <rect x="54" y="116" width="156" height="28" rx="4" fill="#fffbeb"/>
      <rect x="46" y="108" width="26" height="44" rx="6" fill="#b91c1c"/>
      <rect x="56" y="62" width="156" height="42" rx="8" fill="#065f46" stroke="#022c22" stroke-width="2.5"/>
      <rect x="64" y="70" width="140" height="26" rx="4" fill="#fef9c3"/>
      <polygon points="154,96 170,96 170,142 162,132 154,142" fill="#f59e0b"/>
    </g>
  `),

  // 23. Gold Filigree Coptic Cross Medallion
  coptic_cross: wrap(`
    <defs>
      <linearGradient id="ccg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#fef08a"/><stop offset="50%" stop-color="#d97706"/><stop offset="100%" stop-color="#78350f"/>
      </linearGradient>
    </defs>
    <circle cx="128" cy="128" r="56" fill="none" stroke="url(#ccg)" stroke-width="10"/>
    <rect x="114" y="24" width="28" height="208" rx="10" fill="url(#ccg)"/>
    <rect x="24" y="114" width="208" height="28" rx="10" fill="url(#ccg)"/>
    ${[[128, 24], [128, 232], [24, 128], [232, 128]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="16" fill="url(#ccg)" stroke="#fef9c3" stroke-width="2"/>`).join("")}
    <circle cx="128" cy="128" r="18" fill="#991b1b" stroke="#fef9c3" stroke-width="3"/>
  `),
};

(async () => {
  fs.mkdirSync("src/assets/decor", { recursive: true });
  for (const [name, svg] of Object.entries(SPRITES)) {
    await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toFile(`src/assets/decor/${name}.png`);
  }
  console.log("Generated", Object.keys(SPRITES).length, "high-resolution realistic seasonal decor sprites.");
})();
