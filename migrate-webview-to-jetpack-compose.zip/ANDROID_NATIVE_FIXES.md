# DAYFLOW — تقرير الإصلاحات الكامل (جاهز للنسخ)

المشروع الآن مكوّن من طبقتين:

1. **تطبيق أندرويد أصلي (الأساس):** Kotlin + Jetpack Compose داخل `android/`، بدون WebView للواجهة. المنطق والصلاحيات والخدمات بلغات أندرويد.
2. **معاينة الويب:** نفس الواجهة والهوية البصرية داخل `src/`، وتُستخدم للمعاينة فقط. رسائل «غير متاح في المتصفح» موجودة **داخل طبقة الويب فقط**، ولا توجد في Compose إطلاقًا.

## قائمة المشاكل والإصلاحات

1. **[P0] التطبيق كان WebView/Capacitor وليس أصليًا**
   - المشكلة: الواجهة والمنطق داخل WebView، بلا Launcher Compose ولا خدمات نظام.
   - الإصلاح: مشروع أندرويد كامل + واجهة Compose أصلية + DataStore + خدمات. لا WebView للواجهة الأساسية.
   - التقنية: `MainActivity` + Compose + Navigation + Material3.

2. **[P0] الروبوت لا يظهر إلا داخل التطبيق**
   - المشكلة: عنصر React داخل الصفحة فقط.
   - الإصلاح: خدمة Foreground + `TYPE_APPLICATION_OVERLAY` + إذن `SYSTEM_ALERT_WINDOW`، سحب ولمس وفتح التطبيق، ونفس ملف الرسم `RobotRenderer` داخل التطبيق وخارجه.
   - التقنية: `CompanionOverlayService` / `WindowManager` / `RobotOverlayView`.

3. **[P0] المنبه لا يعمل فعليًا**
   - المشكلة: جدولة محاكاة في JS تتوقف مع إغلاق الصفحة.
   - الإصلاح: `AlarmManager.setAlarmClock()` + `BroadcastReceiver` + Foreground `AlarmRingService` + `AlarmRingActivity` كاملة الشاشة + غفوة + إيقاف، وإعادة الجدولة بعد كل رنين.
   - التقنية: `AlarmScheduler` / `AlarmReceiver` / `AlarmRingService`.

4. **[P0] لا توجد صلاحيات أندرويد حقيقية**
   - الإصلاح: فحص/طلب `SCHEDULE_EXACT_ALARM`، `POST_NOTIFICATIONS`، `SYSTEM_ALERT_WINDOW`، `ACCESS_COARSE_LOCATION`، ونغمات/ملفات عبر SAF.
   - التقنية: Activity Result Contracts + فحص `Settings`/`AlarmManager`.

5. **[P1] لا إشعارات أصلية**
   - الإصلاح: قنوات منفصلة (المنبهات/التذكيرات/الرفيق/التحميل)، إشعار منبه عالي الأولوية + Full-screen Intent + أزرار إيقاف وغفوة، وزر اختبار إشعار.
   - التقنية: `NotificationChannel` + `NotificationCompat`.

6. **[P1] لا ويدجتس على الشاشة الرئيسية**
   - الإصلاح: `AppWidgetProvider` + RemoteViews لثلاثة قوالب + ١٢ تصميمًا منفذًا + شاشة `WidgetConfigActivity` تفتح **شاشة الودجتس نفسها** وتطلب «اختار واحدة لتكون هي الودجت»، ثم تُثبت الودجت وتفتح التطبيق بالضغط.
   - التقنية: `DayflowWidgetProvider` + `WidgetUpdater` + `requestPinAppWidget`.

7. **[P0] مواقيت الصلاة غير صحيحة**
   - المشكلة: إزاحة ثابتة، لا Giza، لا DST، تراجع خاطئ لليوم التالي.
   - الإصلاح: حساب فلكي على الجهاز بمنطقة IANA ومراعاة DST، ١٧ مدينة (منها الجيزة)، الطريقة المصرية افتراضيًا، ٦ طرق، مذهب العصر، وموقع الجهاز عبر LocationManager، وقاعدة خطوط العرض العالية.
   - التقنية: `PrayerCalculator` + `java.time` + `LocationManager`.

8. **[P1] الوقت لم يكن ١٢ ساعة دائمًا**
   - الإصلاح: `DayflowTime.clock12` فقط في كل شاشة/ودجت/إشعار/شاشة رنين، بالعربية ص/م. لا خيار ٢٤ ساعة في التطبيق.

9. **[P0] رسالة CORS عند تحميل أي صيغة**
   - الإصلاح: قراءة الصفحات عبر OkHttp/Jsoup أصليًا بدون CORS، والتنزيل عبر `DownloadManager` لمجلد التنزيلات مع MIME والحجم الحقيقيين.
   - التقنية: `NativeMedia` + `LinkPreview` + `DownloadManager`.

10. **[P1] لا معاينة عنوان/غلاف/وصف للرابط**
    - الإصلاح: استخراج `og:title`/`og:image`/`og:description`/`author`/`site_name` + Twitter + JSON-LD، مع صورة غلاف ووصف ومدّة عند توفرها، ودعم `ACTION_SEND` لمشاركة الروابط للتطبيق.
    - التقنية: `JsoupMetaParser` داخل `NativeMedia`.

11. **[P1] صيغ وأحجام وهمية**
    - الإصلاح: الملفات المباشرة تُكتشف من الامتداد/Content-Type. يوتيوب عبر InnerTube، وتُعرض فقط الصيغ التي لها رابط فعلي (تقدمية/صوت). DRM أو المنع يعطي رسالة صريحة، بدون اختراع أحجام أو صيغ.

12. **[P1] نغمة الجهاز لا تُحفظ ولا تصل للمنبه**
    - الإصلاح: `ACTION_RINGTONE_PICKER` + `OpenDocument` مع `takePersistableUriPermission`، وحفظ URI/العنوان في DataStore وتمريره إلى `MediaPlayer` مع `USAGE_ALARM` واهتزاز وغفوة.

13. **[P1] المنبهات تُفقد بعد إعادة التشغيل**
    - الإصلاح: `SystemEventReceiver` يستمع لـ BOOT/MY_PACKAGE_REPLACED/TIME_SET/TIMEZONE_CHANGED/إذن المنبه الدقيق ويعيد جدولة كل المنبهات.

14. **[P1] رفض إذن المنبه كان يُتجاهل**
    - الإصلاح: فحص `canScheduleExactAlarms()`، وفتح إعدادات النظام، وبديل `setAndAllowWhileIdle` مع إشعار صريح بعدم الدقة. لا ادعاء زائف.

15. **[P2] الرسائل التحذيرية تظهر دائمًا**
    - الإصلاح: كل رسائل المتصفح محصورة في `src/` (Web). نسخة Compose لا تحتويها (`webOnlyMessages = false` غير مستخدمة).

16. **[P1] التطبيق بطيء وغير سلس**
    - الإصلاح: رسم الروبوت مرة واحدة على Canvas، قيمة الحركة تُقرأ في `drawBehind` لتقليل إعادة التركيب، LazyColumn، تحديث الوقت كل ٢٠–٣٠ ثانية بدل كل إطار، صور مضغوطة وأصول محلية.

17. **[P1] لا ويدجت تفاعلية/تحديث بيانات**
    - الإصلاح: تحديث تلقائي للودجتس بعد أي تغيير في DataStore (منبه/مهمة/صلاة/ماء)، RemoteViews، وضغط الودجت يفتح الشاشة المطابقة.

18. **[P2] الجيزة/موقع الجهاز غير مدعوم**
    - الإصلاح: إضافة الجيزة و١٦ مدينة، وزر «استخدم موقعي» عبر LocationManager مع صلاحية الموقع.

19. **[P2] التقويم/المناسبات والزخارف**
    - الإصلاح: Hijri (Umm al-Qura) + Coptic أصليان بدون مكتبات خارجية، مناسبات قادمة حقيقية، وأصول فنية موسمية واقعية (أزهار، أوراق خريف، فانوس، ثلج، وطني) + صورة فجر القاهرة.

20. **[P2] مؤقت التركيز لا يعمل خارج الصفحة**
    - الإصلاح: المؤقت Compose، وعند الانتهاء يُجدول منبه/إشعار أصلي عبر AlarmManager (مع تاريخ لليوم التالي عند تجاوز منتصف الليل).

21. **[P1] التخزين غير مناسب للخدمات الأصلية**
    - الإصلاح: DataStore Preferences + kotlinx.serialization، ترحيل/قيم افتراضية آمنة، ومزامنة كل الخدمات مع نفس المصدر.

22. **[P2] لا اختبار إشعار/رنين داخل التطبيق**
    - الإصلاح: زر إشعار تجريبي، ومعاينة رنين ١٢ ثانية قابلة للإيقاف، مع إظهار سبب فشل أي ميزة بدل الادعاء الكاذب.

## ملفات مهمة

- `android/README.md` — البناء والصلاحيات والاختبار.
- `android/app/src/main/AndroidManifest.xml` — كل المكوّنات والصلاحيات.
- `android/app/src/main/java/app/dayflow/android/alarm/` — المنبه والرنين.
- `android/app/src/main/java/app/dayflow/android/overlay/` — الرفيق فوق التطبيقات.
- `android/app/src/main/java/app/dayflow/android/widget/` — الودجتس.
- `android/app/src/main/java/app/dayflow/android/domain/` — الصلاة، الوقت، الوسائط، التقويم.
- `android/app/src/main/java/app/dayflow/android/ui/` — واجهة Compose المطابقة.

> ملاحظة أمانة: لم أستطع تشغيل Gradle/جهاز أندرويد داخل هذه البيئة (لا Android SDK/جهاز). التطبيق مكتوب كاملًا وقابل للبناء في Android Studio. أي نتيجة على جهاز حقيقي (رنين فعلي، تثبيت ودجت، Overlay) تحتاج تجربة الجهاز، وهذا موثّق بدقة.
