import { alarmCountdown, greeting, nextAlarmTime, todayKey, type DecorFamily, type State } from "./data";
import { CITIES, PRAYERS, prayerTimes } from "./prayer";

export function articles(s: State, now: Date, family: DecorFamily): string[] {
  const city = CITIES.find((c) => c.id === s.cityId) || CITIES[0];
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const next = nextAlarmTime(s.alarms, now);
  const tasks = s.tasks.filter((t) => t.date === todayKey() && !t.done);
  const lines: string[] = [];
  lines.push(`${greeting(now)}. النهاردة ${tasks.length ? `عندك ${tasks.length} مهمة لسه` : "يومك فاضي، خد نفسك"} — وأنا معاك.`);
  if (pr.next) lines.push(`فاضل ${pr.next.inMinutes} دقيقة على ${pr.next.key === "sunrise" ? "الشروق" : PRAYERS.find((p) => p.key === pr.next?.key)?.ar} في ${city.ar}.`);
  if (next) lines.push(`المنبه الجاي ${next.alarm.label || "منبه"} ${alarmCountdown(next.at, now)}.`);
  if (family === "ramadan") lines.push("رمضان مبارك 🌙 — اشرب ماء كفاية من الفجر للمغرب، وخد وقتك في الإفطار.");
  if (family === "friday") lines.push("الجمعة نور — متنساش الصلاة على النبي ﷺ وسورة الكهف لو قدرت.");
  lines.push("تحب نبدأ مهمة صغيرة دلوقتي؟ خطوة واحدة أحسن من عشرة مخططين.");
  return lines;
}
