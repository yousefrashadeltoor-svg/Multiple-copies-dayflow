import { useSyncExternalStore } from "react";
import { CITIES, dayKeyInZone, type City, type MethodId } from "./prayer";

export type Lang = "ar" | "en";
export type Mood = "idle" | "happy" | "think" | "sleep" | "celebrate";
export type SoundSource = "device" | "files" | "library" | "downloaded";

export interface AlarmSound { source: SoundSource; title: string; uri?: string; }
export interface Alarm {
  id: string;
  time: string;
  date?: string;
  days: number[];
  label: string;
  enabled: boolean;
  sound: AlarmSound;
  vibrate: boolean;
  snooze: number;
  gentle: boolean;
  createdAt: number;
}
export interface Task { id: string; title: string; date: string; dueTime?: string; done: boolean; urgent: boolean; important: boolean; createdAt: number; }
export interface Note { id: string; text: string; pinned: boolean; at: number; }
export interface Habit { id: string; ar: string; en: string; emoji: string; color: string; log: string[]; target?: number; unit?: string; }
export interface JournalEntry { id: string; date: string; mood: number; text: string; }
export type WForm = "1x1" | "2x1" | "2x2" | "4x1" | "4x2" | "4x4";
export type WStyle = "oneui" | "material" | "paper" | "neon" | "amoled" | "ios" | "outline" | "clay" | "gold";
export type WCat = "clock" | "alarms" | "calendar" | "occasions" | "plan" | "tasks" | "habits" | "focus" | "review" | "media" | "utility" | "companion";

export interface WidgetDef {
  id: string; ar: string; en: string; cat: WCat; arche: string; forms: WForm[];
  desc: string; family: DecorFamily; interactive: boolean;
}
export interface PlacedWidget { id: string; designId: string; form: WForm; style: WStyle; createdAt: number; }

export type DecorFamily = "spring" | "summer" | "autumn" | "winter" | "ramadan" | "eid" | "national" | "friday" | "islamic";

export interface FamilyStyle {
  id: DecorFamily; ar: string; en: string; c1: string; c2: string; c3: string;
  ornament: string | null; motif: "blossom" | "sun" | "leaves" | "snow" | "lantern" | "crescent" | "flag" | "star"; note: string;
}

export const FAMILY_STYLES: Record<DecorFamily, FamilyStyle> = {
  spring: { id: "spring", ar: "الربيع", en: "Spring", c1: "#5c8a6b", c2: "#a8c3a0", c3: "#e7b7a9", ornament: "/images/ornament-blossom.png", motif: "blossom", note: "زهور الربيعى" },
  summer: { id: "summer", ar: "الصيف والنيل", en: "Summer & Nile", c1: "#2f6f7a", c2: "#8fbfc0", c3: "#e7c67a", ornament: null, motif: "sun", note: "زرقة النيل" },
  autumn: { id: "autumn", ar: "الخريف", en: "Autumn", c1: "#8c5b3a", c2: "#c79a63", c3: "#d8b26b", ornament: "/images/ornament-autumn.png", motif: "leaves", note: "ورق الخريف" },
  winter: { id: "winter", ar: "الشتاء", en: "Winter", c1: "#42617a", c2: "#9db4c4", c3: "#d6e5ee", ornament: null, motif: "snow", note: "صباح شتوي" },
  ramadan: { id: "ramadan", ar: "رمضان", en: "Ramadan", c1: "#3b5a46", c2: "#8f7c4b", c3: "#d7b56d", ornament: "/images/ornament-lantern.png", motif: "lantern", note: "فوانيس وأهلة" },
  eid: { id: "eid", ar: "العيد", en: "Eid", c1: "#59653d", c2: "#b39a58", c3: "#eed9a4", ornament: "/images/ornament-blossom.png", motif: "crescent", note: "فرحة العيد" },
  national: { id: "national", ar: "وطنية", en: "National", c1: "#6c3730", c2: "#c6b79c", c3: "#d7bd76", ornament: null, motif: "flag", note: "أيام مصر" },
  friday: { id: "friday", ar: "الجمعة", en: "Friday", c1: "#3c5c4b", c2: "#9c9a71", c3: "#d5bb80", ornament: null, motif: "star", note: "نور الجمعة" },
  islamic: { id: "islamic", ar: "إسلامية", en: "Islamic", c1: "#2f5b4b", c2: "#9f9a67", c3: "#d2b56f", ornament: "/images/ornament-lantern.png", motif: "star", note: "زخارف عربية" },
};

export interface State {
  version: number;
  lang: Lang;
  cityId: string;
  methodId: MethodId;
  asrFactor: 1 | 2;
  alarms: Alarm[];
  tasks: Task[];
  notes: Note[];
  habits: Habit[];
  water: Record<string, number>;
  waterGoal: number;
  journal: JournalEntry[];
  placed: PlacedWidget[];
  selectedWidgetId: string | null;
  autoSeason: boolean;
  intensity: "off" | "subtle" | "rich" | "festival";
  reduceMotion: boolean;
  companion: { enabled: boolean; hidden: boolean; emotion: Mood; size: number; opacity: number; outfit: "auto" | "gold" | "snow" | "national"; bubbles: boolean; notify: boolean; overlayDemo: boolean };
  notif: { enabled: boolean; preview: boolean; sound: boolean; vibrate: boolean; quiet: boolean; quietFrom: string; quietTo: string; reminderOffset: number };
  hour12: true;
  onboarded: boolean;
  webBannerDismissed: boolean;
  decoSeen: Record<string, boolean>;
}

const DAY = 86_400_000;
export const uid = () => Math.random().toString(36).slice(2, 10);
export const todayKey = () => dayKeyInZone(new Date(), CITIES[0].tz);
export const localKey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
export const DAYS_AR = ["الأحد", "الاتنين", "التلات", "الأربع", "الخميس", "الجمعة", "السبت"];
export const DAYS_SHORT_AR = ["حد", "اتنين", "تلات", "أربع", "خميس", "جمعة", "سبت"];
export const DAYS_EN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
export const SOUND_SOURCES: { id: SoundSource; ar: string; en: string }[] = [
  { id: "device", ar: "منبه الجهاز الافتراضي", en: "Default alarm (device)" },
  { id: "library", ar: "مكتبة نغمات DAYFLOW", en: "DAYFLOW sound library" },
  { id: "files", ar: "ملف صوتي من الهاتف", en: "Audio file from device" },
  { id: "downloaded", ar: "من التحميلات", en: "From downloads" },
];

const seedTasks = (): Task[] => {
  const k = todayKey();
  return [
    { id: uid(), title: "مراجعة خطة اليوم في ٥ دقايق", date: k, done: false, urgent: true, important: true, createdAt: Date.now() },
    { id: uid(), title: "خلص شغل العميل الأول", date: k, done: true, urgent: false, important: true, createdAt: Date.now() - 1 },
    { id: uid(), title: "اتصل بالوالدة قبل المغرب 🌿", date: k, done: false, urgent: false, important: true, createdAt: Date.now() - 2 },
    { id: uid(), title: "اقرأ ١٠ صفحات قبل النوم", date: k, done: false, urgent: false, important: false, createdAt: Date.now() - 3 },
  ];
};

const seedHabits = (): Habit[] => {
  const y = new Date(Date.now() - DAY).toISOString().slice(0, 10);
  return [
    { id: uid(), ar: "قرآن", en: "Quran", emoji: "📖", color: "#2f6f5e", log: [y] },
    { id: uid(), ar: "مشي", en: "Walk", emoji: "🚶", color: "#c9a24a", log: [todayKey()] },
    { id: uid(), ar: "نوم بدري", en: "Early sleep", emoji: "🌙", color: "#42617a", log: [y] },
    { id: uid(), ar: "ماء", en: "Water", emoji: "💧", color: "#4a93b8", log: [todayKey()] },
  ];
};

const seed = (): State => ({
  version: 1,
  lang: "ar",
  cityId: "giza",
  methodId: "egypt",
  asrFactor: 1,
  alarms: [
    { id: "morning", time: "07:00", days: [0, 1, 2, 3, 4], label: "صحيان للشغل", enabled: true, sound: { source: "device", title: "منبه الجهاز الافتراضي" }, vibrate: true, snooze: 10, gentle: true, createdAt: Date.now() - 20 },
    { id: "evening", time: "22:30", days: [], label: "اقرأ قبل النوم", enabled: true, sound: { source: "library", title: "صوت الهدوء — DAYFLOW" }, vibrate: false, snooze: 5, gentle: true, createdAt: Date.now() - 10 },
  ],
  tasks: seedTasks(),
  notes: [{ id: uid(), text: "يوم بسيط، خطوة صغيرة أحسن من مفيش.", pinned: true, at: Date.now() - 5000 }],
  habits: seedHabits(),
  water: { [todayKey()]: 750 },
  waterGoal: 2500,
  journal: [],
  placed: [],
  selectedWidgetId: null,
  autoSeason: true,
  intensity: "subtle",
  reduceMotion: false,
  companion: { enabled: true, hidden: false, emotion: "idle", size: 1, opacity: 1, outfit: "auto", bubbles: true, notify: false, overlayDemo: false },
  notif: { enabled: false, preview: true, sound: true, vibrate: true, quiet: false, quietFrom: "23:00", quietTo: "06:30", reminderOffset: 0 },
  hour12: true,
  onboarded: false,
  webBannerDismissed: false,
  decoSeen: {},
});

const KEY = "dayflow-native-preview-v1";

function load(): State {
  if (typeof window === "undefined") return seed();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return seed();
    const parsed = JSON.parse(raw) as Partial<State>;
    const base = seed();
    return {
      ...base,
      ...parsed,
      alarms: Array.isArray(parsed.alarms) ? parsed.alarms : base.alarms,
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks : base.tasks,
      habits: Array.isArray(parsed.habits) ? parsed.habits : base.habits,
      notes: Array.isArray(parsed.notes) ? parsed.notes : base.notes,
      placed: Array.isArray(parsed.placed) ? parsed.placed : [],
      companion: { ...base.companion, ...(parsed.companion || {}) },
      notif: { ...base.notif, ...(parsed.notif || {}) },
      hour12: true,
      version: 1,
    };
  } catch {
    return seed();
  }
}

let state: State = load();
const listeners = new Set<() => void>();
let saveTimer: number | null = null;

function persist() {
  if (typeof window === "undefined") return;
  if (saveTimer) window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    try { window.localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* private mode */ }
  }, 120);
}

export const store = {
  get: () => state,
  subscribe(fn: () => void) { listeners.add(fn); return () => listeners.delete(fn); },
  set: (patch: Partial<State> | ((current: State) => Partial<State>)) => {
    const next = typeof patch === "function" ? patch(state) : patch;
    state = { ...state, ...next };
    persist();
    listeners.forEach((l) => l());
  },
  reset: () => { state = seed(); persist(); listeners.forEach((l) => l()); },
};

export function useDayflow(): State {
  return useSyncExternalStore(store.subscribe, store.get, store.get);
}

/** Every mutation used by the UI. Kept outside React so timers/services can use it too. */
export const actions = {
  addAlarm(a: Omit<Alarm, "id" | "createdAt">) {
    const alarm: Alarm = { ...a, id: uid(), createdAt: Date.now() };
    store.set((s) => ({ alarms: [...s.alarms, alarm] }));
    return alarm.id;
  },
  updateAlarm(id: string, patch: Partial<Alarm>) {
    store.set((s) => ({ alarms: s.alarms.map((a) => (a.id === id ? { ...a, ...patch } : a)) }));
  },
  removeAlarm(id: string) {
    store.set((s) => ({ alarms: s.alarms.filter((a) => a.id !== id) }));
  },
  addTask(title: string, date = todayKey(), urgent = false, important = true, dueTime?: string) {
    store.set((s) => ({ tasks: [{ id: uid(), title, date, urgent, important, dueTime, done: false, createdAt: Date.now() }, ...s.tasks] }));
  },
  toggleTask(id: string) {
    store.set((s) => ({ tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)) }));
  },
  removeTask(id: string) {
    store.set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) }));
  },
  addNote(text: string) {
    store.set((s) => ({ notes: [{ id: uid(), text, pinned: false, at: Date.now() }, ...s.notes] }));
  },
  togglePin(id: string) {
    store.set((s) => ({ notes: s.notes.map((n) => (n.id === id ? { ...n, pinned: !n.pinned } : n)) }));
  },
  removeNote(id: string) {
    store.set((s) => ({ notes: s.notes.filter((n) => n.id !== id) }));
  },
  addWater(ml: number) {
    store.set((s) => ({ water: { ...s.water, [todayKey()]: Math.max(0, (s.water[todayKey()] || 0) + ml) } }));
  },
  toggleHabit(id: string) {
    const k = todayKey();
    store.set((s) => ({ habits: s.habits.map((h) => h.id === id ? { ...h, log: h.log.includes(k) ? h.log.filter((d) => d !== k) : [k, ...h.log] } : h) }));
  },
  addHabit(ar: string, en: string, emoji = "✨") {
    store.set((s) => ({ habits: [...s.habits, { id: uid(), ar, en, emoji, color: "#2f6f5e", log: [] }] }));
  },
  addWidget(designId: string, form: WForm, style: WStyle) {
    const w: PlacedWidget = { id: uid(), designId, form, style, createdAt: Date.now() };
    store.set((s) => ({ placed: [...s.placed, w], selectedWidgetId: designId }));
    return w.id;
  },
  removeWidget(id: string) {
    store.set((s) => ({ placed: s.placed.filter((w) => w.id !== id) }));
  },
  setSelectedWidget(designId: string | null) {
    store.set({ selectedWidgetId: designId });
  },
  setCompanion(patch: Partial<State["companion"]>) {
    store.set((s) => ({ companion: { ...s.companion, ...patch } }));
  },
  setNotif(patch: Partial<State["notif"]>) {
    store.set((s) => ({ notif: { ...s.notif, ...patch } }));
  },
  markDecoSeen(key: string) {
    store.set((s) => ({ decoSeen: { ...s.decoSeen, [key]: true } }));
  },
};

/* ------------------------------------------------------------------ */
/* Alarms                                                              */
/* ------------------------------------------------------------------ */

export function nextAlarmOccurrence(alarm: Alarm, now = new Date()): Date | null {
  if (!alarm.enabled) return null;
  const [hh, mm] = alarm.time.split(":").map(Number);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (alarm.date) {
    const at = new Date(`${alarm.date}T${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:00`);
    return at.getTime() > now.getTime() ? at : null;
  }
  if (!alarm.days.length) {
    const at = new Date(now);
    at.setHours(hh, mm, 0, 0);
    if (at.getTime() <= now.getTime()) at.setDate(at.getDate() + 1);
    return at;
  }
  for (let i = 0; i <= 7; i++) {
    const at = new Date(now);
    at.setDate(now.getDate() + i);
    at.setHours(hh, mm, 0, 0);
    if (alarm.days.includes(at.getDay()) && at.getTime() > now.getTime()) return at;
  }
  return null;
}

export function nextAlarmTime(alarms: Alarm[], now = new Date()) {
  const items = alarms
    .map((alarm) => ({ alarm, at: nextAlarmOccurrence(alarm, now) }))
    .filter((x): x is { alarm: Alarm; at: Date } => x.at !== null)
    .sort((a, b) => a.at.getTime() - b.at.getTime());
  return items[0] || null;
}

export function alarmDaysLabel(alarm: Alarm) {
  if (alarm.date && !alarm.days.length) return new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(new Date(`${alarm.date}T12:00:00`));
  if (!alarm.days.length) return "مرة واحدة";
  if (alarm.days.length === 7) return "كل يوم";
  return [...alarm.days].sort((a, b) => ((a + 1) % 7) - ((b + 1) % 7)).map((d) => DAYS_SHORT_AR[d]).join(" · ");
}

export function alarmCountdown(at: Date, now = new Date()) {
  const diff = Math.max(0, at.getTime() - now.getTime());
  const minutes = Math.floor(diff / 60000);
  const days = Math.floor(minutes / 1440);
  const hours = Math.floor((minutes % 1440) / 60);
  const mins = minutes % 60;
  if (days > 0) return `بعد ${days} يوم و${hours} ساعة`;
  if (hours > 0) return `بعد ${hours} ساعة و${mins} دقيقة`;
  return `بعد ${mins} دقيقة`;
}

/* ------------------------------------------------------------------ */
/* Seasons, occasions, calendar                                       */
/* ------------------------------------------------------------------ */

export interface Occasion { id: string; ar: string; en: string; date: string; family: DecorFamily; priority: number; lunar: boolean; }

const FIXED_OCCASIONS: Occasion[] = [
  { id: "coptic-xmas", ar: "عيد الميلاد المجيد", en: "Coptic Christmas", date: "01-07", family: "winter", priority: 80, lunar: false },
  { id: "revolution", ar: "عيد الشرطة وثورة ٢٥ يناير", en: "Police & 25 January", date: "01-25", family: "national", priority: 90, lunar: false },
  { id: "mothers", ar: "عيد الأم", en: "Mother's Day", date: "03-21", family: "spring", priority: 85, lunar: false },
  { id: "nile", ar: "عيد وفاء النيل", en: "Nile Flood", date: "08-15", family: "summer", priority: 70, lunar: false },
  { id: "june30", ar: "ثورة ٣٠ يونيو", en: "30 June", date: "06-30", family: "national", priority: 85, lunar: false },
  { id: "july23", ar: "ثورة ٢٣ يوليو", en: "23 July", date: "07-23", family: "national", priority: 85, lunar: false },
  { id: "oct6", ar: "عيد القوات المسلحة", en: "Armed Forces Day", date: "10-06", family: "national", priority: 85, lunar: false },
  { id: "newyear", ar: "رأس السنة", en: "New Year", date: "01-01", family: "winter", priority: 75, lunar: false },
  { id: "orthodox-easter", ar: "عيد القيامة", en: "Easter", date: "04-20", family: "spring", priority: 70, lunar: false },
];

const LUNAR_OCCASIONS: Occasion[] = [
  { id: "islamic-newyear", ar: "رأس السنة الهجرية", en: "Islamic New Year", date: "01-01", family: "islamic", priority: 78, lunar: true },
  { id: "ashura", ar: "يوم عاشوراء", en: "Ashura", date: "01-10", family: "islamic", priority: 60, lunar: true },
  { id: "mawlid", ar: "المولد النبوي", en: "Mawlid", date: "03-12", family: "islamic", priority: 88, lunar: true },
  { id: "isra", ar: "الإسراء والمعراج", en: "Isra & Mi'raj", date: "07-27", family: "islamic", priority: 70, lunar: true },
  { id: "ramadan", ar: "رمضان", en: "Ramadan", date: "09-01", family: "ramadan", priority: 100, lunar: true },
  { id: "laylat-qadr", ar: "ليلة القدر", en: "Laylat al-Qadr", date: "09-27", family: "ramadan", priority: 95, lunar: true },
  { id: "eid-fitr", ar: "عيد الفطر", en: "Eid al-Fitr", date: "10-01", family: "eid", priority: 100, lunar: true },
  { id: "arafat", ar: "يوم عرفة", en: "Arafat", date: "12-09", family: "eid", priority: 92, lunar: true },
  { id: "eid-adha", ar: "عيد الأضحى", en: "Eid al-Adha", date: "12-10", family: "eid", priority: 100, lunar: true },
];

const hijriFmt = (() => {
  try { return new Intl.DateTimeFormat("en-US-u-ca-islamic-umalqura", { day: "numeric", month: "numeric", year: "numeric" }); }
  catch { return null; }
})();

export function hijriParts(date: Date) {
  try {
    const fmt = hijriFmt;
    if (!fmt) return null;
    const parts = fmt.formatToParts(date);
    const get = (t: string) => Number(parts.find((p) => p.type === t)?.value || 0);
    return { day: get("day"), month: get("month"), year: get("year") };
  } catch { return null; }
}

export function hijriLabel(date: Date) {
  const h = hijriParts(date);
  if (!h) return "";
  const months = ["محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"];
  return `${h.day} ${months[h.month - 1] || ""} ${h.year} هـ`;
}

export function copticLabel(date: Date) {
  try {
    return new Intl.DateTimeFormat("ar-EG-u-ca-coptic", { day: "numeric", month: "long", year: "numeric" }).format(date);
  } catch { return ""; }
}

function lunarToGregorian(hijriMonth: number, hijriDay: number, from: Date) {
  const start = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  for (let i = -10; i < 420; i++) {
    const d = new Date(start.getTime() + i * DAY);
    const h = hijriParts(d);
    if (h && h.month === hijriMonth && h.day === hijriDay) return d;
  }
  return null;
}

export function upcomingOccasions(from = new Date(), count = 6): Occasion[] {
  const start = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  const results: { occasion: Occasion; at: Date }[] = [];
  for (const occ of FIXED_OCCASIONS) {
    const [m, d] = occ.date.split("-").map(Number);
    let at = new Date(start.getFullYear(), m - 1, d);
    if (at < start) at = new Date(start.getFullYear() + 1, m - 1, d);
    results.push({ occasion: occ, at });
  }
  for (const occ of LUNAR_OCCASIONS) {
    const [m, d] = occ.date.split("-").map(Number);
    const at = lunarToGregorian(m, d, start);
    if (at && at >= start) results.push({ occasion: occ, at });
  }
  return results.sort((a, b) => a.at.getTime() - b.at.getTime()).slice(0, count).map((r) => {
    const [m, d] = [r.at.getMonth() + 1, r.at.getDate()];
    return { ...r.occasion, date: `${r.at.getFullYear()}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}` };
  });
}

export function seasonFor(date = new Date()): FamilyStyle {
  const h = hijriParts(date);
  if (h) {
    if (h.month === 9) return FAMILY_STYLES.ramadan;
    if (h.month === 10 && h.day <= 12) return FAMILY_STYLES.eid;
    if (h.month === 12 && h.day >= 9 && h.day <= 13) return FAMILY_STYLES.eid;
  }
  const fixed = FIXED_OCCASIONS.find((o) => {
    const [m, d] = o.date.split("-").map(Number);
    return date.getMonth() + 1 === m && date.getDate() === d;
  });
  if (fixed) return FAMILY_STYLES[fixed.family];
  if (date.getDay() === 5) return FAMILY_STYLES.friday;
  const m = date.getMonth() + 1;
  if (m === 12 || m <= 2) return FAMILY_STYLES.winter;
  if (m <= 5) return FAMILY_STYLES.spring;
  if (m <= 8) return FAMILY_STYLES.summer;
  return FAMILY_STYLES.autumn;
}

export function cityOf(state: State): City {
  return CITIES.find((c) => c.id === state.cityId) || CITIES[0];
}

export function greeting(date = new Date()) {
  const h = date.getHours();
  if (h < 5) return "طابت ليلتك";
  if (h < 12) return "صباح الخير";
  if (h < 17) return "طاب يومك";
  return "مساء الخير";
}

export function arabicDate(date = new Date()) {
  return new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(date);
}

/* ------------------------------------------------------------------ */
/* Widget catalog                                                     */
/* ------------------------------------------------------------------ */

const W = (cat: WCat, en: string, ar: string, arche: string, desc: string, forms: WForm[] = ["1x1", "2x1", "2x2", "4x1", "4x2", "4x4"], family: DecorFamily = "islamic", interactive = false): WidgetDef => ({
  id: `${cat}-${en.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`,
  ar, en, cat, arche, desc, family, interactive, forms,
});

export const WIDGET_CATS: { id: WCat; ar: string; en: string; icon: string }[] = [
  { id: "clock", ar: "الساعة", en: "Clock", icon: "clock" },
  { id: "alarms", ar: "المنبهات", en: "Alarms", icon: "alarm" },
  { id: "calendar", ar: "التقويم", en: "Calendar", icon: "calendar" },
  { id: "occasions", ar: "المناسبات", en: "Occasions", icon: "star" },
  { id: "plan", ar: "الخطة واليوم", en: "Plan & today", icon: "list" },
  { id: "tasks", ar: "المهام والملاحظات", en: "Tasks & notes", icon: "check" },
  { id: "habits", ar: "العادات والصحة", en: "Habits & health", icon: "heart" },
  { id: "focus", ar: "التركيز والدراسة", en: "Focus", icon: "focus" },
  { id: "review", ar: "المراجعة والإحصاءات", en: "Review", icon: "chart" },
  { id: "media", ar: "مركز الوسائط", en: "Media Hub", icon: "download" },
  { id: "utility", ar: "أدوات", en: "Utility", icon: "grid" },
  { id: "companion", ar: "الرفيق", en: "Companion", icon: "robot" },
];

export const WIDGETS: WidgetDef[] = [
  W("clock", "Minimal digital", "رقمية بسيطة", "digital", "الساعة الآن بخط واضح وهادئ", ["1x1", "2x1", "2x2", "4x1", "4x2"], "friday"),
  W("clock", "Ornate clock", "ساعة مزخرفة", "digital", "ساعة وزخرفة إسلامية ذهبية", ["2x1", "2x2", "4x2"], "ramadan"),
  W("clock", "Analog classic", "عقارب كلاسيكية", "analog", "ساعة بعقارب وثواني اختيارية", ["1x1", "2x2"], "autumn"),
  W("clock", "Sun-arc", "قوس الشمس", "sunarc", "الوقت مع مسار الشمس والصباح", ["2x1", "2x2", "4x1", "4x2"], "summer"),
  W("clock", "Clock + day", "ساعة + اليوم", "digital", "الساعة وملخص مهامك اليوم", ["2x2", "4x2"]),
  W("clock", "Bedside", "ساعة السرير", "digital", "ساعة ليلية هادئة للمنبه", ["2x1", "2x2", "4x2"], "winter"),
  W("alarms", "Next alarm", "المنبه التالي", "countdown", "المنبه القادم والعد التنازلي", ["1x1", "2x1", "2x2", "4x1", "4x2"], "friday", true),
  W("alarms", "Alarm ring", "قرص المنبه", "dial", "قرص دائري واضح للوقت المتبقي", ["1x1", "2x2"], "islamic", true),
  W("alarms", "Alarm list", "قائمة المنبهات", "checklist", "المنبهات مع تشغيل وإيقاف", ["2x2", "4x1", "4x2", "4x4"], "islamic", true),
  W("calendar", "Month compact", "شهر مدمج", "month", "التقويم الشهري بشكل مختصر", ["2x2", "4x2", "4x4"], "spring"),
  W("calendar", "Week strip", "شريط الأسبوع", "week", "أيام الأسبوع واليوم الحالي", ["2x1", "4x1", "4x2"], "autumn"),
  W("calendar", "Agenda artwork", "أجندة بالزخارف", "list", "مواعيد اليوم مع زخرفة موسمية", ["2x2", "4x2", "4x4"], "spring"),
  W("calendar", "Tri-calendar", "التقاويم الثلاثة", "tri", "هجري وميلادي وقبطي", ["2x2", "4x2"], "islamic"),
  W("occasions", "Occasion hero", "بطل المناسبة", "hero", "المناسبة القادمة بصورة وزخرفة", ["2x2", "4x2", "4x4"], "national"),
  W("occasions", "Countdown ring", "حلقة العد التنازلي", "ring", "عدد الأيام المتبقية للمناسبة", ["1x1", "2x2"], "eid"),
  W("occasions", "Iftar countdown", "العد للإفطار", "countdown", "وقت المغرب ومتبقي الصيام", ["2x1", "2x2", "4x2"], "ramadan"),
  W("occasions", "Friday card", "بطاقة الجمعة", "hero", "دعاء وأذكار الجمعة", ["2x1", "2x2", "4x2"], "friday"),
  W("plan", "Now · Next", "الآن · التالي", "list", "المهمة الحالية والقادمة", ["2x2", "4x2", "4x4"]),
  W("plan", "Today progress", "تقدم اليوم", "ring", "نسبة إنجاز اليوم", ["1x1", "2x2"], "spring"),
  W("plan", "Top priorities", "أهم الأولويات", "checklist", "أهم ٣ مهام وتأشيرها", ["2x2", "4x2", "4x4"], "islamic", true),
  W("plan", "Schedule river", "نهر الجدول", "timeline", "خط زمني أفقي لليوم", ["4x1", "4x2"]),
  W("tasks", "Checklist", "قائمة التحقق", "checklist", "مهام اليوم قابلة للتأشير", ["2x1", "2x2", "4x2", "4x4"], "islamic", true),
  W("tasks", "Pinned note", "ملاحظة مثبتة", "note", "ورقة أنيقة لملاحظتك", ["2x1", "2x2", "4x2", "4x4"], "autumn"),
  W("tasks", "Task rings", "حلقات المهام", "ring", "ثلاث حلقات للمهام", ["1x1", "2x2"], "spring"),
  W("tasks", "Quick add", "إضافة سريعة", "quick", "زر إضافة مهمة من الشاشة", ["2x1", "4x1"], "islamic", true),
  W("habits", "Habit grid", "شبكة العادات", "heatmap", "مربعات العادات والأيام", ["2x2", "4x2", "4x4"], "spring", true),
  W("habits", "Streak", "السلسلة", "counter", "عدد الأيام المتتالية", ["1x1", "2x1"], "autumn"),
  W("habits", "Water drop", "قطرة ماء", "drop", "شرب الماء وإضافة كوب", ["1x1", "2x1", "2x2"], "summer", true),
  W("habits", "Medication", "جدول الأدوية", "checklist", "تذكير الدواء وتأشير الجرعات", ["2x2", "4x2", "4x4"], "islamic", true),
  W("focus", "Focus ring", "حلقة التركيز", "ring", "مؤقت تركيز ٢٥ دقيقة", ["1x1", "2x2"], "autumn", true),
  W("focus", "Pomodoro", "بومودورو", "dial", "دورة عمل واستراحة", ["2x2"], "summer"),
  W("focus", "Exam countdown", "عد الامتحانات", "countdown", "الأيام المتبقية للامتحان", ["2x2", "4x2"], "autumn"),
  W("review", "Daily score", "نتيجة اليوم", "ring", "درجة اليوم من الإنجاز", ["1x1", "2x2"], "islamic"),
  W("review", "Week radar", "رادار الأسبوع", "radar", "توازن عاداتك على مدار الأسبوع", ["2x2", "4x2"], "spring"),
  W("review", "Strengths", "نقاط القوة", "bars", "أين تنجح أكثر", ["2x2", "4x2", "4x4"]),
  W("media", "Active downloads", "التنزيلات النشطة", "download", "تقدم التنزيلات الحقيقية", ["2x1", "2x2", "4x2"], "islamic", true),
  W("media", "Paste link", "الصق رابطًا", "quick", "افتح محمّل الوسائط فورًا", ["2x1"], "summer", true),
  W("utility", "Battery ring", "حلقة البطارية", "battery", "البطارية والشحن", ["1x1", "2x1"], "winter"),
  W("utility", "Next prayer", "الصلاة القادمة", "nextprayer", "الصلاة القادمة والوقت المتبقي", ["1x1", "2x1", "2x2", "4x1"], "ramadan"),
  W("utility", "Prayer times", "مواقيت الصلاة", "prayer", "المواقيت الستة كاملة", ["4x1", "4x2", "4x4"], "ramadan"),
  W("utility", "Qibla", "القبلة", "compass", "اتجاه القبلة من موقعك", ["1x1", "2x2"], "islamic"),
  W("utility", "Tasbih", "عداد التسبيح", "counter", "عداد تسبيح بلمسة", ["1x1", "2x1", "2x2"], "islamic", true),
  W("utility", "Quick actions", "إجراءات سريعة", "quick", "أربعة اختصارات للتطبيق", ["2x2", "4x2"], "islamic", true),
  W("companion", "Companion portrait", "صورة الرفيق", "portrait", "رفيقك على الشاشة الرئيسية", ["1x1", "2x2", "4x2"], "islamic"),
  W("companion", "Companion tip", "نصيحة الرفيق", "portrait", "نصيحة قصيرة حسب وقتك", ["2x1", "4x1"], "friday"),
  W("companion", "Companion actions", "إجراءات الرفيق", "quick", "أضف مهمة أو ابدأ التركيز", ["2x1", "2x2"], "islamic", true),
];

export const W_STYLES: { id: WStyle; ar: string; en: string }[] = [
  { id: "oneui", ar: "زجاج One UI", en: "One UI Glass" },
  { id: "material", ar: "Material You", en: "Material You" },
  { id: "ios", ar: "مستوحى من iOS", en: "iOS" },
  { id: "paper", ar: "ورق", en: "Paper" },
  { id: "neon", ar: "نيون", en: "Neon" },
  { id: "clay", ar: "صلصال ناعم", en: "Soft Clay" },
  { id: "outline", ar: "محدد", en: "Outline" },
  { id: "amoled", ar: "أسود AMOLED", en: "AMOLED" },
  { id: "gold", ar: "ذهبي", en: "Golden" },
  { id: "ios", ar: "زجاج فاتح", en: "Frosted" },
];

export const W_FORMS: { id: WForm; ar: string; label: string }[] = [
  { id: "1x1", ar: "مربع صغير", label: "1×1" },
  { id: "2x1", ar: "عريض صغير", label: "2×1" },
  { id: "2x2", ar: "مربع متوسط", label: "2×2" },
  { id: "4x1", ar: "شريط طويل", label: "4×1" },
  { id: "4x2", ar: "مستطيل واسع", label: "4×2" },
  { id: "4x4", ar: "لوحة كبيرة", label: "4×4" },
];

export function widgetById(id: string | null): WidgetDef | undefined {
  if (!id) return undefined;
  return WIDGETS.find((w) => w.id === id);
}
