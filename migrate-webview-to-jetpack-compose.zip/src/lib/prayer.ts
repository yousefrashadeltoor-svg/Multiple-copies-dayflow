// DAYFLOW — on-device prayer engine.
// Corrects the original implementation: real IANA time zones (DST aware), Giza,
// additional Egyptian cities, selectable calculation methods, high-latitude
// fallbacks, and a true next-prayer rollover. No network is required.

export type PrayerKey = "fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha";
export type MethodId = "egypt" | "mwl" | "umm" | "isna" | "karachi" | "dubai";

export interface City {
  id: string;
  en: string;
  ar: string;
  lat: number;
  lng: number;
  tz: string;
}

export interface Method {
  id: MethodId;
  en: string;
  ar: string;
  fajrAngle: number;
  ishaAngle: number;
  ishaMinutes?: number;
  noteAr: string;
}

export const CITIES: City[] = [
  { id: "cairo", en: "Cairo", ar: "القاهرة", lat: 30.0444, lng: 31.2357, tz: "Africa/Cairo" },
  { id: "giza", en: "Giza", ar: "الجيزة", lat: 30.0131, lng: 31.2089, tz: "Africa/Cairo" },
  { id: "alexandria", en: "Alexandria", ar: "الإسكندرية", lat: 31.2001, lng: 29.9187, tz: "Africa/Cairo" },
  { id: "luxor", en: "Luxor", ar: "الأقصر", lat: 25.6872, lng: 32.6396, tz: "Africa/Cairo" },
  { id: "aswan", en: "Aswan", ar: "أسوان", lat: 24.0889, lng: 32.8998, tz: "Africa/Cairo" },
  { id: "suez", en: "Suez", ar: "السويس", lat: 29.9668, lng: 32.5498, tz: "Africa/Cairo" },
  { id: "sharm", en: "Sharm El-Sheikh", ar: "شرم الشيخ", lat: 27.9158, lng: 34.3299, tz: "Africa/Cairo" },
  { id: "mansoura", en: "Mansoura", ar: "المنصورة", lat: 31.0409, lng: 31.3785, tz: "Africa/Cairo" },
  { id: "tanta", en: "Tanta", ar: "طنطا", lat: 30.7865, lng: 31.0004, tz: "Africa/Cairo" },
  { id: "asyut", en: "Asyut", ar: "أسيوط", lat: 27.1809, lng: 31.1837, tz: "Africa/Cairo" },
  { id: "hurghada", en: "Hurghada", ar: "الغردقة", lat: 27.2579, lng: 33.8116, tz: "Africa/Cairo" },
  { id: "makkah", en: "Makkah", ar: "مكة المكرمة", lat: 21.4225, lng: 39.8262, tz: "Asia/Riyadh" },
  { id: "madinah", en: "Madinah", ar: "المدينة المنورة", lat: 24.4686, lng: 39.6142, tz: "Asia/Riyadh" },
  { id: "dubai", en: "Dubai", ar: "دبي", lat: 25.2048, lng: 55.2708, tz: "Asia/Dubai" },
  { id: "london", en: "London", ar: "لندن", lat: 51.5074, lng: -0.1278, tz: "Europe/London" },
  { id: "istanbul", en: "Istanbul", ar: "إسطنبول", lat: 41.0082, lng: 28.9784, tz: "Europe/Istanbul" },
  { id: "paris", en: "Paris", ar: "باريس", lat: 48.8566, lng: 2.3522, tz: "Europe/Paris" },
];

export const METHODS: Method[] = [
  { id: "egypt", en: "Egyptian General Survey", ar: "الهيئة المصرية العامة للمساحة", fajrAngle: 19.5, ishaAngle: 17.5, noteAr: "الطريقة المصرية الرسمية (الفجر ١٩٫٥° — العشاء ١٧٫٥°)" },
  { id: "mwl", en: "Muslim World League", ar: "رابطة العالم الإسلامي", fajrAngle: 18, ishaAngle: 17, noteAr: "رابطة العالم الإسلامي (١٨° / ١٧°)" },
  { id: "umm", en: "Umm al-Qura", ar: "أم القرى", fajrAngle: 18.5, ishaAngle: 0, ishaMinutes: 90, noteAr: "أم القرى: العشاء بعد المغرب بـ ٩٠ دقيقة" },
  { id: "isna", en: "ISNA", ar: "الجمعية الأمريكية", fajrAngle: 15, ishaAngle: 15, noteAr: "ISNA (١٥° / ١٥°)" },
  { id: "karachi", en: "University of Karachi", ar: "جامعة كراتشي", fajrAngle: 18, ishaAngle: 18, noteAr: "كراتشي (١٨° / ١٨°)" },
  { id: "dubai", en: "Dubai (UAE)", ar: "دبي (الإمارات)", fajrAngle: 18.2, ishaAngle: 18.2, noteAr: "الإمارات (١٨٫٢° / ١٨٫٢°)" },
];

export const PRAYERS: { key: PrayerKey; en: string; ar: string; icon: string; prayer: boolean }[] = [
  { key: "fajr", en: "Fajr", ar: "الفجر", icon: "🌅", prayer: true },
  { key: "sunrise", en: "Sunrise", ar: "الشروق", icon: "☀️", prayer: false },
  { key: "dhuhr", en: "Dhuhr", ar: "الظهر", icon: "🕛", prayer: true },
  { key: "asr", en: "Asr", ar: "العصر", icon: "🌤️", prayer: true },
  { key: "maghrib", en: "Maghrib", ar: "المغرب", icon: "🌇", prayer: true },
  { key: "isha", en: "Isha", ar: "العشاء", icon: "🌙", prayer: true },
];

export interface PrayerSlot {
  key: PrayerKey;
  date: Date;
  text: string;
}

export interface PrayerResult {
  city: City;
  method: Method;
  dateKey: string;
  slots: PrayerSlot[];
  times: Record<PrayerKey, PrayerSlot>;
  next: (PrayerSlot & { inMinutes: number; tomorrow: boolean }) | null;
  sunrise?: PrayerSlot;
  highLatitude: boolean;
}

const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;
const norm360 = (x: number) => ((x % 360) + 360) % 360;

/** Julian day from a civil (city) calendar date at 0h UT. */
function julianDay(y: number, m: number, d: number) {
  let yy = y;
  let mm = m;
  if (mm <= 2) { yy -= 1; mm += 12; }
  const a = Math.floor(yy / 100);
  const b = 2 - a + Math.floor(a / 4);
  return Math.floor(365.25 * (yy + 4716)) + Math.floor(30.6001 * (mm + 1)) + d + b - 1524.5;
}

const partsFmt = new Map<string, Intl.DateTimeFormat>();
function formatter(timeZone: string) {
  let f = partsFmt.get(timeZone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-GB", {
      timeZone, hour12: false, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
    partsFmt.set(timeZone, f);
  }
  return f;
}

/** Calendar date + clock of an instant in a specific IANA zone (DST aware). */
export function zonedParts(instant: Date, timeZone: string) {
  const p: Record<string, string> = {};
  for (const part of formatter(timeZone).formatToParts(instant)) if (part.type !== "literal") p[part.type] = part.value;
  return {
    year: Number(p.year), month: Number(p.month), day: Number(p.day),
    hour: Number(p.hour === "24" ? "0" : p.hour), minute: Number(p.minute), second: Number(p.second),
  };
}

/** Offset of a time zone at a given instant, in hours east of UTC. */
export function zoneOffsetHours(instant: Date, timeZone: string) {
  const p = zonedParts(instant, timeZone);
  const asUTC = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return (asUTC - Math.floor(instant.getTime() / 1000) * 1000) / 3_600_000;
}

const displayCache = new Map<string, Intl.DateTimeFormat>();
export function formatClock(date: Date, timeZone: string, seconds = false) {
  const key = timeZone + (seconds ? "s" : "");
  let f = displayCache.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat("ar-EG", {
      timeZone, hour: "numeric", minute: "2-digit", ...(seconds ? { second: "2-digit" } : {}), hour12: true,
    });
    displayCache.set(key, f);
  }
  return f.format(date).replace(/\s+/g, " ");
}

export function arabicDigits(value: string | number) {
  return String(value).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);
}

/** Always 12-hour. Accepts "HH:MM" or a Date. */
export function time12(value: string | Date, timeZone?: string, seconds = false) {
  if (value instanceof Date) return formatClock(value, timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone, seconds);
  const [hhRaw, mmRaw = "0"] = String(value).split(":");
  const hh = Number(hhRaw);
  const suffix = hh < 12 ? "ص" : "م";
  const h = hh % 12 || 12;
  return `${arabicDigits(String(h))}:${arabicDigits(String(mmRaw).padStart(2, "0"))} ${suffix}`;
}

export function time24To12(value: string) {
  const [h, m] = value.split(":").map(Number);
  return `${String(h % 12 || 12).padStart(2, "0")}:${String(m || 0).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
}

export function toMinutes(time: string) {
  const [h, m] = time.split(":").map(Number);
  return (Number.isFinite(h) ? h : 0) * 60 + (Number.isFinite(m) ? m : 0);
}

function cityCivilDate(now: Date, tz: string) {
  const p = zonedParts(now, tz);
  return { year: p.year, month: p.month, day: p.day };
}

function shiftCivil(date: { year: number; month: number; day: number }, days: number) {
  const d = new Date(Date.UTC(date.year, date.month - 1, date.day + days, 12, 0, 0));
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

function localInstant(y: number, m: number, d: number, hours: number, tz: string) {
  // First approximation, then correct by the real zone offset at that instant
  // so the result is correct across DST transitions.
  const guessUTC = Date.UTC(y, m - 1, d, 0, 0, 0) + (hours - 2) * 3_600_000;
  const offset = zoneOffsetHours(new Date(guessUTC), tz);
  return new Date(Date.UTC(y, m - 1, d, 0, 0, 0) + (hours - offset) * 3_600_000);
}

export function dayKeyInZone(instant: Date, timeZone: string) {
  const p = zonedParts(instant, timeZone);
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}

export function prayerTimes(
  city: City,
  now = new Date(),
  methodId: MethodId = "egypt",
  asrFactor: 1 | 2 = 1,
): PrayerResult {
  const method = METHODS.find((m) => m.id === methodId) || METHODS[0];
  const civil = cityCivilDate(now, city.tz);
  const jd = julianDay(civil.year, civil.month, civil.day);
  const d = jd - 2451545.0;
  const g = rad(norm360(357.529 + 0.98560028 * d));
  const q = 280.459 + 0.98564736 * d;
  const L = rad(norm360(q + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)));
  const e = rad(23.439 - 0.00000036 * d);
  const RA = deg(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15;
  const decl = Math.asin(Math.sin(e) * Math.sin(L));
  const eqt = q / 15 - (((RA % 24) + 24) % 24);
  const noonProbe = localInstant(civil.year, civil.month, civil.day, 12, city.tz);
  const tzOffset = zoneOffsetHours(noonProbe, city.tz);
  const midDay = 12 - eqt - city.lng / 15 + tzOffset;

  const hourAngle = (altitude: number) => {
    const cosH =
      (Math.sin(rad(altitude)) - Math.sin(rad(city.lat)) * Math.sin(decl)) /
      (Math.cos(rad(city.lat)) * Math.cos(decl));
    if (cosH > 1 || cosH < -1) return null;
    return deg(Math.acos(cosH)) / 15;
  };

  const sunriseHA = hourAngle(-0.833);
  const sunsetHA = sunriseHA;
  let highLatitude = false;
  const at = (altitude: number, before: boolean, fallback?: number): number => {
    const ha = hourAngle(altitude);
    if (ha === null) { highLatitude = true; return fallback ?? midDay; }
    return midDay + (before ? -ha : ha);
  };

  let fajr = at(method.fajrAngle, true);
  let isha = method.ishaMinutes ? undefined : at(method.ishaAngle, false);
  let maghrib = sunsetHA === null ? midDay + 6 : midDay + sunsetHA;
  let sunrise = sunriseHA === null ? midDay - 6 : midDay - sunriseHA;

  // High-latitude night-portion rule (also used in polar summer).
  if (highLatitude) {
    const night = sunriseHA === null || sunsetHA === null ? 8 : 2 * sunsetHA;
    highLatitude = true;
    if (hourAngle(method.fajrAngle) === null) fajr = sunrise - night / 5;
    if (!method.ishaMinutes && hourAngle(method.ishaAngle) === null) isha = maghrib + night / 5;
  }

  const asrAlt = deg(Math.atan(1 / (asrFactor + Math.tan(Math.abs(rad(city.lat) - decl)))));
  const asr = at(asrAlt, false, midDay + 3.5);
  if (method.ishaMinutes) isha = maghrib + method.ishaMinutes / 60;

  const toHours = (value: number) => ((value % 24) + 24) % 24;
  const values: Record<PrayerKey, number> = {
    fajr: toHours(fajr), sunrise: toHours(sunrise), dhuhr: toHours(midDay),
    asr: toHours(asr), maghrib: toHours(maghrib), isha: toHours(isha as number),
  };

  const slots: PrayerSlot[] = PRAYERS.map((p) => {
    const date = localInstant(civil.year, civil.month, civil.day, values[p.key], city.tz);
    return { key: p.key, date, text: formatClock(date, city.tz) };
  });
  const times = Object.fromEntries(slots.map((s) => [s.key, s])) as Record<PrayerKey, PrayerSlot>;

  let next: PrayerResult["next"] = null;
  for (const slot of slots) {
    if (slot.key !== "sunrise" && slot.date.getTime() > now.getTime()) {
      next = { ...slot, inMinutes: Math.max(0, Math.round((slot.date.getTime() - now.getTime()) / 60000)), tomorrow: false };
      break;
    }
  }
  if (!next) {
    const tomorrowCivil = shiftCivil(civil, 1);
    const tomorrowJd = julianDay(tomorrowCivil.year, tomorrowCivil.month, tomorrowCivil.day);
    const dd = tomorrowJd - 2451545.0;
    const gg = rad(norm360(357.529 + 0.98560028 * dd));
    const qq = 280.459 + 0.98564736 * dd;
    const LL = rad(norm360(qq + 1.915 * Math.sin(gg) + 0.02 * Math.sin(2 * gg)));
    const ee = rad(23.439 - 0.00000036 * dd);
    const RA2 = deg(Math.atan2(Math.cos(ee) * Math.sin(LL), Math.cos(LL))) / 15;
    const decl2 = Math.asin(Math.sin(ee) * Math.sin(LL));
    const eqt2 = qq / 15 - (((RA2 % 24) + 24) % 24);
    const probe = localInstant(tomorrowCivil.year, tomorrowCivil.month, tomorrowCivil.day, 12, city.tz);
    const off2 = zoneOffsetHours(probe, city.tz);
    const noon2 = 12 - eqt2 - city.lng / 15 + off2;
    const cosH = (Math.sin(rad(method.fajrAngle)) - Math.sin(rad(city.lat)) * Math.sin(decl2)) /
      (Math.cos(rad(city.lat)) * Math.cos(decl2));
    const ha = cosH > 1 || cosH < -1 ? 1.6 : deg(Math.acos(cosH)) / 15;
    const fajrTomorrow = localInstant(tomorrowCivil.year, tomorrowCivil.month, tomorrowCivil.day, noon2 - ha, city.tz);
    next = {
      key: "fajr", date: fajrTomorrow, text: formatClock(fajrTomorrow, city.tz),
      inMinutes: Math.max(0, Math.round((fajrTomorrow.getTime() - now.getTime()) / 60000)), tomorrow: true,
    };
  }

  return {
    city, method, dateKey: `${civil.year}-${String(civil.month).padStart(2, "0")}-${String(civil.day).padStart(2, "0")}`,
    slots, times, next, sunrise: times.sunrise, highLatitude,
  };
}

export function qiblaDirection(lat: number, lng: number) {
  const kaabaLat = rad(21.4225);
  const kaabaLng = rad(39.8262);
  const phi = rad(lat);
  const dLng = kaabaLng - rad(lng);
  const y = Math.sin(dLng);
  const x = Math.cos(phi) * Math.tan(kaabaLat) - Math.sin(phi) * Math.cos(dLng);
  return (deg(Math.atan2(y, x)) + 360) % 360;
}

export function durationText(minutes: number) {
  const m = Math.max(0, Math.round(minutes));
  const h = Math.floor(m / 60);
  if (h <= 0) return `${arabicDigits(m)} دقيقة`;
  return `${arabicDigits(h)} س ${arabicDigits(m % 60)} د`;
}
