import type { SVGProps } from "react";

export type IconName =
  | "sun" | "calendar" | "alarm" | "grid" | "sparkles" | "download" | "user" | "plus"
  | "bell" | "check" | "x" | "chevron-left" | "chevron-right" | "droplet" | "heart"
  | "settings" | "trash" | "play" | "pause" | "edit" | "copy" | "link" | "clock"
  | "moon" | "star" | "smartphone" | "widget" | "external" | "send" | "clipboard"
  | "shield" | "volume" | "vibrate" | "compass" | "share" | "home" | "more"
  | "book" | "timer" | "refresh" | "location" | "arrow-left" | "eye-off" | "bot"
  | "layers" | "languages" | "info" | "alert" | "check-circle" | "zap" | "image"
  | "music" | "file" | "grip" | "chevron-down" | "sparkle" | "list" | "chart"
  | "focus" | "flag" | "maximize" | "minimize" | "wifi" | "lock";

const P: Record<IconName, React.ReactNode> = {
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
  calendar: <><rect x="3" y="4.5" width="18" height="16" rx="3" /><path d="M8 2.5v4M16 2.5v4M3 9.5h18" /><path d="M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01" /></>,
  alarm: <><circle cx="12" cy="13" r="7.5" /><path d="M12 9.5V13l2.4 1.5M5 3.5 2.5 6M19 3.5 21.5 6M7 21l-1.5 1.5M17 21l1.5 1.5" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
  sparkles: <><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8Z" /><path d="M18.5 15.5 19.5 18l2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1Z" /></>,
  download: <><path d="M12 3v12M7 10l5 5 5-5" /><path d="M4 19.5h16" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4.5 21c.6-4.2 3.4-6.5 7.5-6.5s6.9 2.3 7.5 6.5" /></>,
  plus: <path d="M12 5v14M5 12h14" />,
  bell: <><path d="M18 9a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7" /><path d="M10 20a2.2 2.2 0 0 0 4 0" /></>,
  check: <path d="m4.5 12.5 5 5L20 6.5" />,
  x: <path d="M6 6l12 12M18 6 6 18" />,
  "chevron-left": <path d="m15 5-7 7 7 7" />,
  "chevron-right": <path d="m9 5 7 7-7 7" />,
  "chevron-down": <path d="m5 9 7 7 7-7" />,
  droplet: <path d="M12 3.5S5.5 10 5.5 14.2A6.5 6.5 0 0 0 12 21a6.5 6.5 0 0 0 6.5-6.8C18.5 10 12 3.5 12 3.5Z" />,
  heart: <path d="M12 20.5S3.5 15 3.5 9.3A4.6 4.6 0 0 1 12 6.2a4.6 4.6 0 0 1 8.5 3.1c0 5.7-8.5 11.2-8.5 11.2Z" />,
  settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.36a1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.1-1.55 1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.54 15a1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.64 9a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.64h.08a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.36 9v.08a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51 1Z" /></>,
  trash: <><path d="M4 7h16M9 7V4.5h6V7M6 7l1 13.5h10L18 7" /><path d="M10 11v6M14 11v6" /></>,
  play: <path d="M7 4.5 20 12 7 19.5Z" />,
  pause: <><path d="M8 5v14M16 5v14" /></>,
  edit: <><path d="M4 20h4L19.5 8.5a2.8 2.8 0 0 0-4-4L4 16Z" /><path d="m14 6 4 4" /></>,
  copy: <><rect x="9" y="9" width="12" height="12" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></>,
  link: <><path d="M10 13a4 4 0 0 0 6 .5l2-2a4.2 4.2 0 0 0-6-6l-1.2 1.2" /><path d="M14 11a4 4 0 0 0-6-.5l-2 2a4.2 4.2 0 0 0 6 6l1.2-1.2" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5.5l3.5 2" /></>,
  moon: <path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5Z" />,
  star: <><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9Z" /><path d="m18.8 17.2 1 3.3M5.2 17.2l-1 3.3" /></>,
  smartphone: <><rect x="6" y="2.5" width="12" height="19" rx="3" /><path d="M10.5 19h3" /></>,
  widget: <><rect x="3" y="3" width="8" height="8" rx="2" /><rect x="13" y="3" width="8" height="5" rx="2" /><rect x="13" y="10" width="8" height="11" rx="2" /><rect x="3" y="13" width="8" height="8" rx="2" /></>,
  external: <><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 14v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4" /></>,
  send: <><path d="m21 3-7.5 18-3-7.5L3 10.5Z" /><path d="M10.5 13.5 21 3" /></>,
  clipboard: <><rect x="5" y="4" width="14" height="17" rx="2" /><path d="M9 4V2.5h6V4M9 10h6M9 14h6M9 18h4" /></>,
  shield: <><path d="M12 2.5 20 6v6c0 4.8-3.4 8.2-8 9.5C7.4 20.2 4 16.8 4 12V6Z" /><path d="m8.5 12 2.4 2.4 4.6-4.8" /></>,
  volume: <><path d="M11 5 6.5 9H3v6h3.5L11 19Z" /><path d="M15 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12" /></>,
  vibrate: <><rect x="8" y="4" width="8" height="16" rx="2" /><path d="M4 8v8M20 8v8M2 10v4M22 10v4" /></>,
  compass: <><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2 5-5 2 2-5Z" /></>,
  share: <><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="m8.6 10.5 6.8-4M8.6 13.5l6.8 4" /></>,
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 9.5V21h14V9.5" /><path d="M9.5 21v-6h5v6" /></>,
  more: <><circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" /></>,
  book: <><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5Z" /><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /></>,
  timer: <><circle cx="12" cy="13.5" r="8" /><path d="M12 9.5v4l2.5 1.5M9 2.5h6" /></>,
  refresh: <><path d="M20 11a8 8 0 0 0-14-4.5L3 9" /><path d="M4 13a8 8 0 0 0 14 4.5L21 15" /><path d="M3 4v5h5M21 20v-5h-5" /></>,
  location: <><path d="M20 10.5c0 6-8 11-8 11s-8-5-8-11a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10.5" r="2.7" /></>,
  "arrow-left": <path d="M20 12H4M10 6l-6 6 6 6" />,
  "eye-off": <><path d="m3 3 18 18" /><path d="M10.6 10.7a2 2 0 0 0 2.7 2.7" /><path d="M9.9 5.2A10 10 0 0 1 12 5c5.5 0 9 5.5 9 7 0 .7-.5 1.7-1.4 2.8M6.2 6.3C4 8 3 10.1 3 12c0 1.5 3.5 7 9 7a9 9 0 0 0 3.9-.9" /></>,
  bot: <><rect x="4" y="7" width="16" height="12" rx="4" /><path d="M12 3v4M9 12h.01M15 12h.01M9 16h6" /><path d="M2 11v3M22 11v3" /></>,
  layers: <><path d="m12 3 9 5-9 5-9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>,
  languages: <><path d="M4 5h9M8.5 3v2c0 4-2 7-5 8.5" /><path d="M6 9.5c1.4 2.4 3.4 4 6 5" /><path d="m13 21 4.2-10L21 21M14.6 17h5" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  alert: <><path d="M12 3 2.5 20.5h19Z" /><path d="M12 9v5M12 17.5h.01" /></>,
  "check-circle": <><circle cx="12" cy="12" r="9" /><path d="m8 12 2.5 2.5L16 9" /></>,
  zap: <path d="M13 2 4.5 14H11l-1 8 9-12.5H12Z" />,
  image: <><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="8.5" cy="9.5" r="1.8" /><path d="m4 17 5-5 4.5 4.5L17 13l3 3" /></>,
  music: <><path d="M9 18V6l11-2v12" /><circle cx="6" cy="18" r="3" /><circle cx="17" cy="16" r="3" /></>,
  file: <><path d="M14 2.5H6.5a2 2 0 0 0-2 2v15a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V8Z" /><path d="M14 2.5V8h5" /></>,
  grip: <><circle cx="9" cy="6" r="1.4" /><circle cx="15" cy="6" r="1.4" /><circle cx="9" cy="12" r="1.4" /><circle cx="15" cy="12" r="1.4" /><circle cx="9" cy="18" r="1.4" /><circle cx="15" cy="18" r="1.4" /></>,
  sparkle: <path d="m12 3 1.6 4.9L18.5 9.5l-4.9 1.6L12 16l-1.6-4.9L5.5 9.5l4.9-1.6Z" />,
  list: <><path d="M8 6h13M8 12h13M8 18h13" /><path d="M3.5 6h.01M3.5 12h.01M3.5 18h.01" /></>,
  chart: <><path d="M4 20V9M10 20V4M16 20v-7M22 20H2" /></>,
  focus: <><circle cx="12" cy="12" r="3" /><path d="M3 8V5a2 2 0 0 1 2-2h3M16 3h3a2 2 0 0 1 2 2v3M21 16v3a2 2 0 0 1-2 2h-3M8 21H5a2 2 0 0 1-2-2v-3" /></>,
  flag: <><path d="M5 21V3.5M5 4h11l-1.5 4.5L16 13H5" /></>,
  maximize: <><path d="M8 3H3v5M16 3h5v5M21 16v5h-5M3 16v5h5" /></>,
  minimize: <><path d="M8 3v5H3M16 3v5h5M21 16h-5v5M3 16h5v5" /></>,
  wifi: <><path d="M3 9a15 15 0 0 1 18 0M6 12.5a10.5 10.5 0 0 1 12 0M9.5 16a5.5 5.5 0 0 1 5 0" /><circle cx="12" cy="19.5" r="1" /></>,
  lock: <><rect x="4" y="10" width="16" height="11" rx="3" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
};

export function Icon({
  name, size = 20, strokeWidth = 1.9, filled = false, className, ...rest
}: { name: IconName; size?: number; strokeWidth?: number; filled?: boolean } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24" width={size} height={size} fill={filled ? "currentColor" : "none"}
      stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      aria-hidden className={className} {...rest}
    >
      {P[name]}
    </svg>
  );
}
