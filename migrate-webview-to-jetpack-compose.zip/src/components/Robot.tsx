import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import { articles } from "../lib/companion";
import { actions, greeting, seasonFor, useDayflow, type DecorFamily } from "../lib/data";

export function useNow(interval = 30_000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), interval);
    return () => window.clearInterval(id);
  }, [interval]);
  return now;
}

function Outfit({ family, mood }: { family: DecorFamily; mood: string }) {
  if (family === "ramadan" || family === "islamic") {
    return (
      <g>
        <path d="M92 92v10" stroke="#b08a3e" strokeWidth="1.6" />
        <path d="M82 100h20l-3 5H85Z" fill="#d5b56d" />
        <rect x="84" y="104" width="16" height="17" rx="4" fill="#d5b56d" />
        <rect x="88" y="108" width="8" height="9" rx="2" fill="#ffedb9" />
        <path d="M86 121h12l-2 4h-8Z" fill="#b08a3e" />
        <path d="M92 125v5" stroke="#b08a3e" strokeWidth="1.6" />
        <circle cx="92" cy="106" r="2.2" fill="#ffe8a8" className="twinkle" />
      </g>
    );
  }
  if (family === "winter") {
    return (
      <g>
        <path d="M42 66q18 10 36 0l4 13q-22 10-44 0Z" fill="#b34a3f" stroke="#8e352d" strokeWidth=".8" />
        <path d="M74 80l7 27h-9Z" fill="#b34a3f" />
      </g>
    );
  }
  if (family === "spring") {
    return <g><path d="M84 30q7-7 14 0-7 7-14 0Z" fill="#e7b7a9" /><circle cx="91" cy="29" r="2.2" fill="#c9a24a" /><path d="M86 33q-3 8 2 12" stroke="#5c8a6b" strokeWidth="1.4" fill="none" /></g>;
  }
  if (family === "national") {
    return <g><path d="M42 74 80 98" stroke="#ce1126" strokeWidth="4.5" /><path d="M42 79 80 102" stroke="#fff" strokeWidth="4" /><path d="M42 84 78 106" stroke="#1d1c1a" strokeWidth="4" /></g>;
  }
  if (family === "autumn") {
    return <g><path d="M92 26q9 4 6 11-8 2-10-6Z" fill="#c79a63" /><path d="M93 34q-2 8-8 9" stroke="#8c5b3a" strokeWidth="1.2" fill="none" /></g>;
  }
  if (family === "summer") {
    return <g><path d="M91 25q8-4 12 2-4 7-12 4Z" fill="#8fbfc0" opacity=".85" /></g>;
  }
  if (family === "eid" || mood === "celebrate") {
    return <g><path d="M52 22 60 0l8 22Z" fill="#d5b56d" stroke="#a67c22" /><circle cx="60" cy="0" r="2.5" fill="#c9a24a" /></g>;
  }
  return null;
}

export function RobotArt({ size = 86, family = "friday" as DecorFamily, mood = "idle", opacity = 1 }: { size?: number; family?: DecorFamily; mood?: string; opacity?: number }) {
  const sleeping = mood === "sleep";
  const eyeY = 41 + (mood === "think" ? -2 : 0);
  return (
    <svg viewBox="0 0 120 150" width={size} height={size * 1.18} aria-hidden style={{ opacity, overflow: "visible" }}>
      <defs>
        <radialGradient id="rb-body" cx="35%" cy="30%" r="80%"><stop offset="0" stopColor="#ffffff" /><stop offset=".55" stopColor={mood === "cold" ? "#cfe3f5" : "#d9e2ee"} /><stop offset="1" stopColor="#8d9bb0" /></radialGradient>
        <radialGradient id="rb-visor" cx="40%" cy="30%" r="90%"><stop offset="0" stopColor={mood === "sad" ? "#3d3a52" : "#3a4a66"} /><stop offset="1" stopColor="#0d1424" /></radialGradient>
        <linearGradient id="rb-limb" x1="0" x2="1"><stop offset="0" stopColor="#c3cddb" /><stop offset="1" stopColor="#7d8aa0" /></linearGradient>
      </defs>
      <ellipse cx="60" cy="142" rx="27" ry="4.5" fill="#000" opacity=".13" />
      {mood === "celebrate" && <g fill="#c9a24a">{[0, 1, 2, 3].map((i) => <circle key={i} className="twinkle" style={{ animationDelay: `${i * 0.2}s` }} cx={16 + i * 26} cy={10 + (i % 2) * 7} r={2.2} />)}</g>}
      <path d="M47 112v22M73 112v22" fill="none" stroke="url(#rb-limb)" strokeWidth="9" strokeLinecap="round" />
      <path d="M34 78 24 97 21 113" fill="none" stroke="url(#rb-limb)" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M86 78 96 97 100 111" fill="none" stroke="url(#rb-limb)" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="21" cy="113" r="5.5" fill="#e7edf5" stroke="#8d9bb0" /><circle cx="100" cy="111" r="5.5" fill="#e7edf5" stroke="#8d9bb0" />
      <rect x="34" y="66" width="52" height="56" rx="18" fill="url(#rb-body)" stroke="#7f8ca2" />
      <rect x="47" y="80" width="26" height="16" rx="5" fill="#0f1a2c" /><circle cx="60" cy="88" r="4" fill="#2f6f5e" className="twinkle" />
      <path d="M50 22 44 10 40 0M70 22l6-12 4-10" fill="none" stroke="#7d8aa0" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="40" cy="0" r="4" fill="#c9a24a" className={mood === "think" ? "twinkle" : ""} /><circle cx="80" cy="0" r="4" fill="#c9a24a" />
      <rect x="30" y="20" width="60" height="46" rx="20" fill="url(#rb-body)" stroke="#7f8ca2" />
      <rect x="37" y="29" width="46" height="28" rx="13" fill="url(#rb-visor)" />
      {sleeping ? (
        <g stroke="#7fd6ff" strokeWidth="2.5" fill="none" strokeLinecap="round"><path d="M46 44q4 3 8 0" /><path d="M66 44q4 3 8 0" /></g>
      ) : mood === "happy" || mood === "celebrate" ? (
        <g stroke="#7fd6ff" strokeWidth="2.8" fill="none" strokeLinecap="round"><path d="M46 46q4-5 8 0" /><path d="M66 46q4-5 8 0" /></g>
      ) : mood === "sad" ? (
        <g stroke="#7fd6ff" strokeWidth="2.5" fill="none" strokeLinecap="round"><path d="M46 46q4-3 8 0" /><path d="M66 46q4-3 8 0" /></g>
      ) : (
        <g fill="#7fd6ff"><ellipse cx="50" cy={eyeY} rx="4" ry="5" className="twinkle" /><ellipse cx="70" cy={eyeY} rx="4" ry="5" className="twinkle" /></g>
      )}
      {mood === "happy" && <g fill="#ff9ab5" opacity=".6"><ellipse cx="43" cy="53" rx="4" ry="2.2" /><ellipse cx="77" cy="53" rx="4" ry="2.2" /></g>}
      {mood === "think" && <g fill="#c9a24a"><circle cx="94" cy="34" r="2" className="twinkle" /><circle cx="99" cy="29" r="1.4" className="twinkle" style={{ animationDelay: ".4s" }} /></g>}
      <ellipse cx="44" cy="27" rx="8" ry="3" fill="#fff" opacity=".7" />
      <Outfit family={family} mood={mood} />
    </svg>
  );
}

export function Companion({ onGo }: { onGo: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const now = useNow(60_000);
  const family = seasonFor(now).id;
  const cfg = s.companion;
  const size = 78 * cfg.size;
  const [panel, setPanel] = useState(false);
  const [bubble, setBubble] = useState<string | null>(null);
  const bubbleIndex = useRef(0);
  const dragRef = useRef<{ startX: number; startY: number; baseX: number; baseY: number; moved: boolean } | null>(null);
  const posRef = useRef({ x: 14, y: 0 });
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const place = () => {
      if (!wrapRef.current) return;
      if (!posRef.current.y) posRef.current.y = Math.max(80, window.innerHeight - size * 1.5 - 120);
      if (posRef.current.x + size > window.innerWidth - 8) posRef.current.x = Math.max(8, window.innerWidth - size - 14);
      if (posRef.current.y + size * 1.3 > window.innerHeight - 70) posRef.current.y = Math.max(70, window.innerHeight - size * 1.3 - 78);
      wrapRef.current.style.transform = `translate3d(${posRef.current.x}px, ${posRef.current.y}px, 0)`;
    };
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, [size, cfg.overlayDemo]);

  useEffect(() => {
    if (!cfg.bubbles || cfg.hidden || !cfg.enabled) return;
    let hideTimer = 0;
    const show = () => {
      const lines = articles(s, now, family);
      const line = lines[bubbleIndex.current % lines.length];
      bubbleIndex.current += 1;
      setBubble(line);
      hideTimer = window.setTimeout(() => setBubble((b) => (b === line ? null : b)), 8000);
    };
    const hello = window.setTimeout(show, 4000);
    const id = window.setInterval(show, 30000);
    return () => { window.clearInterval(id); window.clearTimeout(hello); window.clearTimeout(hideTimer); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cfg.bubbles, cfg.hidden, cfg.enabled, family]);

  if (!cfg.enabled || cfg.hidden) return null;

  const onPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest("[data-no-drag]")) return;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragRef.current = { startX: e.clientX, startY: e.clientY, baseX: posRef.current.x, baseY: posRef.current.y, moved: false };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d || !wrapRef.current) return;
    const dx = e.clientX - d.startX;
    const dy = e.clientY - d.startY;
    if (Math.abs(dx) + Math.abs(dy) > 6) d.moved = true;
    const x = Math.max(4, Math.min(window.innerWidth - size - 6, d.baseX + dx));
    const y = Math.max(6, Math.min(window.innerHeight - size * 1.2 - 76, d.baseY + dy));
    posRef.current = { x, y };
    wrapRef.current.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  };
  const onPointerUp = () => {
    const moved = dragRef.current?.moved;
    dragRef.current = null;
    if (!moved) setPanel((p) => !p);
  };

  return (
    <div className={cfg.overlayDemo ? "robot-overlay-mode" : ""} dir="rtl">
      {cfg.overlayDemo && (
        <div className="absolute inset-x-3 top-3 z-[72] flex items-center gap-2 rounded-2xl px-3 py-2.5 text-[11.5px] font-bold shadow-lg" style={{ background: "rgba(255,253,248,.94)", border: "1px solid var(--line)" }}>
          <Icon name="smartphone" size={15} className="accent" />
          <span className="flex-1">معاينة وضع «فوق التطبيقات» — في أندرويد يعمل الرفيق فوق الهاتف كله.</span>
          <button data-no-drag onClick={() => actions.setCompanion({ overlayDemo: false })} className="chip">إنهاء</button>
        </div>
      )}
      <div
        ref={wrapRef}
        className="robot-wrap"
        style={{ opacity: cfg.opacity, left: 0, top: 0, zIndex: cfg.overlayDemo ? 75 : 45 }}
        onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp}
      >
        {panel && (
          <div data-no-drag className="absolute bottom-[calc(100%+6px)] start-0 z-[4] w-[224px] overflow-hidden rounded-2xl p-1.5 shadow-xl" style={{ background: "var(--surface)", border: "1px solid var(--line)" }} dir="rtl">
            <p className="px-2.5 py-2 text-[10.5px] font-bold muted">{greeting(now)} · أنا رفيقك 🌿</p>
            {[
              { icon: "plus" as const, label: "أضف مهمة للنهاردة", run: () => { actions.addTask("مهمة جديدة من الرفيق"); onGo("today"); } },
              { icon: "alarm" as const, label: "المنبهات", run: () => onGo("alarms") },
              { icon: "sparkles" as const, label: "الذكاء والرفيق", run: () => onGo("ai") },
              { icon: "widget" as const, label: "الودجتس", run: () => onGo("tools", "widgets") },
              { icon: "maximize" as const, label: cfg.overlayDemo ? "الخروج من وضع الهاتف" : "فوق كل التطبيقات", run: () => actions.setCompanion({ overlayDemo: !cfg.overlayDemo }) },
            ].map((item) => (
              <button key={item.label} onClick={() => { item.run(); setPanel(false); }} className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-start text-[12px] font-semibold hover:bg-black/5">
                <Icon name={item.icon} size={15} className="accent" />{item.label}
              </button>
            ))}
            <button onClick={() => { actions.setCompanion({ hidden: true }); setPanel(false); }} className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-start text-[12px] font-semibold" style={{ color: "#9a3f28" }}>
              <Icon name="eye-off" size={15} />إخفاء الرفيق
            </button>
            {cfg.overlayDemo && <p className="px-2.5 pb-2 pt-1 text-[10px] leading-relaxed muted">في نسخة الويب دي معاينة فقط. نسخة أندرويد الأصلية تعرض الرفيق فوق أي تطبيق عبر Overlay system permission.</p>}
          </div>
        )}
        {bubble && !panel && (
          <button data-no-drag onClick={() => { setPanel(true); setBubble(null); }} className="robot-bubble text-start" style={{ animation: "fade-in 300ms ease" }}>
            {bubble}
            <span className="mt-1 block text-[10px] font-bold accent">اسمعني ←</span>
          </button>
        )}
        <div className={s.reduceMotion ? "" : "float"} style={{ filter: "drop-shadow(0 12px 14px rgba(20,30,25,.18))" }} aria-label="رفيق DAYFLOW — اسحبني أو اضغطني">
          <div className="relative" style={{ width: size, height: size * 1.18 }}>
            <RobotArt size={size} family={family} mood={cfg.emotion} opacity={cfg.opacity} />
            <span className="absolute -bottom-1 start-1/2 -translate-x-1/2 rounded-full px-2 py-[1px] text-[8.5px] font-bold" style={{ background: "rgba(255,253,248,.92)", color: "var(--accent)", border: "1px solid var(--line)" }}>DAYFLOW</span>
          </div>
        </div>
      </div>
    </div>
  );
}
