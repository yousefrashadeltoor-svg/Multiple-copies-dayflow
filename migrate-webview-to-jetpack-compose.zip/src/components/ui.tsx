import { useEffect, useId, useRef, useState, type ReactNode } from "react";
import { Icon, type IconName } from "./icons";
import { FAMILY_STYLES, type DecorFamily } from "../lib/data";

export function cx(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}

/* ------------------------------------------------------------------ */
/* Seasonal art — real photographic ornaments + layered SVG            */
/* ------------------------------------------------------------------ */

const ORNAMENT_IMAGES: Partial<Record<DecorFamily, string>> = {
  spring: "/images/ornament-blossom.png",
  eid: "/images/ornament-blossom.png",
  autumn: "/images/ornament-autumn.png",
  ramadan: "/images/ornament-lantern.png",
  islamic: "/images/ornament-lantern.png",
};

export function Ornament({ family, size = 96, className, rotate = 0, flip = false }: { family: DecorFamily; size?: number; className?: string; rotate?: number; flip?: boolean }) {
  const st = FAMILY_STYLES[family];
  const gid = useId().replace(/:/g, "");
  const img = ORNAMENT_IMAGES[family];
  if (img) {
    return (
      <img
        src={img} alt="" aria-hidden draggable={false}
        width={size} height={size}
        className={cx("ornament-img select-none", className)}
        style={{ transform: `rotate(${rotate}deg) ${flip ? "scaleX(-1)" : ""}`, width: size, height: size, objectFit: "contain" }}
      />
    );
  }
  return (
    <svg viewBox="0 0 120 120" width={size} height={size} aria-hidden className={cx("ornament-img", className)} style={{ transform: `rotate(${rotate}deg) ${flip ? "scaleX(-1)" : ""}` }}>
      <defs>
        <radialGradient id={`o-${gid}`} cx="35%" cy="28%" r="80%">
          <stop offset="0" stopColor="#fff" stopOpacity=".95" />
          <stop offset=".5" stopColor={st.c2} stopOpacity=".9" />
          <stop offset="1" stopColor={st.c1} stopOpacity=".85" />
        </radialGradient>
        <linearGradient id={`l-${gid}`} x1="0" x2="1">
          <stop offset="0" stopColor={st.c1} /><stop offset="1" stopColor={st.c3} />
        </linearGradient>
      </defs>
      {st.motif === "snow" && (
        <g stroke={`url(#l-${gid})`} strokeWidth="2.2" strokeLinecap="round" fill="none">
          {[0, 30, 60, 90, 120, 150].map((deg) => (
            <g key={deg} transform={`rotate(${deg} 60 60)`}>
              <path d="M60 10v100" opacity=".8" />
              <path d="M60 24l-9 -9M60 24l9 -9M60 92l-9 9M60 92l9 9" />
            </g>
          ))}
          <circle cx="60" cy="60" r="5" fill={st.c3} stroke="none" />
        </g>
      )}
      {st.motif === "sun" && (
        <>
          <circle cx="60" cy="60" r="22" fill={`url(#o-${gid})`} />
          {Array.from({ length: 12 }).map((_, i) => (
            <path key={i} d="M60 28V12" stroke={st.c2} strokeWidth="3" strokeLinecap="round" opacity={0.4 + (i % 3) * 0.2} transform={`rotate(${i * 30} 60 60)`} />
          ))}
          <path d="M18 92c18-20 35-12 44-25 10 14 24 4 40 24" fill="none" stroke={st.c1} strokeWidth="3" opacity=".65" />
        </>
      )}
      {st.motif === "star" && (
        <g fill="none" stroke={`url(#l-${gid})`} strokeWidth="1.6">
          {[0, 45].map((r) => <rect key={r} x="28" y="28" width="64" height="64" rx="4" transform={`rotate(${r} 60 60)`} />)}
          <circle cx="60" cy="60" r="32" />
          <circle cx="60" cy="60" r="18" fill={`url(#o-${gid})`} opacity=".85" />
          <path d="M60 6v20M60 94v20M6 60h20M94 60h20" strokeLinecap="round" opacity=".6" />
        </g>
      )}
      {(st.motif === "blossom" || st.motif === "leaves") && (
        <g>
          <path d="M28 92C42 64 60 42 92 26" stroke={st.c1} strokeWidth="2.5" fill="none" opacity=".75" />
          {[0, 1, 2, 3, 4].map((i) => (
            <ellipse key={i} cx={42 + i * 11} cy={76 - i * 11} rx="9" ry="5" fill={`url(#o-${gid})`} transform={`rotate(${-30 + i * 18} ${42 + i * 11} ${76 - i * 11})`} />
          ))}
        </g>
      )}
      {st.motif === "lantern" && (
        <g>
          <path d="M60 4v14" stroke={st.c3} strokeWidth="2" />
          <path d="M38 34h44l-6-12H44Z" fill={`url(#l-${gid})`} />
          <rect x="34" y="34" width="52" height="52" rx="12" fill={`url(#l-${gid})`} opacity=".92" />
          <rect x="43" y="43" width="34" height="34" rx="7" fill="#ffe6a4" opacity=".8" />
          <path d="M44 86h32l-6 12H50Z" fill={`url(#l-${gid})`} />
          <path d="M60 98v14" stroke={st.c3} strokeWidth="2.5" />
          <g stroke={st.c1} strokeWidth=".8" opacity=".55" fill="none">
            <path d="m50 56 10-8 10 8-10 12Z" /><circle cx="60" cy="60" r="9" />
          </g>
        </g>
      )}
      {st.motif === "crescent" && (
        <g>
          <path d="M76 16a42 42 0 1 0 0 88 35 35 0 0 1 0-88Z" fill={`url(#o-${gid})`} />
          <path d="m86 38 3.5 7.2 8 1.2-5.8 5.6 1.4 8-7.1-3.8-7.1 3.8 1.4-8-5.8-5.6 8-1.2Z" fill={st.c3} />
        </g>
      )}
      {st.motif === "flag" && (
        <g>
          <path d="M60 8v104" stroke={st.c1} strokeWidth="3" strokeLinecap="round" />
          <path d="M63 16c14 9 25 5 38 10-8 8-27 3-38-2Z" fill="#ce1126" />
          <path d="M63 31c14 9 25 5 38 10-8 8-27 3-38-2Z" fill="#f4efe2" stroke="#d8d1bf" />
          <path d="M63 46c14 9 25 5 38 10-8 8-27 3-38-2Z" fill="#1d1c1a" opacity=".85" />
        </g>
      )}
    </svg>
  );
}

export function HeaderCrown({ family, height = 54 }: { family: DecorFamily; height?: number }) {
  const st = FAMILY_STYLES[family];
  const gid = useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 400 70" width="100%" height={height} preserveAspectRatio="none" aria-hidden>
      <defs>
        <linearGradient id={`hc-${gid}`} x1="0" x2="1">
          <stop offset="0" stopColor={st.c1} stopOpacity=".2" /><stop offset=".5" stopColor={st.c3} stopOpacity=".8" /><stop offset="1" stopColor={st.c1} stopOpacity=".2" />
        </linearGradient>
      </defs>
      <path d="M0 18C70 54 120 4 200 12s130 42 200 6" fill="none" stroke={`url(#hc-${gid})`} strokeWidth="1.4" />
      <path d="M0 26C80 60 130 12 200 20s120 38 200 4" fill="none" stroke={`url(#hc-${gid})`} strokeWidth=".8" opacity=".7" />
      {[48, 84, 120, 280, 316, 352].map((x, i) => (
        <g key={x} opacity={0.85}>
          <path d={`M${x} 4v${12 + (i % 3) * 7}`} stroke={st.c3} strokeWidth=".9" />
          <circle cx={x} cy={22 + (i % 3) * 7} r={2 + (i % 2)} fill={st.c3} opacity=".8" />
        </g>
      ))}
    </svg>
  );
}

export function RobotMini({ size = 54, family = "friday" as DecorFamily, mood = "idle" }: { size?: number; family?: DecorFamily; mood?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 120 140" aria-hidden>
      <defs>
        <radialGradient id="rm-body" cx="35%" cy="30%" r="80%"><stop offset="0" stopColor="#fff" /><stop offset=".55" stopColor="#d9e2ee" /><stop offset="1" stopColor="#8d9bb0" /></radialGradient>
        <radialGradient id="rm-visor" cx="40%" cy="30%" r="90%"><stop offset="0" stopColor="#3a4a66" /><stop offset="1" stopColor="#0d1424" /></radialGradient>
      </defs>
      <ellipse cx="60" cy="132" rx="24" ry="4" fill="#000" opacity=".12" />
      <path d="M48 110v18M72 110v18" stroke="#9aa7b9" strokeWidth="8" strokeLinecap="round" />
      <path d="M36 72 26 94M84 72l10 22" stroke="#9aa7b9" strokeWidth="7" strokeLinecap="round" />
      <rect x="34" y="60" width="52" height="54" rx="18" fill="url(#rm-body)" stroke="#7f8ca2" />
      <rect x="48" y="78" width="24" height="14" rx="5" fill="#0f1a2c" />
      <circle cx="60" cy="85" r="3.6" fill="#2f6f5e" className="twinkle" />
      <path d="M50 22 44 8M70 22l6-14" stroke="#7d8aa0" strokeWidth="2.4" />
      <circle cx="44" cy="7" r="3.5" fill={FAMILY_STYLES[family].c3} />
      <circle cx="76" cy="7" r="3.5" fill={FAMILY_STYLES[family].c3} />
      <rect x="30" y="18" width="60" height="46" rx="20" fill="url(#rm-body)" stroke="#7f8ca2" />
      <rect x="37" y="27" width="46" height="28" rx="13" fill="url(#rm-visor)" />
      {mood === "sleep" ? (
        <g stroke="#7fd6ff" strokeWidth="2.4" fill="none" strokeLinecap="round"><path d="M46 42q4 3 8 0M66 42q4 3 8 0" /></g>
      ) : (
        <g fill="#7fd6ff"><ellipse cx="50" cy="41" rx="4" ry="5" className="twinkle" /><ellipse cx="70" cy="41" rx="4" ry="5" className="twinkle" /></g>
      )}
      <ellipse cx="44" cy="25" rx="8" ry="2.6" fill="#fff" opacity=".65" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Core components                                                    */
/* ------------------------------------------------------------------ */

export function Card({ children, className, onClick, padded = true, style }: { children: ReactNode; className?: string; onClick?: () => void; padded?: boolean; style?: React.CSSProperties }) {
  const Comp: React.ElementType = onClick ? "button" : "div";
  return (
    <Comp onClick={onClick} style={style} className={cx("card", padded && "card-pad", onClick && "press card-hover text-start", className)}>
      {children}
    </Comp>
  );
}

export function ScreenHeader({ title, subtitle, right, eyebrow }: { title: string; subtitle?: ReactNode; right?: ReactNode; eyebrow?: string }) {
  return (
    <header className="flex items-start justify-between gap-3 pb-3 pt-1">
      <div className="min-w-0">
        {eyebrow && <p className="mb-0.5 text-[10.5px] font-bold uppercase tracking-[.16em] accent">{eyebrow}</p>}
        <h1 className="text-[24px] font-extrabold leading-tight tracking-tight">{title}</h1>
        {subtitle && <div className="mt-0.5 text-[12.5px] leading-relaxed muted">{subtitle}</div>}
      </div>
      {right && <div className="flex-none pt-1">{right}</div>}
    </header>
  );
}

export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} className="switch" />;
}

export function Ring({ value, size = 60, stroke = 6, color = "var(--accent)", track = "var(--line)", children }: { value: number; size?: number; stroke?: number; color?: string; track?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid flex-none place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(0, Math.min(1, value)))} style={{ transition: "stroke-dashoffset 700ms var(--ease)" }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

export function Sheet({ open, onClose, title, subtitle, children, footer }: { open: boolean; onClose: () => void; title: ReactNode; subtitle?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="sheet-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }} role="dialog" aria-modal="true">
      <div className="sheet-panel" ref={ref}>
        <div className="sheet-grab" />
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-[19px] font-extrabold leading-tight">{title}</h2>
            {subtitle && <p className="mt-1 text-xs leading-relaxed muted">{subtitle}</p>}
          </div>
          <button onClick={onClose} className="icon-btn -mr-1 -mt-1" aria-label="إغلاق"><Icon name="x" size={19} /></button>
        </div>
        <div className="space-y-4">{children}</div>
        {footer && <div className="sticky bottom-0 mt-5 border-t pt-3" style={{ borderColor: "var(--line)", background: "var(--surface)" }}>{footer}</div>}
      </div>
    </div>
  );
}

export function Segmented<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { id: T; label: string }[] }) {
  return (
    <div className="seg">
      {options.map((o) => <button key={o.id} aria-pressed={value === o.id} onClick={() => onChange(o.id)}>{o.label}</button>)}
    </div>
  );
}

export function EmptyState({ title, hint, action, family = "friday", icon = "sparkle" }: { title: string; hint: string; action?: ReactNode; family?: DecorFamily; icon?: IconName }) {
  return (
    <div className="relative overflow-hidden rounded-[20px] border border-dashed px-5 py-7 text-center" style={{ borderColor: "var(--line-strong)", background: "linear-gradient(160deg, rgba(255,253,248,.9), rgba(233,241,236,.55))" }}>
      <Ornament family={family} size={86} className="!absolute -bottom-5 -right-4 opacity-[.22]" rotate={-22} />
      <div className="relative mx-auto mb-3 grid h-11 w-11 place-items-center rounded-2xl" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={icon} size={21} /></div>
      <p className="relative text-[14px] font-bold">{title}</p>
      <p className="relative mx-auto mt-1 max-w-[260px] text-[12px] leading-relaxed muted">{hint}</p>
      {action && <div className="relative mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

export function WebOnlyNotice({ children, warn = false }: { children: ReactNode; warn?: boolean }) {
  // Rendered by the web presentation only. The native Compose app never mounts this.
  return (
    <div className={cx("notice", warn ? "notice-warn" : "notice-web")} role="note">
      <span className="mt-0.5 flex-none" style={{ color: warn ? "#9a3f28" : "#8a6a1c" }}><Icon name="smartphone" size={15} /></span>
      <div>{children}</div>
    </div>
  );
}

export function NativeOnlyNote({ children }: { children: ReactNode }) {
  return (
    <div className="notice notice-native" role="note">
      <span className="mt-0.5 flex-none accent"><Icon name="shield" size={15} /></span>
      <div>{children}</div>
    </div>
  );
}

export function Row({ icon, title, sub, right, onClick, danger }: { icon: IconName; title: string; sub?: string; right?: ReactNode; onClick?: () => void; danger?: boolean }) {
  const Comp: React.ElementType = onClick ? "button" : "div";
  return (
    <Comp onClick={onClick} className={cx("flex w-full items-center gap-3 py-2.5 text-start", onClick && "press")}>
      <span className="grid h-9 w-9 flex-none place-items-center rounded-xl" style={{ background: danger ? "#f7e8e3" : "var(--soft)", color: danger ? "#a3482f" : "var(--accent)" }}>
        <Icon name={icon} size={17} />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[13.5px] font-bold" style={danger ? { color: "#9a3f28" } : undefined}>{title}</span>
        {sub && <span className="mt-0.5 block text-[11px] leading-snug muted">{sub}</span>}
      </span>
      {right}
    </Comp>
  );
}

export function Tag({ children, tone = "soft" }: { children: ReactNode; tone?: "soft" | "gold" | "green" | "warn" }) {
  const colors: Record<string, React.CSSProperties> = {
    soft: { background: "var(--bg-deep)", color: "var(--muted)" },
    gold: { background: "var(--soft-gold)", color: "#7a5c17" },
    green: { background: "var(--soft)", color: "var(--accent-strong)" },
    warn: { background: "#f7e8e3", color: "#9a3f28" },
  };
  return <span className="inline-flex flex-none items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold" style={colors[tone]}>{children}</span>;
}

// Suppress unused import warning while keeping the icon helper close to UI.
void useId; void useState;
