import { Icon } from "./icons";
import { Ring } from "./ui";
import { RobotMini } from "./ui";
import {
  DAYS_SHORT_AR, alarmDaysLabel, alarmCountdown, arabicDate, cityOf, FAMILY_STYLES, hijriLabel,
  nextAlarmTime, seasonFor, todayKey, useDayflow, widgetById, type WForm, type WStyle,
} from "../lib/data";
import { arabicDigits, PRAYERS, prayerTimes } from "../lib/prayer";

const ARABIC_FORMS: Record<WForm, string> = { "1x1": "1×1", "2x1": "2×1", "2x2": "2×2", "4x1": "4×1", "4x2": "4×2", "4x4": "4×4" };
const FORM_ASPECT: Record<WForm, string> = { "1x1": "120px", "2x1": "150px", "2x2": "200px", "4x1": "160px", "4x2": "220px", "4x4": "340px" };

export function WidgetArt({ designId, form = "2x2", style = "oneui", home = false }: { designId: string; form?: WForm; style?: WStyle; home?: boolean }) {
  const s = useDayflow();
  const now = new Date();
  const def = widgetById(designId);
  if (!def) return null;
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const next = nextAlarmTime(s.alarms, now);
  const fam = FAMILY_STYLES[def.family];
  const tasks = s.tasks.filter((t) => t.date === todayKey());
  const done = tasks.filter((t) => t.done).length;
  const compact = form === "1x1" || form === "2x1" || form === "4x1";
  const clock = new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(now);
  const bigClock = new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: false }).format(now);

  return (
    <div className={`widget-card wt-${style}`} style={{ height: home ? undefined : FORM_ASPECT[form], borderRadius: form === "4x1" ? 18 : undefined, padding: compact ? 11 : 14 }}>
      {def.arche === "digital" && (
        <>
          <div className="flex items-start justify-between gap-2">
            <span className="text-[9.5px] font-bold opacity-65">{arabicDate(now)}</span>
            <Icon name="sun" size={12} className="opacity-60" />
          </div>
          <div className={compact ? "flex items-baseline gap-2" : "text-center"}>
            <p className={compact ? "text-[25px] font-extrabold tnum leading-none" : "text-[42px] font-extrabold tnum leading-none"}>{bigClock}</p>
            {!compact && <p className="mt-1 text-[10px] font-bold opacity-60">صباح الخير · {city.ar}</p>}
          </div>
          {!compact && <p className="text-center text-[9.5px] font-semibold opacity-60">{hijriLabel(now)}</p>}
        </>
      )}
      {def.arche === "analog" && (
        <>
          <p className="text-[9.5px] font-bold opacity-60">{city.ar} · {arabicDate(now)}</p>
          <div className="relative mx-auto my-auto h-[88px] w-[88px] rounded-full" style={{ background: `conic-gradient(from -90deg, var(--accent) 0 2%, transparent 2%), rgba(0,0,0,.03)`, border: "1px solid rgba(0,0,0,.12)" }}>
            {[0, 1, 2, 3].map((i) => <span key={i} className="absolute left-1/2 top-1/2 h-[1px] w-[3px] origin-left bg-black/30" style={{ transform: `rotate(${i * 90}deg) translateX(35px)` }} />)}
            <span className="absolute left-1/2 top-1/2 origin-bottom" style={{ width: 2, height: 26, background: "#1d1c1a", transform: `translate(-50%,-100%) rotate(${now.getHours() % 12 * 30 + now.getMinutes() / 2}deg)` }} />
            <span className="absolute left-1/2 top-1/2 origin-bottom" style={{ width: 2, height: 36, background: "var(--accent)", transform: `translate(-50%,-100%) rotate(${now.getMinutes() * 6}deg)` }} />
            <span className="absolute left-1/2 top-1/2 h-[5px] w-[5px] -translate-x-1/2 -translate-y-1/2 rounded-full" style={{ background: "#1d1c1a" }} />
          </div>
          <p className="text-center text-[9px] font-bold opacity-60">{clock}</p>
        </>
      )}
      {def.arche === "sunarc" && (
        <>
          <div className="flex items-center justify-between text-[10px] font-bold"><span>{pr.times.fajr.text}</span><span className="opacity-60">الشروق</span><span>{pr.times.maghrib.text}</span></div>
          <div className="relative my-auto h-[52px]">
            <svg viewBox="0 0 200 60" className="h-full w-full"><path d="M6 54Q100 -16 194 54" fill="none" stroke="rgba(0,0,0,.15)" strokeWidth="1.4" strokeDasharray="3 4" /><path d="M6 54Q100 -16 148 31" fill="none" stroke={fam.c2} strokeWidth="2.4" /><circle cx="148" cy="31" r="5" fill={fam.c3} /></svg>
          </div>
          <p className="text-[9px] font-bold opacity-60">القاهرة · صلاة {pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : ""}</p>
        </>
      )}
      {def.arche === "countdown" && (
        <>
          <div className="flex items-center gap-1.5 text-[10px] font-bold" style={{ color: fam.c1 }}><Icon name="alarm" size={12} />{next ? "المنبه التالي" : "لا منبهات"}</div>
          <p className="text-[30px] font-extrabold leading-none">{next ? new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(next.at) : "—"}</p>
          <p className="text-[10px] font-semibold opacity-65">{next ? `${next.alarm.label || "منبه"} · ${alarmCountdown(next.at, now)}` : "افتح التطبيق وأضف منبهًا"}</p>
        </>
      )}
      {def.arche === "dial" && (
        <div className="flex h-full flex-col items-center justify-center">
          <Ring value={0.62} size={compact ? 54 : 82} stroke={6}>
            <span className="text-[10px] font-extrabold">{clock}</span>
          </Ring>
          <p className="mt-1 text-[9px] font-bold opacity-60">المنبه التالي {next ? alarmDaysLabel(next.alarm) : ""}</p>
        </div>
      )}
      {def.arche === "checklist" && (
        <>
          <div className="flex items-center justify-between"><p className="text-[11.5px] font-extrabold">{def.ar}</p><span className="text-[9px] font-bold opacity-60">{arabicDigits(done)}/{arabicDigits(tasks.length)}</span></div>
          <div className="space-y-1.5">
            {tasks.slice(0, compact ? 2 : 4).map((t) => (
              <div key={t.id} className="flex items-center gap-1.5">
                <span className="grid h-3 w-3 place-items-center rounded border" style={{ borderColor: "currentColor", opacity: t.done ? 0.6 : 1, background: t.done ? "currentColor" : "transparent" }}>{t.done && <Icon name="check" size={7} />}</span>
                <span className="truncate text-[9.5px] font-semibold" style={{ textDecoration: t.done ? "line-through" : "none", opacity: t.done ? 0.55 : 0.9 }}>{t.title}</span>
              </div>
            ))}
          </div>
          <p className="text-[8px] font-bold opacity-50">{next ? `التالي: ${next.alarm.label || "منبه"}` : "اضغط للإضافة"}</p>
        </>
      )}
      {def.arche === "prayer" && (
        <>
          <div className="flex items-center justify-between text-[9.5px] font-bold"><span>مواقيت الصلاة · {city.ar}</span><span className="opacity-60">{hijriLabel(now)}</span></div>
          <div className="grid grid-cols-6 gap-0.5">
            {PRAYERS.map((p) => (
              <div key={p.key} className="rounded-md py-1 text-center" style={{ background: pr.next?.key === p.key ? fam.c1 : "rgba(0,0,0,.05)", color: pr.next?.key === p.key ? "#fff" : "inherit" }}>
                <p className="text-[7.5px] font-bold">{p.ar}</p><p className="text-[8px] font-extrabold tnum">{pr.times[p.key].text.split(" ")[0]}</p>
              </div>
            ))}
          </div>
          <p className="text-[8.5px] font-semibold opacity-60">القادمة: {pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : ""} {pr.next?.text}</p>
        </>
      )}
      {def.arche === "nextprayer" && (
        <>
          <p className="flex items-center gap-1 text-[9.5px] font-bold opacity-65"><Icon name="moon" size={10} />الصلاة القادمة</p>
          <div className="flex items-end justify-between">
            <div><p className="text-[15px] font-extrabold">{pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : "الفجر"}</p><p className="text-[10.5px] font-bold tnum opacity-70">{pr.next?.text}</p></div>
            <span className="rounded-full px-2 py-0.5 text-[9px] font-extrabold" style={{ background: "rgba(0,0,0,.07)" }}>{pr.next ? `${arabicDigits(pr.next.inMinutes)} د` : ""}</span>
          </div>
        </>
      )}
      {def.arche === "ring" && (
        <div className="flex h-full flex-col items-center justify-center gap-1">
          <Ring value={tasks.length ? done / tasks.length : 0.25} size={compact ? 50 : 72} stroke={6} color={fam.c1} track="rgba(0,0,0,.09)">
            <span className="text-[12px] font-extrabold">{arabicDigits(tasks.length ? Math.round(done / tasks.length * 100) : 0)}%</span>
          </Ring>
          <p className="text-[9.5px] font-bold opacity-65">{def.ar}</p>
        </div>
      )}
      {def.arche === "drop" && (
        <>
          <div className="flex items-center justify-between"><p className="text-[10px] font-bold opacity-65">الماء</p><span className="text-[10px] font-extrabold" style={{ color: fam.c1 }}>+٢٥٠</span></div>
          <div className="flex items-center gap-2">
            <Icon name="droplet" size={compact ? 26 : 36} filled className="flex-none" style={{ color: fam.c2 }} />
            <div><p className="text-[19px] font-extrabold leading-none">{(s.water[todayKey()] || 0) / 1000}<span className="text-[9px] opacity-60"> / {s.waterGoal / 1000} لتر</span></p>
              <div className="progress mt-1.5" style={{ width: 84 }}><i style={{ width: `${Math.min(100, (s.water[todayKey()] || 0) / s.waterGoal * 100)}%`, background: fam.c1 }} /></div>
            </div>
          </div>
        </>
      )}
      {def.arche === "heatmap" && (
        <>
          <p className="text-[10px] font-extrabold">{def.ar}</p>
          <div className="flex gap-1">
            {s.habits.map((h) => (
              <div key={h.id} className="flex-1">
                <div className="grid grid-cols-5 gap-[2px]">{[0, 1, 2, 3, 4].map((i) => <span key={i} className="aspect-square rounded-[2px]" style={{ background: i < Math.min(5, h.log.length + 1) ? fam.c1 : "rgba(0,0,0,.07)", opacity: 0.5 + i * 0.1 }} />)}</div>
                <p className="mt-0.5 truncate text-[7px] font-bold opacity-65">{h.ar}</p>
              </div>
            ))}
          </div>
        </>
      )}
      {def.arche === "list" && (
        <>
          <div className="flex items-center justify-between"><p className="text-[10.5px] font-extrabold">{def.ar}</p><Icon name="chevron-left" size={12} className="opacity-50" /></div>
          <div className="space-y-1.5">
            {tasks.slice(0, 3).map((t) => <div key={t.id} className="flex items-center gap-1.5 text-[9px] font-semibold"><span className="h-1 w-1 rounded-full" style={{ background: t.urgent ? "#b5503b" : fam.c1 }} /><span className="truncate opacity-85">{t.title}</span></div>)}
            {tasks.length === 0 && <p className="text-[9px] opacity-60">يوم هادي، مفيش مهام.</p>}
          </div>
        </>
      )}
      {def.arche === "week" && (
        <div className="flex h-full flex-col justify-center">
          <p className="mb-1 text-[10px] font-extrabold">{def.ar}</p>
          <div className="flex justify-between">
            {DAYS_SHORT_AR.map((d, i) => <div key={d} className="text-center"><p className="text-[8px] font-bold opacity-60">{d}</p><span className="mx-auto mt-1 grid h-5 w-5 place-items-center rounded-full text-[8.5px] font-extrabold" style={{ background: i === now.getDay() ? fam.c1 : "rgba(0,0,0,.05)", color: i === now.getDay() ? "#fff" : "inherit" }}>{arabicDigits(new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay() + i).getDate())}</span></div>)}
          </div>
        </div>
      )}
      {def.arche === "month" && (
        <>
          <p className="text-[10px] font-extrabold">{def.ar}</p>
          <div className="grid grid-cols-7 gap-y-1 text-center">{Array.from({ length: 21 }).map((_, i) => <span key={i} className="mx-auto grid h-4 w-4 place-items-center rounded-full text-[7px] font-bold" style={{ background: i === 11 ? fam.c1 : "transparent", color: i === 11 ? "#fff" : "inherit", opacity: i === 11 ? 1 : 0.65 }}>{arabicDigits(i + 1)}</span>)}</div>
          <p className="text-[8px] font-semibold opacity-60">{hijriLabel(now)}</p>
        </>
      )}
      {def.arche === "note" && (
        <>
          <div className="flex justify-between"><Icon name="book" size={12} className="opacity-50" /><Icon name="star" size={10} className="opacity-40" /></div>
          <p className="font-serif text-[13px] font-semibold leading-relaxed">{s.notes[0]?.text || "اكتب ملاحظة صغيرة ليومك…"}</p>
          <p className="text-[8px] font-bold opacity-55">ملاحظة مثبتة</p>
        </>
      )}
      {def.arche === "hero" && (
        <>
          <div className="flex items-center justify-between"><p className="text-[10px] font-extrabold">{dateHero(def.ar)}</p><span className="rounded-full bg-white/20 px-1.5 py-0.5 text-[8px] font-bold">{seasonFor(now).ar}</span></div>
          <p className="font-serif text-[16px] font-bold leading-snug">{def.ar === "بطل المناسبة" ? "الجمعة نور وسكينة" : def.ar === "العد للإفطار" ? "فاضل للإفطار" : def.ar}</p>
          <p className="text-[9px] opacity-75">{def.arche === "hero" && def.id.includes("countdown") ? `${pr.times.maghrib.text} · ${city.ar}` : "ربنا يكرمك ويسعد قلبك 🌿"}</p>
        </>
      )}
      {def.arche === "tri" && (
        <div className="grid h-full grid-cols-3 items-center gap-1 text-center">
          <div><p className="text-[15px] font-extrabold leading-none">{arabicDigits(now.getDate())}</p><p className="text-[8px] font-bold opacity-60">ميلادي</p></div>
          <div className="border-x border-black/10"><p className="text-[10px] font-extrabold leading-tight">{hijriLabel(now).split(" ").slice(0, 2).join(" ")}</p><p className="text-[8px] font-bold opacity-60">هجري</p></div>
          <div><p className="text-[10px] font-extrabold leading-tight">{new Intl.DateTimeFormat("ar-EG-u-ca-coptic", { day: "numeric", month: "short" }).format(now)}</p><p className="text-[8px] font-bold opacity-60">قبطي</p></div>
        </div>
      )}
      {def.arche === "compass" && (
        <div className="flex h-full flex-col items-center justify-center">
          <div className="relative grid h-16 w-16 place-items-center rounded-full border border-black/10">
            <span className="absolute top-1 text-[7px] font-bold opacity-60">N</span>
            <span className="text-[17px]" style={{ transform: "rotate(135deg)" }}>➤</span>
          </div>
          <p className="mt-1 text-[9px] font-bold opacity-65">{def.ar} ١٣٥°</p>
        </div>
      )}
      {def.arche === "portrait" && (
        <div className="flex h-full items-center gap-2">
          <RobotMini size={compact ? 44 : 62} family={def.family} />
          <div className="min-w-0"><p className="text-[10.5px] font-extrabold">رفيقك</p><p className="text-[8.5px] font-semibold leading-relaxed opacity-70">{seasonFor(now).note} · {def.ar}</p></div>
        </div>
      )}
      {!["digital", "analog", "sunarc", "countdown", "dial", "checklist", "prayer", "nextprayer", "ring", "drop", "heatmap", "list", "week", "month", "note", "hero", "tri", "compass", "portrait"].includes(def.arche) && (
        <div className="flex h-full flex-col justify-between">
          <div className="flex items-center justify-between"><p className="text-[10px] font-extrabold">{def.ar}</p><Icon name="grid" size={11} className="opacity-50" /></div>
          <div className="flex flex-1 items-center justify-center"><span className="grid h-12 w-12 place-items-center rounded-2xl" style={{ background: "rgba(0,0,0,.06)", color: fam.c1 }}><Icon name={def.interactive ? "zap" : "sparkle"} size={20} /></span></div>
          <p className="text-[8.5px] font-semibold opacity-60">{def.desc}</p>
        </div>
      )}
    </div>
  );
}

function dateHero(ar: string) {
  if (ar.includes("إفطار")) return "إفطار اليوم";
  if (ar.includes("الجمعة")) return "جمعة مباركة";
  return "المناسبة القادمة";
}

void ARABIC_FORMS;
