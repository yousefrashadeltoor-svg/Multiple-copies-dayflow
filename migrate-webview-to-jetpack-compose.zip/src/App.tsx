import { useEffect, useRef, useState } from "react";
import { Icon, type IconName } from "./components/icons";
import { Sheet, Toggle } from "./components/ui";
import { Companion, useNow } from "./components/Robot";
import {
  actions, cityOf, nextAlarmTime, seasonFor, useDayflow,
  type Alarm,
} from "./lib/data";
import { prayerTimes } from "./lib/prayer";
import { Today } from "./screens/Today";
import { CalendarScreen } from "./screens/Calendar";
import { Alarms, RingScreen } from "./screens/Alarms";
import { Tools } from "./screens/Tools";
import { AI } from "./screens/AI";
import { Downloads } from "./screens/Downloads";
import { Me } from "./screens/Me";
import { Widgets } from "./screens/Widgets";

type Tab = "today" | "calendar" | "alarms" | "tools" | "ai" | "downloads" | "me";
const TABS: Tab[] = ["today", "calendar", "alarms", "tools", "ai", "downloads", "me"];

const TAB_META: Record<Tab, { icon: IconName; label: string }> = {
  today: { icon: "sun", label: "النهاردة" },
  calendar: { icon: "calendar", label: "التقويم" },
  alarms: { icon: "alarm", label: "المنبهات" },
  tools: { icon: "grid", label: "أدوات" },
  ai: { icon: "sparkles", label: "الذكاء" },
  downloads: { icon: "download", label: "التحميل" },
  me: { icon: "user", label: "أنا" },
};

function parseHash(): { tab: Tab; sub?: string } {
  const [, tab, sub] = window.location.hash.replace(/^#/, "").split("/");
  return { tab: (TABS.includes(tab as Tab) ? tab : "today") as Tab, sub: sub || undefined };
}

export default function App() {
  const s = useDayflow();
  const now = useNow(15_000);
  const [route, setRoute] = useState(parseHash);
  const [quick, setQuick] = useState(false);
  const [ringing, setRinging] = useState<Alarm | null>(null);
  const [mounted, setMounted] = useState(false);
  const fired = useRef(new Set<string>());
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const season = seasonFor(now);
  const next = nextAlarmTime(s.alarms, now);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    window.addEventListener("popstate", onHash);
    return () => { window.removeEventListener("hashchange", onHash); window.removeEventListener("popstate", onHash); };
  }, []);

  const go = (tab: string, sub?: string) => {
    const hash = `#/${tab}${sub ? `/${sub}` : ""}`;
    if (window.location.hash !== hash) window.history.pushState(null, "", hash);
    setRoute({ tab: tab as Tab, sub });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Real alarm matching for the web preview. The native app uses AlarmManager.
  useEffect(() => {
    const tick = () => {
      const current = new Date();
      const hhmm = `${String(current.getHours()).padStart(2, "0")}:${String(current.getMinutes()).padStart(2, "0")}`;
      for (const alarm of s.alarms) {
        if (!alarm.enabled || alarm.time !== hhmm) continue;
        if (alarm.date) {
          const today = `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, "0")}-${String(current.getDate()).padStart(2, "0")}`;
          if (alarm.date !== today) continue;
        } else if (alarm.days.length && !alarm.days.includes(current.getDay())) continue;
        const key = `${alarm.id}-${current.toDateString()}-${alarm.time}`;
        if (fired.current.has(key)) continue;
        fired.current.add(key);
        setRinging(alarm);
        if (!alarm.days.length) actions.updateAlarm(alarm.id, { enabled: false });
        try {
          if ("Notification" in window && Notification.permission === "granted" && s.notif.enabled) {
            new Notification(`⏰ ${alarm.label || "منبه DAYFLOW"}`, { body: "اضغط لإيقاف المنبه — معاينة ويب", tag: `df-${alarm.id}` });
          }
          if (alarm.vibrate && navigator.vibrate) navigator.vibrate([350, 200, 350]);
        } catch { /* optional APIs */ }
      }
    };
    tick();
    const id = window.setInterval(tick, 15_000);
    return () => window.clearInterval(id);
  }, [s.alarms, s.notif.enabled]);

  const snooze = () => {
    if (!ringing) return;
    const at = new Date(Date.now() + Math.max(1, ringing.snooze) * 60_000);
    const time = `${String(at.getHours()).padStart(2, "0")}:${String(at.getMinutes()).padStart(2, "0")}`;
    actions.addAlarm({
      time, days: [], date: `${at.getFullYear()}-${String(at.getMonth() + 1).padStart(2, "0")}-${String(at.getDate()).padStart(2, "0")}`,
      label: `${ringing.label || "منبه"} · غفوة`, enabled: true, sound: ringing.sound,
      vibrate: ringing.vibrate, snooze: ringing.snooze, gentle: ringing.gentle,
    });
    setRinging(null);
  };

  const render = () => {
    if (route.tab === "today") return <Today go={go} />;
    if (route.tab === "calendar") return <CalendarScreen />;
    if (route.tab === "alarms") return <Alarms onPreview={setRinging} />;
    if (route.tab === "tools") return route.sub === "widgets" ? <Widgets go={go} /> : <Tools go={go} sub={route.sub} />;
    if (route.tab === "ai") return <AI />;
    if (route.tab === "downloads") return <Downloads />;
    if (route.tab === "me") return <Me go={go} sub={route.sub} />;
    return null;
  };

  return (
    <div className="relative min-h-dvh" dir="rtl">
      <div className="app-bg" />
      <div className="grain" aria-hidden />
      {s.intensity !== "off" && !s.reduceMotion && <SeasonParticles season={season.id} />}

      <header className="sticky top-0 z-30">
        <div className="mx-auto flex h-[52px] max-w-[680px] items-center justify-between px-4" style={{ backdropFilter: "blur(14px)", background: "rgba(250,248,242,.78)", borderBottom: "1px solid var(--line)" }}>
          <button onClick={() => go("today")} className="dayflow-logo text-[13px] tracking-[.12em]" aria-label="DAYFLOW الرئيسية">
            <span className="mark"><Icon name="sun" size={17} strokeWidth={2.2} /></span>
            <span className="brand-word text-[15px]">DAYFLOW</span>
            <span className="rounded-full px-1.5 py-0.5 text-[8px] font-extrabold" style={{ background: "var(--soft)", color: "var(--accent)" }}>أصلي</span>
          </button>
          <div className="flex items-center gap-1">
            <button onClick={() => go("me", "prayer")} className="hidden items-center gap-1 rounded-full px-2 py-1 text-[9.5px] font-bold min-[380px]:flex" style={{ background: "var(--soft)", color: "var(--accent-strong)" }}>
              <Icon name="moon" size={11} />{pr.next?.text || ""}
            </button>
            <button onClick={() => go("downloads")} className="icon-btn !h-8 !w-8" aria-label="التحميل"><Icon name="download" size={17} /></button>
            <button onClick={() => go("me", "notifications")} className="icon-btn relative !h-8 !w-8" aria-label="الإشعارات">
              <Icon name="bell" size={17} />
              {next && <span className="absolute end-1 top-1 h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent2)" }} />}
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-[2] mx-auto max-w-[680px] px-4 pb-[calc(var(--tabbar-h)+18px)] pt-3">
        <div key={`${route.tab}-${route.sub || ""}`} className="fade-page">
          {render()}
        </div>
      </main>

      {!quick && (
        <button onClick={() => setQuick(true)} className="btn-primary fixed bottom-[calc(var(--tabbar-h)+14px)] left-1/2 z-40 grid h-[52px] w-[52px] -translate-x-1/2 place-items-center rounded-full transition-transform active:scale-90"
          style={{ background: `var(--accent)`, color: "var(--on-accent)", boxShadow: "0 12px 26px -10px rgba(47,111,94,.65)" }} aria-label="اعمل جديد">
          <Icon name="plus" size={24} strokeWidth={2.2} />
        </button>
      )}

      <nav className="tabbar fixed inset-x-0 bottom-0 z-30 select-none" aria-label="الرئيسية" style={{ paddingBottom: "max(env(safe-area-inset-bottom), 0px)" }}>
        <div className="mx-auto flex max-w-[680px]">
          {TABS.map((tab) => {
            const active = route.tab === tab;
            const meta = TAB_META[tab];
            return (
              <button key={tab} onClick={() => go(tab)} className="tab" aria-current={active ? "page" : undefined} aria-label={meta.label}>
                <span className="ico"><Icon name={meta.icon} size={19} strokeWidth={active ? 2.4 : 1.8} /></span>
                <span className="lbl">{meta.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {mounted && <Companion onGo={go} />}
      <QuickCreate open={quick} onClose={() => setQuick(false)} go={go} />
      {ringing && <RingScreen alarm={ringing} onClose={() => setRinging(null)} onSnooze={snooze} />}
    </div>
  );
}

function SeasonParticles({ season }: { season: string }) {
  const items = season === "autumn" ? ["🍂", "🍁", "🌿"] : season === "ramadan" || season === "eid" || season === "islamic" ? ["✦", "✧", "🌙"] : season === "spring" ? ["🌸", "❀", "✿"] : season === "winter" ? ["❄", "✻", "❅"] : ["✦", "🌿", "✧"];
  return (
    <div className="pointer-events-none fixed inset-0 z-[1] overflow-hidden" aria-hidden>
      {Array.from({ length: 9 }).map((_, i) => (
        <span key={i} className="particle" style={{
          left: `${(i * 11 + 6) % 96}%`, top: "-6vh", fontSize: `${9 + (i % 3) * 3}px`, color: i % 3 === 0 ? "var(--accent2)" : "var(--accent)",
          animationDuration: `${16 + (i % 5) * 5}s`, animationDelay: `${-i * 2.7}s`,
          ["--dx" as string]: `${(i % 2 ? -1 : 1) * (20 + i * 3)}px`, ["--rot" as string]: `${i * 55}deg`, opacity: 0.45,
        }}>{items[i % items.length]}</span>
      ))}
    </div>
  );
}

function QuickCreate({ open, onClose, go }: { open: boolean; onClose: () => void; go: (tab: string, sub?: string) => void }) {
  const [mode, setMode] = useState<"task" | "note" | "reminder" | null>(null);
  const [txt, setTxt] = useState("");
  const [hour, setHour] = useState(6); const [minute, setMinute] = useState(0); const [period, setPeriod] = useState<"am" | "pm">("pm");
  const [remind, setRemind] = useState(true);
  const [created, setCreated] = useState("");
  const close = () => { setMode(null); setTxt(""); setCreated(""); onClose(); };
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txt.trim()) return;
    if (mode === "task") actions.addTask(txt.trim());
    if (mode === "note") actions.addNote(txt.trim());
    if (mode === "reminder") {
      const t24 = `${String(period === "pm" ? (hour % 12) + 12 : hour % 12).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
      actions.addAlarm({ time: t24, days: [], label: txt.trim(), enabled: true, sound: { source: "device", title: "منبه الجهاز الافتراضي" }, vibrate: true, snooze: 10, gentle: true });
    }
    setCreated(mode === "task" ? "تمت إضافة المهمة لليوم" : mode === "note" ? "تم حفظ الملاحظة" : "تم جدولة التذكير");
    window.setTimeout(close, 650);
  };
  const main = [
    { icon: "alarm" as IconName, ar: "منبه", run: () => { close(); go("alarms"); } },
    { icon: "list" as IconName, ar: "مهمة", run: () => setMode("task") },
    { icon: "heart" as IconName, ar: "عادة", run: () => { close(); go("tools", "habits"); } },
    { icon: "book" as IconName, ar: "ملاحظة", run: () => setMode("note") },
    { icon: "bell" as IconName, ar: "تذكير", run: () => setMode("reminder") },
    { icon: "more" as IconName, ar: "المزيد", run: () => { close(); go("tools"); } },
  ];
  return (
    <Sheet open={open} onClose={close} title={mode ? (mode === "task" ? "مهمة جديدة" : mode === "note" ? "ملاحظة جديدة" : "تذكير جديد") : "اعمل جديد"} subtitle={mode ? undefined : "اختَر نوع الإضافة — كلها تُحفظ على جهازك"}>
      {created && <div className="notice notice-native"><Icon name="check-circle" size={16} />{created}</div>}
      {!mode && (
        <>
          <div className="grid grid-cols-3 gap-2">
            {main.map((m) => <button key={m.ar} onClick={m.run} className="card press flex aspect-square flex-col items-center justify-center gap-1.5 !rounded-2xl"><span className="grid h-10 w-10 place-items-center rounded-2xl" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={m.icon} size={19} /></span><span className="text-[11px] font-bold">{m.ar}</span></button>)}
          </div>
          <div className="mt-1 flex flex-wrap gap-1.5">
            <button onClick={() => { close(); go("tools", "widgets"); }} className="chip !text-[10px]"><Icon name="widget" size={12} />إضافة ودجت</button>
            <button onClick={() => { close(); go("downloads"); }} className="chip !text-[10px]"><Icon name="link" size={12} />لصق رابط</button>
            <button onClick={() => { close(); go("tools", "focus"); }} className="chip !text-[10px]"><Icon name="focus" size={12} />تركيز</button>
          </div>
        </>
      )}
      {mode && (
        <form onSubmit={submit} className="space-y-3">
          <label className="block"><span className="mb-1 block text-[11px] font-bold">{mode === "task" ? "عنوان المهمة" : mode === "note" ? "نص الملاحظة" : "اسم التذكير"}</span>
            <textarea autoFocus rows={mode === "note" ? 4 : 2} value={txt} onChange={(e) => setTxt(e.target.value)} className="field resize-none" placeholder={mode === "task" ? "مثال: مراجعة الحسابات" : mode === "note" ? "اكتب فكرتك…" : "مثال: اشرب ماء"} maxLength={200} />
          </label>
          {mode === "reminder" && (
            <div>
              <p className="mb-1.5 text-[11px] font-bold">وقت التذكير (١٢ ساعة)</p>
              <div className="flex items-center justify-center gap-1.5 rounded-xl p-2" style={{ background: "var(--surface-2)" }} dir="ltr">
                <button type="button" onClick={() => setHour((h) => h === 1 ? 12 : h - 1)} className="icon-btn !h-7 !w-7"><Icon name="chevron-down" size={14} /></button>
                <span className="text-[22px] font-extrabold tnum">{String(hour).padStart(2, "0")}</span>
                <span className="font-bold muted">:</span>
                <span className="text-[22px] font-extrabold tnum">{String(minute).padStart(2, "0")}</span>
                <button type="button" onClick={() => setMinute((m) => (m + 5) % 60)} className="icon-btn !h-7 !w-7"><Icon name="chevron-down" size={14} /></button>
                <button type="button" onClick={() => setPeriod((p) => p === "am" ? "pm" : "am")} className="chip !text-[10px]">{period === "am" ? "ص" : "م"}</button>
              </div>
            </div>
          )}
          <div className="flex items-center justify-between rounded-xl px-3 py-2" style={{ background: "var(--surface-2)" }}>
            <div><p className="text-[11px] font-bold">تفعيل التذكير</p><p className="text-[9px] muted">صوت وإشعار — أصلي على أندرويد</p></div>
            <Toggle on={remind} onChange={setRemind} label="تفعيل التذكير" />
          </div>
          <div className="flex gap-2"><button type="button" onClick={() => setMode(null)} className="btn btn-ghost flex-1">رجوع</button><button className="btn btn-primary flex-1" disabled={!!created}>حفظ</button></div>
        </form>
      )}
      {!mode && <p className="text-center text-[9px] muted">صيغة الوقت ١٢ ساعة دائمًا · التزامن مع الودجتس والمنبه الأصلي</p>}
    </Sheet>
  );
}
