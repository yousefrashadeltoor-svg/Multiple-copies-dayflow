import { useRef, useState } from "react";
import { Icon } from "../components/icons";
import { Card, RobotMini, ScreenHeader, Tag } from "../components/ui";
import { actions, cityOf, nextAlarmTime, seasonFor, todayKey, useDayflow } from "../lib/data";
import { arabicDigits, PRAYERS, prayerTimes } from "../lib/prayer";

interface Msg { id: string; role: "user" | "bot"; text: string; at: number }

function reply(text: string, ctx: { city: string; prayer: string; nextTime: string; tasks: number; done: number; water: number; alarm: string; family: string }) {
  const t = text.toLowerCase();
  if (/منبه|صحيان|alarm/.test(t)) return `المنبه الجاي ${ctx.alarm}. لو عايز منبه جديد، افتح تبويب «المنبهات» واختار الوقت بصيغة ١٢ ساعة. على أندرويد المنبه بيرن حتى لو التطبيق مقفول.`;
  if (/صلاه|صلاة|فجر|مغرب|مواقيت|prayer/.test(t)) return `في ${ctx.city}، ${ctx.prayer}. خدلك ٥ دقايق هدوء قبلها — وأنا أفكرك لو حبيت.`;
  if (/مهم|مهام|task|انتاج|إنجاز/.test(t)) return `عندك ${ctx.done} من ${ctx.tasks} مهام النهاردة. لو حاسس إن اليوم تقيل، نبدأ بأصغر مهمة ٢ دقيقة بس. تحب نضيفها؟`;
  if (/ماء|مياه|شرب|water/.test(t)) return `شربت ${ctx.water} مل من ٢٥٠٠. اشرب كوباية دلوقتي — الرفيق بيطمن عليك 💧`;
  if (/مزاج|تعب|زهق|قلق|stress|mood/.test(t)) return `حاسس بيك. اخد نفس عميق ٤ ثواني، احبسه ٤، وطلعه ٦. مفيش حاجة مستعجلة أكتر من هدوءك.`;
  if (/عيد|رمضان|مناسبه|مناسبة|season/.test(t)) return `إحنا في موسم ${ctx.family}. الزخرفة والألوان اتغيرت مع الموسم، والمناسبات القادمة في التقويم معروضة بتواريخها.`;
  if (/تحميل|download|رابط|لينك|لينك|فيديو/.test(t)) return `ارسل الرابط في شاشة «التحميل». على أندرويد المعاينة والتحميل يتمّوا محليًا عبر HTTP وDownloadManager — مفيش CORS. لو الموقع محمي أو DRM، هنقولك بصراحة بدل ما نعرض صيغ وهمية.`;
  if (/ودجت|widget/.test(t)) return `ودجتس DAYFLOW تعرض بياناتك الحقيقية: المنبه التالي، الصلاة القادمة، المهام، والماء. افتح «أدوات ← الودجتس» واختار واحدة، وفي أندرويد هتتثبت على الشاشة الرئيسية من غير ما تخرج من التطبيق.`;
  if (/شكرا|تسلم|برافو/.test(t)) return `دايمًا 🌿 خطوة صغيرة النهاردة أحسن من خطة كبيرة بكرة.`;
  return `فهمت. أقدر أساعدك في: تنظيم مهامك، مواقيت الصلاة، المنبهات، أو اختيار ودجت. قولّي تحب نبدأ بإيه — وعندك ${ctx.tasks - ctx.done} مهام لسه النهاردة.`;
}

export function AI() {
  const s = useDayflow();
  const city = cityOf(s);
  const pr = prayerTimes(city, new Date(), s.methodId, s.asrFactor);
  const next = nextAlarmTime(s.alarms);
  const season = seasonFor(new Date());
  const [msgs, setMsgs] = useState<Msg[]>([{ id: "hello", role: "bot", text: "أهلاً بيك 🌿 أنا رفيق DAYFLOW. بعرف أنظم يومك، أفكرك بالصلاة والمنبه، وأساعدك تختار ودجت. اسألني.", at: Date.now() }]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const tasks = s.tasks.filter((t) => t.date === todayKey());
  const ctx = {
    city: city.ar,
    prayer: pr.next ? `الصلاة القادمة ${PRAYERS.find((p) => p.key === pr.next?.key)?.ar} ${pr.next.text}` : "المواقيت جاهزة",
    nextTime: pr.next?.text || "",
    tasks: tasks.length,
    done: tasks.filter((t) => t.done).length,
    water: s.water[todayKey()] || 0,
    alarm: next ? `${new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(next.at)} — ${next.alarm.label || "منبه"}` : "مفيش منبه مفعّل",
    family: season.ar,
  };

  const send = (value?: string) => {
    const text = (value ?? input).trim();
    if (!text) return;
    const user: Msg = { id: crypto.randomUUID(), role: "user", text, at: Date.now() };
    setMsgs((m) => [...m, user]);
    setInput("");
    setTyping(true);
    window.setTimeout(() => {
      const answer = reply(text, ctx);
      setMsgs((m) => [...m, { id: crypto.randomUUID(), role: "bot", text: answer, at: Date.now() }]);
      setTyping(false);
      window.setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 80);
    }, 700);
    window.setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), 80);
  };

  const suggestions = ["اقترح خطة خفيفة لليوم", "فاضل قد إيه للصلاة؟", "ساعدني أختار ودجت", "المنبه الجاي امتى؟"];

  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="الرفيق الذكي" eyebrow="COMPANION · محلي" subtitle="مساعد يفهم بياناتك بدون إرسالها لأي سيرفر" right={<Tag tone="green"><Icon name="shield" size={11} />خصوصية</Tag>} />
      <Card className="relative overflow-hidden !p-3.5" style={{ background: "linear-gradient(150deg, #eef4ee, #fdfaf2)" }}>
        <div className="flex items-center gap-2.5">
          <RobotMini size={54} family={season.id} mood={s.companion.emotion} />
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-extrabold">رفيقك مستعد</p>
            <p className="text-[10px] leading-relaxed muted">{arabicDateSafe()} · {ctx.family} · {city.ar}</p>
          </div>
          <div className="flex flex-col items-end gap-1"><Tag tone="gold">{pr.next ? `${arabicDigits(pr.next.inMinutes)} د` : ""}</Tag><span className="text-[8.5px] muted">{pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : ""}</span></div>
        </div>
      </Card>

      <div className="space-y-2.5">
        {msgs.map((m) => (
          <div key={m.id} className={m.role === "user" ? "flex justify-start" : "flex justify-end"}>
            <div className={m.role === "user" ? "max-w-[86%] rounded-2xl rounded-tr-md bg-white/60 px-3.5 py-2.5" : "relative max-w-[88%] rounded-2xl rounded-tl-md px-3.5 py-2.5"}
              style={m.role === "user" ? { border: "1px solid var(--line)" } : { background: "var(--surface)", border: "1px solid var(--line)", boxShadow: "0 6px 20px -18px rgba(0,0,0,.4)" }}>
              {m.role === "bot" && <p className="mb-1 flex items-center gap-1 text-[9px] font-extrabold accent"><Icon name="bot" size={10} />الرفيق</p>}
              <p className="whitespace-pre-wrap text-[12.5px] leading-relaxed">{m.text}</p>
            </div>
          </div>
        ))}
        {typing && <div className="flex justify-end"><div className="flex gap-1 rounded-2xl px-4 py-3" style={{ background: "var(--surface)", border: "1px solid var(--line)" }}>{[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 rounded-full twinkle" style={{ background: "var(--accent)", animationDelay: `${i * 0.2}s` }} />)}</div></div>}
        <div ref={endRef} />
      </div>

      <div className="flex gap-1.5 overflow-x-auto hide-scroll pb-1">
        {suggestions.map((x) => <button key={x} onClick={() => send(x)} className="chip flex-none !text-[10px]">{x}</button>)}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex items-end gap-2">
        <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          rows={1} className="field max-h-24 flex-1 resize-none" placeholder="اكتب لرفيقك…" />
        <button className="btn btn-primary !min-h-11 !px-3.5" aria-label="إرسال"><Icon name="send" size={18} /></button>
      </form>
      <button onClick={() => { actions.addTask("مهمة من الرفيق", todayKey()); send("ضيف مهمة"); }} className="w-full text-center text-[10px] font-bold accent">جرّب: أضف مهمة للنهاردة من الشات</button>
      <p className="text-center text-[9px] leading-relaxed muted">المساعد المحلي ده لا يزعم اتصالًا بنموذج سحابي. نسخة أندرويد تحتفظ بالبيانات على الجهاز فقط.</p>
    </div>
  );
}

function arabicDateSafe() {
  return new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(new Date());
}
