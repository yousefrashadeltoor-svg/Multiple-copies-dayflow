import { useEffect, useState } from "react";
import { Icon } from "../components/icons";
import { Card, NativeOnlyNote, Ornament, RobotMini, ScreenHeader, Segmented, Sheet, Tag, Toggle, WebOnlyNotice } from "../components/ui";
import {
  actions, arabicDate, cityOf, hijriLabel, nextAlarmTime, seasonFor, store, todayKey, useDayflow, type Mood,
} from "../lib/data";
import { CITIES, METHODS, PRAYERS, prayerTimes, qiblaDirection, type MethodId } from "../lib/prayer";
import { arabicDigits } from "../lib/prayer";
import { REPORT_ITEMS, reportText } from "../lib/report";
import { useNow } from "../components/Robot";

export function Me({ go, sub }: { go: (tab: string, sub?: string) => void; sub?: string }) {
  if (sub === "prayer") return <PrayerSettings go={go} />;
  if (sub === "settings") return <SettingsScreen go={go} />;
  if (sub === "notifications") return <NotificationsScreen go={go} />;
  if (sub === "companion") return <CompanionSettings go={go} />;
  if (sub === "report") return <ReportScreen go={go} />;
  return <MeHome go={go} />;
}

function MeHome({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const now = useNow(30_000);
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const fam = seasonFor(now);
  const next = nextAlarmTime(s.alarms, now);
  const tasks = s.tasks.filter((t) => t.date === todayKey());
  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="أنا" eyebrow="DAYFLOW · حسابك" subtitle="إعداداتك وبياناتك تفضل على جهازك" right={<button onClick={() => go("me", "settings")} className="icon-btn" aria-label="الإعدادات"><Icon name="settings" size={19} /></button>} />

      <Card className="relative overflow-hidden" style={{ background: "linear-gradient(145deg, #f0f5ef, #fbf6ea)" }}>
        <Ornament family={fam.id} size={120} className="!absolute -bottom-8 -left-6 opacity-45" rotate={-18} />
        <div className="relative flex items-center gap-3">
          <div className="grid h-[68px] w-[68px] flex-none place-items-center rounded-full" style={{ background: "linear-gradient(150deg, #fff, #e8efe9)", border: "1px solid var(--line)" }}><RobotMini size={58} family={fam.id} mood={s.companion.emotion} /></div>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-bold muted">أهلاً بيك</p>
            <p className="text-[18px] font-extrabold leading-tight">صاحب يوم هادي</p>
            <p className="mt-1 flex items-center gap-1 text-[10px] muted"><Icon name="location" size={11} />{city.ar} · {fam.ar} · {hijriLabel(now).replace(" هـ", "")}</p>
          </div>
        </div>
        <div className="relative mt-3 grid grid-cols-3 gap-1.5">
          {[{ v: s.alarms.filter((a) => a.enabled).length, l: "منبه مفعّل" }, { v: tasks.filter((t) => !t.done).length, l: "مهمة باقية" }, { v: s.habits.filter((h) => h.log.includes(todayKey())).length, l: "عادة النهاردة" }].map((x) => (
            <div key={x.l} className="rounded-xl px-2 py-2 text-center" style={{ background: "rgba(255,255,255,.65)", border: "1px solid var(--line)" }}>
              <p className="text-[17px] font-extrabold leading-none">{arabicDigits(x.v)}</p><p className="mt-0.5 text-[8.5px] font-bold muted">{x.l}</p>
            </div>
          ))}
        </div>
      </Card>

      <div className="rounded-2xl px-3 py-2.5 text-[10.5px] font-semibold" style={{ background: "var(--soft)", color: "var(--accent-strong)" }}>
        <Icon name="moon" size={13} className="inline" /> الصلاة القادمة: <b>{pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : "الفجر"} {pr.next?.text}</b> · {next ? `المنبه ${new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(next.at)}` : "لا منبه مفعل"}
      </div>

      <Card className="!p-2">
        {[
          { icon: "moon" as const, title: "مواقيت الصلاة والمدينة", sub: `${city.ar} · ${pr.method.ar}`, tap: () => go("me", "prayer") },
          { icon: "widget" as const, title: "الودجتس والاختيار المفضل", sub: "اختر ودجت واحدة لتظهر على الشاشة الرئيسية", tap: () => go("tools", "widgets") },
          { icon: "bell" as const, title: "الإشعارات والتذكيرات", sub: "قنوات، صوت، اهتزاز، أوقات هادئة", tap: () => go("me", "notifications") },
          { icon: "bot" as const, title: "الرفيق والزينة", sub: "الحجم، الشفافية، الموسم، وفوق التطبيقات", tap: () => go("me", "companion") },
          { icon: "alarm" as const, title: "المنبهات وتجربة الرنين", sub: `${s.alarms.length} منبه · صيغة ١٢ ساعة`, tap: () => go("alarms") },
          { icon: "shield" as const, title: "مركز الجودة والإصلاحات", sub: `${REPORT_ITEMS.length} مشكلة موثقة وتم إصلاحها`, tap: () => go("me", "report") },
          { icon: "settings" as const, title: "كل الإعدادات", sub: "الشكل، الحركة، الصلاحيات والبيانات", tap: () => go("me", "settings") },
        ].map((row, i, arr) => (
          <button key={row.title} onClick={row.tap} className="flex w-full items-center gap-2.5 rounded-xl px-2 py-2.5 text-start press" style={{ borderBottom: i < arr.length - 1 ? "1px solid var(--line)" : "none" }}>
            <span className="grid h-8 w-8 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={row.icon} size={15} /></span>
            <span className="min-w-0 flex-1"><span className="block truncate text-[12px] font-bold">{row.title}</span><span className="block truncate text-[9.5px] muted">{row.sub}</span></span>
            <Icon name="chevron-left" size={14} className="muted" />
          </button>
        ))}
      </Card>

      {s.companion.hidden && (
        <button onClick={() => actions.setCompanion({ hidden: false, enabled: true })} className="btn btn-soft w-full"><Icon name="bot" size={16} />إظهار الرفيق تاني</button>
      )}
      <WebOnlyNotice>إعدادات الصلاحيات هنا تعرض حالة المتصفح فقط. نسخة أندرويد تفحص صلاحيات النظام فعليًا وتطلبها في السياق المناسب.</WebOnlyNotice>
      <p className="text-center text-[9.5px] leading-relaxed muted">DAYFLOW 1.0 · واجهة Kotlin/Jetpack Compose أصلية · بيانات محلية<br />صُمم ليكون يومك أهدأ.</p>
    </div>
  );
}

function PrayerSettings({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const now = useNow(30_000);
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const qibla = qiblaDirection(city.lat, city.lng);
  const [cityOpen, setCityOpen] = useState(false);
  const [methodOpen, setMethodOpen] = useState(false);
  return (
    <div className="space-y-3 pb-3">
      <SubHeader title="مواقيت الصلاة" onBack={() => go("me")} eyebrow={`${city.ar} · ${pr.method.ar}`} />
      <Card className="relative overflow-hidden" style={{ background: `linear-gradient(145deg, ${FAMILY_ACCENT(city.id)}, #1f342a)` }}>
        <Ornament family="ramadan" size={95} className="!absolute -bottom-5 -left-3 opacity-70" rotate={-12} />
        <div className="relative text-white">
          <p className="text-[10px] font-semibold text-white/70">الصلاة القادمة</p>
          <div className="mt-1 flex items-end justify-between">
            <div><p className="text-[26px] font-extrabold leading-tight">{pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : "الفجر"}</p><p className="text-[14px] font-bold text-white/85 tnum">{pr.next?.text}</p></div>
            <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold backdrop-blur">فاضل {arabicDigits(pr.next?.inMinutes || 0)} دقيقة</span>
          </div>
          <p className="mt-2 text-[9.5px] text-white/65">{arabicDate(now)} · {hijriLabel(now)}</p>
        </div>
      </Card>

      <div className="grid grid-cols-3 gap-1.5">
        {PRAYERS.map((p) => (
          <div key={p.key} className="rounded-xl px-2 py-2.5 text-center" style={{ background: pr.next?.key === p.key ? "var(--accent)" : "var(--surface)", color: pr.next?.key === p.key ? "var(--on-accent)" : "inherit", border: "1px solid var(--line)" }}>
            <p className="text-[9px] font-semibold opacity-75">{p.ar}</p><p className="mt-0.5 text-[13px] font-extrabold tnum">{pr.times[p.key].text}</p>
          </div>
        ))}
      </div>

      <Card className="!p-2">
        <RowBtn icon="location" title="المدينة" value={city.ar} onClick={() => setCityOpen(true)} />
        <RowBtn icon="compass" title="طريقة الحساب" value={pr.method.ar} onClick={() => setMethodOpen(true)} />
        <div className="px-2 pb-1">
          <p className="mb-1.5 mt-1 text-[10.5px] font-bold">مذهب العصر</p>
          <Segmented value={s.asrFactor === 1 ? "std" : "hanafi"} onChange={(v) => store.set({ asrFactor: v === "std" ? 1 : 2 })} options={[{ id: "std", label: "الجمهور / الشافعي" }, { id: "hanafi", label: "الحنفي" }]} />
        </div>
        <RowBtn icon="compass" title="اتجاه القبلة" value={`${Math.round(qibla)}° من الشمال`} onClick={() => undefined} />
      </Card>

      <Card>
        <p className="text-[11.5px] font-extrabold">دقة الحساب</p>
        <p className="mt-1 text-[10px] leading-relaxed muted">{pr.method.noteAr}. يتم الحساب على الجهاز بالمعادلات الشمسية، مع منطقة زمنية IANA ومراعاة التوقيت الصيفي تلقائيًا، وقاعدة منتصف الليل لخطوط العرض العالية عند تعذر زاوية الفجر أو العشاء.{pr.highLatitude ? " تم تطبيق قاعدة خطوط العرض العالية لهذا اليوم." : ""}</p>
        <div className="mt-2 flex flex-wrap gap-1"><Tag tone="green">Africa/Cairo · DST</Tag><Tag tone="gold">بدون إنترنت</Tag><Tag>٢٠٢٦</Tag></div>
        <div className="mt-2"><WebOnlyNotice>على أندرويد يمكن استخدام موقع الجهاز الحقيقي (LocationManager) مع صلاحية الموقع، أو الاعتماد على مدينة مختارة. الويب لا يطلب موقعك تلقائيًا.</WebOnlyNotice></div>
      </Card>

      <Sheet open={cityOpen} onClose={() => setCityOpen(false)} title="اختر المدينة" subtitle="المواقيت تُحسب بإحداثيات المدينة ومنطقتها الزمنية" footer={<p className="text-[9.5px] leading-relaxed muted">الافتراضي: الجيزة/القاهرة — طريقة الهيئة المصرية العامة للمساحة. تمت إضافة الجيزة ومدن مصرية أخرى.</p>}>
        <div className="grid grid-cols-2 gap-1.5">
          {CITIES.map((c) => <button key={c.id} onClick={() => { store.set({ cityId: c.id }); setCityOpen(false); }} className="flex items-center justify-between rounded-xl px-2.5 py-2 text-[11px] font-bold" style={{ background: s.cityId === c.id ? "var(--soft)" : "var(--surface-2)", border: `1px solid ${s.cityId === c.id ? "var(--accent)" : "var(--line)"}`, color: s.cityId === c.id ? "var(--accent-strong)" : "inherit" }}><span>{c.ar}</span><span className="text-[8px] font-normal muted" dir="ltr">{c.tz.split("/")[1]?.replace("_", " ")}</span></button>)}
        </div>
      </Sheet>
      <Sheet open={methodOpen} onClose={() => setMethodOpen(false)} title="طريقة الحساب" subtitle="اختر الجهة الموثوقة عندك">
        <div className="space-y-1.5">
          {METHODS.map((m) => <button key={m.id} onClick={() => { store.set({ methodId: m.id as MethodId }); setMethodOpen(false); }} className="w-full rounded-xl px-3 py-2.5 text-start" style={{ background: s.methodId === m.id ? "var(--soft)" : "var(--surface-2)", border: `1px solid ${s.methodId === m.id ? "var(--accent)" : "var(--line)"}` }}><p className="text-[11.5px] font-bold">{m.ar}</p><p className="mt-0.5 text-[9.5px] muted">{m.noteAr}</p></button>)}
        </div>
      </Sheet>
    </div>
  );
}

function NotificationsScreen({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const [permission, setPermission] = useState<string>(typeof Notification !== "undefined" ? Notification.permission : "unsupported");
  const [tested, setTested] = useState(false);
  const request = async () => {
    if (!("Notification" in window)) return;
    const result = await Notification.requestPermission();
    setPermission(result);
    if (result === "granted") actions.setNotif({ enabled: true });
  };
  const test = async () => {
    if (!("Notification" in window)) return;
    if (Notification.permission !== "granted") await request();
    try { new Notification("DAYFLOW — إشعار تجريبي", { body: "الإشعارات جاهزة. في أندرويد تُرسل عبر قناة Reminders.", tag: "dayflow-test" }); setTested(true); } catch { setTested(false); }
  };
  return (
    <div className="space-y-3 pb-3">
      <SubHeader title="الإشعارات" onBack={() => go("me")} eyebrow="NOTIFICATIONS" />
      <Card>
        <div className="flex items-start justify-between gap-2">
          <div><p className="text-[12.5px] font-extrabold">إذن الإشعارات</p><p className="mt-0.5 text-[10px] muted">{permission === "granted" ? "مسموح في المتصفح" : permission === "denied" ? "مرفوض — فعّله من إعدادات المتصفح" : "لسه مش مطلوب"}</p></div>
          <Tag tone={permission === "granted" ? "green" : "warn"}>{permission === "granted" ? "مسموح" : permission === "denied" ? "مرفوض" : "غير مفعّل"}</Tag>
        </div>
        <div className="mt-2.5 flex gap-1.5"><button onClick={request} className="btn btn-primary flex-1 !min-h-9 !py-1.5 !text-[11px]">طلب الإذن</button><button onClick={test} className="btn btn-soft !min-h-9 !py-1.5 !text-[11px]"><Icon name="bell" size={14} />اختبار</button></div>
        {tested && <p className="mt-1.5 text-[9.5px] font-bold accent"><Icon name="check" size={11} className="inline" /> تم إرسال إشعار تجريبي للمتصفح.</p>}
      </Card>
      <Card className="!p-2">
        <ToggleRow icon="bell" title="الإشعارات" sub="إشعارات المنبهات والتذكيرات" on={s.notif.enabled} set={(v) => actions.setNotif({ enabled: v })} />
        <ToggleRow icon="volume" title="الصوت" sub="صوت المنبه/التذكير" on={s.notif.sound} set={(v) => actions.setNotif({ sound: v })} />
        <ToggleRow icon="vibrate" title="الاهتزاز" sub="نمط اهتزاز أصلي" on={s.notif.vibrate} set={(v) => actions.setNotif({ vibrate: v })} />
        <ToggleRow icon="sparkle" title="معاينة التفاصيل" sub="إظهار اسم المنبه أو المهمة" on={s.notif.preview} set={(v) => actions.setNotif({ preview: v })} />
        <ToggleRow icon="moon" title="الأوقات الهادئة" sub={`${s.notif.quietFrom} – ${s.notif.quietTo}`} on={s.notif.quiet} set={(v) => actions.setNotif({ quiet: v })} />
      </Card>
      <NativeOnlyNote>على أندرويد: قنوات <b>Alarms</b> (صوت عالٍ + Full-screen)، <b>Reminders</b>، و<b>Companion</b>؛ إذن POST_NOTIFICATIONS لأندرويد ١٣+؛ إعادة الجدولة بعد BOOT؛ واختبار إشعار حقيقي داخل التطبيق. لا تُعرض أزرار لا تعمل.</NativeOnlyNote>
      <WebOnlyNotice>المتصفح لا يمكنه ضمان إشعار عند إغلاق الصفحة. كل التحذيرات دي لا تظهر في تطبيق أندرويد.</WebOnlyNotice>
    </div>
  );
}

function CompanionSettings({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const cfg = s.companion;
  const moods: { id: Mood; ar: string }[] = [{ id: "idle", ar: "هادي" }, { id: "happy", ar: "سعيد" }, { id: "think", ar: "بيفكر" }, { id: "sleep", ar: "نايم" }, { id: "celebrate", ar: "بيحتفل" }];
  return (
    <div className="space-y-3 pb-3">
      <SubHeader title="الرفيق" onBack={() => go("me")} eyebrow="COMPANION · فوق التطبيقات" />
      <Card className="flex flex-col items-center py-4 text-center" style={{ background: "linear-gradient(150deg, #eef5ef, #fcf6e9)" }}>
        <RobotMini size={92} family={seasonFor(new Date()).id} mood={cfg.emotion} />
        <p className="mt-2 text-[13px] font-extrabold">رفيقك {moods.find((m) => m.id === cfg.emotion)?.ar}</p>
        <p className="mt-0.5 text-[10px] muted">اسحبه من أي مكان في التطبيق، اضغطه يكلمك.</p>
        <div className="mt-2 flex gap-1.5">
          <button onClick={() => actions.setCompanion({ overlayDemo: true })} className="btn btn-soft !min-h-8 !py-1 !text-[10px]"><Icon name="maximize" size={13} />معاينة فوق الهاتف</button>
          <button onClick={() => actions.setCompanion({ hidden: true })} className="btn btn-ghost !min-h-8 !py-1 !text-[10px]"><Icon name="eye-off" size={13} />إخفاء</button>
        </div>
      </Card>
      <Card className="!p-2">
        <ToggleRow icon="bot" title="تفعيل الرفيق" sub="ظهور داخل التطبيق وفوق التطبيقات" on={cfg.enabled} set={(v) => actions.setCompanion({ enabled: v, hidden: !v ? true : false })} />
        <ToggleRow icon="sparkle" title="الفقاعات والنصائح" sub="جُمل قصيرة حسب وقتك" on={cfg.bubbles} set={(v) => actions.setCompanion({ bubbles: v })} />
        <ToggleRow icon="bell" title="إشعارات الرفيق" sub="تذكيرات ودّية (أندرويد)" on={cfg.notify} set={(v) => actions.setCompanion({ notify: v })} />
      </Card>
      <Card>
        <p className="mb-1.5 text-[11px] font-bold">الحجم</p>
        <input type="range" min={0.7} max={1.35} step={0.05} value={cfg.size} onChange={(e) => actions.setCompanion({ size: Number(e.target.value) })} className="w-full accent-[var(--accent)]" />
        <div className="flex justify-between text-[8.5px] muted"><span>صغير</span><span>كبير</span></div>
        <p className="mb-1.5 mt-3 text-[11px] font-bold">الشفافية</p>
        <input type="range" min={0.4} max={1} step={0.05} value={cfg.opacity} onChange={(e) => actions.setCompanion({ opacity: Number(e.target.value) })} className="w-full accent-[var(--accent)]" />
        <p className="mb-1.5 mt-3 text-[11px] font-bold">الحالة</p>
        <div className="flex flex-wrap gap-1.5">{moods.map((m) => <button key={m.id} onClick={() => actions.setCompanion({ emotion: m.id })} className="chip !text-[10px]" aria-pressed={cfg.emotion === m.id}>{m.ar}</button>)}</div>
        <p className="mb-1.5 mt-3 text-[11px] font-bold">الملابس والزينة</p>
        <div className="flex flex-wrap gap-1.5">{([{ id: "auto", ar: "تلقائي بالموسم" }, { id: "gold", ar: "ذهبي/رمضان" }, { id: "snow", ar: "شتوي" }, { id: "national", ar: "وطني" }] as const).map((o) => <button key={o.id} onClick={() => actions.setCompanion({ outfit: o.id })} className="chip !text-[10px]" aria-pressed={cfg.outfit === o.id}>{o.ar}</button>)}</div>
      </Card>
      <WebOnlyNotice>وضع «فوق التطبيقات» في الويب معاينة داخل الصفحة فقط. نسخة Android تستخدم <b>SYSTEM_ALERT_WINDOW + Foreground Service</b> لتظهر فوق كل التطبيقات، مع إخفاء فوري وفتح التطبيق باللمس.</WebOnlyNotice>
      <button onClick={() => actions.setCompanion({ overlayDemo: true })} className="btn btn-primary w-full">جرّب وضع فوق التطبيقات</button>
    </div>
  );
}

function SettingsScreen({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const [reset, setReset] = useState(false);
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    const text = reportText();
    try { await navigator.clipboard.writeText(text); setCopied(true); window.setTimeout(() => setCopied(false), 2000); } catch { setCopied(false); }
  };
  return (
    <div className="space-y-3 pb-3">
      <SubHeader title="الإعدادات" onBack={() => go("me")} eyebrow="SETTINGS" />
      <Card>
        <p className="text-[11px] font-bold">تنسيق الوقت</p>
        <div className="mt-1.5 flex items-center justify-between rounded-xl px-2.5 py-2" style={{ background: "var(--soft)" }}>
          <div><p className="text-[11.5px] font-extrabold">١٢ ساعة دائمًا</p><p className="mt-0.5 text-[9px] muted">ص/م — لا يوجد خيار ٢٤ ساعة</p></div>
          <Icon name="lock" size={15} className="accent" />
        </div>
      </Card>
      <Card className="!p-2">
        <ToggleRow icon="sparkles" title="الزخارف والزينة" sub="صور موسمية واقعية وزخارف" on={s.intensity !== "off"} set={(v) => store.set({ intensity: v ? "subtle" : "off" })} />
        <ToggleRow icon="moon" title="تقليل الحركة" sub="أداء أسلم وإرهاق أقل" on={s.reduceMotion} set={(v) => store.set({ reduceMotion: v })} />
        <ToggleRow icon="star" title="تغيير الزينة مع الموسم" sub="رمضان، العيد، الربيع، الخريف" on={s.autoSeason} set={(v) => store.set({ autoSeason: v })} />
        <div className="px-2 py-2"><p className="mb-1.5 text-[10.5px] font-bold">كثافة الزخرفة</p><Segmented value={s.intensity} onChange={(v) => store.set({ intensity: v })} options={[{ id: "off", label: "بسيط" }, { id: "subtle", label: "هادي" }, { id: "rich", label: "غني" }, { id: "festival", label: "مهرجان" }]} /></div>
        <ToggleRow icon="bot" title="الرفيق" sub="يمكنك إظهاره أو إخفاؤه من صفحته" on={s.companion.enabled && !s.companion.hidden} set={(v) => actions.setCompanion({ enabled: v, hidden: !v })} />
      </Card>
      <Card>
        <p className="text-[11px] font-bold">الصلاحيات على أندرويد</p>
        <div className="mt-1.5 space-y-1.5">
          {[
            ["المنبهات الدقيقة", "SCHEDULE_EXACT_ALARM · USE_EXACT_ALARM", "alarm"],
            ["الإشعارات", "POST_NOTIFICATIONS (أندرويد ١٣+)", "bell"],
            ["فوق التطبيقات", "SYSTEM_ALERT_WINDOW للرفيق العائم", "layers"],
            ["الموقع", "ACCESS_COARSE_LOCATION لحساب المواقيت", "location"],
            ["الصوتيات والملفات", "READ_MEDIA_AUDIO + OpenDocument", "music"],
            ["الودجتس", "AppWidgetProvider + requestPinAppWidget", "widget"],
          ].map(([t, sub, icon]) => <div key={t} className="flex items-center gap-2"><span className="grid h-7 w-7 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={icon as never} size={13} /></span><div className="min-w-0 flex-1"><p className="text-[10.5px] font-bold">{t}</p><p className="text-[8px] muted" dir="ltr">{sub}</p></div><Icon name="shield" size={13} className="accent" /></div>)}
        </div>
      </Card>
      <Card>
        <div className="flex items-center justify-between gap-2">
          <div><p className="text-[11.5px] font-extrabold">قائمة الإصلاحات جاهزة للنسخ</p><p className="mt-0.5 text-[9px] muted">كل مشكلة، إصلاحها، وتقنية أندرويد المستخدمة</p></div>
          <button onClick={copy} className="btn btn-soft !min-h-8 !px-2.5 !text-[10px]">{copied ? <><Icon name="check" size={13} />تم النسخ</> : <><Icon name="copy" size={13} />نسخ</>}</button>
        </div>
        <button onClick={() => go("me", "report")} className="mt-2 flex w-full items-center justify-between rounded-xl px-2.5 py-2" style={{ background: "var(--surface-2)" }}><span className="text-[10.5px] font-bold">عرض قائمة المشاكل والإصلاحات ({REPORT_ITEMS.length})</span><Icon name="chevron-left" size={14} className="muted" /></button>
      </Card>
      <Card style={{ borderColor: "#ebcdc3" }}>
        <p className="text-[11.5px] font-extrabold" style={{ color: "#9a3f28" }}>إعادة ضبط البيانات</p>
        <p className="mt-0.5 text-[9.5px] muted">يحذف المنبهات والمهام والودجتس المحفوظة في هذه المعاينة.</p>
        <button onClick={() => setReset(true)} className="btn btn-ghost mt-2 w-full !min-h-9 !text-[11px]" style={{ color: "#9a3f28" }}><Icon name="refresh" size={14} />إعادة ضبط</button>
      </Card>
      <WebOnlyNotice>الإعدادات المتقدمة للصلاحيات وSYSTEM_ALERT_WINDOW تعيش في نسخة Android الأصلية، ويتم فحصها عبر Settings.canDrawOverlays وAlarmManager.canScheduleExactAlarms.</WebOnlyNotice>
      <Sheet open={reset} onClose={() => setReset(false)} title="إعادة ضبط البيانات؟" subtitle="لا يمكن التراجع عن هذا الإجراء."
        footer={<div className="flex gap-2"><button onClick={() => setReset(false)} className="btn btn-ghost flex-1">تراجع</button><button onClick={() => { store.reset(); setReset(false); go("today"); }} className="btn btn-primary flex-1">إعادة الضبط</button></div>}>
        <p className="text-[11px] leading-relaxed muted">هيتم حذف كل البيانات المحفوظة في هذه المعاينة وإرجاع البيانات التجريبية. مش بيأثر على تطبيق أندرويد الأصلي.</p>
      </Sheet>
    </div>
  );
}

function ReportScreen({ go }: { go: (tab: string, sub?: string) => void }) {
  const [copied, setCopied] = useState(false);
  const [filter, setFilter] = useState<"all" | "P0" | "P1" | "P2">("all");
  const items = REPORT_ITEMS.filter((r) => filter === "all" || r.priority === filter);
  const copy = async () => {
    try { await navigator.clipboard.writeText(reportText()); setCopied(true); window.setTimeout(() => setCopied(false), 2200); } catch { setCopied(false); }
  };
  return (
    <div className="space-y-3 pb-3">
      <SubHeader title="مركز الجودة" onBack={() => go("me")} eyebrow="REPAIR REPORT · جاهز للنسخ" />
      <Card className="relative overflow-hidden" style={{ background: "linear-gradient(145deg, #eef4ee, #fbf4e3)" }}>
        <Ornament family="autumn" size={110} className="!absolute -bottom-6 -left-4 opacity-40" rotate={-20} />
        <div className="relative">
          <div className="flex items-center gap-2"><span className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Icon name="shield" size={18} /></span><div><p className="text-[13px] font-extrabold">تمت مراجعة التطبيق وإصلاحه</p><p className="text-[9.5px] muted">{REPORT_ITEMS.length} مشكلة موثقة · Kotlin + Jetpack Compose</p></div></div>
          <p className="mt-2 text-[10.5px] leading-relaxed muted">كل بند يوضح الخلل الأصلي، الإصلاح المنفذ، وتقنية أندرويد المقابلة. الواجهة محافظة على نفس الشكل والتصميم، والمنطق أصبح أصليًا.</p>
          <button onClick={copy} className="btn btn-primary mt-2.5 !min-h-9 !py-1.5 !text-[11px]">{copied ? <><Icon name="check" size={14} />تم نسخ القائمة</> : <><Icon name="copy" size={14} />نسخ القائمة كاملة</>}</button>
        </div>
      </Card>
      <div className="flex gap-1.5">{(["all", "P0", "P1", "P2"] as const).map((p) => <button key={p} onClick={() => setFilter(p)} className="chip flex-1 !justify-center !text-[10px]" aria-pressed={filter === p}>{p === "all" ? "الكل" : p}</button>)}</div>
      <div className="space-y-2">
        {items.map((r, i) => (
          <Card key={r.id}>
            <div className="flex items-start gap-2">
              <span className="grid h-6 w-6 flex-none place-items-center rounded-lg text-[9px] font-extrabold" style={{ background: r.priority === "P0" ? "#f7e8e3" : r.priority === "P1" ? "var(--soft-gold)" : "var(--soft)", color: r.priority === "P0" ? "#9a3f28" : r.priority === "P1" ? "#7a5c17" : "var(--accent)" }}>{r.priority}</span>
              <div className="min-w-0 flex-1">
                <p className="text-[11.5px] font-extrabold leading-snug">{i + 1}. {r.title}</p>
                <p className="mt-1 text-[9.5px] leading-relaxed muted"><b style={{ color: "var(--text)" }}>المشكلة: </b>{r.problem}</p>
                <p className="mt-1 text-[9.5px] leading-relaxed" style={{ color: "var(--accent-strong)" }}><b>الإصلاح: </b>{r.fix}</p>
                <div className="mt-1.5 flex flex-wrap gap-1"><Tag tone="green">{r.area}</Tag><Tag tone="soft" >{r.native}</Tag></div>
              </div>
            </div>
          </Card>
        ))}
      </div>
      <p className="text-center text-[9px] leading-relaxed muted">الملف التقني الكامل والأوامر في <span dir="ltr" className="font-mono">android/README.md</span> و<span dir="ltr" className="font-mono">ANDROID_NATIVE_FIXES.md</span></p>
    </div>
  );
}

function SubHeader({ title, eyebrow, onBack }: { title: string; eyebrow: string; onBack: () => void }) {
  return <ScreenHeader title={title} eyebrow={eyebrow} right={<button onClick={onBack} className="btn btn-ghost !min-h-9 !px-2.5 !text-[11px]"><Icon name="arrow-left" size={15} />رجوع</button>} />;
}

function RowBtn({ icon, title, value, onClick }: { icon: "location" | "compass"; title: string; value: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="flex w-full items-center gap-2.5 rounded-xl px-2 py-2.5 text-start">
      <span className="grid h-8 w-8 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={icon} size={15} /></span>
      <span className="flex-1 text-[11.5px] font-bold">{title}</span>
      <span className="max-w-[55%] truncate text-[10px] muted">{value}</span>
      <Icon name="chevron-left" size={13} className="muted" />
    </button>
  );
}

function ToggleRow({ icon, title, sub, on, set }: { icon: Parameters<typeof Icon>[0]["name"]; title: string; sub: string; on: boolean; set: (v: boolean) => void }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl px-2 py-2.5" style={{ borderBottom: "1px solid var(--line)" }}>
      <span className="grid h-8 w-8 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={icon} size={15} /></span>
      <div className="min-w-0 flex-1"><p className="text-[11.5px] font-bold">{title}</p><p className="truncate text-[9px] muted">{sub}</p></div>
      <Toggle on={on} onChange={set} label={title} />
    </div>
  );
}

function FAMILY_ACCENT(cityId: string) {
  return cityId === "london" || cityId === "paris" ? "#3d5568" : cityId === "makkah" || cityId === "madinah" ? "#4a3c28" : "#2f5b4b";
}

void useEffect;
