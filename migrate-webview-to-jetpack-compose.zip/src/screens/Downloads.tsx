import { useMemo, useRef, useState } from "react";
import { Icon } from "../components/icons";
import { Card, EmptyState, NativeOnlyNote, ScreenHeader, Sheet, Tag, WebOnlyNotice } from "../components/ui";

interface Preview { url: string; title: string; description?: string; image?: string; author?: string; site?: string; }
interface Format { id: string; label: string; ext: string; kind: "direct" | "video" | "audio" | "image" | "file"; note: string; }
interface HistoryItem { id: string; name: string; url: string; at: number; status: "started" | "done" | "unsupported"; }

const MIME: Record<string, { label: string; kind: Format["kind"] }> = {
  jpg: { label: "صورة JPEG", kind: "image" }, jpeg: { label: "صورة JPEG", kind: "image" }, png: { label: "صورة PNG", kind: "image" },
  webp: { label: "صورة WebP", kind: "image" }, gif: { label: "صورة GIF", kind: "image" }, svg: { label: "صورة SVG", kind: "image" },
  mp4: { label: "فيديو MP4", kind: "video" }, webm: { label: "فيديو WebM", kind: "video" }, mov: { label: "فيديو MOV", kind: "video" },
  m4a: { label: "صوت M4A", kind: "audio" }, mp3: { label: "صوت MP3", kind: "audio" }, ogg: { label: "صوت OGG", kind: "audio" }, wav: { label: "صوت WAV", kind: "audio" },
  pdf: { label: "مستند PDF", kind: "file" }, zip: { label: "أرشيف ZIP", kind: "file" }, apk: { label: "تطبيق APK", kind: "file" }, epub: { label: "كتاب EPUB", kind: "file" },
};

function extOf(url: string) {
  try { const p = new URL(url).pathname; const m = p.match(/\.([a-z0-9]{2,5})$/i); return m ? m[1].toLowerCase() : ""; } catch { return ""; }
}
function fileName(url: string) {
  try { const p = decodeURIComponent(new URL(url).pathname.split("/").pop() || "ملف"); return p || "ملف"; } catch { return "ملف"; }
}
function hostOf(url: string) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return ""; }
}

function videoId(url: string) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) return u.pathname.slice(1);
    if (u.hostname.includes("youtube.com")) return u.searchParams.get("v") || "";
    return "";
  } catch { return ""; }
}

export function Downloads() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState("");
  const [pasted, setPasted] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try { return JSON.parse(localStorage.getItem("dayflow-downloads-v1") || "[]") as HistoryItem[]; } catch { return []; }
  });
  const inputRef = useRef<HTMLInputElement>(null);

  const ext = extOf(url);
  const direct = !!ext && !!MIME[ext];
  const ytId = videoId(url);
  const site = hostOf(url);

  const formats = useMemo<Format[]>(() => {
    if (!url) return [];
    if (direct) {
      const m = MIME[ext];
      return [{ id: ext, label: `${m.label} · .${ext}`, ext, kind: m.kind, note: "ملف مباشر — التنزيل عبر DownloadManager على أندرويد أو رابط المتصفح هنا" }];
    }
    if (ytId) {
      return [
        { id: "18", label: "MP4 360p — صيغة تقدمية", ext: "mp4", kind: "video", note: "تُستخرج على أندرويد فقط بعد التحقق من توفر الصيغة، بدون DASH أو DRM" },
        { id: "140", label: "M4A صوت", ext: "m4a", kind: "audio", note: "صوت فقط — لا يُعرض زر التنزيل في الويب، ويُتحقق منه أصليًا" },
      ];
    }
    return [];
  }, [url, direct, ext, ytId]);

  const saveHistory = (item: HistoryItem) => {
    setHistory((h) => {
      const next = [item, ...h].slice(0, 30);
      try { localStorage.setItem("dayflow-downloads-v1", JSON.stringify(next)); } catch { /* full storage */ }
      return next;
    });
  };

  const analyze = async (value?: string) => {
    const target = (value ?? url).trim();
    setPreview(null); setError(""); setPasted(false);
    if (!target) { setError("الصق رابطًا أولًا."); return; }
    let parsed: URL;
    try { parsed = new URL(target); } catch { setError("الرابط غير صالح. تأكد إنه يبدأ بـ https://"); return; }
    if (!["http:", "https:"].includes(parsed.protocol)) { setError("يُسمح بروابط http/https فقط."); return; }
    setUrl(target);
    const fallback: Preview = { url: target, title: direct ? fileName(target) : parsed.hostname.replace(/^www\./, ""), site, description: direct ? MIME[ext]?.label : "المعاينة الكاملة للعنوان والغلاف والوصف تتم على أندرويد عبر قراءة OpenGraph مباشرة بدون CORS.", image: ytId ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg` : undefined };
    setLoading(true);
    try {
      if (ytId) {
        fallback.image = `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg`;
        fallback.title = "فيديو يوتيوب";
      }
      if (!direct) {
        const controller = new AbortController();
        const timer = window.setTimeout(() => controller.abort(), 8000);
        const res = await fetch(`https://noembed.com/embed?url=${encodeURIComponent(target)}`, { signal: controller.signal });
        window.clearTimeout(timer);
        if (res.ok) {
          const data = await res.json() as { title?: string; author_name?: string; thumbnail_url?: string; provider_name?: string; error?: string };
          if (!data.error) {
            fallback.title = data.title || fallback.title;
            fallback.author = data.author_name;
            fallback.image = data.thumbnail_url || fallback.image;
            fallback.site = data.provider_name || fallback.site;
          }
        }
      }
      setPreview(fallback);
    } catch {
      setPreview(fallback);
      setError("تعذّر جلب معاينة الموقع من المتصفح (CORS أو حجب). مش بنعرضش بيانات وهمية — على أندرويد بتتم القراءة أصلًا عبر OkHttp + Jsoup.");
    } finally { setLoading(false); }
  };

  const startDownload = () => {
    if (!url || !direct) return;
    const a = document.createElement("a");
    a.href = url; a.download = fileName(url); a.rel = "noopener"; a.target = "_blank";
    document.body.appendChild(a); a.click(); a.remove();
    saveHistory({ id: crypto.randomUUID(), name: fileName(url), url, at: Date.now(), status: "started" });
  };

  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) { setUrl(text); void analyze(text); setPasted(true); }
      else setError("الحافظة فاضية.");
    } catch {
      setError("الوصول للحافظة ممنوع من المتصفح. اضغط في خانة الرابط والصق يدويًا (Ctrl+V). على أندرويد الصق من زر التطبيق مباشرة.");
      inputRef.current?.focus();
    }
  };

  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="التحميل" eyebrow="MEDIA HUB · أصلي" subtitle="الصق أو شارك رابطًا — معاينة غنية وتنزيل حقيقي" right={<Tag tone="green"><Icon name="shield" size={11} />بدون CORS</Tag>} />

      <Card className="relative overflow-hidden">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 flex-none place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Icon name="link" size={17} /></span>
          <p className="flex-1 text-[12px] font-extrabold">معاينة الرابط وتحميله</p>
          <button onClick={paste} className="chip !text-[10px]"><Icon name="clipboard" size={12} />{pasted ? "تم اللصق" : "لصق"}</button>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); void analyze(); }} className="mt-2.5 flex gap-1.5">
          <input ref={inputRef} value={url} onChange={(e) => setUrl(e.target.value)} inputMode="url" dir="ltr" className="field flex-1 !text-[11.5px]" placeholder="https://… الصق رابط هنا" aria-label="رابط التحميل" />
          <button className="btn btn-primary !min-h-11 !px-3.5" disabled={loading} aria-label="تحليل">{loading ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : <Icon name="sparkles" size={17} />}</button>
        </form>
        <div className="mt-2 flex flex-wrap gap-1.5">
          <button onClick={() => { const u = `${window.location.origin}/images/hero-dawn.jpg`; setUrl(u); void analyze(u); }} className="chip !text-[9.5px]"><Icon name="image" size={11} />جرّب ملف صورة حقيقي</button>
          <button onClick={() => { const u = `${window.location.origin}/images/ornament-lantern.png`; setUrl(u); void analyze(u); }} className="chip !text-[9.5px]"><Icon name="image" size={11} />PNG شفاف</button>
        </div>
        {error && <div className="notice notice-warn mt-2"><Icon name="alert" size={14} className="mt-0.5 flex-none" /><span>{error}</span></div>}
      </Card>

      {preview && (
        <Card className="pop !p-0 overflow-hidden">
          <div className="relative h-[132px] w-full overflow-hidden" style={{ background: "linear-gradient(135deg, #e7ede7, #f4ecd8)" }}>
            {preview.image ? <img src={preview.image} alt="غلاف المعاينة" className="h-full w-full object-cover" onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }} /> : (
              <div className="flex h-full flex-col items-center justify-center gap-1.5" style={{ color: "var(--accent-strong)" }}>
                <Icon name={direct ? "file" : "globe" as never} size={30} />
                <span className="text-[11px] font-bold">معاينة صفحة الويب</span>
              </div>
            )}
            <span className="absolute end-2 top-2 rounded-full bg-black/55 px-2 py-1 text-[9px] font-bold text-white backdrop-blur">{preview.site || site}</span>
          </div>
          <div className="p-3.5">
            <p className="text-[13px] font-extrabold leading-snug">{preview.title || "بدون عنوان"}</p>
            <p className="mt-1 text-[10.5px] leading-relaxed muted">{preview.author ? `${preview.author} · ` : ""}{preview.description || "لا يوجد وصف متاح."}</p>
            <div className="mt-2 flex flex-wrap gap-1"><Tag tone="soft">{direct ? MIME[ext]?.label : "صفحة/وسائط"}</Tag>{preview.author && <Tag tone="gold">{preview.author}</Tag>}{ytId && <Tag tone="warn"><Icon name="play" size={9} />فيديو</Tag>}</div>
            <div className="mt-2.5 flex items-center gap-1.5">
              {direct ? <button onClick={startDownload} className="btn btn-primary flex-1 !min-h-9 !py-1.5 !text-[11.5px]"><Icon name="download" size={15} />تنزيل الملف ({ext.toUpperCase()})</button>
                : <button onClick={() => setPasted(true)} className="btn btn-soft flex-1 !min-h-9 !py-1.5 !text-[11px]"><Icon name="smartphone" size={14} />التنزيل يتم في أندرويد</button>}
              <button onClick={async () => { try { await navigator.clipboard.writeText(url); } catch { /* no clipboard */ } }} className="btn btn-ghost !min-h-9 !px-2.5" aria-label="نسخ الرابط"><Icon name="copy" size={15} /></button>
            </div>
          </div>
        </Card>
      )}

      {formats.length > 0 && (
        <Card>
          <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">الصيغ المكتشفة</h3><Tag tone={direct ? "green" : "gold"}>{direct ? "متاحة الآن" : "أندرويد"}</Tag></div>
          <div className="space-y-1.5">
            {formats.map((f) => (
              <div key={f.id} className="flex items-center gap-2 rounded-xl px-2.5 py-2" style={{ background: "var(--surface-2)" }}>
                <span className="grid h-8 w-8 flex-none place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name={f.kind === "audio" ? "music" : f.kind === "image" ? "image" : f.kind === "video" ? "play" : "file"} size={14} /></span>
                <div className="min-w-0 flex-1"><p className="truncate text-[11px] font-bold">{f.label}</p><p className="text-[8.5px] leading-snug muted">{f.note}</p></div>
                {direct ? <button onClick={startDownload} className="btn btn-soft !min-h-7 !px-2 !text-[9.5px]"><Icon name="download" size={12} />تنزيل</button> : <span className="rounded-md px-1.5 py-0.5 text-[8px] font-bold" style={{ background: "var(--soft-gold)", color: "#7a5c17" }}>أصلي</span>}
              </div>
            ))}
          </div>
          {!direct && <div className="mt-2"><WebOnlyNotice>الويب لا يستطيع استخراج روابط الفيديو (CORS/DRM). نسخة أندرويد تستخدم <b>InnerTube</b> وتتحقق من توفر الصيغة قبل العرض. لا يتم اختراع أحجام أو صيغ غير متاحة.</WebOnlyNotice></div>}
        </Card>
      )}

      <div className="grid gap-2">
        <NativeOnlyNote><b>على أندرويد:</b> قراءة OpenGraph وJSON-LD عبر OkHttp/Jsoup بدون CORS، والتنزيل عبر DownloadManager إلى مجلد Downloads، مع إشعار تقدم حقيقي وإمكانية الإلغاء.</NativeOnlyNote>
        <WebOnlyNotice>لو موقع رفض الوصول من المتصفح هتظهر رسالة صريحة بدل بيانات مزيفة. الصور والملفات المباشرة هنا تعمل فعليًا في الويب للاختبار.</WebOnlyNotice>
      </div>

      <Card>
        <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">سجل التنزيلات</h3>{history.length > 0 && <button onClick={() => { setHistory([]); localStorage.removeItem("dayflow-downloads-v1"); }} className="text-[9.5px] font-bold" style={{ color: "#9a3f28" }}>مسح</button>}</div>
        {history.length === 0 ? <EmptyState family="summer" icon="download" title="مفيش تنزيلات لسه" hint="أول ملف تنزّله هيظهر هنا بحالته الحقيقية." /> : (
          <div className="space-y-1">
            {history.map((h) => (
              <div key={h.id} className="flex items-center gap-2 py-1.5">
                <Icon name="file" size={15} className="accent" />
                <div className="min-w-0 flex-1"><p className="truncate text-[10.5px] font-bold">{h.name}</p><p className="truncate text-[8.5px] muted" dir="ltr">{h.url}</p></div>
                <span className="text-[8px] font-bold" style={{ color: h.status === "started" ? "var(--accent)" : "var(--muted)" }}>{h.status === "started" ? "بدأ" : "غير مدعوم"}</span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

void Sheet;
