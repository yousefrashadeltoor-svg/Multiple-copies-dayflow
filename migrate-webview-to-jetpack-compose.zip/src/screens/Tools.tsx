import { useEffect, useRef, useState } from "react";
import { Icon, type IconName } from "../components/icons";
import { Card, Ornament, ScreenHeader, Sheet, Tag, WebOnlyNotice } from "../components/ui";
import { actions, arabicDate, cityOf, hijriLabel, todayKey, useDayflow } from "../lib/data";
import { PRAYERS, prayerTimes } from "../lib/prayer";

const TOOLS: { id: string; sub?: string; icon: IconName; title: string; sub2: string; tone?: string }[] = [
  { id: "widgets", sub: "widgets", icon: "widget", title: "الودجتس", sub2: "تصاميم حقيقية للشاشة الرئيسية", tone: "gold" },
  { id: "prayer", sub: "prayer", icon: "moon", title: "مواقيت الصلاة", sub2: "دقيقة حسب مدينتك والمنطقة الزمنية", tone: "green" },
  { id: "focus", sub: "focus", icon: "focus", title: "التركيز", sub2: "مؤقت بومودورو حقيقي", tone: "green" },
  { id: "habits", sub: "habits", icon: "heart", title: "العادات", sub2: "تسجيل يومي وسلاسل", tone: "gold" },
  { id: "notes", sub: "notes", icon: "book", title: "الملاحظات", sub2: "أفكار صغيرة محفوظة", tone: "green" },
  { id: "alarms", icon: "alarm", title: "المنبهات", sub2: "أصلي ودقيق", tone: "gold" },
  { id: "downloads", icon: "download", title: "التحميل", sub2: "روابط ووسائط", tone: "green" },
  { id: "ai", icon: "sparkles", title: "الرفيق الذكي", sub2: "مساعد محلي", tone: "gold" },
  { id: "report", sub: "report", icon: "shield", title: "مركز الجودة", sub2: "كل الإصلاحات موثقة", tone: "green" },
];

export function Tools({ go, sub }: { go: (tab: string, sub?: string) => void; sub?: string }) {
  const s = useDayflow();
  const city = cityOf(s);
  const pr = prayerTimes(city, new Date(), s.methodId, s.asrFactor);
  const key = todayKey();
  const [blank, setBlank] = useState(false);
  const [newHabit, setNewHabit] = useState("");
  const [note, setNote] = useState("");
  const [focusOpen, setFocusOpen] = useState(false);

  if (sub === "habits") {
    return (
      <div className="space-y-3 pb-3">
        <ScreenHeader title="العادات" eyebrow="HABITS" subtitle="سجّل عاداتك النهاردة — خطوة صغيرة كل يوم" right={<button onClick={() => setBlank(true)} className="btn btn-primary !min-h-10 !px-3"><Icon name="plus" size={16} />عادة</button>} />
        <div className="grid grid-cols-2 gap-2.5">
          {s.habits.map((h) => {
            const on = h.log.includes(key);
            const streak = (() => { let c = 0; for (let i = 0; i < 60; i++) { const d = new Date(); d.setDate(d.getDate() - i); const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; if (h.log.includes(k)) c++; else if (i > 0) break; } return c; })();
            return (
              <Card key={h.id} onClick={() => actions.toggleHabit(h.id)} className="!p-3.5" style={{ background: on ? "linear-gradient(150deg, var(--soft), var(--surface))" : "var(--surface)" }}>
                <div className="flex items-start justify-between"><span className="text-[22px]">{h.emoji}</span><span className="grid h-6 w-6 place-items-center rounded-full border" style={{ borderColor: on ? "var(--accent)" : "var(--line-strong)", background: on ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{on && <Icon name="check" size={13} strokeWidth={3} />}</span></div>
                <p className="mt-2 text-[13px] font-extrabold">{h.ar}</p>
                <div className="mt-1 flex items-center gap-1"><Icon name="zap" size={10} className="gold" /><p className="text-[9.5px] font-semibold muted">{streak} يوم متتالي</p></div>
                <div className="mt-2 flex gap-[3px]">{[...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); const k = d.toISOString().slice(0, 10); return <span key={i} className="h-1.5 flex-1 rounded-full" style={{ background: h.log.includes(k) ? h.color : "var(--line)" }} />; })}</div>
              </Card>
            );
          })}
        </div>
        <WebOnlyNotice>الإشعارات والتذكيرات الدورية للعادات تعمل في أندرويد عبر قنوات إشعارات وWorkManager. في المتصفح التسجيل محفوظ فقط.</WebOnlyNotice>
      </div>
    );
  }

  if (sub === "notes") {
    return (
      <div className="space-y-3 pb-3">
        <ScreenHeader title="الملاحظات" eyebrow="NOTES" subtitle="كل فكرة تستاهل تتكتب" />
        <form onSubmit={(e) => { e.preventDefault(); if (!note.trim()) return; actions.addNote(note.trim()); setNote(""); }} className="flex gap-2">
          <input value={note} onChange={(e) => setNote(e.target.value)} className="field" placeholder="اكتب ملاحظة…" />
          <button className="btn btn-primary !px-3" aria-label="إضافة"><Icon name="plus" size={18} /></button>
        </form>
        <div className="space-y-2">
          {s.notes.map((n) => (
            <Card key={n.id} className="relative overflow-hidden">
              <div className="absolute inset-y-0 start-0 w-1" style={{ background: n.pinned ? "var(--accent2)" : "var(--line)" }} />
              <div className="flex items-start gap-2">
                <p className="flex-1 whitespace-pre-wrap text-[12.5px] leading-relaxed">{n.text}</p>
                <button onClick={() => actions.togglePin(n.id)} aria-label="تثبيت" style={{ color: n.pinned ? "var(--accent2)" : "var(--muted)" }}><Icon name="star" size={15} filled={n.pinned} /></button>
                <button onClick={() => actions.removeNote(n.id)} aria-label="حذف" className="muted"><Icon name="trash" size={14} /></button>
              </div>
              <p className="mt-2 text-[9px] muted">{new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit", hour12: true }).format(new Date(n.at))}</p>
            </Card>
          ))}
          {s.notes.length === 0 && <p className="py-8 text-center text-[12px] muted">مفيش ملاحظات. ابدأ بفكرة صغيرة.</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="أدوات" eyebrow="TOOLS · كل حاجة في مكان" subtitle={`${arabicDate(new Date())} · ${hijriLabel(new Date())}`} />
      <Card className="relative overflow-hidden" style={{ background: "linear-gradient(145deg, #f2ede0, #faf8f2)" }}>
        <Ornament family="autumn" size={90} className="!absolute -bottom-6 -left-5 opacity-50" rotate={-15} />
        <div className="relative flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-2xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Icon name="moon" size={20} /></span>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold muted">الصلاة القادمة في {city.ar}</p>
            <p className="text-[15px] font-extrabold">{pr.next ? PRAYERS.find((p) => p.key === pr.next?.key)?.ar : "الفجر"} · {pr.next?.text}</p>
          </div>
          <button onClick={() => go("me", "prayer")} className="btn btn-soft !min-h-8 !py-1 !text-[10px]">المواقيت</button>
        </div>
      </Card>
      <div className="grid grid-cols-3 gap-2">
        {TOOLS.map((tool) => (
          <button key={tool.id} onClick={() => tool.id === "alarms" ? go("alarms") : tool.id === "downloads" ? go("downloads") : tool.id === "ai" ? go("ai") : tool.sub ? go("tools", tool.sub) : undefined}
            className="card press flex aspect-square flex-col items-center justify-center gap-1.5 !rounded-2xl px-1.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl" style={{ background: tool.tone === "gold" ? "var(--soft-gold)" : "var(--soft)", color: tool.tone === "gold" ? "#8a6a1c" : "var(--accent)" }}><Icon name={tool.icon} size={19} /></span>
            <span className="text-center text-[11px] font-extrabold leading-tight">{tool.title}</span>
            <span className="line-clamp-2 text-center text-[8.5px] leading-tight muted">{tool.sub2}</span>
          </button>
        ))}
      </div>

      <Card>
        <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">مؤقت التركيز</h3><Tag tone="green">بومودورو</Tag></div>
        <button onClick={() => setFocusOpen(true)} className="flex w-full items-center gap-3 rounded-2xl p-3" style={{ background: "var(--surface-2)" }}>
          <span className="grid h-10 w-10 place-items-center rounded-full" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name="play" size={16} /></span>
          <span className="flex-1 text-start"><span className="block text-[12px] font-bold">٢٥ دقيقة تركيز</span><span className="block text-[10px] muted">منبه حقيقي عند الانتهاء على أندرويد</span></span>
          <Icon name="chevron-left" size={15} className="muted" />
        </button>
      </Card>

      <div className="grid grid-cols-2 gap-2.5">
        <Card className="!p-3.5">
          <p className="text-[10px] muted">الماء النهاردة</p>
          <p className="mt-1 text-[19px] font-extrabold">{((s.water[key] || 0) / 1000).toFixed(2)} <span className="text-[10px] font-medium muted">/ {s.waterGoal / 1000} لتر</span></p>
          <button onClick={() => actions.addWater(250)} className="btn btn-soft mt-2 w-full !min-h-8 !py-1 text-[10.5px]">+٢٥٠ مل</button>
        </Card>
        <Card className="!p-3.5" onClick={() => go("tools", "habits")}>
          <p className="text-[10px] muted">العادات</p>
          <p className="mt-1 text-[19px] font-extrabold">{s.habits.filter((h) => h.log.includes(key)).length}/{s.habits.length}</p>
          <div className="progress mt-2"><i style={{ width: `${s.habits.length ? s.habits.filter((h) => h.log.includes(key)).length / s.habits.length * 100 : 0}%` }} /></div>
        </Card>
      </div>

      <WebOnlyNotice>المؤقتات والمنبهات الأصلية والودجتس والرفيق فوق التطبيقات تعمل في نسخة أندرويد. هذه المعاينة تعرض المنطق والواجهة فقط.</WebOnlyNotice>

      <Sheet open={blank} onClose={() => setBlank(false)} title="عادة جديدة" subtitle="عادة صغيرة قابلة للتكرار"
        footer={<button onClick={() => { if (newHabit.trim()) actions.addHabit(newHabit.trim(), newHabit.trim(), "✨"); setBlank(false); setNewHabit(""); }} className="btn btn-primary w-full">حفظ العادة</button>}>
        <input className="field" value={newHabit} onChange={(e) => setNewHabit(e.target.value)} placeholder="مثال: قراءة ١٠ دقايق" autoFocus />
      </Sheet>

      <FocusTimer open={focusOpen} onClose={() => setFocusOpen(false)} />
    </div>
  );
}

function FocusTimer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [seconds, setSeconds] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [mode, setMode] = useState<"focus" | "break">("focus");
  const interval = useRef<number | null>(null);
  useEffect(() => {
    if (!running) return;
    interval.current = window.setInterval(() => setSeconds((v) => { if (v <= 1) { setRunning(false); return 0; } return v - 1; }), 1000);
    return () => { if (interval.current) window.clearInterval(interval.current); };
  }, [running]);
  const reset = (next: "focus" | "break") => { setMode(next); setRunning(false); setSeconds(next === "focus" ? 25 * 60 : 5 * 60); };
  const pct = 1 - seconds / (mode === "focus" ? 1500 : 300);
  return (
    <Sheet open={open} onClose={onClose} title="مؤقت التركيز" subtitle="٢٥ دقيقة تركيز، ٥ دقايق راحة">
      <div className="flex items-center justify-center py-2">
        <div className="relative grid h-[190px] w-[190px] place-items-center rounded-full" style={{ background: `conic-gradient(var(--accent) ${pct * 360}deg, var(--bg-deep) 0)` }}>
          <div className="grid h-[166px] w-[166px] place-items-center rounded-full" style={{ background: "var(--surface)" }}>
            <p className="text-[38px] font-extrabold tnum" dir="ltr">{String(Math.floor(seconds / 60)).padStart(2, "0")}:{String(seconds % 60).padStart(2, "0")}</p>
            <p className="text-[10px] font-bold muted">{mode === "focus" ? "وقت التركيز" : "استراحة"}</p>
          </div>
        </div>
      </div>
      <div className="flex justify-center gap-1.5"><button onClick={() => reset("focus")} className="chip" aria-pressed={mode === "focus"}>تركيز</button><button onClick={() => reset("break")} className="chip" aria-pressed={mode === "break"}>راحة</button></div>
      <div className="flex gap-2"><button onClick={() => setRunning((r) => !r)} className="btn btn-primary flex-1">{running ? <><Icon name="pause" size={16} />إيقاف مؤقت</> : <><Icon name="play" size={16} />ابدأ</>}</button><button onClick={() => reset(mode)} className="btn btn-ghost !px-3"><Icon name="refresh" size={17} /></button></div>
      <WebOnlyNotice>المؤقت في المتصفح يعمل أثناء فتح الصفحة فقط. على أندرويد يُجدول إشعار عند الانتهاء حتى لو التطبيق مغلق.</WebOnlyNotice>
    </Sheet>
  );
}
