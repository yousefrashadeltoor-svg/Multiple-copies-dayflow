import { useMemo, useState } from "react";
import { Icon } from "../components/icons";
import { Card, Ornament, ScreenHeader, Tag } from "../components/ui";
import { actions, arabicDate, copticLabel, hijriLabel, seasonFor, todayKey, upcomingOccasions, useDayflow } from "../lib/data";
import { PRAYERS, prayerTimes, type City } from "../lib/prayer";
import { cityOf } from "../lib/data";
import { arabicDigits } from "../lib/prayer";

const WEEK = ["أحد", "اتنين", "تلات", "أربع", "خميس", "جمعة", "سبت"];

export function CalendarScreen() {
  const s = useDayflow();
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState(() => todayKey());
  const city = cityOf(s);
  const pr = prayerTimes(city, new Date(), s.methodId, s.asrFactor);
  const occasions = upcomingOccasions(new Date(), 4);
  const fam = seasonFor(new Date());

  const cells = useMemo(() => {
    const y = cursor.getFullYear();
    const m = cursor.getMonth();
    const first = new Date(y, m, 1);
    const days = new Date(y, m + 1, 0).getDate();
    const offset = first.getDay();
    return [...Array.from({ length: offset }).map(() => null), ...Array.from({ length: days }).map((_, i) => new Date(y, m, i + 1))];
  }, [cursor]);

  const selectedDate = new Date(`${selected}T12:00:00`);
  const tasks = s.tasks.filter((t) => t.date === selected);
  const monthLabel = new Intl.DateTimeFormat("ar-EG", { month: "long", year: "numeric" }).format(cursor);
  const shift = (n: number) => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + n, 1));

  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="التقويم" eyebrow="CALENDAR · ثلاث تقاويم" subtitle={arabicDate(new Date())} right={<Tag tone="gold">{fam.ar}</Tag>} />

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <button onClick={() => shift(-1)} className="icon-btn !h-8 !w-8" aria-label="الشهر السابق"><Icon name="chevron-right" size={17} /></button>
          <p className="text-[14px] font-extrabold">{monthLabel}</p>
          <button onClick={() => shift(1)} className="icon-btn !h-8 !w-8" aria-label="الشهر التالي"><Icon name="chevron-left" size={17} /></button>
        </div>
        <div className="mb-1 grid grid-cols-7 text-center">{WEEK.map((d) => <span key={d} className="text-[9px] font-bold muted">{d}</span>)}</div>
        <div className="grid grid-cols-7 gap-y-1">
          {cells.map((d, i) => {
            if (!d) return <span key={`e${i}`} />;
            const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
            const isToday = key === todayKey();
            const isSel = key === selected;
            const hasTasks = s.tasks.some((t) => t.date === key);
            return (
              <button key={key} onClick={() => setSelected(key)} className="relative mx-auto grid h-8 w-8 place-items-center rounded-xl text-[11.5px] font-bold transition-colors"
                style={{ background: isSel ? "var(--accent)" : isToday ? "var(--soft)" : "transparent", color: isSel ? "var(--on-accent)" : "var(--text)" }}>
                {arabicDigits(d.getDate())}
                {hasTasks && <span className="absolute bottom-1 h-1 w-1 rounded-full" style={{ background: isSel ? "#fff" : "var(--accent2)" }} />}
              </button>
            );
          })}
        </div>
        <div className="mt-3 grid grid-cols-3 gap-1.5 border-t pt-3 text-center" style={{ borderColor: "var(--line)" }}>
          <div><p className="text-[11.5px] font-extrabold">{new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "short" }).format(selectedDate)}</p><p className="text-[8.5px] font-bold muted">ميلادي</p></div>
          <div className="border-x" style={{ borderColor: "var(--line)" }}><p className="text-[11.5px] font-extrabold">{hijriLabel(selectedDate).replace(" هـ", "")}</p><p className="text-[8.5px] font-bold muted">هجري</p></div>
          <div><p className="text-[11.5px] font-extrabold">{copticLabel(selectedDate) || "—"}</p><p className="text-[8.5px] font-bold muted">قبطي</p></div>
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-[13px] font-extrabold">مهام {new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(selectedDate)}</h3>
          <Tag>{arabicDigits(tasks.length)}</Tag>
        </div>
        {tasks.length === 0 ? (
          <div className="flex items-center justify-between gap-2 rounded-xl px-3 py-4" style={{ background: "var(--surface-2)" }}>
            <p className="text-[11px] muted">مفيش مهام في اليوم ده.</p>
            <button onClick={() => actions.addTask("مهمة جديدة", selected)} className="btn btn-soft !min-h-8 !py-1 !text-[10.5px]"><Icon name="plus" size={13} />إضافة</button>
          </div>
        ) : (
          <div className="space-y-1">
            {tasks.map((t) => (
              <button key={t.id} onClick={() => actions.toggleTask(t.id)} className="flex w-full items-center gap-2.5 py-1.5 text-start">
                <span className="grid h-5 w-5 flex-none place-items-center rounded-md border-2" style={{ borderColor: "var(--accent)", background: t.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{t.done && <Icon name="check" size={11} strokeWidth={3} />}</span>
                <span className="flex-1 truncate text-[11.5px] font-medium" style={{ textDecoration: t.done ? "line-through" : "none", opacity: t.done ? 0.5 : 1 }}>{t.title}</span>
                {t.urgent && !t.done && <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#bf5a45" }} />}
              </button>
            ))}
            <button onClick={() => actions.addTask("مهمة جديدة", selected)} className="mt-1 flex items-center gap-1 text-[10px] font-bold accent"><Icon name="plus" size={12} />إضافة للتاريخ المحدد</button>
          </div>
        )}
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">المناسبات القادمة</h3><Icon name="star" size={15} className="gold" /></div>
        <div className="space-y-1">
          {occasions.map((occ) => {
            const at = new Date(`${occ.date}T12:00:00`);
            const days = Math.max(0, Math.round((at.getTime() - Date.now()) / 86_400_000));
            const occFam = seasonFor(at);
            return (
              <div key={occ.id} className="relative flex items-center gap-2.5 overflow-hidden rounded-xl px-2 py-2" style={{ background: "var(--surface-2)" }}>
                <Ornament family={occ.family} size={38} className="!relative !inset-auto flex-none" />
                <div className="min-w-0 flex-1"><p className="truncate text-[11.5px] font-extrabold">{occ.ar}</p><p className="text-[9px] muted">{new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "long", weekday: "long" }).format(at)}</p></div>
                <Tag tone={days <= 7 ? "gold" : "soft"}>{days === 0 ? "النهاردة" : `${arabicDigits(days)} يوم`}</Tag>
                <span className="pointer-events-none absolute -bottom-2 -left-3 h-10 w-10 rounded-full opacity-30" style={{ background: occFam.c2 }} />
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">مواقيت الصلاة</h3><span className="text-[10px] muted flex items-center gap-1"><Icon name="location" size={11} />{city.ar}</span></div>
        <div className="grid grid-cols-3 gap-1.5">
          {PRAYERS.map((p) => (
            <div key={p.key} className="rounded-xl px-2 py-2 text-center" style={{ background: pr.next?.key === p.key ? "var(--accent)" : "var(--soft)", color: pr.next?.key === p.key ? "var(--on-accent)" : "inherit" }}>
              <p className="text-[9.5px] font-semibold opacity-75">{p.icon} {p.ar}</p>
              <p className="mt-0.5 text-[13px] font-extrabold tnum">{pr.times[p.key].text}</p>
            </div>
          ))}
        </div>
        <p className="mt-2 text-[9px] leading-relaxed muted">{pr.method.noteAr} · وقت محلي تلقائي ({city.tz.replace("_", " ")}).</p>
      </Card>
    </div>
  );
}

void (undefined as unknown as City);
