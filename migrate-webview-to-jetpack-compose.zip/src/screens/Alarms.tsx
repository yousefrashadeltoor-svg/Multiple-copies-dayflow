import { useEffect, useRef, useState } from "react";
import { Icon } from "../components/icons";
import { Card, EmptyState, NativeOnlyNote, ScreenHeader, Segmented, Sheet, Toggle, WebOnlyNotice } from "../components/ui";
import {
  actions, alarmDaysLabel, DAYS_AR, nextAlarmTime, SOUND_SOURCES, useDayflow,
  type Alarm, type SoundSource,
} from "../lib/data";
import { arabicDigits, PRAYERS, prayerTimes, time12 } from "../lib/prayer";
import { useNow } from "../components/Robot";
import { cityOf } from "../lib/data";

const SOUND_LIBRARY: Record<string, string> = {
  device: "منبه الجهاز الافتراضي",
  library: "صوت الهدوء — DAYFLOW",
  downloaded: "من التحميلات",
};

function emptyAlarm(): Omit<Alarm, "id" | "createdAt"> {
  const h = new Date().getHours();
  return {
    time: `${String(h === 0 ? 7 : h).padStart(2, "0")}:00`, days: [], label: "",
    enabled: true, sound: { source: "device", title: SOUND_LIBRARY.device },
    vibrate: true, snooze: 10, gentle: true,
  };
}

export function RingScreen({ alarm, onClose, onSnooze }: { alarm: Alarm; onClose: () => void; onSnooze: () => void }) {
  const now = useNow(1000);
  const s = useDayflow();
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const nextP = PRAYERS.find((p) => p.key === pr.next?.key);
  const [volumeDown, setVolumeDown] = useState(false);
  const ctxRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    let stopped = false;
    let timer = 0;
    let AudioCtor: typeof AudioContext | undefined;
    try {
      AudioCtor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    } catch { AudioCtor = undefined; }
    if (AudioCtor) {
      let ctx: AudioContext;
      try { ctx = new AudioCtor(); } catch { return () => undefined; }
      ctxRef.current = ctx;
      const beep = () => {
        if (stopped) return;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        const t = ctx.currentTime;
        osc.frequency.setValueAtTime(740, t);
        osc.frequency.exponentialRampToValueAtTime(560, t + 0.35);
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.exponentialRampToValueAtTime(0.16, t + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.55);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(t); osc.stop(t + 0.6);
      };
      beep();
      timer = window.setInterval(beep, 1400);
    }
    try {
      if (navigator.vibrate) navigator.vibrate([400, 220, 400, 900]);
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification(`⏰ ${alarm.label || "منبه DAYFLOW"}`, { body: `${time12(alarm.time)} · قم لصلاة ${nextP?.ar || "الفجر"}`, tag: `alarm-${alarm.id}`, silent: true });
      }
    } catch { /* notification/vibration are unavailable on some browsers */ }
    return () => {
      stopped = true;
      window.clearInterval(timer);
      ctxRef.current?.close().catch(() => undefined);
      try { if (navigator.vibrate) navigator.vibrate(0); } catch { /* noop */ }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [alarm.id]);

  return (
    <div className="ringing" role="dialog" aria-modal="true" aria-label="منبه يرن">
      <div className="relative flex w-full flex-col items-center pt-4">
        <span className="pulse" /><span className="pulse" /><span className="pulse" />
        <div className="bell relative grid h-[92px] w-[92px] place-items-center rounded-full border border-white/20 bg-white/10 backdrop-blur">
          <Icon name="alarm" size={42} />
        </div>
        <p className="mt-6 text-[13px] font-semibold text-white/65">{new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(now)}</p>
        <p className="mt-1 text-[54px] font-extrabold leading-none tracking-tight tnum">{time12(alarm.time)}</p>
        <p className="mt-3 text-[17px] font-semibold">{alarm.label || "منبه"}</p>
        <p className="mt-1.5 text-[12px] text-white/65">صلاة {nextP?.ar || "الفجر"} {pr.times.fajr.text} · فاضل {arabicDigits(pr.next?.inMinutes || 0)} دقيقة</p>
      </div>
      <div className="w-full">
        <div className="mx-auto mb-6 max-w-[300px]">
          <WebOnlyNotice warn>ده رنين تجريبي في المتصفح. في نسخة أندرويد الأصلية يرن المنبه بالكامل عبر AlarmManager + Full-screen notification حتى لو التطبيق مقفول أو الهاتف مقفول.</WebOnlyNotice>
        </div>
        <div className="mb-4 flex items-center justify-between px-2 text-white/60">
          <button onClick={() => setVolumeDown((v) => !v)} className="flex items-center gap-1.5 text-[11px] font-semibold" aria-pressed={volumeDown}><Icon name="volume" size={15} />{volumeDown ? "صوت منخفض" : "صوت الرنين"}</button>
          <span className="text-[10.5px]">غفوة {arabicDigits(alarm.snooze)} دقايق</span>
        </div>
        <div className="flex items-center justify-center gap-3">
          <button onClick={onStopWrap} className="hidden" />
          <button onClick={onSnooze} className="flex h-[74px] w-[74px] flex-col items-center justify-center gap-1 rounded-full border border-white/25 bg-white/10 text-white backdrop-blur transition-transform active:scale-95">
            <Icon name="timer" size={22} /><span className="text-[10px] font-bold">غفوة</span>
          </button>
          <button onClick={onClose} className="flex h-[92px] w-[92px] flex-col items-center justify-center gap-1 rounded-full bg-[#e9efe7] text-[#21372b] shadow-xl transition-transform active:scale-95">
            <Icon name="alarm" size={28} /><span className="text-[12px] font-extrabold">إيقاف</span>
          </button>
        </div>
        <p className="mt-5 text-center text-[10px] text-white/40">لإيقاف المنبه اضغط إيقاف — DAYFLOW</p>
      </div>
    </div>
  );

  function onStopWrap() { onClose(); }
}

export function Alarms({ onPreview }: { onPreview: (alarm: Alarm) => void }) {
  const s = useDayflow();
  const now = useNow(20_000);
  const next = nextAlarmTime(s.alarms, now);
  const [editing, setEditing] = useState<Alarm | "new" | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  return (
    <div className="pb-3">
      <ScreenHeader
        title="المنبهات" eyebrow="ALARMS · أصلي"
        subtitle={next ? `التالي: ${next.alarm.label || "منبه"} · ${new Intl.DateTimeFormat("ar-EG", { weekday: "short", hour: "numeric", minute: "2-digit", hour12: true }).format(next.at)}` : "لا منبهات مفعّلة"}
        right={<button onClick={() => setEditing("new")} className="btn btn-primary !min-h-10 !px-3.5 !text-[12px]"><Icon name="plus" size={16} />جديد</button>}
      />

      <div className="mb-3">
        <NativeOnlyNote>
          المنبهات تُجدول على أندرويد بـ <b>AlarmManager.setAlarmClock()</b> بدقة، مع إذن المنبهات الدقيق، إعادة الجدولة بعد إعادة التشغيل وتغيير الوقت والمنطقة الزمنية، وشاشة رنين كاملة. لا يعتمد الرنين على بقاء التطبيق مفتوحًا.
        </NativeOnlyNote>
      </div>

      {s.alarms.length === 0 ? (
        <EmptyState family="friday" icon="alarm" title="مفيش منبهات لسه" hint="أنشئ منبهًا حقيقيًا في ثوانٍ. اختر الوقت بصيغة ١٢ ساعة، أيام التكرار، ونغمة من هاتفك." action={<button onClick={() => setEditing("new")} className="btn btn-primary"><Icon name="plus" size={16} />اعمل منبه</button>} />
      ) : (
        <div className="space-y-2.5">
          {[...s.alarms].sort((a, b) => a.time.localeCompare(b.time)).map((alarm) => (
            <div key={alarm.id} className="card overflow-hidden">
              <div className="flex items-center gap-3 p-3.5" style={{ opacity: alarm.enabled ? 1 : 0.55 }}>
                <button onClick={() => setEditing(alarm)} className="min-w-0 flex-1 text-start">
                  <div className="flex items-baseline gap-1.5">
                    <p className="text-[30px] font-extrabold leading-none tracking-tight tnum">{time12(alarm.time)}</p>
                    {alarm.gentle && <span className="rounded-full px-1.5 py-0.5 text-[8px] font-bold" style={{ background: "var(--soft)", color: "var(--accent)" }}>لطيف</span>}
                  </div>
                  <p className="mt-1 truncate text-[12px] font-bold">{alarm.label || "منبه"}</p>
                  <p className="mt-0.5 truncate text-[10px] muted">{alarmDaysLabel(alarm)} · {alarm.sound.title}</p>
                </button>
                <div className="flex flex-none items-center gap-1">
                  <button onClick={() => setExpanded(expanded === alarm.id ? null : alarm.id)} className="icon-btn !h-8 !w-8" aria-label="خيارات"><Icon name="more" size={17} /></button>
                  <Toggle label={alarm.label || alarm.time} on={alarm.enabled} onChange={(v) => { actions.updateAlarm(alarm.id, { enabled: v }); if (!v && expanded === alarm.id) setExpanded(null); }} />
                </div>
              </div>
              {expanded === alarm.id && (
                <div className="flex items-center gap-1.5 border-t px-3.5 py-2" style={{ borderColor: "var(--line)", background: "var(--surface-2)" }}>
                  <button onClick={() => onPreview(alarm)} className="chip !text-[10px]" style={{ color: "var(--accent)" }}><Icon name="play" size={11} />جرّب الرنين</button>
                  <button onClick={() => setEditing(alarm)} className="chip !text-[10px]"><Icon name="edit" size={11} />تعديل</button>
                  <button onClick={() => { actions.removeAlarm(alarm.id); setExpanded(null); }} className="chip !text-[10px]" style={{ color: "#9a3f28" }}><Icon name="trash" size={11} />حذف</button>
                  <span className="ms-auto text-[9px] muted">غفوة {arabicDigits(alarm.snooze)} د</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 space-y-2.5">
        <WebOnlyNotice>
          في المتصفح لا يمكن للمنبه الرنين والتطبيق مغلق — دي حقيقة المتصفح وليست خطأ. جرّب زر «جرّب الرنين» لمعاينة صوت المنبه وشاشته.
        </WebOnlyNotice>
        <Card className="!p-3.5" onClick={() => setEditing("new")}>
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 flex-none place-items-center rounded-xl" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name="smartphone" size={17} /></span>
            <div className="min-w-0 flex-1"><p className="text-[12px] font-extrabold">إضافة منبه سريع</p><p className="text-[10px] muted">صيغة ١٢ ساعة فقط · نغمة الهاتف · اهتزاز · غفوة</p></div>
            <Icon name="chevron-left" size={15} className="muted" />
          </div>
        </Card>
      </div>

      {editing && <AlarmEditor alarm={editing === "new" ? null : editing} onClose={() => setEditing(null)} onPreview={onPreview} />}
    </div>
  );
}

function AlarmEditor({ alarm, onClose, onPreview }: { alarm: Alarm | null; onClose: () => void; onPreview: (alarm: Alarm) => void }) {
  const initial = alarm || emptyAlarm();
  const [hh, mm] = initial.time.split(":").map(Number);
  const [hour, setHour] = useState(() => hh % 12 || 12);
  const [minute, setMinute] = useState(() => Math.round(mm / 5) * 5 % 60);
  const [period, setPeriod] = useState<"am" | "pm">(() => (hh >= 12 ? "pm" : "am"));
  const [label, setLabel] = useState(initial.label);
  const [days, setDays] = useState<number[]>(initial.days);
  const [repeat, setRepeat] = useState<"days" | "once">(initial.date ? "once" : initial.days.length ? "days" : "once");
  const [date, setDate] = useState(initial.date || (() => { const d = new Date(); d.setDate(d.getDate() + 1); return d.toISOString().slice(0, 10); })());
  const [soundSource, setSoundSource] = useState<SoundSource>(initial.sound.source);
  const [soundTitle, setSoundTitle] = useState(initial.sound.title);
  const [vibrateOn, setVibrateOn] = useState(initial.vibrate);
  const [snooze, setSnooze] = useState(initial.snooze);
  const [gentle, setGentle] = useState(initial.gentle);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const city = "Egypt";

  const time24 = `${String(period === "pm" ? (hour % 12) + 12 : hour % 12).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;

  const save = () => {
    if (repeat === "days" && days.length === 0) { setError("اختر يومًا واحدًا على الأقل للتنبيه المتكرر، أو اختر مرة واحدة."); return; }
    if (!/^\d{2}:\d{2}$/.test(time24)) { setError("الوقت غير صحيح."); return; }
    const payload = {
      time: time24, label: label.trim(), days: repeat === "days" ? days : [], date: repeat === "once" ? date : undefined,
      enabled: alarm ? alarm.enabled : true, sound: { source: soundSource, title: soundTitle }, vibrate: vibrateOn,
      snooze, gentle,
    };
    if (alarm) actions.updateAlarm(alarm.id, payload);
    else actions.addAlarm(payload);
    setSaved(true);
    window.setTimeout(onClose, 650);
  };

  return (
    <Sheet open onClose={onClose} title={alarm ? "تعديل المنبه" : "منبه جديد"} subtitle="الوقت بصيغة ١٢ ساعة — صباحًا / مساءً"
      footer={<div className="flex gap-2">
        {alarm && <button onClick={() => { actions.removeAlarm(alarm.id); onClose(); }} className="btn btn-ghost !px-3" style={{ color: "#9a3f28" }}><Icon name="trash" size={16} /></button>}
        <button onClick={save} disabled={saved} className="btn btn-primary flex-1">{saved ? <><Icon name="check" size={16} />تم الحفظ والجدولة</> : "حفظ المنبه"}</button>
      </div>}>
      <div className="rounded-[18px] p-3.5" style={{ background: "var(--surface-2)", border: "1px solid var(--line)" }}>
        <p className="mb-2 text-center text-[10.5px] font-bold muted">وقت الرنين</p>
        <div className="flex items-center justify-center gap-1.5" dir="ltr">
          <div className="flex flex-col items-center">
            <button onClick={() => setHour((h) => h === 12 ? 1 : h + 1)} className="icon-btn !h-7 !w-10" aria-label="زيادة الساعة"><Icon name="chevron-down" size={15} className="rotate-180" /></button>
            <p className="w-[76px] text-center text-[42px] font-extrabold leading-none tnum">{arabicDigits(String(hour).padStart(2, "0"))}</p>
            <button onClick={() => setHour((h) => h === 1 ? 12 : h - 1)} className="icon-btn !h-7 !w-10" aria-label="تقليل الساعة"><Icon name="chevron-down" size={15} /></button>
          </div>
          <span className="pb-1 text-[34px] font-bold muted">:</span>
          <div className="flex flex-col items-center">
            <button onClick={() => setMinute((m) => (m + 5) % 60)} className="icon-btn !h-7 !w-10" aria-label="زيادة الدقيقة"><Icon name="chevron-down" size={15} className="rotate-180" /></button>
            <p className="w-[76px] text-center text-[42px] font-extrabold leading-none tnum">{arabicDigits(String(minute).padStart(2, "0"))}</p>
            <button onClick={() => setMinute((m) => (m - 5 + 60) % 60)} className="icon-btn !h-7 !w-10" aria-label="تقليل الدقيقة"><Icon name="chevron-down" size={15} /></button>
          </div>
          <div className="flex flex-col gap-1">
            <button onClick={() => setPeriod("am")} className="chip !justify-center" aria-pressed={period === "am"}>ص</button>
            <button onClick={() => setPeriod("pm")} className="chip !justify-center" aria-pressed={period === "pm"}>م</button>
          </div>
        </div>
        <p className="mt-2 text-center text-[11px] font-bold accent">{time12(time24)}</p>
      </div>

      <label className="block">
        <span className="mb-1 block text-[11px] font-bold">اسم المنبه</span>
        <input className="field" value={label} onChange={(e) => setLabel(e.target.value)} placeholder="مثال: صحيان لصلاة الفجر" maxLength={48} />
      </label>

      <div>
        <Segmented value={repeat} onChange={setRepeat} options={[{ id: "days", label: "أيام محددة" }, { id: "once", label: "مرة واحدة" }]} />
      </div>
      {repeat === "days" ? (
        <div>
          <p className="mb-1.5 text-[11px] font-bold">أيام التكرار</p>
          <div className="flex flex-wrap gap-1.5">
            {DAYS_AR.map((d, i) => (
              <button key={d} onClick={() => setDays((v) => v.includes(i) ? v.filter((x) => x !== i) : [...v, i])} className="chip !text-[10.5px] !px-2.5" aria-pressed={days.includes(i)}>{d}</button>
            ))}
          </div>
          <button onClick={() => setDays([0, 1, 2, 3, 4])} className="mt-1.5 text-[10px] font-bold accent">أيام العمل (حد–خميس)</button>
        </div>
      ) : (
        <label className="block">
          <span className="mb-1 block text-[11px] font-bold">التاريخ</span>
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="field" />
        </label>
      )}

      <div>
        <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold"><Icon name="volume" size={13} />نغمة الرنين</p>
        <div className="grid grid-cols-2 gap-1.5">
          {SOUND_SOURCES.filter((x) => x.id !== "downloaded" || true).map((src) => (
            <button key={src.id} onClick={() => {
              setSoundSource(src.id);
              if (src.id === "files") { setSoundTitle("اختر ملفًا صوتيًا من الهاتف"); fileRef.current?.click(); }
              else if (src.id === "downloaded") setSoundTitle("من التحميلات — اختر من المكتبة");
              else setSoundTitle(SOUND_LIBRARY[src.id]);
            }} className="flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-start text-[10.5px] font-bold" aria-pressed={soundSource === src.id}
              style={{ background: soundSource === src.id ? "var(--soft)" : "var(--surface-2)", border: `1px solid ${soundSource === src.id ? "var(--accent)" : "var(--line)"}`, color: soundSource === src.id ? "var(--accent-strong)" : "var(--text)" }}>
              <Icon name={src.id === "files" ? "file" : src.id === "device" ? "smartphone" : src.id === "library" ? "music" : "download"} size={14} />
              <span className="truncate">{src.ar}</span>
            </button>
          ))}
        </div>
        <input ref={fileRef} type="file" accept="audio/*" className="hidden" onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          setSoundSource("files"); setSoundTitle(f.name);
        }} />
        <div className="mt-1.5 flex items-center gap-2 rounded-xl px-2.5 py-2" style={{ background: "var(--soft-gold)" }}>
          <Icon name="music" size={13} style={{ color: "#8a6a1c" }} />
          <span className="min-w-0 flex-1 truncate text-[10px] font-bold" style={{ color: "#715610" }}>{soundTitle}</span>
          <button onClick={() => onPreview({ ...initial, id: alarm?.id || "preview", createdAt: Date.now(), time: time24, label: label || "منبه", sound: { source: soundSource, title: soundTitle }, days })} className="grid h-6 w-6 place-items-center rounded-full bg-white/60" style={{ color: "#715610" }} aria-label="معاينة النغمة"><Icon name="play" size={11} /></button>
        </div>
        <div className="mt-1"><WebOnlyNotice>اختيار نغمة الجهاز والملفات يعمل على أندرويد عبر نغمة النظام و<b>Storage Access Framework</b> مع حفظ الصلاحية الدائمة للـ URI. في المتصفح المعاينة صوتية فقط.</WebOnlyNotice></div>
      </div>

      <div className="flex items-center justify-between rounded-xl px-3 py-2.5" style={{ background: "var(--surface-2)" }}>
        <div><p className="text-[11.5px] font-bold flex items-center gap-1.5"><Icon name="vibrate" size={14} />اهتزاز</p><p className="text-[9.5px] muted">نمط اهتزاز أصلي على أندرويد</p></div>
        <Toggle on={vibrateOn} onChange={setVibrateOn} label="اهتزاز" />
      </div>
      <div className="flex items-center justify-between rounded-xl px-3 py-2.5" style={{ background: "var(--surface-2)" }}>
        <div><p className="text-[11.5px] font-bold flex items-center gap-1.5"><Icon name="sparkles" size={14} />بداية لطيفة</p><p className="text-[9.5px] muted">صوت يبدأ هادي ويزيد</p></div>
        <Toggle on={gentle} onChange={setGentle} label="بداية لطيفة" />
      </div>
      <div>
        <p className="mb-1.5 text-[11px] font-bold">مدة الغفوة</p>
        <div className="flex gap-1.5">{([5, 10, 15, 20] as const).map((n) => <button key={n} onClick={() => setSnooze(n)} className="chip flex-1 !justify-center !text-[10.5px]" aria-pressed={snooze === n}>{arabicDigits(n)} د</button>)}</div>
      </div>
      {error && <p className="notice notice-warn"><Icon name="alert" size={15} />{error}</p>}
      <p className="text-center text-[9px] muted">التوقيت المحلي · {city}</p>
    </Sheet>
  );
}

void useNow;
