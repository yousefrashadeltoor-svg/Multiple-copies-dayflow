import { useState } from "react";
import { Icon } from "../components/icons";
import { Card, HeaderCrown, Ornament, Ring, Tag, WebOnlyNotice } from "../components/ui";
import { WidgetArt } from "../components/WidgetView";
import {
  actions, alarmCountdown, arabicDate, cityOf, copticLabel, greeting, hijriLabel,
  nextAlarmTime, seasonFor, todayKey, useDayflow, upcomingOccasions, widgetById,
} from "../lib/data";
import { arabicDigits, durationText, PRAYERS, prayerTimes } from "../lib/prayer";
import { useNow } from "../components/Robot";

export function Today({ go }: { go: (tab: string, sub?: string) => void }) {
  const s = useDayflow();
  const now = useNow(20_000);
  const fam = seasonFor(now);
  const city = cityOf(s);
  const pr = prayerTimes(city, now, s.methodId, s.asrFactor);
  const next = nextAlarmTime(s.alarms, now);
  const key = todayKey();
  const tasks = s.tasks.filter((t) => t.date === key);
  const done = tasks.filter((t) => t.done).length;
  const water = s.water[key] || 0;
  const hijri = hijriLabel(now);
  const coptic = copticLabel(now);
  const occasions = upcomingOccasions(now, 4);
  const occ = occasions[0];
  const occDays = occ ? Math.round((new Date(`${occ.date}T12:00:00`).getTime() - now.getTime()) / 86_400_000) : 0;
  const chosen = widgetById(s.selectedWidgetId);
  const [quick, setQuick] = useState("");
  const [hideWebNote, setHideWebNote] = useState(s.webBannerDismissed);

  const dayProgress = (now.getHours() * 60 + now.getMinutes()) / 1440;
  const nextPrayer = PRAYERS.find((p) => p.key === pr.next?.key);
  const doneHabits = s.habits.filter((h) => h.log.includes(key)).length;

  return (
    <div className="space-y-3.5 pb-3">
      <section className="hero" style={{ background: `linear-gradient(147deg, ${fam.c2}, ${fam.c1} 72%)` }}>
        <img src="/images/hero-dawn.jpg" alt="" aria-hidden className="hero-photo" />
        <div className="hero-wash" style={{ background: `linear-gradient(150deg, ${fam.c2}d9, ${fam.c1}cc)` }} />
        <div className="hero-pattern" style={{ backgroundImage: `linear-gradient(30deg, rgba(255,255,255,.13) 12%, transparent 12.5%, transparent 87%, rgba(255,255,255,.13) 87.5%), linear-gradient(150deg, rgba(255,255,255,.1) 12%, transparent 12.5%, transparent 87%, rgba(255,255,255,.1) 87.5%)`, backgroundSize: "60px 104px" }} />
        <div className="hero-glow" />
        <div className="absolute inset-x-0 top-0 opacity-80"><HeaderCrown family={fam.id} height={50} /></div>
        <div className="relative px-5 pb-5 pt-11">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-[12px] font-semibold text-white/85">{greeting(now)}</p>
              <h1 className="mt-1 text-[25px] font-extrabold leading-[1.18] tracking-tight" style={{ textShadow: "0 1px 12px rgba(0,0,0,.12)" }}>{arabicDate(now)}</h1>
            </div>
            <button onClick={() => go("me", "settings")} className="grid h-9 w-9 flex-none place-items-center rounded-full bg-white/15 text-white backdrop-blur" aria-label="الإعدادات">
              <Icon name="settings" size={17} />
            </button>
          </div>
          <p className="mt-1.5 text-[11.5px] font-medium text-white/85">{hijri}{coptic ? ` · ${coptic}` : ""}</p>
          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            <span className="rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold text-white backdrop-blur-sm">{fam.ar}</span>
            {occ && occDays <= 30 && <span className="rounded-full bg-white/20 px-2.5 py-1 text-[10px] font-bold text-white backdrop-blur-sm">{occ.ar} · {occDays === 0 ? "النهاردة" : `${arabicDigits(occDays)} يوم`}</span>}
            <span className="rounded-full bg-white/15 px-2.5 py-1 text-[10px] font-bold text-white backdrop-blur-sm inline-flex items-center gap-1"><Icon name="location" size={10} />{city.ar}</span>
          </div>
        </div>
        <div className="pointer-events-none absolute -bottom-5 end-2 opacity-95">
          <Ornament family={fam.id} size={96} rotate={fam.id === "spring" ? -12 : fam.id === "autumn" ? 8 : 0} />
        </div>
      </section>

      <Card className="!p-3" onClick={() => go("me", "prayer")}>
        <div className="mb-2 flex items-center justify-between gap-2">
          <p className="flex items-center gap-1.5 text-[11.5px] font-extrabold"><span className="text-[15px]">🕌</span>الصلاة · {city.ar}</p>
          <p className="text-[10.5px] muted">القادمة: <b className="accent">{nextPrayer?.ar} {pr.next?.text}</b></p>
        </div>
        <div className="grid grid-cols-6 gap-1 text-center">
          {PRAYERS.map((p) => {
            const active = pr.next?.key === p.key;
            return (
              <div key={p.key} className="rounded-xl px-0.5 py-1.5 transition-colors" style={{ background: active ? "var(--accent)" : "var(--soft)", color: active ? "var(--on-accent)" : "var(--text)" }}>
                <div className="text-[11px] leading-tight">{p.icon}</div>
                <div className="truncate text-[8.5px] font-semibold opacity-85">{p.ar}</div>
                <div className="whitespace-nowrap text-[9px] font-extrabold tnum">{pr.times[p.key].text}</div>
              </div>
            );
          })}
        </div>
        <div className="mt-2 flex items-center justify-between border-t pt-2 text-[9.5px]" style={{ borderColor: "var(--line)" }}>
          <span className="muted">{pr.method.ar}</span>
          <span className="font-bold accent">{pr.next ? `فاضل ${durationText(pr.next.inMinutes)}` : ""} <Icon name="chevron-left" size={9} className="inline" /></span>
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card onClick={() => go("alarms")} className="!p-3.5">
          <div className="flex items-center gap-1.5 text-[10.5px] muted"><Icon name="alarm" size={13} />المنبه التالي</div>
          {next ? (
            <>
              <p className="mt-1.5 text-[24px] font-extrabold leading-none tracking-tight">{new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(next.at)}</p>
              <p className="mt-1 truncate text-[10px] muted">{next.alarm.label || "منبه"} · {alarmCountdown(next.at, now)}</p>
            </>
          ) : <p className="mt-2 text-[11px] leading-relaxed muted">لا منبهات مفعّلة.<br />أضف منبهًا حقيقيًا.</p>}
        </Card>
        <Card className="!p-3.5">
          <div className="flex items-center gap-2.5">
            <Ring value={dayProgress} size={54} stroke={5.5}><span className="text-[10px] font-extrabold">{arabicDigits(Math.round(dayProgress * 100))}٪</span></Ring>
            <div className="min-w-0">
              <p className="text-[10px] muted">اليوم</p>
              <p className="text-[15px] font-extrabold">{arabicDigits(done)}/{arabicDigits(tasks.length)}</p>
              <p className="text-[9.5px] muted">مهام</p>
            </div>
          </div>
          <div className="mt-2 h-1 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><i className="block h-full rounded-full" style={{ width: `${Math.round(dayProgress * 100)}%`, background: "var(--accent2)" }} /></div>
        </Card>
      </div>

      {chosen && (
        <Card className="!p-3" onClick={() => { actions.setSelectedWidget(chosen.id); go("tools", "widgets"); }}>
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[11px] font-extrabold flex items-center gap-1.5"><Icon name="widget" size={14} className="accent" />ودجت اليوم</p>
            <span className="text-[9.5px] font-bold accent">تغيير</span>
          </div>
          <WidgetArt designId={chosen.id} form="4x2" style="oneui" />
        </Card>
      )}

      {occ && (
        <Card onClick={() => go("calendar")} className="relative overflow-hidden">
          <Ornament family={occ.family} size={70} className="!absolute -bottom-5 -left-3 opacity-40" rotate={-18} />
          <div className="relative flex items-center gap-3">
            <div className="grid h-10 w-10 flex-none place-items-center rounded-2xl" style={{ background: "var(--soft-gold)", color: "#8a6a1c" }}><Icon name={occ.family === "ramadan" || occ.family === "eid" ? "moon" : "star"} size={19} /></div>
            <div className="min-w-0 flex-1">
              <p className="text-[9.5px] font-bold muted">المناسبة القادمة</p>
              <p className="truncate text-[13px] font-extrabold">{occ.ar}</p>
              <p className="text-[9.5px] muted">{new Intl.DateTimeFormat("ar-EG", { day: "numeric", month: "long" }).format(new Date(`${occ.date}T12:00:00`))} · بعد {arabicDigits(occDays)} يوم</p>
            </div>
            <Icon name="chevron-left" size={16} className="muted" />
          </div>
        </Card>
      )}

      <Card className="!p-3" onClick={() => go("downloads")}>
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 flex-none place-items-center rounded-2xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Icon name="download" size={18} /></span>
          <div className="min-w-0 flex-1">
            <p className="text-[12.5px] font-extrabold">التحميل</p>
            <p className="text-[10px] leading-relaxed muted">الصق أو شارك أي رابط — معاينة حقيقية وتحميل أصلي على أندرويد</p>
          </div>
          <Icon name="chevron-left" size={15} className="muted" />
        </div>
      </Card>

      <Card>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-[13px] font-extrabold">مهام اليوم</h3>
          <button onClick={() => go("tools", "focus")} className="text-[10.5px] font-bold accent">الكل</button>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); if (!quick.trim()) return; actions.addTask(quick.trim()); setQuick(""); }} className="mb-2 flex gap-2">
          <input value={quick} onChange={(e) => setQuick(e.target.value)} className="field !min-h-10 !py-2 text-[12px]" placeholder="ضيف مهمة للنهاردة…" aria-label="مهمة جديدة" />
          <button className="btn btn-primary !min-h-10 !px-3" aria-label="إضافة"><Icon name="plus" size={17} /></button>
        </form>
        {tasks.length === 0 ? (
          <div className="py-4 text-center"><p className="text-[12px] font-bold">يوم فاضي وهادي</p><p className="mt-0.5 text-[10.5px] muted">لسه مفيش حاجة متخططة.</p></div>
        ) : tasks.slice(0, 5).map((t) => (
          <button key={t.id} onClick={() => actions.toggleTask(t.id)} className="flex w-full items-center gap-2.5 py-2 text-start press">
            <span className="grid h-[22px] w-[22px] flex-none place-items-center rounded-lg border-2 transition-all" style={{ borderColor: "var(--accent)", background: t.done ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{t.done && <Icon name="check" size={12} strokeWidth={3} />}</span>
            <span className="min-w-0 flex-1 truncate text-[12px] font-medium" style={{ textDecoration: t.done ? "line-through" : "none", opacity: t.done ? 0.5 : 1 }}>{t.title}</span>
            {t.urgent && !t.done && <span className="h-1.5 w-1.5 flex-none rounded-full" style={{ background: "#bf5a45" }} />}
          </button>
        ))}
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="!p-3.5">
          <div className="flex items-center gap-1.5 text-[10.5px] muted"><Icon name="droplet" size={13} />الماء</div>
          <p className="mt-1 text-[20px] font-extrabold leading-none">{(water / 1000).toFixed(2).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)])}<span className="text-[11px] font-medium muted"> / {(s.waterGoal / 1000).toFixed(1)} لتر</span></p>
          <div className="progress mt-2"><i style={{ width: `${Math.min(100, water / s.waterGoal * 100)}%`, background: "#4a93b8" }} /></div>
          <button onClick={() => actions.addWater(250)} className="btn btn-soft mt-2.5 w-full !min-h-8 !py-1 text-[11px]">+٢٥٠ مل</button>
        </Card>
        <Card className="!p-3.5">
          <div className="flex items-center justify-between"><p className="text-[10.5px] muted">العادات</p><Tag tone="gold">{arabicDigits(doneHabits)}/{arabicDigits(s.habits.length)}</Tag></div>
          <div className="mt-1.5 space-y-1.5">
            {s.habits.slice(0, 4).map((h) => {
              const on = h.log.includes(key);
              return (
                <button key={h.id} onClick={() => actions.toggleHabit(h.id)} className="flex w-full items-center gap-1.5 text-start">
                  <span className="grid h-4 w-4 flex-none place-items-center rounded-full border text-[8px]" style={{ borderColor: on ? "var(--accent)" : "var(--line-strong)", background: on ? "var(--accent)" : "transparent", color: "var(--on-accent)" }}>{on ? "✓" : ""}</span>
                  <span className="truncate text-[10.5px] font-semibold" style={{ opacity: on ? 1 : 0.7 }}>{h.emoji} {h.ar}</span>
                </button>
              );
            })}
          </div>
        </Card>
      </div>

      <Card className="relative overflow-hidden" style={{ background: `linear-gradient(150deg, ${fam.c2}22, var(--surface) 60%)` }}>
        <div className="flex items-start gap-3">
          <span className="grid h-9 w-9 flex-none place-items-center rounded-2xl" style={{ background: "var(--soft-gold)", color: "#8a6a1c" }}><Icon name="sparkles" size={17} /></span>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-bold muted">من رفيقك</p>
            <p className="font-serif mt-0.5 text-[13px] font-semibold leading-relaxed">{s.notes[0]?.text || "خطوة صغيرة النهاردة أحسن من خطة كبيرة بكرة."}</p>
          </div>
          <button onClick={() => go("tools", "widgets")} className="chip !text-[9px]" style={{ color: "var(--accent)" }}>ودجت</button>
        </div>
      </Card>

      {!hideWebNote && (
        <div className="relative">
          <WebOnlyNotice>
            <b>أنت دلوقتي في معاينة الويب.</b> المنبهات، الإشعارات، والودجتس الكاملة تعمل في نسخة أندرويد الأصلية المرفقة في مجلد <span dir="ltr" className="font-mono text-[11px]">android/</span>. جرّب الرنين من شاشة المنبهات.
          </WebOnlyNotice>
          <button onClick={() => { setHideWebNote(true); actions.markDecoSeen("web-note"); }} className="absolute end-2 top-2 grid h-6 w-6 place-items-center rounded-full" style={{ background: "#0000000d" }} aria-label="إخفاء"><Icon name="x" size={12} /></button>
        </div>
      )}

      <p className="pt-1 text-center text-[9.5px] leading-relaxed muted">DAYFLOW · يومك بهدوء — الواجهة والمنطق في نسخة أندرويد أصلية بـ Kotlin &amp; Jetpack Compose</p>
    </div>
  );
}
