import { useMemo, useState } from "react";
import { Icon } from "../components/icons";
import { Card, Ornament, ScreenHeader, Sheet, Tag, Toggle, WebOnlyNotice } from "../components/ui";
import { WidgetArt } from "../components/WidgetView";
import {
  actions, seasonFor, useDayflow, W_FORMS, W_STYLES, WIDGETS, WIDGET_CATS,
  widgetById, type WCat, type WForm, type WStyle, type WidgetDef,
} from "../lib/data";

export function Widgets({ go }: { go: (tab: string, sub?: string) => void }) {
  void go;
  const s = useDayflow();
  const [cat, setCat] = useState<WCat>("clock");
  const [picked, setPicked] = useState<WidgetDef | null>(null);
  const [form, setForm] = useState<WForm>("2x2");
  const [style, setStyle] = useState<WStyle>("oneui");
  const [confirm, setConfirm] = useState(false);
  const [installFlow, setInstallFlow] = useState(false);
  const [sizeSheet, setSizeSheet] = useState(false);
  const [q, setQ] = useState("");
  const [visible, setVisible] = useState(12);
  const fam = seasonFor(new Date());
  const chosen = widgetById(s.selectedWidgetId);
  const list = useMemo(() => WIDGETS.filter((w) => w.cat === cat && (!q.trim() || `${w.ar} ${w.en} ${w.desc}`.toLowerCase().includes(q.toLowerCase().trim()))), [cat, q]);

  const openPicked = (w: WidgetDef) => {
    setPicked(w); setForm((current) => w.forms.includes(current) ? current : (w.forms.includes("2x2") ? "2x2" : w.forms[0])); setStyle("oneui"); setConfirm(false); setInstallFlow(true);
  };

  const install = () => {
    if (!picked) return;
    actions.addWidget(picked.id, form, style);
    setConfirm(true);
    setInstallFlow(false);
  };

  return (
    <div className="space-y-3 pb-3">
      <ScreenHeader title="الودجتس" eyebrow="WIDGETS · أصلية على أندرويد" subtitle="كل ودجت بتعرض بياناتك الحقيقية — وبتفتح التطبيق على شاشة الودجتس الجديدة" right={<button onClick={() => setSizeSheet(true)} className="btn btn-primary !min-h-10 !px-3 !text-[11px]"><Icon name="plus" size={15} />إضافة</button>} />

      {installFlow && (
        <div className="notice" style={{ background: "var(--soft)", border: "1px solid rgba(47,111,94,.25)", color: "var(--accent-strong)" }}>
          <Icon name="widget" size={16} className="mt-0.5 flex-none" />
          <div><b>اختار واحدة لتكون هي الودجت.</b> اختر تصميمًا من المعرض ثم حدد الحجم المناسب من الشاشة الرئيسية — الودجت المختارة هتتثبت على الهاتف وتفتح على نفس الشاشة دي في أي وقت.</div>
        </div>
      )}

      <div className="overflow-hidden rounded-[26px] border shadow-sm" style={{ borderColor: "var(--line-strong)" }}>
        <div className="wallpaper relative px-4 pb-5 pt-3" style={{ background: `linear-gradient(160deg, ${fam.c2}, ${fam.c1})` }}>
          <Ornament family={fam.id} size={150} className="!absolute -right-8 -top-8 opacity-35" rotate={20} />
          <div className="mb-5 flex items-start justify-between text-white">
            <div>
              <p className="text-[10px] font-semibold opacity-75">{new Intl.DateTimeFormat("ar-EG", { weekday: "long", day: "numeric", month: "long" }).format(new Date())}</p>
              <p className="text-[30px] font-extrabold leading-tight tnum">{new Intl.DateTimeFormat("ar-EG", { hour: "numeric", minute: "2-digit", hour12: true }).format(new Date())}</p>
            </div>
            <div className="flex gap-1.5 opacity-80"><span className="h-6 w-6 rounded-full bg-white/20" /><span className="h-6 w-6 rounded-full bg-white/20" /></div>
          </div>
          <div className="mx-auto w-[86%]">
            {chosen ? (
              <div className="pop"><WidgetArt designId={chosen.id} form="4x2" style={s.placed.length ? s.placed[s.placed.length - 1].style : "oneui"} /></div>
            ) : (
              <button onClick={() => setSizeSheet(true)} className="flex w-full flex-col items-center justify-center gap-1.5 rounded-[22px] border border-dashed border-white/50 px-4 py-7 text-white" style={{ background: "rgba(255,255,255,.12)", backdropFilter: "blur(8px)" }}>
                <Icon name="plus" size={22} />
                <span className="text-[11.5px] font-bold">مساحة ودجت فاضية</span>
                <span className="text-[9px] opacity-70">اضغط لإضافة ودجت حقيقية</span>
              </button>
            )}
          </div>
          <p className="mt-3 text-center text-[9.5px] font-semibold text-white/70">شاشة رئيسية تجريبية · الودجت المختارة تتثبت فعليًا على أندرويد</p>
        </div>
      </div>

      {confirm && picked && (
        <div className="notice notice-native"><Icon name="check-circle" size={16} className="mt-0.5 flex-none" /><div><b>تم اختيار «{picked.ar}» ({W_FORMS.find((f) => f.id === form)?.label}).</b> {s.placed.length} ودجت محفوظة في مساحتك. على أندرويد يُطلب التثبيت من اللاuncher وتظهر نفس الشاشة لاختيار الودجت.</div></div>
      )}

      {s.placed.length > 0 && (
        <Card>
          <div className="mb-2 flex items-center justify-between"><h3 className="text-[13px] font-extrabold">ودجتس مساحتك</h3><Tag tone="green">{s.placed.length}</Tag></div>
          <div className="space-y-1.5">
            {s.placed.map((p) => {
              const def = widgetById(p.designId);
              return (
                <div key={p.id} className="flex items-center gap-2 rounded-xl px-2.5 py-2" style={{ background: "var(--surface-2)" }}>
                  <span className="grid h-8 w-8 place-items-center rounded-lg" style={{ background: "var(--soft)", color: "var(--accent)" }}><Icon name="widget" size={15} /></span>
                  <div className="min-w-0 flex-1"><p className="truncate text-[11.5px] font-bold">{def?.ar || p.designId}</p><p className="text-[9px] muted">{p.form.replace("x", "×")} · {W_STYLES.find((x) => x.id === p.style)?.ar}</p></div>
                  <button onClick={() => actions.setSelectedWidget(p.designId)} className="chip !text-[9px]">اختيار</button>
                  <button onClick={() => actions.removeWidget(p.id)} className="muted" aria-label="حذف"><Icon name="trash" size={14} /></button>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      <div className="flex flex-wrap gap-1.5">
        {WIDGET_CATS.map((c) => <button key={c.id} onClick={() => { setCat(c.id); setVisible(12); }} className="chip !text-[10px]" aria-pressed={cat === c.id}><Icon name={c.icon as never} size={12} />{c.ar}</button>)}
      </div>

      <div className="relative">
        <Icon name="sparkle" size={15} className="absolute start-3 top-1/2 -translate-y-1/2 muted" />
        <input value={q} onChange={(e) => setQ(e.target.value)} className="field !ps-9" placeholder="ابحث بين الودجتس…" aria-label="بحث" />
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {list.slice(0, visible).map((w) => (
          <button key={w.id} onClick={() => openPicked(w)} className="card press overflow-hidden !rounded-2xl p-2 text-start">
            <div className="pointer-events-none origin-top" style={{ transform: "scale(.92)", transformOrigin: "top right" }}>
              <WidgetArt designId={w.id} form="2x2" style={w.family === "ramadan" ? "gold" : w.family === "autumn" ? "paper" : "oneui"} />
            </div>
            <p className="mt-1.5 truncate text-[11px] font-extrabold">{w.ar}</p>
            <p className="truncate text-[8.5px] muted">{w.desc}</p>
            <div className="mt-1 flex items-center gap-1"><Tag tone={w.interactive ? "green" : "soft"}>{w.interactive ? "تفاعلية" : "عرض"}</Tag><span className="text-[8px] muted">{w.forms.length} أحجام</span></div>
          </button>
        ))}
      </div>
      {list.length === 0 && <p className="py-8 text-center text-[12px] muted">مفيش ودجت بالبحث ده. جرّب كلمة تانية.</p>}
      {list.length > visible && <button onClick={() => setVisible((v) => v + 12)} className="btn btn-ghost w-full">عرض المزيد ({list.length - visible})</button>}

      <WebOnlyNotice>
        <b>كل حجم/تصميم تختاره يدخلك شاشة الودجتس دي ويطلب منك اختيار واحدة.</b> على أندرويد تُسجّل الودجت في <span dir="ltr" className="font-mono text-[10.5px]">AppWidgetProvider</span> وتُثبت من الـ launcher مباشرة، وتُحدّث بياناتها بعد تغيير المنبه أو الصلاة أو المهام. هذه المعاينة تحفظ اختيارك محليًا لعرضه.
      </WebOnlyNotice>

      <Sheet open={sizeSheet} onClose={() => setSizeSheet(false)} title="إضافة ودجت من الشاشة الرئيسية" subtitle="اختر الحجم — ثم هيتم فتح شاشة الودجتس لتختار التصميم"
        footer={<button onClick={() => { setSizeSheet(false); setInstallFlow(true); setPicked(null); document.getElementById("widget-gallery-top")?.scrollIntoView({ behavior: "smooth" }); }} className="btn btn-primary w-full">فتح شاشة الودجتس</button>}>
        <div className="grid grid-cols-2 gap-2">
          {W_FORMS.map((f) => (
            <button key={f.id} onClick={() => { setForm(f.id); setSizeSheet(false); setInstallFlow(true); }} className="rounded-2xl p-3 text-start" style={{ border: "1px solid var(--line)", background: "var(--surface-2)" }}>
              <div className="mb-1.5 flex items-center justify-between"><Icon name="widget" size={16} className="accent" /><span className="text-[9px] font-bold muted">{f.label}</span></div>
              <p className="text-[11.5px] font-extrabold">{f.ar}</p>
              <p className="text-[8.5px] muted">اختيار هذا الحجم</p>
            </button>
          ))}
        </div>
        <WebOnlyNotice>على أندرويد يفتح التطبيق مباشرة على هذه الشاشة بدل إعداد منفصل، وتظهر رسالة «اختار واحدة لتكون هي الودجت» كما هو مطبق في نسخة Compose.</WebOnlyNotice>
      </Sheet>

      <Sheet open={!!picked} onClose={() => setPicked(null)} title={picked ? `إضافة «${picked.ar}»` : ""} subtitle="معاينة مباشرة وتخصيص قبل التثبيت"
        footer={<div className="flex gap-2"><button onClick={() => setPicked(null)} className="btn btn-ghost !px-4">إلغاء</button><button onClick={install} className="btn btn-primary flex-1"><Icon name="widget" size={16} />اختَر دي لتكون الودجت</button></div>}>
        {picked && (
          <>
            <div className="rounded-[22px] p-3" style={{ background: "var(--bg-deep)" }}>
              <WidgetArt designId={picked.id} form={form} style={style} />
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-bold">الحجم على الشاشة</p>
              <div className="flex flex-wrap gap-1.5">{picked.forms.map((f) => <button key={f} onClick={() => setForm(f)} className="chip !text-[10px]" aria-pressed={form === f}>{W_FORMS.find((x) => x.id === f)?.label} · {W_FORMS.find((x) => x.id === f)?.ar}</button>)}</div>
            </div>
            <div>
              <p className="mb-1.5 text-[11px] font-bold">نمط التصميم</p>
              <div className="flex flex-wrap gap-1.5">{W_STYLES.slice(0, 9).map((st) => <button key={st.id + st.ar} onClick={() => setStyle(st.id)} className="chip !text-[10px]" aria-pressed={style === st.id}>{st.ar}</button>)}</div>
            </div>
            <div className="flex items-center justify-between rounded-xl px-3 py-2.5" style={{ background: "var(--surface-2)" }}>
              <div><p className="text-[11.5px] font-bold">الضغط يفتح التطبيق</p><p className="text-[9px] muted">على الودجت المثبتة</p></div>
              <Toggle on={true} onChange={() => undefined} label="الضغط يفتح التطبيق" />
            </div>
            <WebOnlyNotice>الأحجام الكبيرة (4×4) تعمل كودجت حقيقي في أندرويد. لا تُعرض صيغ وهمية أو ودجتس غير منفذة — كل واجهة هنا لها RemoteViews مقابلة في النسخة الأصلية.</WebOnlyNotice>
          </>
        )}
      </Sheet>
    </div>
  );
}
