# DAYFLOW — Native Android

تطبيق **أندرويد أصلي** بواجهة **Kotlin + Jetpack Compose**، وليس WebView للواجهة.

## البناء

المشروع مفتوح مباشرة في Android Studio (Ladybug أو أحدث). لا يوجد `gradle-wrapper.jar` ثنائي في هذا المستودع؛ استخدم:

```bash
cd android
gradle wrapper --gradle-version 8.9   # مرة واحدة إن لم يكن الـ wrapper موجودًا
./gradlew assembleDebug
```

- AGP 8.7.2 · Kotlin 2.0.21 · Compose BOM 2024.09.03
- `compileSdk 35` · `minSdk 26` · `targetSdk 35`
- التطبيق: `app.dayflow.android`

> البيئة التي صُنع فيها المشروع لا تحتوي Android SDK، لذلك لم يُنفذ بناء Gradle هنا. تم فحص سلامة المصادر وبنية الموارد، لكن اختبار الجهاز/المحاكي مطلوب لتأكيد سلوك AlarmManager والودجتس والـ Overlay.

## نظرة سريعة على المعمارية

| المجال | التقنية |
|---|---|
| الواجهة | Jetpack Compose + Material 3، مطابقة ألوان/تباعد/زوايا الويب الأصلية |
| التخزين | Preferences DataStore + kotlinx.serialization |
| المنبه | `AlarmManager.setAlarmClock`، BroadcastReceiver، Foreground Service، Full-screen Activity، إعادة جدولة BOOT/TIME_SET/TIMEZONE |
| الصوت | `ACTION_RINGTONE_PICKER` / `OpenDocument` + URI دائم + `MediaPlayer(USAGE_ALARM)` + VibrationEffect |
| الإشعارات | قنوات منفصلة + POST_NOTIFICATIONS + Full-screen Intent + اختبار إشعار |
| الرفيق | `SYSTEM_ALERT_WINDOW` + Foreground `specialUse` + WindowManager Overlay + نفس Canvas renderer |
| الودجتس | `AppWidgetProvider` + RemoteViews + `WidgetConfigActivity` (نفس شاشة اختيار الودجت) + `requestPinAppWidget` |
| الصلاة | `PrayerCalculator` فلكي، IANA/DST، Giza + ١٦ مدينة، ٦ طرق، مذهب العصر، خطوط العرض العالية، LocationManager |
| الوقت | ١٢ ساعة فقط — `DayflowTime.clock12` |
| الروابط | OkHttp + Jsoup (OpenGraph/Twitter/JSON-LD) + InnerTube للصيغ المتاحة فقط + DownloadManager |
| المشاركة | `ACTION_SEND text/plain` → شاشة التحميل |

## الصلاحيات المطلوبة ولماذا

- `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM`: منبه دقيق في وقته. عند الرفض يوجد بديل غير دقيق + إشعار صريح.
- `POST_NOTIFICATIONS`: إشعارات أندرويد ١٣+.
- `SYSTEM_ALERT_WINDOW`: الرفيق فوق باقي التطبيقات.
- `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_MEDIA_PLAYBACK` + `FOREGROUND_SERVICE_SPECIAL_USE`: الرنين والرفيق.
- `RECEIVE_BOOT_COMPLETED`: استعادة المنبهات بعد إعادة التشغيل.
- `USE_FULL_SCREEN_INTENT`: شاشة الرنين عند قفل الهاتف.
- `ACCESS_COARSE_LOCATION`: خيار «استخدم موقعي» لحساب المواقيت.
- `READ_MEDIA_AUDIO`: اختيار نغمة من الهاتف (وبديل SAF لا يحتاجها).

## اختبارات مطلوبة على جهاز حقيقي

1. منبه بعد دقيقة مع إغلاق التطبيق وقفل الشاشة → رنين + إيقاف + غفوة.
2. إعادة تشغيل الهاتف → بقاء المنبهات (SystemEventReceiver).
3. تغيير المنطقة الزمنية/الوقت → إعادة الجدولة وتغير المواقيت.
4. منح/سحب SYSTEM_ALERT_WINDOW وتشغيل/إيقاف الرفيق فوق تطبيق آخر.
5. إضافة ودجت من اللانشر → تُفتح شاشة اختيار الودجت داخل DAYFLOW → اختيار واحدة → تثبيت وتحديث بعد تغيير المهمة/المنبه.
6. تحميل ملف صورة/PDF مباشر → مجلد Download + إشعار DownloadManager.
7. لصق رابط يوتيوب → معاينة عنوان/غلاف/مؤلف وصيغ متاحة فقط أو رسالة منع واضحة.
8. مقارنة المواقيت مع تقويم الهيئة المصرية لعدة أيام/مدن.
9. رفض/منح POST_NOTIFICATIONS وSCHEDULE_EXACT_ALARM.

## الملفات الرئيسية

```
app/src/main/java/app/dayflow/android/
  MainActivity.kt
  DayflowApplication.kt
  data/DayflowModels.kt · data/DayflowRepository.kt
  domain/DayflowTime.kt · domain/PrayerCalculator.kt · domain/NativeMedia.kt
  alarm/AlarmScheduler.kt · AlarmReceiver.kt · AlarmRingService.kt · AlarmRingActivity.kt · SystemEventReceiver.kt
  notifications/DayflowNotifications.kt
  overlay/CompanionOverlayService.kt
  widget/DayflowWidgetProvider.kt · WidgetConfigActivity.kt
  ui/DayflowApp.kt
  ui/screens/*.kt
  ui/components/RobotRenderer.kt · Components.kt
  ui/theme/Theme.kt
```

## ملاحظات

- لا يوجد WebView في الواجهة الأساسية. لا تعتمد نسخة الويب على هذه الطبقة.
- التصميم يحافظ على نفس الهوية: خلفية عاجية، أخضر `#2F6F5E`، ذهبي `#C9A24A`، بطاقات ٢٠dp، شريط سفلي سبع تبويبات، رفيق روبوت، زخارف موسمية.
- الأصول الفنية داخل `res/drawable`: صورة فجر + فانوس + أزهار + أوراق خريف.
