package app.dayflow.android.data

import kotlinx.serialization.Serializable

@Serializable
data class AlarmSound(
    val source: String = "device",
    val title: String = "منبه الجهاز الافتراضي",
    val uri: String? = null,
)

@Serializable
data class Alarm(
    val id: String,
    val time: String = "07:00",
    val date: String? = null,
    val days: List<Int> = emptyList(),
    val label: String = "",
    val enabled: Boolean = true,
    val sound: AlarmSound = AlarmSound(),
    val vibrate: Boolean = true,
    val snooze: Int = 10,
    val gentle: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class Task(
    val id: String,
    val title: String,
    val date: String,
    val dueTime: String? = null,
    val done: Boolean = false,
    val urgent: Boolean = false,
    val important: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class Note(val id: String, val text: String, val pinned: Boolean = false, val at: Long = System.currentTimeMillis())

@Serializable
data class Habit(
    val id: String,
    val ar: String,
    val en: String = ar,
    val emoji: String = "✨",
    val color: String = "#2F6F5E",
    val log: List<String> = emptyList(),
    val target: Int? = null,
    val unit: String? = null,
)

@Serializable
data class JournalEntry(val id: String, val date: String, val mood: Int = 3, val text: String)

@Serializable
data class PlacedWidget(
    val id: String,
    val designId: String,
    val form: String = "4x2",
    val style: String = "oneui",
    val createdAt: Long = System.currentTimeMillis(),
)

@Serializable
data class DownloadRecord(
    val id: String,
    val title: String,
    val url: String,
    val mime: String? = null,
    val at: Long = System.currentTimeMillis(),
    val status: String = "started",
    val localUri: String? = null,
)

@Serializable
data class PrayerSettings(
    val cityId: String = "giza",
    val methodId: String = "egypt",
    val asrFactor: Int = 1,
    val customLat: Double? = null,
    val customLng: Double? = null,
    val customLabel: String? = null,
    val customZone: String? = null,
)

@Serializable
data class CompanionPrefs(
    val enabled: Boolean = true,
    val hidden: Boolean = false,
    val size: Float = 1f,
    val opacity: Float = 1f,
    val outfit: String = "auto",
    val emotion: String = "idle",
    val bubbles: Boolean = true,
    val notify: Boolean = false,
)

@Serializable
data class NotifPrefs(
    val enabled: Boolean = true,
    val sound: Boolean = true,
    val vibrate: Boolean = true,
    val preview: Boolean = true,
    val quiet: Boolean = false,
    val quietFrom: String = "23:00",
    val quietTo: String = "06:30",
    val reminderOffset: Int = 0,
)

@Serializable
data class Appearance(
    val autoSeason: Boolean = true,
    val intensity: String = "subtle",
    val reduceMotion: Boolean = false,
    val ambientPhoto: Boolean = true,
)

@Serializable
data class WidgetSettings(
    val designId: String = "clock-minimal-digital",
    val form: String = "4x2",
    val style: String = "oneui",
    val placed: List<PlacedWidget> = emptyList(),
)

@Serializable
data class ScreenState(
    val lang: String = "ar",
    val hour12: Boolean = true, // locked: 12-hour only. Kept for migration.
    val onboarded: Boolean = false,
    val webOnlyMessages: Boolean = false, // intentionally false: native never shows browser notices.
)

@Serializable
data class DayflowState(
    val version: Int = 1,
    val screen: ScreenState = ScreenState(),
    val prayer: PrayerSettings = PrayerSettings(),
    val appearance: Appearance = Appearance(),
    val companion: CompanionPrefs = CompanionPrefs(),
    val notif: NotifPrefs = NotifPrefs(),
    val widgets: WidgetSettings = WidgetSettings(),
    val alarms: List<Alarm> = emptyList(),
    val tasks: List<Task> = emptyList(),
    val notes: List<Note> = emptyList(),
    val habits: List<Habit> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val water: Map<String, Int> = emptyMap(),
    val waterGoal: Int = 2500,
    val downloads: List<DownloadRecord> = emptyList(),
)

/** Seed data used only the very first time; mirrors the original demo content. */
fun defaultState(today: String): DayflowState = DayflowState(
    alarms = emptyList(),
    tasks = listOf(
        Task("seed-1", "مراجعة خطة اليوم في ٥ دقايق", today, urgent = true),
        Task("seed-2", "شغل العميل الأول", today, done = true),
        Task("seed-3", "اتصل بالوالدة قبل المغرب", today),
        Task("seed-4", "اقرأ ١٠ صفحات قبل النوم", today),
    ),
    notes = listOf(Note("seed-note", "خطوة صغيرة النهاردة أحسن من خطة كبيرة بكرة.", pinned = true)),
    habits = listOf(
        Habit("quran", "قرآن", "Quran", "📖", "#2F6F5E", log = listOf(today)),
        Habit("walk", "مشي", "Walk", "🚶", "#C9A24A", log = listOf(today)),
        Habit("sleep", "نوم بدري", "Early sleep", "🌙", "#42617A"),
        Habit("water", "ماء", "Water", "💧", "#4A93B8", log = listOf(today)),
    ),
    water = mapOf(today to 750),
)
