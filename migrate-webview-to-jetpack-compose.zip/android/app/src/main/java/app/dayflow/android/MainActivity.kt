package app.dayflow.android

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.overlay.CompanionOverlayService
import app.dayflow.android.ui.DayflowApp
import app.dayflow.android.ui.theme.DayflowTheme
import app.dayflow.android.widget.WidgetUpdater
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_TAB = "open_tab"
        const val EXTRA_OPEN_SUB = "open_sub"
        const val EXTRA_LINK = "shared_link"
    }

    private var openTab by mutableStateOf("today")
    private var openSub by mutableStateOf<String?>(null)
    private var sharedLink by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = true
        readIntent(intent)

        val repository = DayflowApplication.repository(this)
        setContent {
            DayflowTheme {
                DayflowApp(
                    repository = repository,
                    initialTab = openTab,
                    initialSub = openSub,
                    initialLink = sharedLink,
                    onRequestRouteConsumed = { sharedLink = null },
                )
            }
        }

        lifecycleScope.launch {
            runCatching {
                val state = repository.snapshot()
                // Safety net: if a device reboot or OEM kill was missed, all
                // enabled alarms are restored whenever the app is opened.
                AlarmScheduler.sync(this@MainActivity, state.alarms)
                WidgetUpdater.updateAll(this@MainActivity)
                if (state.companion.enabled && !state.companion.hidden && Settings.canDrawOverlays(this@MainActivity)) {
                    CompanionOverlayService.start(this@MainActivity)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!text.isNullOrBlank()) {
                    sharedLink = text.trim()
                    openTab = "downloads"
                    openSub = null
                }
            }
        }
        intent.getStringExtra(EXTRA_OPEN_TAB)?.let { tab ->
            if (tab.isNotBlank()) {
                openTab = tab
                openSub = intent.getStringExtra(EXTRA_OPEN_SUB)
            }
        }
        intent.getStringExtra(EXTRA_LINK)?.let { SharedLinkBus.publish(it) }
    }
}

/** Small process-wide bus used to pass "share to DAYFLOW" text into Compose. */
object SharedLinkBus {
    var pending by mutableStateOf<String?>(null)
        private set

    fun publish(url: String) { pending = url }
    fun consume(): String? { val value = pending; pending = null; return value }
}

@Suppress("unused")
private val apiCheck = Build.VERSION.SDK_INT
