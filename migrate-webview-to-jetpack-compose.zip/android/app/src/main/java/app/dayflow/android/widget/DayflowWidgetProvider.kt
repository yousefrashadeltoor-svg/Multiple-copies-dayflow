package app.dayflow.android.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import app.dayflow.android.DayflowApplication
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.NativeWidgetCatalog
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.ZonedDateTime
import java.time.ZoneId

/**
 * Real home-screen widgets. Data comes from the same repository used by Compose.
 * Clicking a widget opens the exact screen it represents, and the configuration
 * activity opens DAYFLOW's widget selection screen before the launcher pins it.
 */
class DayflowWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateAll(context)
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle) {
        WidgetUpdater.updateAll(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        val prefs = WidgetUpdater.prefs(context)
        appWidgetIds.forEach { prefs.edit().remove("widget_$it").apply() }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TOGGLE_ALARM -> {
                val id = intent.getStringExtra("alarm_id") ?: return
                val pending = goAsync()
                CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                    try {
                        val repository = DayflowApplication.repository(context)
                        val state = repository.snapshot()
                        val alarm = state.alarms.firstOrNull { it.id == id } ?: return@launch
                        repository.toggleAlarm(id, !alarm.enabled)
                        WidgetUpdater.updateAll(context)
                    } finally { pending.finish() }
                }
            }
            ACTION_ADD_WATER -> {
                val pending = goAsync()
                CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                    try {
                        DayflowApplication.repository(context).addWater(250)
                        WidgetUpdater.updateAll(context)
                    } finally { pending.finish() }
                }
            }
            ACTION_REFRESH -> WidgetUpdater.updateAll(context)
        }
    }

    companion object {
        const val ACTION_TOGGLE_ALARM = "app.dayflow.android.WIDGET_TOGGLE_ALARM"
        const val ACTION_ADD_WATER = "app.dayflow.android.WIDGET_ADD_WATER"
        const val ACTION_REFRESH = "app.dayflow.android.WIDGET_REFRESH"
    }
}

object WidgetUpdater {
    private const val PREFS = "dayflow_widgets"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveChoice(context: Context, appWidgetId: Int, designId: String, form: String, style: String) {
        prefs(context).edit().putString("widget_$appWidgetId", "$designId|$form|$style").apply()
    }

    fun choiceFor(context: Context, appWidgetId: Int, fallback: DayflowState): Triple<String, String, String> {
        val stored = prefs(context).getString("widget_$appWidgetId", null)
        if (stored != null) {
            val parts = stored.split("|")
            if (parts.size >= 1 && parts[0].isNotBlank()) {
                return Triple(parts[0], parts.getOrElse(1) { fallback.widgets.form }, parts.getOrElse(2) { fallback.widgets.style })
            }
        }
        val widget = fallback.widgets
        return Triple(widget.designId, widget.form, widget.style)
    }

    fun updateAll(context: Context) {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, DayflowWidgetProvider::class.java))
                if (ids.isEmpty()) return@runCatching
                val repository = DayflowApplication.repository(context)
                val state = repository.snapshot()
                val city = repository.activeCity(state)
                val method = PrayerCatalog.method(state.prayer.methodId)
                val zone = runCatching { ZoneId.of(city.zone) }.getOrDefault(ZoneId.systemDefault())
                val now = ZonedDateTime.now(zone)
                val prayer = PrayerCalculator.forCity(city, method, state.prayer.asrFactor, now)
                val nextAlarm = DayflowTime.nextAlarm(state.alarms, now)
                val tasks = state.tasks.filter { it.date == repository.todayKey(state) }
                ids.forEach { id ->
                    val (designId, form, _) = choiceFor(context, id, state)
                    runCatching { render(context, manager, id, designId, form, state, prayer, nextAlarm, tasks) }
                }
            }
        }
    }

    fun updateWidget(context: Context, appWidgetId: Int) {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching {
                val manager = AppWidgetManager.getInstance(context)
                val repository = DayflowApplication.repository(context)
                val state = repository.snapshot()
                val city = repository.activeCity(state)
                val zone = runCatching { ZoneId.of(city.zone) }.getOrDefault(ZoneId.systemDefault())
                val now = ZonedDateTime.now(zone)
                val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor, now)
                val nextAlarm = DayflowTime.nextAlarm(state.alarms, now)
                val tasks = state.tasks.filter { it.date == repository.todayKey(state) }
                val (designId, form, _) = choiceFor(context, appWidgetId, state)
                render(context, manager, appWidgetId, designId, form, state, prayer, nextAlarm, tasks)
            }
        }
    }

    private fun render(
        context: Context,
        manager: AppWidgetManager,
        id: Int,
        designId: String,
        form: String,
        state: DayflowState,
        prayer: app.dayflow.android.domain.PrayerDay,
        nextAlarm: app.dayflow.android.domain.AlarmOccurrence?,
        tasks: List<app.dayflow.android.data.Task>,
    ) {
        val design = NativeWidgetCatalog.byId(designId)
        val views = when (design.layoutKind) {
            "tasks" -> RemoteViews(context.packageName, R.layout.widget_dayflow_tasks)
            "alarm" -> RemoteViews(context.packageName, R.layout.widget_dayflow_alarm)
            else -> RemoteViews(context.packageName, R.layout.widget_dayflow)
        }
        val openTab = when (design.layoutKind) {
            "tasks" -> "today"
            "alarm" -> "alarms"
            else -> "me/prayer"
        }
        val open = PendingIntent.getActivity(
            context,
            id,
            Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(MainActivity.EXTRA_OPEN_TAB, openTab.substringBefore('/'))
                putExtra(MainActivity.EXTRA_OPEN_SUB, openTab.substringAfter('/', ""))
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        when (design.layoutKind) {
            "tasks" -> {
                views.setTextViewText(R.id.widget_tasks_progress, "${DayflowTime.digits(tasks.count { it.done })}/${DayflowTime.digits(tasks.size)}")
                val ids = listOf(R.id.widget_task_1, R.id.widget_task_2, R.id.widget_task_3)
                ids.forEachIndexed { index, viewId ->
                    val task = tasks.getOrNull(index)
                    views.setTextViewText(viewId, if (task == null) "—" else "${if (task.done) "✓" else "□"} ${task.title.take(42)}")
                }
                views.setTextViewText(R.id.widget_tasks_next, "الصلاة القادمة: ${prayer.nextLabel} ${prayer.nextText}")
                views.setOnClickPendingIntent(R.id.widget_tasks_root, open)
            }
            "alarm" -> {
                views.setTextViewText(R.id.widget_alarm_clock, nextAlarm?.clock ?: "—")
                views.setTextViewText(R.id.widget_alarm_label, nextAlarm?.let { "${it.alarm.label.ifBlank { "منبه" }} · ${DayflowTime.daysLabel(it.alarm)}" } ?: "لا منبهات مفعّلة")
                views.setTextViewText(R.id.widget_alarm_countdown, nextAlarm?.let { DayflowTime.countdown(it.at) } ?: "أضف منبهًا")
                views.setTextViewText(R.id.widget_alarm_prayer, "الصلاة القادمة: ${prayer.nextLabel} ${prayer.nextText}")
                views.setOnClickPendingIntent(R.id.widget_alarm_root, open)
            }
            else -> {
                if (form == "1x1" || form == "2x1") {
                    views.setViewVisibility(R.id.widget_prayers, android.view.View.GONE)
                    views.setViewVisibility(R.id.widget_footer, android.view.View.GONE)
                }
                if (form == "1x1") views.setViewVisibility(R.id.widget_next_prayer, android.view.View.GONE)
                val now = ZonedDateTime.now(runCatching { ZoneId.of(prayer.city.zone) }.getOrDefault(ZoneId.systemDefault()))
                views.setTextViewText(R.id.widget_clock, DayflowTime.clock12(now))
                views.setTextViewText(R.id.widget_date, DayflowTime.fullDate(now.toLocalDate()))
                views.setTextViewText(R.id.widget_next_prayer, "${prayer.nextLabel} · ${prayer.nextText}")
                views.setTextViewText(R.id.widget_fajr, "الفجر\n${prayer.text("fajr")}")
                views.setTextViewText(R.id.widget_dhuhr, "الظهر\n${prayer.text("dhuhr")}")
                views.setTextViewText(R.id.widget_asr, "العصر\n${prayer.text("asr")}")
                views.setTextViewText(R.id.widget_maghrib, "المغرب\n${prayer.text("maghrib")}")
                views.setTextViewText(R.id.widget_isha, "العشاء\n${prayer.text("isha")}")
                views.setTextViewText(R.id.widget_footer, nextAlarm?.let { "المنبه: ${it.clock} · ${it.alarm.label.ifBlank { "منبه" }}" } ?: "${prayer.city.ar} · ${CalendarMath.hijriLabel(now.toLocalDate())}")
                views.setOnClickPendingIntent(R.id.widget_root, open)
            }
        }
        manager.updateAppWidget(id, views)
    }
}
