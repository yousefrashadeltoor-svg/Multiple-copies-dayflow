package app.dayflow.android.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Ported 1:1 from the original CSS design tokens. Keeping these values in one
 * place is what prevents the native screen from drifting away from the web UI.
 */
object DayflowColors {
    val Bg = Color(0xFFF7F5F0)
    val BgDeep = Color(0xFFEFEBE2)
    val Surface = Color(0xFFFFFDF8)
    val Surface2 = Color(0xFFFBF8F1)
    val Text = Color(0xFF1E1C18)
    val Muted = Color(0xFF777167)
    val Accent = Color(0xFF2F6F5E)
    val AccentStrong = Color(0xFF245C4D)
    val Gold = Color(0xFFC9A24A)
    val GoldText = Color(0xFF8A6A1C)
    val Line = Color(0xFFE7E2D8)
    val LineStrong = Color(0xFFD8D2C6)
    val Soft = Color(0xFFE9F1EC)
    val SoftGold = Color(0xFFF5EEDC)
    val OnAccent = Color(0xFFFFFDF7)
    val Danger = Color(0xFF9A3F28)
    val DangerSoft = Color(0xFFF7E8E3)
    val Water = Color(0xFF4A93B8)
    val RingBg = Color(0xFF112019)
}

/** Seasonal families mirrored from the web design. */
data class SeasonalFamily(
    val id: String,
    val ar: String,
    val c1: Color,
    val c2: Color,
    val c3: Color,
    val ornamentRes: Int?,
    val note: String,
)

object DayflowSeasons {
    val spring = SeasonalFamily("spring", "الربيع", Color(0xFF5C8A6B), Color(0xFFA8C3A0), Color(0xFFE7B7A9), app.dayflow.android.R.drawable.ornament_blossom, "زهور الربيعى")
    val summer = SeasonalFamily("summer", "الصيف والنيل", Color(0xFF2F6F7A), Color(0xFF8FBFC0), Color(0xFFE7C67A), null, "زرقة النيل")
    val autumn = SeasonalFamily("autumn", "الخريف", Color(0xFF8C5B3A), Color(0xFFC79A63), Color(0xFFD8B26B), app.dayflow.android.R.drawable.ornament_autumn, "ورق الخريف")
    val winter = SeasonalFamily("winter", "الشتاء", Color(0xFF42617A), Color(0xFF9DB4C4), Color(0xFFD6E5EE), null, "صباح شتوي")
    val ramadan = SeasonalFamily("ramadan", "رمضان", Color(0xFF3B5A46), Color(0xFF8F7C4B), Color(0xFFD7B56D), app.dayflow.android.R.drawable.ornament_lantern, "فوانيس وأهلة")
    val eid = SeasonalFamily("eid", "العيد", Color(0xFF59653D), Color(0xFFB39A58), Color(0xFFEED9A4), app.dayflow.android.R.drawable.ornament_blossom, "فرحة العيد")
    val national = SeasonalFamily("national", "وطنية", Color(0xFF6C3730), Color(0xFFC6B79C), Color(0xFFD7BD76), null, "أيام مصر")
    val friday = SeasonalFamily("friday", "الجمعة", Color(0xFF3C5C4B), Color(0xFF9C9A71), Color(0xFFD5BB80), null, "نور الجمعة")
    val islamic = SeasonalFamily("islamic", "إسلامية", Color(0xFF2F5B4B), Color(0xFF9F9A67), Color(0xFFD2B56F), app.dayflow.android.R.drawable.ornament_lantern, "زخارف عربية")

    fun forId(id: String): SeasonalFamily = when (id) {
        "spring" -> spring
        "summer" -> summer
        "autumn" -> autumn
        "winter" -> winter
        "ramadan" -> ramadan
        "eid" -> eid
        "national" -> national
        "friday" -> friday
        else -> islamic
    }
}

private val Typography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 42.sp, lineHeight = 46.sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, lineHeight = 32.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 17.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.5.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 10.sp),
)

private val DayflowShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(26.dp),
)

private val Scheme = lightColorScheme(
    primary = DayflowColors.Accent,
    onPrimary = DayflowColors.OnAccent,
    primaryContainer = DayflowColors.Soft,
    onPrimaryContainer = DayflowColors.AccentStrong,
    secondary = DayflowColors.Gold,
    onSecondary = Color(0xFF231B08),
    secondaryContainer = DayflowColors.SoftGold,
    onSecondaryContainer = DayflowColors.GoldText,
    background = DayflowColors.Bg,
    onBackground = DayflowColors.Text,
    surface = DayflowColors.Surface,
    onSurface = DayflowColors.Text,
    surfaceVariant = DayflowColors.Surface2,
    onSurfaceVariant = DayflowColors.Muted,
    outline = DayflowColors.LineStrong,
    error = DayflowColors.Danger,
    onError = Color.White,
)

@Composable
fun DayflowTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography, shapes = DayflowShapes, content = content)
}

object DayflowText {
    val numeric = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.ExtraBold,
        fontFeatureSettings = "tnum",
    )
    val serif = TextStyle(fontFamily = FontFamily.Serif, fontSize = 14.sp, lineHeight = 23.sp)
}
