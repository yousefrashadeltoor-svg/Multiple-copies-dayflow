package app.dayflow.android.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.domain.PrayerCity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

private val Context.dayflowDataStore by preferencesDataStore(name = "dayflow_state")

class DayflowRepository(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }
    private val stateKey: Preferences.Key<String> = stringPreferencesKey("state_json")

    /** Invoked after every successful write (widgets + alarm scheduling + widget sync). */
    var onChanged: ((DayflowState) -> Unit)? = null

    val state: Flow<DayflowState> = context.dayflowDataStore.data
        .catch { emit(androidx.datastore.preferences.core.emptyPreferences()) }
        .map { preferences -> decode(preferences[stateKey]) }

    suspend fun snapshot(): DayflowState = state.first()

    fun activeCity(state: DayflowState): PrayerCity {
        val customLat = state.prayer.customLat
        val customLng = state.prayer.customLng
        return if (customLat != null && customLng != null) {
            PrayerCity(
                id = "device",
                ar = state.prayer.customLabel ?: "موقعي",
                en = "My location",
                lat = customLat,
                lng = customLng,
                zone = state.prayer.customZone ?: ZoneId.systemDefault().id,
            )
        } else PrayerCatalog.city(state.prayer.cityId)
    }

    fun todayKey(state: DayflowState): String {
        val zone = runCatching { ZoneId.of(activeCity(state).zone) }.getOrDefault(ZoneId.systemDefault())
        return DayflowTime.dateKey(LocalDate.now(zone))
    }

    private suspend fun updateNow(block: (DayflowState) -> DayflowState): DayflowState {
        var result: DayflowState? = null
        context.dayflowDataStore.edit { preferences ->
            val current = decode(preferences[stateKey])
            val next = block(current)
            preferences[stateKey] = json.encodeToString(next)
            result = next
        }
        val next = result ?: decode(emptyPreferences())
        runCatching { onChanged?.invoke(next) }
        return next
    }

    /** Fire-and-forget mutation used by UI and system services. */
    fun update(block: (DayflowState) -> DayflowState) {
        scope.launch { runCatching { updateNow(block) } }
    }

    suspend fun updateAndWait(block: (DayflowState) -> DayflowState): DayflowState = updateNow(block)

    private fun decode(preferences: Preferences): DayflowState {
        val raw = preferences[stateKey] ?: return seed()
        return runCatching { json.decodeFromString<DayflowState>(raw) }.getOrElse { seed() }
    }

    private fun seed(): DayflowState {
        val today = DayflowTime.todayKey(ZoneId.of("Africa/Cairo"))
        return defaultState(today)
    }

    // ---------------- Prayer / appearance ----------------

    fun setCity(cityId: String) = update { it.copy(prayer = it.prayer.copy(cityId = cityId, customLat = null, customLng = null, customLabel = null)) }
    fun setMethod(methodId: String) = update { it.copy(prayer = it.prayer.copy(methodId = methodId)) }
    fun setAsrFactor(factor: Int) = update { it.copy(prayer = it.prayer.copy(asrFactor = factor)) }
    fun setCustomLocation(lat: Double, lng: Double, label: String, zone: String) = update {
        it.copy(prayer = it.prayer.copy(customLat = lat, customLng = lng, customLabel = label, customZone = zone))
    }
    fun clearCustomLocation() = update { it.copy(prayer = it.prayer.copy(customLat = null, customLng = null, customLabel = null, customZone = null)) }
    fun setAppearance(block: (Appearance) -> Appearance) = update { it.copy(appearance = block(it.appearance)) }
    fun setNotif(block: (NotifPrefs) -> NotifPrefs) = update { it.copy(notif = block(it.notif)) }
    fun setCompanion(block: (CompanionPrefs) -> CompanionPrefs) = update { it.copy(companion = block(it.companion)) }

    // ---------------- Alarms ----------------

    fun upsertAlarm(alarm: Alarm) = update { state ->
        val exists = state.alarms.any { it.id == alarm.id }
        state.copy(alarms = if (exists) state.alarms.map { if (it.id == alarm.id) alarm else it } else state.alarms + alarm)
    }

    fun newAlarmId(): String = UUID.randomUUID().toString().take(10)

    fun deleteAlarm(id: String) = update { state -> state.copy(alarms = state.alarms.filterNot { it.id == id }) }

    fun toggleAlarm(id: String, enabled: Boolean) = update { state ->
        state.copy(alarms = state.alarms.map { if (it.id == id) it.copy(enabled = enabled) else it })
    }

    // ---------------- Tasks / notes / habits ----------------

    fun addTask(title: String, date: String, urgent: Boolean = false, important: Boolean = true, dueTime: String? = null) = update { state ->
        state.copy(tasks = listOf(Task(UUID.randomUUID().toString().take(10), title, date, dueTime, urgent = urgent, important = important)) + state.tasks)
    }

    fun toggleTask(id: String) = update { state ->
        state.copy(tasks = state.tasks.map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    fun deleteTask(id: String) = update { state -> state.copy(tasks = state.tasks.filterNot { it.id == id }) }

    fun addNote(text: String) = update { state -> state.copy(notes = listOf(Note(UUID.randomUUID().toString().take(10), text)) + state.notes) }
    fun toggleNotePin(id: String) = update { state -> state.copy(notes = state.notes.map { if (it.id == id) it.copy(pinned = !it.pinned) else it }) }
    fun deleteNote(id: String) = update { state -> state.copy(notes = state.notes.filterNot { it.id == id }) }

    fun addHabit(ar: String, emoji: String = "✨") = update { state ->
        state.copy(habits = state.habits + Habit(UUID.randomUUID().toString().take(10), ar, ar, emoji))
    }

    fun toggleHabit(id: String) = update { state ->
        val today = todayKey(state)
        state.copy(habits = state.habits.map { habit ->
            if (habit.id != id) habit
            else habit.copy(log = if (today in habit.log) habit.log - today else habit.log + today)
        })
    }

    fun deleteHabit(id: String) = update { state -> state.copy(habits = state.habits.filterNot { it.id == id }) }

    fun addWater(ml: Int) = update { state ->
        val key = todayKey(state)
        state.copy(water = state.water + (key to ((state.water[key] ?: 0) + ml).coerceAtLeast(0)))
    }

    // ---------------- Widgets ----------------

    fun placeWidget(designId: String, form: String, style: String) = update { state ->
        val placed = state.widgets.placed + PlacedWidget(UUID.randomUUID().toString().take(10), designId, form, style)
        state.copy(widgets = state.widgets.copy(designId = designId, form = form, style = style, placed = placed))
    }

    fun setWidgetChoice(designId: String, form: String, style: String) = update { state ->
        state.copy(widgets = state.widgets.copy(designId = designId, form = form, style = style))
    }

    fun deleteWidget(id: String) = update { state ->
        state.copy(widgets = state.widgets.copy(placed = state.widgets.placed.filterNot { it.id == id }))
    }

    // ---------------- Downloads ----------------

    fun addDownload(record: DownloadRecord) = update { state -> state.copy(downloads = (listOf(record) + state.downloads).take(30)) }
    fun clearDownloads() = update { it.copy(downloads = emptyList()) }
    fun deleteDownload(id: String) = update { state -> state.copy(downloads = state.downloads.filterNot { it.id == id }) }

    fun setOnboarded() = update { it.copy(screen = it.screen.copy(onboarded = true)) }
}
