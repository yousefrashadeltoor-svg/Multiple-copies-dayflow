package app.dayflow.android.domain

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

data class LinkPreview(
    val url: String,
    val title: String,
    val description: String? = null,
    val imageUrl: String? = null,
    val author: String? = null,
    val siteName: String? = null,
    val mimeType: String? = null,
    val contentLength: Long? = null,
    val filename: String? = null,
    val isDirectFile: Boolean = false,
    val durationSeconds: Int? = null,
)

data class MediaFormat(
    val itag: Int,
    val label: String,
    val mime: String,
    val extension: String,
    val url: String,
    val contentLength: Long?,
    val audioOnly: Boolean,
    val note: String,
)

data class YouTubeData(
    val videoId: String,
    val preview: LinkPreview,
    val formats: List<MediaFormat>,
)

/**
 * Native HTTP. The browser build failed here because cross-origin reads are
 * blocked. Android has no CORS: OkHttp fetches the page and Jsoup parses real
 * OpenGraph/Twitter/JSON-LD metadata, so titles, covers, authors and descriptions
 * are genuine or explicitly absent — never fabricated.
 */
object NativeMedia {
    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val UA = "Mozilla/5.0 (Linux; Android 14; DAYFLOW/1.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36"

    private val extensions = mapOf(
        "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png", "webp" to "image/webp",
        "gif" to "image/gif", "svg" to "image/svg+xml", "mp4" to "video/mp4", "webm" to "video/webm",
        "mkv" to "video/x-matroska", "mov" to "video/quicktime", "mp3" to "audio/mpeg", "m4a" to "audio/mp4",
        "ogg" to "audio/ogg", "wav" to "audio/wav", "pdf" to "application/pdf", "zip" to "application/zip",
        "apk" to "application/vnd.android.package-archive", "epub" to "application/epub+zip",
    )

    fun extensionOf(url: String): String? = runCatching {
        Uri.parse(url).lastPathSegment
            ?.substringAfterLast('.', "")
            ?.lowercase()
            ?.takeIf { it in extensions.keys }
    }.getOrNull()

    fun filenameOf(url: String): String = runCatching {
        Uri.parse(url).lastPathSegment?.substringAfterLast('/')?.ifBlank { null } ?: "ملف DAYFLOW"
    }.getOrDefault("ملف DAYFLOW")

    fun directMime(url: String): String? = extensionOf(url)?.let { extensions[it] }

    fun isYouTube(url: String): Boolean = runCatching {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        host.contains("youtube.com") || host.contains("youtu.be")
    }.getOrDefault(false)

    fun youTubeId(url: String): String? = runCatching {
        val uri = Uri.parse(url)
        when {
            uri.host?.contains("youtu.be") == true -> uri.lastPathSegment
            uri.getQueryParameter("v") != null -> uri.getQueryParameter("v")
            uri.path?.startsWith("/shorts/") == true -> uri.pathSegments.getOrNull(1)
            else -> null
        }
    }.getOrNull()

    suspend fun preview(url: String): LinkPreview = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val directMime = directMime(url)
        if (directMime != null) {
            val head = runCatching {
                client.newCall(Request.Builder().url(url).head().header("User-Agent", UA).build()).execute()
            }.getOrNull()
            return@withContext LinkPreview(
                url = url,
                title = filenameOf(url),
                description = "ملف مباشر — سيتم حفظه في مجلد التنزيلات.",
                mimeType = head?.header("Content-Type")?.substringBefore(';') ?: directMime,
                contentLength = head?.header("Content-Length")?.toLongOrNull(),
                filename = filenameOf(url),
                isDirectFile = true,
            )
        }

        if (isYouTube(url)) {
            val id = youTubeId(url) ?: throw IllegalArgumentException("رابط يوتيوب غير صالح")
            val data = youtube(id).getOrElse { throw it }
            return@withContext data.preview
        }

        val response = client.newCall(
            Request.Builder().url(url).header("User-Agent", UA).header("Accept-Language", "ar,en;q=0.8").build(),
        ).execute()
        response.use { res ->
            val doc = Jsoup.parse(res.body?.string().orEmpty(), res.request.url.toString())
            fun meta(vararg keys: String): String? {
                for (key in keys) {
                    val value = doc.selectFirst("meta[property=$key], meta[name=$key]")?.attr("content")
                    if (!value.isNullOrBlank()) return value.trim()
                }
                return null
            }
            val jsonLd = doc.select("script[type=application/ld+json]").firstOrNull()?.data()?.let { raw ->
                runCatching { JSONObject(raw) }.getOrNull()
            }
            val title = meta("og:title", "twitter:title")
                ?: jsonLd?.optString("headline")?.takeIf { it.isNotBlank() }
                ?: doc.title().takeIf { it.isNotBlank() }
                ?: res.request.url.host
            val image = meta("og:image", "og:image:url", "twitter:image", "twitter:image:src")
                ?: jsonLd?.optString("thumbnailUrl")?.takeIf { it.isNotBlank() }
            val description = meta("og:description", "twitter:description", "description")
                ?: jsonLd?.optString("description")?.takeIf { it.isNotBlank() }
            LinkPreview(
                url = url,
                title = title,
                description = description,
                imageUrl = image?.let { absolute(res.request.url.toString(), it) },
                author = meta("author", "article:author", "og:site_name"),
                siteName = meta("og:site_name") ?: res.request.url.host,
                mimeType = meta("og:type"),
            )
        }
    }

    private fun absolute(base: String, candidate: String): String = runCatching {
        val uri = Uri.parse(candidate)
        if (uri.isAbsolute) candidate else Uri.parse(base).buildUpon().appendEncodedPath(candidate).build().toString()
    }.getOrDefault(candidate)

    /**
     * YouTube's InnerTube player endpoint. Only progressive/adaptive formats that
     * actually return a direct URL are surfaced. No fake formats and no DRM bypass.
     */
    suspend fun youtube(videoId: String): Result<YouTubeData> = runCatching {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val context = JSONObject().put(
                "client",
                JSONObject()
                    .put("clientName", "ANDROID")
                    .put("clientVersion", "19.09.37")
                    .put("androidSdkVersion", 30)
                    .put("hl", "ar")
                    .put("gl", "EG"),
            )
            val payload = JSONObject()
                .put("context", context)
                .put("videoId", videoId)
                .put("contentCheckOk", true)
                .put("racyCheckOk", true)
                .toString()

            val media = "application/json; charset=utf-8".toMediaType()
            val request = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/player?key=AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w")
                .post(payload.toRequestBody(media))
                .header("User-Agent", "com.google.android.youtube/19.09.37 (Linux; U; Android 14) gzip")
                .header("Content-Type", "application/json")
                .build()
            val json = client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("تعذر الوصول إلى يوتيوب (${response.code})")
                JSONObject(response.body?.string().orEmpty())
            }
            val playability = json.optJSONObject("playabilityStatus")?.optString("status")
            if (playability != null && playability != "OK") {
                val reason = json.optJSONObject("playabilityStatus")?.optString("reason") ?: "المقطع غير متاح"
                throw IllegalStateException("يوتيوب منع استخراج هذا المقطع: $reason")
            }
            val details = json.optJSONObject("videoDetails") ?: throw IllegalStateException("لم تصل تفاصيل الفيديو")
            val streaming = json.optJSONObject("streamingData") ?: throw IllegalStateException("لا توجد صيغ مباشرة لهذا الفيديو")
            val formats = mutableListOf<MediaFormat>()
            val arrayNames = listOf("formats", "adaptiveFormats")
            for (arrayName in arrayNames) {
                val array = streaming.optJSONArray(arrayName) ?: continue
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val directUrl = item.optString("url").takeIf { it.startsWith("http") } ?: continue
                    val mime = item.optString("mimeType").substringBefore(';')
                    if (mime.contains("drm", ignoreCase = true)) continue
                    val itag = item.optInt("itag")
                    val length = item.optString("contentLength").toLongOrNull()
                    val audioOnly = mime.startsWith("audio/")
                    val videoOnly = mime.startsWith("video/") && !item.has("audioQuality")
                    if (videoOnly) continue
                    val extension = if (audioOnly) "m4a" else "mp4"
                    val label = when {
                        audioOnly -> "صوت ${item.optString("audioQuality").replace("AUDIO_QUALITY_", "").lowercase()}".replaceFirstChar { it.uppercase() }
                        else -> (item.optString("qualityLabel").ifBlank { "${item.optInt("height")}p" }) + if (arrayName == "formats") " · MP4" else " · MP4 (فيديو)"
                    }
                    if (formats.none { it.itag == itag }) {
                        formats += MediaFormat(itag, label, mime, extension, directUrl, length, audioOnly, if (audioOnly) "صوت مباشر" else "فيديو تقدمي بدون DRM")
                    }
                }
            }
            if (formats.isEmpty()) throw IllegalStateException("لا توجد صيغة قابلة للتنزيل مباشرة لهذا المقطع")
            val thumbnail = details.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.let { thumbs ->
                if (thumbs.length() == 0) null else thumbs.optJSONObject(thumbs.length() - 1)?.optString("url")
            }
            val preview = LinkPreview(
                url = "https://www.youtube.com/watch?v=$videoId",
                title = details.optString("title").ifBlank { "فيديو يوتيوب" },
                description = details.optString("shortDescription").takeIf { it.isNotBlank() },
                imageUrl = thumbnail,
                author = details.optString("author").takeIf { it.isNotBlank() },
                siteName = "YouTube",
                durationSeconds = details.optInt("lengthSeconds", 0),
                filename = details.optString("title").ifBlank { "dayflow-video" },
            )
            YouTubeData(videoId, preview, formats.distinctBy { it.itag })
        }
    }.recoverCatching { throwable -> throw IllegalStateException(throwable.message ?: "تعذر استخراج الفيديو") }

    fun enqueueDownload(context: Context, preview: LinkPreview, format: MediaFormat?): Long {
        val targetUrl = format?.url ?: preview.url
        val extension = format?.extension ?: extensionOf(preview.url) ?: "bin"
        val base = sanitize(preview.title.ifBlank { preview.filename ?: "DAYFLOW" })
        val filename = "$base.${extension}"
        val manager = context.getSystemService(DownloadManager::class.java)
            ?: throw IllegalStateException("مدير التنزيلات غير متاح")
        val request = DownloadManager.Request(Uri.parse(targetUrl))
            .setTitle(base)
            .setDescription("DAYFLOW — تحميل")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .addRequestHeader("User-Agent", UA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            request.setMimeType(format?.mime ?: preview.mimeType ?: directMime(preview.url))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
        } else {
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, filename)
        }
        return manager.enqueue(request)
    }

    fun downloadStatus(context: Context, id: Long): Triple<String, Int, Boolean> {
        val manager = context.getSystemService(DownloadManager::class.java) ?: return Triple("غير متاح", 0, false)
        manager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
            if (cursor == null || !cursor.moveToFirst()) return Triple("غير موجود", 0, false)
            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val downloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val progress = if (total > 0) ((downloaded * 100) / total).toInt() else 0
            val label = when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> "اكتمل"
                DownloadManager.STATUS_RUNNING -> "جاري التحميل $progress%"
                DownloadManager.STATUS_FAILED -> "فشل — تحقق من الرابط أو الاتصال"
                DownloadManager.STATUS_PAUSED -> "متوقف مؤقتًا"
                DownloadManager.STATUS_PENDING -> "في الانتظار"
                else -> "غير معروف"
            }
            return Triple(label, progress, status == DownloadManager.STATUS_SUCCESSFUL)
        }
    }

    private fun sanitize(value: String): String = value
        .replace(Regex("[\\\\/:*?\"<>|]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(80)
        .ifBlank { "DAYFLOW-${System.currentTimeMillis()}" }
}
