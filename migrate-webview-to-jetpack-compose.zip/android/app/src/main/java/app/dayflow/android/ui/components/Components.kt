package app.dayflow.android.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RectF
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.domain.PrayerDay
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowText

@Composable
fun DayflowBackground(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFFEAF1EA), DayflowColors.Bg),
                    center = Offset(240f, 0f),
                    radius = 1300f,
                ),
            ),
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x16C9A24A), radius = size.width * 0.55f, center = Offset(size.width * 0.92f, size.height * 0.08f))
            drawCircle(Color(0x142F6F5E), radius = size.width * 0.6f, center = Offset(size.width * 0.05f, size.height * 0.55f))
        }
        content()
    }
}

@Composable
fun ScreenHeader(
    title: String,
    eyebrow: String? = null,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    action: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
    ) {
        Column(Modifier.weight(1f)) {
            if (eyebrow != null) Text(eyebrow, color = DayflowColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
            Text(title, style = MaterialTheme.typography.headlineLarge, color = DayflowColors.Text)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = DayflowColors.Muted, modifier = Modifier.padding(top = 2.dp))
        }
        if (action != null) Spacer(Modifier.width(8.dp))
        action?.invoke()
    }
}

@Composable
fun DfCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: Dp = 16.dp,
    dark: Boolean = false,
    content: @Composable () -> Unit,
) {
    val base = modifier
        .clip(RoundedCornerShape(20.dp))
        .border(1.dp, if (dark) Color.White.copy(alpha = 0.12f) else DayflowColors.Line, RoundedCornerShape(20.dp))
        .background(if (dark) DayflowColors.RingBg else DayflowColors.Surface)
    Box((if (onClick != null) base.clickable { onClick() } else base).padding(padding)) { content() }
}

@Composable
fun SectionTitle(title: String, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = DayflowColors.Text)
        trailing?.invoke()
    }
}

@Composable
fun DfSwitch(checked: Boolean, onChange: (Boolean) -> Unit, label: String) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = DayflowColors.Accent,
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = DayflowColors.LineStrong,
            uncheckedBorderColor = Color.Transparent,
        ),
        modifier = Modifier.padding(0.dp),
    )
    // label is required for accessibility in the original UI; callers also add text.
    if (label.isBlank()) Spacer(Modifier.size(0.dp))
}

@Composable
fun IconBadge(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color = DayflowColors.Accent, background: Color = DayflowColors.Soft, size: Dp = 38.dp) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 3.4f)).background(background),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.46f)) }
}

@Composable
fun SmallTag(text: String, tone: String = "soft") {
    val bg = when (tone) {
        "green" -> DayflowColors.Soft
        "gold" -> DayflowColors.SoftGold
        "warn" -> DayflowColors.DangerSoft
        else -> DayflowColors.BgDeep
    }
    val fg = when (tone) {
        "green" -> DayflowColors.AccentStrong
        "gold" -> DayflowColors.GoldText
        "warn" -> DayflowColors.Danger
        else -> DayflowColors.Muted
    }
    Text(
        text,
        color = fg,
        fontSize = 9.5.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(CircleShape).background(bg).padding(horizontal = 8.dp, vertical = 3.dp),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun DfChip(text: String, selected: Boolean = false, onClick: (() -> Unit)? = null) {
    Text(
        text,
        color = if (selected) DayflowColors.OnAccent else DayflowColors.Text,
        fontSize = 10.5.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) DayflowColors.Accent else DayflowColors.Surface)
            .border(1.dp, if (selected) Color.Transparent else DayflowColors.Line, CircleShape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 10.dp, vertical = 6.dp),
    )
}

@Composable
fun NoticeCard(title: String, body: String, tone: String = "green", icon: androidx.compose.ui.graphics.vector.ImageVector? = null) {
    val bg = if (tone == "warn") DayflowColors.DangerSoft else DayflowColors.Soft
    val fg = if (tone == "warn") DayflowColors.Danger else DayflowColors.AccentStrong
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).border(1.dp, fg.copy(alpha = 0.14f), RoundedCornerShape(14.dp)).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        if (icon != null) Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(16.dp))
        Column {
            Text(title, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            Text(body, color = fg.copy(alpha = 0.82f), fontSize = 10.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun ProgressBar(value: Float, color: Color = DayflowColors.Accent, height: Dp = 6.dp) {
    Box(Modifier.fillMaxWidth().height(height).clip(CircleShape).background(DayflowColors.Line)) {
        Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).height(height).clip(CircleShape).background(color))
    }
}

@Composable
fun PrayerStrip(day: PrayerDay, onPrayerClick: ((String) -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        day.slots.forEach { slot ->
            val active = day.next?.key == slot.key
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (active) DayflowColors.Accent else DayflowColors.Soft)
                    .then(if (onPrayerClick != null) Modifier.clickable { onPrayerClick(slot.key) } else Modifier)
                    .padding(vertical = 5.dp, horizontal = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(slot.icon, fontSize = 10.sp)
                Text(slot.ar, color = if (active) DayflowColors.OnAccent else DayflowColors.Text, fontSize = 8.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(slot.text, color = if (active) DayflowColors.OnAccent else DayflowColors.Text, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, style = DayflowText.numeric, maxLines = 1)
            }
        }
    }
}

@Composable
fun SeasonOrnament(familyId: String, size: Dp = 96.dp, rotation: Float = 0f, modifier: Modifier = Modifier, alpha: Float = 1f) {
    val family = DayflowSeasons.forId(familyId)
    if (family.ornamentRes != null) {
        Image(
            painter = painterResource(family.ornamentRes),
            contentDescription = null,
            alpha = alpha,
            contentScale = ContentScale.Fit,
            modifier = modifier.size(size).rotate(rotation),
        )
    } else {
        Canvas(modifier.size(size).rotate(rotation)) {
            val color = family.c2.copy(alpha = alpha)
            when (familyId) {
                "winter" -> {
                    repeat(6) { index ->
                        rotate(index * 30f) {
                            drawLine(color, center, Offset(center.x, 4.dp.toPx()), strokeWidth = 1.6f)
                            drawCircle(family.c3, 3.dp.toPx(), Offset(center.x - 8.dp.toPx(), 18.dp.toPx()))
                        }
                    }
                }
                "summer" -> {
                    drawCircle(family.c2.copy(alpha = alpha * 0.8f), size.minDimension / 4f)
                    repeat(12) { index ->
                        rotate(index * 30f) { drawLine(family.c3, Offset(center.x, size.minDimension * 0.18f), Offset(center.x, size.minDimension * 0.04f), strokeWidth = 3f) }
                    }
                }
                "national" -> {
                    drawRect(color = Color(0xFFCE1126), topLeft = Offset(size.width * 0.2f, size.height * 0.2f), size = androidx.compose.ui.geometry.Size(size.width * 0.6f, 6.dp.toPx()))
                    drawRect(color = Color.White, topLeft = Offset(size.width * 0.2f, size.height * 0.3f), size = androidx.compose.ui.geometry.Size(size.width * 0.6f, 6.dp.toPx()))
                    drawRect(color = Color(0xFF1D1C1A), topLeft = Offset(size.width * 0.2f, size.height * 0.4f), size = androidx.compose.ui.geometry.Size(size.width * 0.6f, 6.dp.toPx()))
                }
                else -> {
                    drawCircle(family.c2.copy(alpha = alpha * 0.35f), size.minDimension / 2f)
                    drawCircle(family.c3.copy(alpha = alpha * 0.7f), size.minDimension / 5f)
                    drawRect(family.c2, topLeft = Offset(size.width * 0.25f, size.height * 0.25f), size = androidx.compose.ui.geometry.Size(size.width * 0.5f, size.height * 0.5f), style = Stroke(1.5f))
                }
            }
        }
    }
}

@Composable
fun HeaderCrown(familyId: String, modifier: Modifier = Modifier) {
    val family = DayflowSeasons.forId(familyId)
    Canvas(modifier.fillMaxWidth().height(48.dp)) {
        val path = Path().apply {
            moveTo(0f, 20f)
            cubicTo(size.width * 0.2f, 60f, size.width * 0.34f, 0f, size.width * 0.5f, 16f)
            cubicTo(size.width * 0.66f, 32f, size.width * 0.82f, 4f, size.width, 22f)
        }
        drawPath(path, family.c3.copy(alpha = 0.75f), style = Stroke(1.4f))
        val path2 = Path().apply {
            moveTo(0f, 27f)
            cubicTo(size.width * 0.22f, 68f, size.width * 0.4f, 12f, size.width * 0.55f, 27f)
            cubicTo(size.width * 0.78f, 46f, size.width * 0.88f, 18f, size.width, 30f)
        }
        drawPath(path2, family.c3.copy(alpha = 0.35f), style = Stroke(1f))
        listOf(0.12f, 0.22f, 0.32f, 0.7f, 0.8f, 0.9f).forEachIndexed { index, fraction ->
            drawCircle(family.c3.copy(alpha = 0.75f), 2f + (index % 2), Offset(size.width * fraction, 8f + (index % 3) * 7f))
        }
    }
}

@Composable
fun Robot(
    size: Dp = 78.dp,
    family: String = "friday",
    mood: String = "idle",
    opacity: Float = 1f,
    modifier: Modifier = Modifier,
    animate: Boolean = true,
) {
    val transition = rememberInfiniteTransition(label = "robot")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (animate) -6f else 0f,
        animationSpec = infiniteRepeatable(tween(3000), RepeatMode.Reverse),
        label = "float",
    )
    Canvas(
        modifier = modifier
            .size(width = size, height = size * 1.24f)
            .drawBehind {
                drawContext.canvas.nativeCanvas.let { canvas ->
                    canvas.save()
                    canvas.translate(0f, offset)
                    RobotRenderer.draw(canvas, this.size.width, this.size.height, family, mood, opacity)
                    canvas.restore()
                }
            },
    ) {}
}

@Composable
fun EmptyState(title: String, hint: String, action: (@Composable () -> Unit)? = null, emoji: String = "🌿") {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(DayflowColors.Surface2).border(1.dp, DayflowColors.Line, RoundedCornerShape(18.dp)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(emoji, fontSize = 24.sp)
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text(hint, color = DayflowColors.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        if (action != null) Spacer(Modifier.padding(top = 10.dp)) else Unit
        action?.invoke()
    }
}

@Composable
fun IconRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        IconBadge(icon, size = 34.dp)
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = DayflowColors.Muted, fontSize = 9.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing?.invoke()
    }
}

@Suppress("unused")
private val noopPainter: Painter? = null
