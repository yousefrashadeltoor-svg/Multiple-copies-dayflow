package app.dayflow.android.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alert
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Clipboard
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import coil.compose.AsyncImage
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.data.DownloadRecord
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.LinkPreview
import app.dayflow.android.domain.MediaFormat
import app.dayflow.android.domain.NativeMedia
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.EmptyState
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.ProgressBar
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.components.SectionTitle
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DownloadsScreen(
    state: DayflowState,
    repository: DayflowRepository,
    initialLink: String?,
    onConsumeInitialLink: () -> Unit,
    navigate: Navigate,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(initialLink.orEmpty()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var preview by remember { mutableStateOf<LinkPreview?>(null) }
    var formats by remember { mutableStateOf<List<MediaFormat>>(emptyList()) }
    var activeId by remember { mutableStateOf<Long?>(null) }
    var activeLabel by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0) }

    fun analyze(target: String) {
        if (target.isBlank()) { error = "الصق رابطًا أولًا."; return }
        error = null; preview = null; formats = emptyList(); loading = true
        scope.launch {
            runCatching {
                if (NativeMedia.isYouTube(target)) {
                    val data = NativeMedia.youtube(NativeMedia.youTubeId(target) ?: throw IllegalArgumentException("رابط YouTube غير صالح")).getOrThrow()
                    preview = data.preview
                    formats = data.formats
                } else {
                    val meta = NativeMedia.preview(target)
                    preview = meta
                    val ext = NativeMedia.extensionOf(target)
                    if (meta.isDirectFile && ext != null) {
                        formats = listOf(MediaFormat(0, "${meta.mimeType ?: "ملف"} · .$ext", meta.mimeType ?: "application/octet-stream", ext, target, meta.contentLength, false, "ملف مباشر — DownloadManager"))
                    }
                }
            }.onFailure { error = it.message ?: "تعذّر تحليل الرابط" }
            loading = false
        }
    }

    LaunchedEffect(initialLink) {
        if (!initialLink.isNullOrBlank()) {
            url = initialLink
            analyze(initialLink)
            onConsumeInitialLink()
        }
    }
    LaunchedEffect(activeId) {
        val id = activeId ?: return@LaunchedEffect
        repeat(60) {
            delay(1000)
            val (label, pct, done) = NativeMedia.downloadStatus(context, id)
            activeLabel = label; progress = pct
            if (done || label.startsWith("فشل")) return@LaunchedEffect
        }
    }

    fun startDownload(format: MediaFormat?) {
        val meta = preview ?: return
        runCatching {
            val id = NativeMedia.enqueueDownload(context, meta, format)
            activeId = id
            activeLabel = "بدأ التحميل"
            progress = 0
            repository.addDownload(DownloadRecord(id = id.toString(), title = meta.title, url = meta.url, mime = format?.mime ?: meta.mimeType, localUri = null))
        }.onFailure { error = it.message ?: "تعذّر بدء التحميل" }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("التحميل", "MEDIA HUB · أصلي", "معاينة حقيقية وتحميل بدون CORS") }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Rounded.Link)
                        Spacer(Modifier.width(7.dp))
                        Text("معاينة الرابط وتحميله", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        SmallTag("أصلي", "green")
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = url, onValueChange = { url = it }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                            decorationBox = { if (url.isBlank()) Text("https://… الصق رابط هنا", color = DayflowColors.Muted, fontSize = 10.sp); it() },
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(DayflowColors.Surface2).padding(10.dp),
                        )
                        Spacer(Modifier.width(5.dp))
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(DayflowColors.Accent).clickable { analyze(url) }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Search, "تحليل", tint = DayflowColors.OnAccent, modifier = Modifier.size(17.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        Box(Modifier.clip(CircleShape).border(1.dp, DayflowColors.Line, CircleShape).clickable {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val value = clipboard?.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
                            if (value.isNotBlank()) { url = value; analyze(value) }
                        }.padding(horizontal = 9.dp, vertical = 5.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Clipboard, null, tint = DayflowColors.Accent, modifier = Modifier.size(11.dp)); Spacer(Modifier.width(3.dp)); Text("لصق", fontSize = 9.5.sp, fontWeight = FontWeight.Bold) }
                        }
                        if (loading) Text("جاري قراءة العنوان والغلاف…", color = DayflowColors.Muted, fontSize = 9.5.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    error?.let { Text(it, color = DayflowColors.Danger, fontSize = 10.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        }
        preview?.let { meta ->
            item {
                DfCard(Modifier.fillMaxWidth(), padding = 0.dp) {
                    Column {
                        if (!meta.imageUrl.isNullOrBlank()) {
                            AsyncImage(model = meta.imageUrl, contentDescription = "غلاف المعاينة", modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)), contentScale = androidx.compose.ui.layout.ContentScale.Crop)
                        } else {
                            Box(Modifier.fillMaxWidth().height(100.dp).background(DayflowColors.Soft), contentAlignment = Alignment.Center) {
                                Icon(if (meta.isDirectFile) Icons.Rounded.FileOpen else Icons.Rounded.Link, null, tint = DayflowColors.Accent, modifier = Modifier.size(30.dp))
                            }
                        }
                        Column(Modifier.padding(13.dp)) {
                            Text(meta.title, color = DayflowColors.Text, fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 19.sp)
                            Text(listOfNotNull(meta.author, meta.siteName, meta.description).joinToString(" · "), color = DayflowColors.Muted, fontSize = 9.5.sp, lineHeight = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 6.dp)) {
                                SmallTag(meta.mimeType ?: "صفحة وسائط", "soft")
                                if (meta.durationSeconds != null) SmallTag("${meta.durationSeconds / 60}:${(meta.durationSeconds % 60).toString().padStart(2, '0')}", "gold")
                                if (meta.contentLength != null) SmallTag("${meta.contentLength / 1024 / 1024} MB", "green")
                            }
                        }
                    }
                }
            }
        }
        if (formats.isNotEmpty() && preview != null) {
            item {
                DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                    Column {
                        SectionTitle("الصيغ المكتشفة") { SmallTag("حقيقية", "green") }
                        Spacer(Modifier.height(5.dp))
                        formats.forEach { format ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (format.audioOnly) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow, null, tint = DayflowColors.Accent, modifier = Modifier.size(15.dp))
                                Spacer(Modifier.width(6.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(format.label, color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    Text(format.note, color = DayflowColors.Muted, fontSize = 8.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (format.contentLength != null) Text("${format.contentLength / 1024 / 1024} MB", color = DayflowColors.Muted, fontSize = 8.sp)
                                Spacer(Modifier.width(5.dp))
                                Box(Modifier.clip(CircleShape).background(DayflowColors.Soft).clickable { startDownload(format) }.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text("تنزيل", color = DayflowColors.AccentStrong, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (activeId != null) {
            item {
                DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                    Column {
                        Text(activeLabel, color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        ProgressBar(progress / 100f, DayflowColors.Accent, 6.dp)
                        Text("الملف يُحفظ في مجلد التنزيلات بهاتفك. يمكنك متابعة التقدم من إشعارات النظام.", color = DayflowColors.Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 5.dp))
                    }
                }
            }
        }
        item {
            NoticeCard("لماذا يعمل هنا ولا في المتصفح؟", "الويب يحجب قراءة صفحات المواقع (CORS). أندرويد يقرأ OpenGraph وJSON-LD مباشرة. لا نعرض أي صيغة أو حجم غير مُستخرج فعليًا، وفيديوهات يوتيوب المحمية أو غير المتاحة تظهر برسالة صريحة.", "green", Icons.Rounded.Smartphone)
        }
        item {
            SectionTitle("سجل التنزيلات") { if (state.downloads.isNotEmpty()) Text("مسح", color = DayflowColors.Danger, fontSize = 9.sp, modifier = Modifier.clickable { repository.clearDownloads() }) }
        }
        items(state.downloads, key = { it.id }) { record ->
            DfCard(Modifier.fillMaxWidth(), padding = 11.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Download, size = 32.dp)
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(record.title, color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(record.url, color = DayflowColors.Muted, fontSize = 8.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("بدأ", color = DayflowColors.Accent, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (state.downloads.isEmpty()) item { EmptyState("مفيش تنزيلات لسه", "أول ملف تنزّله هيظهر هنا بحالته الحقيقية.", emoji = "⬇️") }
    }
}
