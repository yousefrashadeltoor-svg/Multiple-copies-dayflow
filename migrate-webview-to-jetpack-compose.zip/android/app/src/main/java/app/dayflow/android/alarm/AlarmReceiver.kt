package app.dayflow.android.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import app.dayflow.android.DayflowApplication
import app.dayflow.android.data.AlarmSound
import app.dayflow.android.data.Alarm
import app.dayflow.android.notifications.DayflowNotifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Receives exact AlarmManager broadcasts while the app may be dead. It starts the
 * foreground ringing service and reschedules the next occurrence.
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_FIRE) return
        val id = intent.getStringExtra(AlarmScheduler.EXTRA_ID) ?: return
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val repository = DayflowApplication.repository(context)
                val stored = runCatching { repository.snapshot() }.getOrNull()
                val alarm = stored?.alarms?.firstOrNull { it.id == id } ?: Alarm(
                    id = id,
                    time = intent.getStringExtra(AlarmScheduler.EXTRA_TIME) ?: "07:00",
                    date = intent.getStringExtra(AlarmScheduler.EXTRA_DATE),
                    days = intent.getIntArrayExtra(AlarmScheduler.EXTRA_DAYS)?.toList() ?: emptyList(),
                    label = intent.getStringExtra(AlarmScheduler.EXTRA_LABEL).orEmpty(),
                    sound = AlarmSound(
                        uri = intent.getStringExtra(AlarmScheduler.EXTRA_SOUND_URI),
                        title = intent.getStringExtra(AlarmScheduler.EXTRA_SOUND_TITLE) ?: "نغمة المنبه",
                    ),
                    vibrate = intent.getBooleanExtra(AlarmScheduler.EXTRA_VIBRATE, true),
                    snooze = intent.getIntExtra(AlarmScheduler.EXTRA_SNOOZE, 10),
                    gentle = intent.getBooleanExtra(AlarmScheduler.EXTRA_GENTLE, true),
                )

                if (stored != null && !alarm.enabled) {
                    DayflowNotifications.createChannels(context)
                    return@launch
                }

                val service = Intent(context, AlarmRingService::class.java).apply {
                    action = AlarmRingService.ACTION_START
                    putExtra(AlarmRingService.EXTRA_ALARM_ID, alarm.id)
                    putExtra(AlarmRingService.EXTRA_LABEL, alarm.label)
                    putExtra(AlarmRingService.EXTRA_TIME, alarm.time)
                    putExtra(AlarmRingService.EXTRA_SOUND_URI, alarm.sound.uri)
                    putExtra(AlarmRingService.EXTRA_VIBRATE, alarm.vibrate)
                    putExtra(AlarmRingService.EXTRA_SNOOZE, alarm.snooze)
                    putExtra(AlarmRingService.EXTRA_GENTLE, alarm.gentle)
                }
                try {
                    ContextCompat.startForegroundService(context, service)
                } catch (t: Throwable) {
                    Log.e("DayflowAlarm", "Unable to start alarm service", t)
                    val fallback = DayflowNotifications.alarmNotification(
                        context, alarm.id, alarm.label, app.dayflow.android.domain.DayflowTime.clock12(alarm.time),
                        alarm.sound.uri, alarm.vibrate, alarm.snooze,
                    )
                    runCatching {
                        androidx.core.app.NotificationManagerCompat.from(context)
                            .notify(DayflowNotifications.ID_ALARM, fallback)
                    }
                }

                if (stored != null) {
                    if (alarm.days.isEmpty()) {
                        repository.updateAndWait { state -> state.copy(alarms = state.alarms.map { if (it.id == alarm.id) it.copy(enabled = false) else it }) }
                    }
                    val latest = repository.snapshot()
                    AlarmScheduler.sync(context, latest.alarms)
                }
            } catch (t: Throwable) {
                Log.e("DayflowAlarm", "Alarm handling failed", t)
            } finally {
                pending.finish()
            }
        }
    }
}
