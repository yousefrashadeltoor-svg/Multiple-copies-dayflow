package app.dayflow.android.ui.screens

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Plus
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.AlarmSound
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.DAYS_AR
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.DfSwitch
import app.dayflow.android.ui.components.EmptyState
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowText
import java.time.ZonedDateTime

@Composable
fun AlarmsScreen(
    state: DayflowState,
    repository: DayflowRepository,
    navigate: Navigate,
    startNew: Boolean = false,
) {
    val context = LocalContext.current
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor, ZonedDateTime.now())
    var editing by remember { mutableStateOf<Alarm?>(null) }
    var creating by remember { mutableStateOf(startNew) }
    var exactAllowed by remember { mutableStateOf(AlarmScheduler.canScheduleExact(context)) }
    var notificationsAllowed by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notificationsAllowed = it }
    val next = DayflowTime.nextAlarm(state.alarms)

    LaunchedEffect(startNew) { if (startNew) creating = true }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            ScreenHeader(
                title = "المنبهات",
                eyebrow = "ALARMS · أصلية",
                subtitle = next?.let { "التالي: ${it.alarm.label.ifBlank { "منبه" }} · ${it.clock}" } ?: "لا منبهات مفعّلة",
                action = {
                    Surface(color = DayflowColors.Accent, shape = RoundedCornerShape(12.dp), modifier = Modifier.clickable { creating = true }) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Plus, contentDescription = null, tint = DayflowColors.OnAccent, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("جديد", color = DayflowColors.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
            )
        }

        item {
            NoticeCard(
                title = "منبه حقيقي حتى لو التطبيق مقفول",
                body = "يُجدول المنبه بـ AlarmManager.setAlarmClock مع شاشة رنين كاملة وصوت من اختيارك. بعد إعادة التشغيل أو تغيير التوقيت يعيد التطبيق الجدولة تلقائيًا. صلاحية المنبهات الدقيقة: ${if (exactAllowed) "مسموحة" else "غير مسموحة"}.",
                tone = if (exactAllowed) "green" else "warn",
                icon = Icons.Rounded.Alarm,
            )
            if (!exactAllowed) {
                Spacer(Modifier.height(6.dp))
                Text("السماح بالمنبهات الدقيقة", color = DayflowColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { AlarmScheduler.openExactAlarmSettings(context) }.padding(vertical = 4.dp))
            }
        }

        if (!notificationsAllowed) {
            item {
                NoticeCard(
                    title = "إشعارات أندرويد غير مفعّلة",
                    body = "المنبه يعمل حتى بدون الإشعارات، لكن شاشة الرنين والإشعارات العالية تحتاج إذن الإشعارات على أندرويد ١٣+.",
                    tone = "warn", icon = Icons.Rounded.Notifications,
                )
                if (Build.VERSION.SDK_INT >= 33) {
                    Text("السماح بالإشعارات", color = DayflowColors.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }.padding(vertical = 4.dp))
                }
            }
        }

        if (state.alarms.isEmpty()) {
            item {
                EmptyState(
                    title = "مفيش منبهات لسه",
                    hint = "أنشئ منبهًا في ثوانٍ. الوقت بصيغة ١٢ ساعة، أيام تكرار، نغمة من هاتفك، وغفوة.",
                ) { Surface(color = DayflowColors.Accent, shape = RoundedCornerShape(12.dp), modifier = Modifier.clickable { creating = true }) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Plus, contentDescription = null, tint = DayflowColors.OnAccent, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("اعمل منبه", color = DayflowColors.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } }
            }
        }

        items(state.alarms.sortedBy { it.time }, key = { it.id }) { alarm ->
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 13.dp, onClick = { editing = alarm }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).alphaIf(!alarm.enabled)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(DayflowTime.clock12(alarm.time), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = DayflowColors.Text, style = DayflowText.numeric, maxLines = 1)
                            if (alarm.gentle) { Spacer(Modifier.width(5.dp)); SmallTag("لطيف", "green") }
                        }
                        Text(alarm.label.ifBlank { "منبه" }, color = DayflowColors.Text, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${DayflowTime.daysLabel(alarm)} · ${alarm.sound.title}", color = DayflowColors.Muted, fontSize = 9.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = {
                        val enabled = !alarm.enabled
                        repository.toggleAlarm(alarm.id, enabled)
                        val updated = alarm.copy(enabled = enabled)
                        if (enabled) AlarmScheduler.schedule(context, updated) else AlarmScheduler.cancel(context, alarm.id)
                    }) { Icon(Icons.Rounded.Alarm, contentDescription = "تبديل المنبه", tint = if (alarm.enabled) DayflowColors.Accent else DayflowColors.Muted, modifier = Modifier.size(18.dp)) }
                    DfSwitch(alarm.enabled, { enabled ->
                        repository.toggleAlarm(alarm.id, enabled)
                        val updated = alarm.copy(enabled = enabled)
                        if (enabled) AlarmScheduler.schedule(context, updated) else AlarmScheduler.cancel(context, alarm.id)
                    }, alarm.label)
                }
            }
        }

        if (state.alarms.isNotEmpty()) {
            item {
                DfCard(modifier = Modifier.fillMaxWidth(), padding = 13.dp) {
                    Column {
                        Text("معاينة الرنين", color = DayflowColors.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("تشغيل حقيقي لمدة ١٢ ثانية (يمكن إيقافه من الإشعار).", color = DayflowColors.Muted, fontSize = 9.5.sp)
                        Spacer(Modifier.height(7.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            state.alarms.take(3).forEach { alarm ->
                                DfChip("جرّب ${DayflowTime.clock12(alarm.time)}") { AlarmScheduler.preview(context, alarm) }
                            }
                        }
                    }
                }
            }
        }
    }

    val toEdit = editing
    if (creating || toEdit != null) {
        AlarmEditor(
            alarm = toEdit,
            state = state,
            prayerNextText = "${prayer.nextLabel} ${prayer.nextText}",
            onDismiss = { editing = null; creating = false },
            onSave = { alarm ->
                repository.upsertAlarm(alarm)
                if (!AlarmScheduler.canScheduleExact(context)) AlarmScheduler.openExactAlarmSettings(context)
                AlarmScheduler.schedule(context, alarm)
                editing = null
                creating = false
            },
            onDelete = { alarm ->
                repository.deleteAlarm(alarm.id)
                AlarmScheduler.cancel(context, alarm.id)
                editing = null
            },
        )
    }
}

@Composable
private fun AlarmEditor(
    alarm: Alarm?,
    state: DayflowState,
    prayerNextText: String,
    onDismiss: () -> Unit,
    onSave: (Alarm) -> Unit,
    onDelete: (Alarm) -> Unit,
) {
    val context = LocalContext.current
    val initialHour = alarm?.time?.substringBefore(':')?.toIntOrNull() ?: 7
    val initialMinute = alarm?.time?.substringAfter(':')?.toIntOrNull() ?: 0
    var hour12 by remember { mutableStateOf(if (initialHour % 12 == 0) 12 else initialHour % 12) }
    var minute by remember { mutableStateOf(initialMinute) }
    var pm by remember { mutableStateOf(initialHour >= 12) }
    var label by remember { mutableStateOf(alarm?.label.orEmpty()) }
    var days by remember { mutableStateOf(alarm?.days ?: emptyList()) }
    var vibrate by remember { mutableStateOf(alarm?.vibrate ?: true) }
    var gentle by remember { mutableStateOf(alarm?.gentle ?: true) }
    var snooze by remember { mutableStateOf(alarm?.snooze ?: 10) }
    var soundTitle by remember { mutableStateOf(alarm?.sound?.title ?: "منبه الجهاز الافتراضي") }
    var soundUri by remember { mutableStateOf(alarm?.sound?.uri) }
    var soundSource by remember { mutableStateOf(alarm?.sound?.source ?: "device") }
    var error by remember { mutableStateOf<String?>(null) }

    val ringtoneLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        @Suppress("DEPRECATION")
        val uri = result.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        if (uri != null) {
            soundSource = "device"
            soundUri = uri.toString()
            soundTitle = runCatching { RingtoneManager.getRingtone(context, uri)?.getTitle(context)?.toString() }.getOrNull() ?: "نغمة من الهاتف"
        }
    }
    val documentLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull()
            soundSource = "files"
            soundUri = uri.toString()
            soundTitle = name ?: "ملف صوتي من الهاتف"
        }
    }

    val time24 = "%02d:%02d".format(if (pm) (hour12 % 12) + 12 else hour12 % 12, minute)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DayflowColors.Surface,
        title = { Text(if (alarm == null) "منبه جديد" else "تعديل المنبه", fontWeight = FontWeight.ExtraBold, color = DayflowColors.Text) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                Text("الوقت بصيغة ١٢ ساعة فقط", color = DayflowColors.Muted, fontSize = 9.5.sp)
                Row(Modifier.fillMaxWidth().padding(top = 7.dp).clip(RoundedCornerShape(16.dp)).background(DayflowColors.Surface2).padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("▲", color = DayflowColors.Accent, fontSize = 13.sp, modifier = Modifier.clickable { hour12 = if (hour12 == 12) 1 else hour12 + 1 })
                        Text(DayflowTime.digits(hour12).padStart(2, '٠'), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric, color = DayflowColors.Text)
                        Text("▼", color = DayflowColors.Accent, fontSize = 13.sp, modifier = Modifier.clickable { hour12 = if (hour12 == 1) 12 else hour12 - 1 })
                    }
                    Text(":", color = DayflowColors.Muted, fontSize = 32.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("▲", color = DayflowColors.Accent, fontSize = 13.sp, modifier = Modifier.clickable { minute = (minute + 5) % 60 })
                        Text(DayflowTime.digits(minute.toString().padStart(2, '0')), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric, color = DayflowColors.Text)
                        Text("▼", color = DayflowColors.Accent, fontSize = 13.sp, modifier = Modifier.clickable { minute = (minute + 55) % 60 })
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        DfChip("ص", !pm) { pm = false }
                        Spacer(Modifier.height(4.dp))
                        DfChip("م", pm) { pm = true }
                    }
                }
                Text(DayflowTime.clock12(time24), color = DayflowColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                FieldLabel("اسم المنبه")
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(DayflowColors.Surface2).border(1.dp, DayflowColors.LineStrong, RoundedCornerShape(12.dp)).padding(11.dp)) {
                    BasicTextField(value = label, onValueChange = { label = it }, singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                        decorationBox = { if (label.isBlank()) Text("مثال: صحيان لصلاة الفجر", color = DayflowColors.Muted, fontSize = 11.sp); it() },
                        modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(10.dp))
                FieldLabel("أيام التكرار — لا اختيار = مرة واحدة")
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DAYS_AR.mapIndexed { index, day -> DfChip(day.take(3), days.contains(index)) {
                        days = if (days.contains(index)) days - index else days + index
                    } }
                }
                Text("أيام العمل", color = DayflowColors.Accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { days = listOf(0, 1, 2, 3, 4) }.padding(top = 3.dp))
                Spacer(Modifier.height(10.dp))
                FieldLabel("النغمة")
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    DfChip("نغمات الهاتف") {
                        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            soundUri?.let { putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
                        }
                        ringtoneLauncher.launch(intent)
                    }
                    DfChip("ملف من الهاتف") { documentLauncher.launch(arrayOf("audio/*")) }
                    DfChip("افتراضي") { soundSource = "device"; soundUri = null; soundTitle = "منبه الجهاز الافتراضي" }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp).clip(RoundedCornerShape(10.dp)).background(DayflowColors.SoftGold).padding(horizontal = 8.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = DayflowColors.GoldText, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(soundTitle, color = DayflowColors.GoldText, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "معاينة", tint = DayflowColors.GoldText, modifier = Modifier.size(17.dp).clickable {
                        AlarmScheduler.preview(context, Alarm(id = alarm?.id ?: "preview", time = time24, label = label.ifBlank { "منبه" }, sound = AlarmSound(soundSource, soundTitle, soundUri), vibrate = vibrate, snooze = snooze, gentle = gentle))
                    })
                }
                Spacer(Modifier.height(8.dp))
                ToggleLine(Icons.Rounded.Vibration, "اهتزاز", vibrate) { vibrate = it }
                ToggleLine(Icons.Rounded.VolumeUp, "بداية لطيفة", gentle) { gentle = it }
                Spacer(Modifier.height(6.dp))
                FieldLabel("الغفوة")
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 4.dp)) {
                    listOf(5, 10, 15, 20).forEach { value -> DfChip("${DayflowTime.digits(value)} د", snooze == value) { snooze = value } }
                }
                Text(prayerNextText, color = DayflowColors.Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 7.dp))
                error?.let { Text(it, color = DayflowColors.Danger, fontSize = 9.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newAlarm = Alarm(
                    id = alarm?.id ?: app.dayflow.android.DayflowApplication.repository(context).newAlarmId(),
                    time = time24, date = null, days = days, label = label.trim(), enabled = true,
                    sound = AlarmSound(soundSource, soundTitle, soundUri), vibrate = vibrate, snooze = snooze, gentle = gentle,
                )
                onSave(newAlarm)
            }) { Text(if (alarm == null) "حفظ واعمل جدولة" else "حفظ التعديلات", color = DayflowColors.Accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            Row {
                if (alarm != null) IconButton(onClick = { onDelete(alarm) }) { Icon(Icons.Rounded.Delete, contentDescription = "حذف", tint = DayflowColors.Danger) }
                TextButton(onClick = onDismiss) { Text("إلغاء", color = DayflowColors.Muted) }
            }
        },
    )
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun ToggleLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = DayflowColors.Accent, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        DfSwitch(checked, onChange, label)
    }
}

private fun Modifier.alphaIf(condition: Boolean): Modifier =
    if (condition) this.alpha(0.5f) else this
