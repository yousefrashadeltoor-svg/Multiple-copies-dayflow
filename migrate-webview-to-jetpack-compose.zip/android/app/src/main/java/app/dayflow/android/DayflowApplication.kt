package app.dayflow.android

import android.app.Application
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.notifications.DayflowNotifications
import app.dayflow.android.widget.WidgetUpdater

class DayflowApplication : Application() {
    lateinit var repository: DayflowRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = DayflowRepository(this)
        DayflowNotifications.createChannels(this)
        repository.onChanged = { state ->
            runCatching { AlarmScheduler.sync(this, state.alarms) }
            runCatching { WidgetUpdater.updateAll(this) }
        }
    }

    companion object {
        fun repository(context: android.content.Context): DayflowRepository =
            (context.applicationContext as DayflowApplication).repository
    }
}
