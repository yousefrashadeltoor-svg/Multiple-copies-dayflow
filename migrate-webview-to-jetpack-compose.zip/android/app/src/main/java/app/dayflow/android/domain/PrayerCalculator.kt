package app.dayflow.android.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/**
 * On-device prayer engine. No network. Uses the standard solar equations with
 * real IANA zones (DST), not a fixed UTC offset.
 *
 * Default method: Egyptian General Survey Authority (Fajr 19.5°, Isha 17.5°),
 * Asr = standard / Shafi'i. Giza is a first-class city.
 */
data class PrayerCity(
    val id: String,
    val ar: String,
    val en: String,
    val lat: Double,
    val lng: Double,
    val zone: String,
)

enum class PrayerMethod(
    val id: String,
    val ar: String,
    val en: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutes: Int? = null,
    val noteAr: String,
) {
    EGYPT("egypt", "الهيئة المصرية العامة للمساحة", "Egyptian General Survey", 19.5, 17.5, noteAr = "الفجر ١٩٫٥° — العشاء ١٧٫٥° (الطريقة المصرية)"),
    MWL("mwl", "رابطة العالم الإسلامي", "Muslim World League", 18.0, 17.0, noteAr = "رابطة العالم الإسلامي ١٨° / ١٧°"),
    UMM_AL_QURA("umm", "أم القرى", "Umm al-Qura", 18.5, 0.0, 90, "أم القرى: العشاء بعد المغرب بـ ٩٠ دقيقة"),
    ISNA("isna", "الجمعية الأمريكية", "ISNA", 15.0, 15.0, noteAr = "ISNA ١٥° / ١٥°"),
    KARACHI("karachi", "جامعة كراتشي", "University of Karachi", 18.0, 18.0, noteAr = "كراتشي ١٨° / ١٨°"),
    DUBAI("dubai", "دبي (الإمارات)", "Dubai", 18.2, 18.2, noteAr = "الإمارات ١٨٫٢° / ١٨٫٢°"),
}

object PrayerCatalog {
    val cities: List<PrayerCity> = listOf(
        PrayerCity("cairo", "القاهرة", "Cairo", 30.0444, 31.2357, "Africa/Cairo"),
        PrayerCity("giza", "الجيزة", "Giza", 30.0131, 31.2089, "Africa/Cairo"),
        PrayerCity("alexandria", "الإسكندرية", "Alexandria", 31.2001, 29.9187, "Africa/Cairo"),
        PrayerCity("luxor", "الأقصر", "Luxor", 25.6872, 32.6396, "Africa/Cairo"),
        PrayerCity("aswan", "أسوان", "Aswan", 24.0889, 32.8998, "Africa/Cairo"),
        PrayerCity("suez", "السويس", "Suez", 29.9668, 32.5498, "Africa/Cairo"),
        PrayerCity("sharm", "شرم الشيخ", "Sharm El-Sheikh", 27.9158, 34.3299, "Africa/Cairo"),
        PrayerCity("mansoura", "المنصورة", "Mansoura", 31.0409, 31.3785, "Africa/Cairo"),
        PrayerCity("tanta", "طنطا", "Tanta", 30.7865, 31.0004, "Africa/Cairo"),
        PrayerCity("asyut", "أسيوط", "Asyut", 27.1809, 31.1837, "Africa/Cairo"),
        PrayerCity("hurghada", "الغردقة", "Hurghada", 27.2579, 33.8116, "Africa/Cairo"),
        PrayerCity("makkah", "مكة المكرمة", "Makkah", 21.4225, 39.8262, "Asia/Riyadh"),
        PrayerCity("madinah", "المدينة المنورة", "Madinah", 24.4686, 39.6142, "Asia/Riyadh"),
        PrayerCity("dubai", "دبي", "Dubai", 25.2048, 55.2708, "Asia/Dubai"),
        PrayerCity("london", "لندن", "London", 51.5074, -0.1278, "Europe/London"),
        PrayerCity("istanbul", "إسطنبول", "Istanbul", 41.0082, 28.9784, "Europe/Istanbul"),
        PrayerCity("paris", "باريس", "Paris", 48.8566, 2.3522, "Europe/Paris"),
    )

    val methods: List<PrayerMethod> = PrayerMethod.entries

    fun city(id: String): PrayerCity = cities.firstOrNull { it.id == id } ?: cities.first { it.id == "giza" }
    fun method(id: String): PrayerMethod = methods.firstOrNull { it.id == id } ?: PrayerMethod.EGYPT
}

data class PrayerSlot(
    val key: String,
    val ar: String,
    val en: String,
    val icon: String,
    val isPrayer: Boolean,
    val at: ZonedDateTime,
) {
    val text: String get() = DayflowTime.clock12(at)
}

data class PrayerDay(
    val city: PrayerCity,
    val method: PrayerMethod,
    val date: LocalDate,
    val slots: List<PrayerSlot>,
    val next: PrayerSlot?,
    val nextTomorrow: Boolean,
    val highLatitude: Boolean,
) {
    fun slot(key: String): PrayerSlot? = slots.firstOrNull { it.key == key }
    fun text(key: String): String = slot(key)?.text ?: "—"
    val nextLabel: String get() = next?.ar ?: "الفجر"
    val nextText: String get() = next?.text ?: "—"
}

object PrayerCalculator {
    private val names = listOf(
        Triple("fajr", "الفجر", "Fajr") to ("🌅" to true),
        Triple("sunrise", "الشروق", "Sunrise") to ("☀️" to false),
        Triple("dhuhr", "الظهر", "Dhuhr") to ("🕛" to true),
        Triple("asr", "العصر", "Asr") to ("🌤️" to true),
        Triple("maghrib", "المغرب", "Maghrib") to ("🌇" to true),
        Triple("isha", "العشاء", "Isha") to ("🌙" to true),
    )

    fun forCity(city: PrayerCity, method: PrayerMethod, asrFactor: Int, now: ZonedDateTime = ZonedDateTime.now(ZoneId.of(city.zone))): PrayerDay {
        val zone = ZoneId.of(city.zone)
        val localNow = now.withZoneSameInstant(zone)
        val day = calculateDate(city, method, asrFactor, localNow.toLocalDate(), zone)
        val upcoming = day.slots.firstOrNull { it.isPrayer && it.at.isAfter(localNow) }
        val next: PrayerSlot
        val tomorrow: Boolean
        if (upcoming != null) {
            next = upcoming
            tomorrow = false
        } else {
            val nextDate = calculateDate(city, method, asrFactor, localNow.toLocalDate().plusDays(1), zone)
            next = nextDate.slots.first()
            tomorrow = true
        }
        return PrayerDay(city, method, localNow.toLocalDate(), day.slots, next, tomorrow, day.highLatitude)
    }

    internal fun calculateDate(city: PrayerCity, method: PrayerMethod, asrFactor: Int, date: LocalDate, zone: ZoneId): PrayerDay {
        val jd = julianDay(date)
        val d = jd - 2451545.0
        val g = rad(normalize360(357.529 + 0.98560028 * d))
        val q = 280.459 + 0.98564736 * d
        val l = rad(normalize360(q + 1.915 * sin(g) + 0.020 * sin(2 * g)))
        val e = rad(23.439 - 0.00000036 * d)
        val ra = deg(atan2(cos(e) * sin(l), cos(l))) / 15.0
        val decl = asin(sin(e) * sin(l))
        val eqt = q / 15.0 - fixHour(ra)
        val probe = date.atTime(12, 0)
        val offsetHours = zone.rules.getOffset(probe).totalSeconds / 3600.0
        val midDay = fixHour(12.0 - eqt - city.lng / 15.0 + offsetHours)

        fun hourAngle(altitude: Double): Double? {
            val cosH = (sin(rad(altitude)) - sin(rad(city.lat)) * sin(decl)) /
                (cos(rad(city.lat)) * cos(decl))
            if (cosH > 1 || cosH < -1) return null
            return deg(acos(cosH)) / 15.0
        }

        var highLatitude = false
        val sunriseHa = hourAngle(-0.833)
        val sunsetHa = hourAngle(-0.833)
        var sunrise = if (sunriseHa == null) { highLatitude = true; midDay - 6.0 } else midDay - sunriseHa
        if (sunsetHa == null) { highLatitude = true }
        var maghrib = if (sunsetHa == null) midDay + 6.0 else midDay + sunsetHa
        val night = 24.0 - (maghrib - sunrise)

        fun atAngle(angle: Double, before: Boolean, missing: Double): Double {
            val ha = hourAngle(angle)
            if (ha == null) { highLatitude = true; return missing }
            return midDay + if (before) -ha else ha
        }

        var fajr = atAngle(method.fajrAngle, true, sunrise - night / 5.0)
        var isha = if (method.ishaMinutes != null) {
            maghrib + method.ishaMinutes / 60.0
        } else {
            atAngle(method.ishaAngle, false, maghrib + night / 5.0)
        }
        if (hourAngle(-0.833) == null) { sunrise = midDay - 6.0; maghrib = midDay + 6.0 }
        if (method.ishaMinutes != null) isha = maghrib + method.ishaMinutes / 60.0

        val asrAltitude = deg(atan(1.0 / (asrFactor + tan(abs(rad(city.lat) - decl)))))
        val asr = atAngle(asrAltitude, false, midDay + 3.5)

        val values = linkedMapOf(
            "fajr" to fixHour(fajr),
            "sunrise" to fixHour(sunrise),
            "dhuhr" to fixHour(midDay),
            "asr" to fixHour(asr),
            "maghrib" to fixHour(maghrib),
            "isha" to fixHour(isha),
        )

        val slots = names.map { (triple, meta) ->
            val minutes = ((values[triple.first] ?: 0.0) * 60.0).roundToInt()
            val normalized = ((minutes % 1440) + 1440) % 1440
            val localTime = LocalTime.of(normalized / 60, normalized % 60)
            PrayerSlot(
                key = triple.first,
                ar = triple.second,
                en = triple.third,
                icon = meta.first,
                isPrayer = meta.second,
                at = ZonedDateTime.of(date, localTime, zone),
            )
        }
        return PrayerDay(city, method, date, slots, slots.first(), false, highLatitude)
    }

    fun qiblaDirection(lat: Double, lng: Double): Double {
        val phi = rad(lat)
        val kaabaLat = rad(21.4225)
        val delta = rad(39.8262) - rad(lng)
        val y = sin(delta)
        val x = cos(phi) * tan(kaabaLat) - sin(phi) * cos(delta)
        return (deg(atan2(y, x)) + 360.0) % 360.0
    }

    private fun julianDay(date: LocalDate): Double {
        var y = date.year
        var m = date.monthValue
        val day = date.dayOfMonth
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun rad(value: Double) = value * Math.PI / 180.0
    private fun deg(value: Double) = value * 180.0 / Math.PI
    private fun normalize360(value: Double) = ((value % 360.0) + 360.0) % 360.0
    private fun fixHour(value: Double) = ((value % 24.0) + 24.0) % 24.0
}

/** Full Arabic week list matching the original order (Saturday first). */
val DAYS_AR = listOf("الأحد", "الاتنين", "التلات", "الأربع", "الخميس", "الجمعة", "السبت")
val DAYS_SHORT_AR = listOf("حد", "اتنين", "تلات", "أربع", "خميس", "جمعة", "سبت")

/** Native widget catalog. Only designs with a real RemoteViews renderer are listed. */
data class NativeWidget(
    val id: String,
    val ar: String,
    val en: String,
    val cat: String,
    val catAr: String,
    val desc: String,
    val forms: List<String>,
    val layoutKind: String,
    val interactive: Boolean,
    val family: String = "islamic",
)

object NativeWidgetCatalog {
    val widgets = listOf(
        NativeWidget("clock-minimal-digital", "رقمية بسيطة", "Minimal digital", "clock", "الساعة", "الساعة الآن بخط واضح وهادئ", listOf("1x1", "2x1", "2x2", "4x1", "4x2"), "clock", false, "friday"),
        NativeWidget("clock-ornate", "ساعة مزخرفة", "Ornate clock", "clock", "الساعة", "ساعة وزخرفة إسلامية ذهبية", listOf("2x1", "2x2", "4x2"), "clock", false, "ramadan"),
        NativeWidget("clock-sun-arc", "قوس الشمس", "Sun-arc", "clock", "الساعة", "الوقت مع مسار الشمس", listOf("2x1", "2x2", "4x1", "4x2"), "clock", false, "summer"),
        NativeWidget("alarms-next-alarm", "المنبه التالي", "Next alarm", "alarms", "المنبهات", "المنبه القادم والعد التنازلي", listOf("1x1", "2x1", "2x2", "4x1", "4x2"), "alarm", true, "friday"),
        NativeWidget("alarms-list", "قائمة المنبهات", "Alarm list", "alarms", "المنبهات", "المنبهات مع تشغيل وإيقاف", listOf("2x2", "4x2", "4x4"), "alarm", true, "islamic"),
        NativeWidget("tasks-checklist", "قائمة التحقق", "Checklist", "tasks", "المهام والملاحظات", "مهام اليوم قابلة للتأشير", listOf("2x1", "2x2", "4x2", "4x4"), "tasks", true, "islamic"),
        NativeWidget("plan-top-priorities", "أهم الأولويات", "Top priorities", "plan", "الخطة واليوم", "أهم ٣ مهام وتأشيرها", listOf("2x2", "4x2", "4x4"), "tasks", true, "spring"),
        NativeWidget("utility-next-prayer", "الصلاة القادمة", "Next prayer", "utility", "أدوات", "الصلاة القادمة والوقت المتبقي", listOf("1x1", "2x1", "2x2", "4x1"), "clock", false, "ramadan"),
        NativeWidget("utility-prayer-times", "مواقيت الصلاة", "Prayer times", "utility", "أدوات", "المواقيت الخمسة كاملة", listOf("4x1", "4x2", "4x4"), "clock", false, "ramadan"),
        NativeWidget("habits-water-drop", "قطرة ماء", "Water drop", "habits", "العادات والصحة", "شرب الماء وإضافة كوب", listOf("1x1", "2x1", "2x2"), "tasks", true, "summer"),
        NativeWidget("occasions-iftar", "العد للإفطار", "Iftar countdown", "occasions", "المناسبات", "وقت المغرب ومتبقي الصيام", listOf("2x2", "4x2"), "alarm", false, "ramadan"),
        NativeWidget("companion-portrait", "صورة الرفيق", "Companion portrait", "companion", "الرفيق", "رفيقك على الشاشة الرئيسية", listOf("1x1", "2x2", "4x2"), "tasks", false, "islamic"),
    )

    fun byId(id: String): NativeWidget = widgets.firstOrNull { it.id == id } ?: widgets.first()

    val categories: List<Pair<String, String>> = listOf(
        "clock" to "الساعة", "alarms" to "المنبهات", "calendar" to "التقويم", "occasions" to "المناسبات",
        "plan" to "الخطة واليوم", "tasks" to "المهام والملاحظات", "habits" to "العادات والصحة",
        "utility" to "أدوات", "companion" to "الرفيق",
    )
}

/** Hijri (Umm al-Qura) + Coptic + Egyptian occasions. */
object CalendarMath {
    private val hijriMonths = listOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")

    fun hijri(date: LocalDate = LocalDate.now()): Triple<Int, Int, Int>? = runCatching {
        val h = java.time.chrono.HijrahDate.from(date)
        Triple(h.get(java.time.temporal.ChronoField.DAY_OF_MONTH), h.get(java.time.temporal.ChronoField.MONTH_OF_YEAR), h.get(java.time.temporal.ChronoField.YEAR))
    }.getOrNull()

    fun hijriLabel(date: LocalDate = LocalDate.now()): String {
        val h = hijri(date) ?: return ""
        return "${DayflowTime.digits(h.first)} ${hijriMonths.getOrElse(h.second - 1) { "" }} ${DayflowTime.digits(h.third)} هـ"
    }

    /** Coptic calendar (Nayrouz = 11 September, 12 in leap years) — no external library needed. */
    fun coptic(date: LocalDate = LocalDate.now()): Triple<Int, Int, Int> {
        var year = date.year - 284
        var newYear = LocalDate.of(date.year, 9, if (java.time.Year.isLeap(date.year.toLong())) 12 else 11)
        if (date.isBefore(newYear)) {
            year -= 1
            val previous = date.year - 1
            newYear = LocalDate.of(previous, 9, if (java.time.Year.isLeap(previous.toLong())) 12 else 11)
        }
        val days = java.time.temporal.ChronoUnit.DAYS.between(newYear, date).toInt()
        val month = days / 30 + 1
        val day = days % 30 + 1
        return Triple(day, month, year)
    }

    fun copticLabel(date: LocalDate = LocalDate.now()): String {
        val coptic = coptic(date)
        val months = listOf("توت", "بابة", "هاتور", "كياهك", "طوبة", "أمشير", "برمهات", "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "نسيء")
        return "${DayflowTime.digits(coptic.first)} ${months.getOrElse(coptic.second - 1) { "" }} ${DayflowTime.digits(coptic.third)}"
    }

    data class Occasion(val id: String, val ar: String, val en: String, val date: LocalDate, val family: String, val priority: Int)

    fun upcomingOccasions(from: LocalDate = LocalDate.now(), count: Int = 6): List<Occasion> {
        val fixed = listOf(
            Triple("coptic-christmas", "عيد الميلاد المجيد", 1 to 7),
            Triple("revolution", "عيد الشرطة وثورة ٢٥ يناير", 1 to 25),
            Triple("mothers", "عيد الأم", 3 to 21),
            Triple("nile", "عيد وفاء النيل", 8 to 15),
            Triple("june30", "ثورة ٣٠ يونيو", 6 to 30),
            Triple("july23", "ثورة ٢٣ يوليو", 7 to 23),
            Triple("oct6", "عيد القوات المسلحة", 10 to 6),
            Triple("newyear", "رأس السنة", 1 to 1),
        ).map { (id, ar, md) ->
            var date = LocalDate.of(from.year, md.first, md.second)
            if (date.isBefore(from)) date = LocalDate.of(from.year + 1, md.first, md.second)
            Occasion(id, ar, id, date, if (id == "revolution" || id == "june30" || id == "july23" || id == "oct6") "national" else if (id == "mothers" || id == "nile") "spring" else "winter", 80)
        }
        val lunar = listOf(
            Triple("islamic-newyear", "رأس السنة الهجرية", 1 to 1),
            Triple("mawlid", "المولد النبوي", 3 to 12),
            Triple("ramadan", "رمضان", 9 to 1),
            Triple("laylat-qadr", "ليلة القدر", 9 to 27),
            Triple("eid-fitr", "عيد الفطر", 10 to 1),
            Triple("arafat", "يوم عرفة", 12 to 9),
            Triple("eid-adha", "عيد الأضحى", 12 to 10),
        ).mapNotNull { (id, ar, md) ->
            val targetMonth = md.first
            val targetDay = md.second
            var date: LocalDate? = null
            var cursor = from
            while (date == null && cursor.isBefore(from.plusDays(400))) {
                val h = hijri(cursor)
                if (h != null && h.second == targetMonth && h.first == targetDay) date = cursor
                cursor = cursor.plusDays(1)
            }
            date?.let { Occasion(id, ar, id, it, if (it == date && (id == "ramadan" || id == "laylat-qadr")) "ramadan" else "eid", 100) }
        }
        return (fixed + lunar).sortedBy { it.date }.take(count)
    }

    fun seasonFor(date: LocalDate = LocalDate.now()): String {
        val h = hijri(date)
        if (h != null) {
            if (h.second == 9) return "ramadan"
            if (h.second == 10 && h.first <= 12) return "eid"
            if (h.second == 12 && h.first in 9..13) return "eid"
        }
        if (date.dayOfWeek == DayOfWeek.FRIDAY) return "friday"
        return when (date.monthValue) {
            12, 1, 2 -> "winter"
            3, 4, 5 -> "spring"
            6, 7, 8 -> "summer"
            else -> "autumn"
        }
    }
}
