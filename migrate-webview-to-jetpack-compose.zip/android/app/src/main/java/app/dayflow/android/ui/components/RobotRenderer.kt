package app.dayflow.android.ui.components

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader

/**
 * ONE robot renderer used by the Compose app and the system overlay service.
 * Keeping a single Android Canvas implementation guarantees the floating robot
 * looks identical to the in-app companion (the original bug was that they were
 * two completely different components).
 */
object RobotRenderer {
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val limbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(30, 0, 0, 0) }

    fun draw(canvas: Canvas, width: Float, height: Float, family: String, mood: String, opacity: Float = 1f) {
        val scale = minOf(width / 120f, height / 150f)
        canvas.save()
        canvas.scale(scale, scale)
        canvas.translate((width / scale - 120f) / 2f, 0f)
        val alpha = (255 * opacity.coerceIn(0.15f, 1f)).toInt()
        drawRobot(canvas, family, mood, alpha)
        canvas.restore()
    }

    private fun drawRobot(canvas: Canvas, family: String, mood: String, alpha: Int) {
        val sleeping = mood == "sleep"
        val happy = mood == "happy" || mood == "celebrate"

        canvas.save()
        canvas.translate(0f, 150f)
        canvas.drawOval(RectF(32f, 143f, 88f, 150f), shadowPaint.apply { this.alpha = (alpha * 0.15f).toInt() })
        canvas.restore()

        // Legs
        limbPaint.color = Color.rgb(154, 167, 185)
        limbPaint.strokeWidth = 9f
        canvas.drawLine(47f, 110f, 46f, 135f, limbPaint)
        canvas.drawLine(73f, 110f, 74f, 135f, limbPaint)

        // Arms
        limbPaint.strokeWidth = 8f
        limbPaint.color = Color.rgb(195, 205, 219)
        val leftArm = Path().apply { moveTo(34f, 78f); lineTo(24f, 97f); lineTo(21f, 113f) }
        val rightArm = Path().apply { moveTo(86f, 78f); lineTo(96f, 97f); lineTo(100f, 111f) }
        canvas.drawPath(leftArm, limbPaint)
        canvas.drawPath(rightArm, limbPaint)
        fillPaint.color = Color.rgb(231, 237, 245)
        canvas.drawCircle(21f, 113f, 5.5f, fillPaint)
        canvas.drawCircle(100f, 111f, 5.5f, fillPaint)

        drawBody(canvas, alpha, mood)
        drawHead(canvas, alpha, mood, sleeping, happy)
        drawOutfit(canvas, family, mood, alpha)
        if (happy) {
            fillPaint.color = Color.argb((alpha * 0.6f).toInt(), 255, 154, 181)
            canvas.drawOval(RectF(39f, 50f, 47f, 54f), fillPaint)
            canvas.drawOval(RectF(73f, 50f, 81f, 54f), fillPaint)
        }
    }

    private fun drawBody(canvas: Canvas, alpha: Int, mood: String) {
        bodyPaint.shader = RadialGradient(
            47f, 82f, 58f,
            intArrayOf(Color.WHITE, if (mood == "cold") Color.rgb(207, 227, 245) else Color.rgb(217, 226, 238), Color.rgb(141, 155, 176)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP,
        )
        bodyPaint.alpha = alpha
        val body = RectF(34f, 64f, 86f, 122f)
        canvas.drawRoundRect(body, 18f, 18f, bodyPaint)
        bodyPaint.shader = null
        strokePaint.color = Color.argb(alpha, 127, 140, 162)
        strokePaint.strokeWidth = 1f
        canvas.drawRoundRect(body, 18f, 18f, strokePaint)

        fillPaint.color = Color.rgb(15, 26, 44)
        fillPaint.alpha = alpha
        canvas.drawRoundRect(RectF(47f, 78f, 73f, 94f), 5f, 5f, fillPaint)
        fillPaint.color = Color.rgb(47, 111, 94)
        canvas.drawCircle(60f, 86f, 4f, fillPaint)
    }

    private fun drawHead(canvas: Canvas, alpha: Int, mood: String, sleeping: Boolean, happy: Boolean) {
        // Antennae
        strokePaint.color = Color.argb(alpha, 125, 138, 160)
        strokePaint.strokeWidth = 2.5f
        canvas.drawLine(50f, 22f, 44f, 10f, strokePaint)
        canvas.drawLine(44f, 10f, 40f, 0f, strokePaint)
        canvas.drawLine(70f, 22f, 76f, 10f, strokePaint)
        canvas.drawLine(76f, 10f, 80f, 0f, strokePaint)
        fillPaint.color = Color.rgb(201, 162, 74)
        canvas.drawCircle(40f, 0f, 4f, fillPaint)
        canvas.drawCircle(80f, 0f, 4f, fillPaint)

        bodyPaint.shader = RadialGradient(
            47f, 34f, 62f,
            intArrayOf(Color.WHITE, Color.rgb(217, 226, 238), Color.rgb(141, 155, 176)),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP,
        )
        bodyPaint.alpha = alpha
        canvas.drawRoundRect(RectF(30f, 20f, 90f, 66f), 20f, 20f, bodyPaint)
        bodyPaint.shader = null
        strokePaint.color = Color.argb(alpha, 127, 140, 162)
        strokePaint.strokeWidth = 1f
        canvas.drawRoundRect(RectF(30f, 20f, 90f, 66f), 20f, 20f, strokePaint)

        bodyPaint.shader = RadialGradient(
            52f, 32f, 38f,
            intArrayOf(Color.rgb(58, 74, 102), Color.rgb(13, 20, 36)),
            null, Shader.TileMode.CLAMP,
        )
        bodyPaint.alpha = alpha
        canvas.drawRoundRect(RectF(37f, 29f, 83f, 57f), 13f, 13f, bodyPaint)
        bodyPaint.shader = null

        val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(alpha, 127, 214, 255) }
        when {
            sleeping -> {
                strokePaint.color = Color.argb(alpha, 127, 214, 255)
                strokePaint.strokeWidth = 2.5f
                val left = Path().apply { moveTo(46f, 43f); quadTo(50f, 46f, 54f, 43f) }
                val right = Path().apply { moveTo(66f, 43f); quadTo(70f, 46f, 74f, 43f) }
                canvas.drawPath(left, strokePaint)
                canvas.drawPath(right, strokePaint)
            }
            happy -> {
                strokePaint.color = Color.argb(alpha, 127, 214, 255)
                strokePaint.strokeWidth = 2.8f
                canvas.drawArc(RectF(44f, 40f, 56f, 49f), 200f, 140f, false, strokePaint)
                canvas.drawArc(RectF(64f, 40f, 76f, 49f), 200f, 140f, false, strokePaint)
            }
            mood == "sad" -> {
                strokePaint.color = Color.argb(alpha, 127, 214, 255)
                strokePaint.strokeWidth = 2.5f
                canvas.drawArc(RectF(44f, 43f, 56f, 49f), 20f, 140f, false, strokePaint)
                canvas.drawArc(RectF(64f, 43f, 76f, 49f), 20f, 140f, false, strokePaint)
            }
            else -> {
                canvas.drawOval(RectF(46f, 36f, 54f, 47f), eyePaint)
                canvas.drawOval(RectF(66f, 36f, 74f, 47f), eyePaint)
            }
        }
        fillPaint.color = Color.argb((alpha * 0.65f).toInt(), 255, 255, 255)
        canvas.drawOval(RectF(36f, 23f, 52f, 29f), fillPaint)
    }

    private fun drawOutfit(canvas: Canvas, family: String, mood: String, alpha: Int) {
        when (family) {
            "ramadan", "islamic" -> {
                fillPaint.color = Color.argb(alpha, 213, 181, 109)
                canvas.drawRect(RectF(92f, 100f, 108f, 121f), fillPaint)
                fillPaint.color = Color.argb(alpha, 176, 138, 62)
                canvas.drawRect(RectF(91f, 96f, 109f, 100f), fillPaint)
                canvas.drawRect(RectF(94f, 121f, 106f, 125f), fillPaint)
                fillPaint.color = Color.argb(alpha, 255, 237, 185)
                canvas.drawRoundRect(RectF(96f, 105f, 104f, 114f), 2f, 2f, fillPaint)
            }
            "winter" -> {
                fillPaint.color = Color.argb(alpha, 179, 74, 63)
                val scarf = Path().apply {
                    moveTo(42f, 65f); quadTo(60f, 76f, 78f, 65f); lineTo(82f, 79f)
                    quadTo(60f, 89f, 38f, 79f); close()
                }
                canvas.drawPath(scarf, fillPaint)
                canvas.drawRect(RectF(74f, 80f, 82f, 107f), fillPaint)
            }
            "national" -> {
                strokePaint.strokeWidth = 4.5f
                strokePaint.color = Color.argb(alpha, 206, 17, 38)
                canvas.drawLine(42f, 72f, 80f, 98f, strokePaint)
                strokePaint.color = Color.argb(alpha, 255, 255, 255)
                strokePaint.strokeWidth = 4f
                canvas.drawLine(42f, 77f, 80f, 102f, strokePaint)
                strokePaint.color = Color.argb(alpha, 29, 28, 26)
                canvas.drawLine(42f, 82f, 78f, 106f, strokePaint)
            }
            "spring" -> {
                fillPaint.color = Color.argb(alpha, 231, 183, 169)
                canvas.drawOval(RectF(86f, 22f, 102f, 34f), fillPaint)
                fillPaint.color = Color.argb(alpha, 201, 162, 74)
                canvas.drawCircle(94f, 28f, 2.5f, fillPaint)
            }
            "autumn" -> {
                fillPaint.color = Color.argb(alpha, 199, 154, 99)
                val leaf = Path().apply {
                    moveTo(92f, 24f); quadTo(106f, 26f, 102f, 38f); quadTo(88f, 34f, 92f, 24f); close()
                }
                canvas.drawPath(leaf, fillPaint)
            }
            "summer" -> {
                fillPaint.color = Color.argb(alpha, 143, 191, 192)
                canvas.drawOval(RectF(88f, 23f, 104f, 33f), fillPaint)
            }
        }
        if (mood == "think") {
            fillPaint.color = Color.rgb(201, 162, 74)
            canvas.drawCircle(101f, 34f, 2.2f, fillPaint)
            canvas.drawCircle(107f, 27f, 1.4f, fillPaint)
        }
    }

    /** A realistic soft glow behind the floating robot; used by the overlay only. */
    fun drawBubble(canvas: Canvas, text: String?, width: Float, alpha: Int) {
        if (text.isNullOrBlank()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(235, 255, 253, 248)
        }
        val radius = 14f
        canvas.drawRoundRect(RectF(2f, 0f, width - 2f, 48f), radius, radius, paint)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(alpha, 30, 28, 24)
            textSize = 11f
        }
        canvas.drawText(text.take(34), 10f, 20f, textPaint)
    }
}
