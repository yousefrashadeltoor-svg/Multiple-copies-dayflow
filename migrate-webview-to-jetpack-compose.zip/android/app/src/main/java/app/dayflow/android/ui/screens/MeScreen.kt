package app.dayflow.android.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bell
import androidx.compose.material.icons.rounded.Bot
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.CopyAll
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Moon
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.notifications.DayflowNotifications
import app.dayflow.android.overlay.CompanionOverlayService
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.DfSwitch
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.IconRow
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.PrayerStrip
import app.dayflow.android.ui.components.Robot
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowText
import org.json.JSONObject
import java.time.ZonedDateTime

@Composable
fun MeScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate, sub: String?) {
    when (sub) {
        "prayer" -> PrayerSettingsScreen(state, repository, navigate)
        "notifications" -> NotificationsScreen(state, repository, navigate)
        "companion" -> CompanionSettingsScreen(state, repository, navigate)
        "settings" -> SettingsScreen(state, repository, navigate)
        "report" -> ReportScreen(navigate)
        else -> MeHome(state, repository, navigate)
    }
}

@Composable
private fun MeHome(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    val family = DayflowSeasons.forId(CalendarMath.seasonFor())
    val today = repository.todayKey(state)
    val tasks = state.tasks.filter { it.date == today }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            ScreenHeader("أنا", "DAYFLOW · حسابك", "إعداداتك وبياناتك على جهازك", action = {
                Icon(Icons.Rounded.Settings, "الإعدادات", tint = DayflowColors.Text,
                    modifier = Modifier.clip(CircleShape).clickable { navigate("me", "settings") }.padding(8.dp).size(19.dp))
            })
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(66.dp).clip(CircleShape).background(DayflowColors.Soft), contentAlignment = Alignment.Center) {
                            Robot(size = 54.dp, family = family.id, mood = state.companion.emotion)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("أهلاً بيك", color = DayflowColors.Muted, fontSize = 9.5.sp)
                            Text("صاحب يوم هادي", color = DayflowColors.Text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.LocationOn, null, tint = DayflowColors.Muted, modifier = Modifier.size(10.dp))
                                Spacer(Modifier.width(2.dp))
                                Text("${city.ar} · ${family.ar} · ${CalendarMath.hijriLabel().replace(" هـ", "")}", color = DayflowColors.Muted, fontSize = 9.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MeStat(DayflowTime.digits(state.alarms.count { it.enabled }), "منبه مفعّل", Modifier.weight(1f))
                        MeStat(DayflowTime.digits(tasks.count { !it.done }), "مهمة باقية", Modifier.weight(1f))
                        MeStat(DayflowTime.digits(state.habits.count { today in it.log }), "عادة النهاردة", Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = { navigate("me", "prayer") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Moon)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("الصلاة القادمة · ${city.ar}", color = DayflowColors.Muted, fontSize = 9.sp)
                        Text("${prayer.nextLabel} · ${prayer.nextText}", color = DayflowColors.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, style = DayflowText.numeric)
                    }
                    Icon(Icons.Rounded.ChevronLeft, null, tint = DayflowColors.Muted, modifier = Modifier.size(15.dp))
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 6.dp) {
                Column {
                    IconRow(Icons.Rounded.Moon, "مواقيت الصلاة والمدينة", "${city.ar} · ${prayer.method.ar}") { navigate("me", "prayer") }
                    IconRow(Icons.Rounded.Widgets, "الودجتس والاختيار المفضل", "اختر ودجت واحدة لتظهر على الشاشة الرئيسية") { navigate("tools", "widgets") }
                    IconRow(Icons.Rounded.Bell, "الإشعارات والتذكيرات", "قنوات، صوت، اهتزاز، اختبار إشعار") { navigate("me", "notifications") }
                    IconRow(Icons.Rounded.Bot, "الرفيق والزينة", "الحجم والشفافية وفوق التطبيقات") { navigate("me", "companion") }
                    IconRow(Icons.Rounded.Alarm, "المنبهات الحقيقية", "${state.alarms.size} منبه · صيغة ١٢ ساعة") { navigate("alarms", null) }
                    IconRow(Icons.Rounded.Shield, "مركز الجودة والإصلاحات", "كل المشاكل وما تم إصلاحه") { navigate("me", "report") }
                    IconRow(Icons.Rounded.Settings, "كل الإعدادات", "الشكل، الحركة، الصلاحيات والبيانات") { navigate("me", "settings") }
                }
            }
        }
        if (state.companion.hidden) {
            item {
                DfChip("إظهار الرفيق تاني") { repository.setCompanion { it.copy(hidden = false, enabled = true) } }
            }
        }
        item {
            NoticeCard("كل شيء أصلي", "الواجهة Kotlin/Jetpack Compose والمنطق أندرويد خالص: AlarmManager، DataStore، DownloadManager، AppWidgetProvider، Foreground Services، وOkHttp. لا يوجد WebView للواجهة.", "green", Icons.Rounded.Smartphone)
        }
        item {
            Text("DAYFLOW · يومك بهدوء\nنسخة أندرويد أصلية 1.0 · بيانات محلية", color = DayflowColors.Muted, fontSize = 9.sp, lineHeight = 15.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

@Composable
private fun MeStat(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(DayflowColors.Surface2).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric)
        Text(label, color = DayflowColors.Muted, fontSize = 8.sp)
    }
}

@Composable
private fun PrayerSettingsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    var locationMessage by remember { mutableStateOf<String?>(null) }
    val qibla = PrayerCalculator.qiblaDirection(city.lat, city.lng)

    fun updateFromDevice() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        @SuppressLint("MissingPermission")
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (manager == null) { locationMessage = "خدمة الموقع غير متاحة على الجهاز."; return }
        val locations = runCatching { manager.getProviders(true).mapNotNull { manager.getLastKnownLocation(it) } }.getOrElse { emptyList() }
        val best = locations.maxByOrNull { it.time }
        if (best == null) {
            locationMessage = "مفيش قراءة موقع محفوظة. فعّل GPS وافتح التطبيق مرة أخرى."
        } else {
            repository.setCustomLocation(best.latitude, best.longitude, "موقعي", java.util.TimeZone.getDefault().id)
            locationMessage = "تم استخدام موقعك الحالي لحساب المواقيت."
        }
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) updateFromDevice() else locationMessage = "لم يتم السماح بالموقع. يمكنك اختيار مدينتك يدويًا."
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            ScreenHeader("مواقيت الصلاة", "PRAYER · ${city.ar}", prayer.method.ar, action = {
                Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { navigate("me", null) }.padding(8.dp))
            })
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    Text("الصلاة القادمة", color = DayflowColors.Muted, fontSize = 9.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                        Column {
                            Text(prayer.nextLabel, color = DayflowColors.Accent, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text(prayer.nextText, color = DayflowColors.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold, style = DayflowText.numeric)
                        }
                        Text("فاضل ${DayflowTime.duration(prayer.next?.let { java.time.Duration.between(ZonedDateTime.now(), it.at).toMinutes() } ?: 0L)}", color = DayflowColors.AccentStrong, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clip(CircleShape).background(DayflowColors.Soft).padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    PrayerStrip(prayer)
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Text("المدينة", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("جيزة", "قاهرة", "إسكندرية", "أقصر", "أسوان", "شرم", "منصورة", "أسوان").take(0).forEach { }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        PrayerCatalog.cities.take(8).chunked(4).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                                row.forEach { c ->
                                    Box(Modifier.weight(1f)) { DfChip(c.ar, city.id == c.id) { repository.setCity(c.id) } }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                        DfChip("استخدم موقعي") {
                            locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                        }
                        if (state.prayer.customLat != null) DfChip("مسح الموقع") { repository.clearCustomLocation() }
                    }
                    locationMessage?.let { Text(it, color = DayflowColors.Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 3.dp)) }
                    Spacer(Modifier.height(8.dp))
                    Text("طريقة الحساب", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        PrayerCatalog.methods.forEach { method ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (prayer.method.id == method.id) DayflowColors.Soft else DayflowColors.Surface2).clickable { repository.setMethod(method.id) }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(method.ar, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    Text(method.noteAr, fontSize = 8.5.sp, color = DayflowColors.Muted)
                                }
                                if (prayer.method.id == method.id) Icon(Icons.Rounded.Check, null, tint = DayflowColors.Accent, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("مذهب العصر", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 4.dp)) {
                        DfChip("الجمهور / الشافعي", state.prayer.asrFactor == 1) { repository.setAsrFactor(1) }
                        DfChip("الحنفي", state.prayer.asrFactor == 2) { repository.setAsrFactor(2) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Explore, null, tint = DayflowColors.Accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("اتجاه القبلة ${DayflowTime.digits(qibla.toInt())}° من الشمال", color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("الحساب فلكي على الجهاز مع IANA Zone (${city.zone}) والتوقيت الصيفي تلقائيًا، و١٧ مدينة، وقاعدة منتصف الليل عند تعذر زوايا الفجر/العشاء في خطوط العرض العالية.${if (prayer.highLatitude) " طُبقت قاعدة خطوط العرض العالية اليوم." else ""}", color = DayflowColors.Muted, fontSize = 8.5.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun NotificationsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    var tested by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("الإشعارات", "NOTIFICATIONS", if (granted) "مسموح في النظام" else "غير مسموح", action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("me", null) }.padding(8.dp)) }) }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("إذن الإشعارات", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(if (granted) "مسموح — ستظهر المنبهات والتذكيرات" else "مطلوب على أندرويد ١٣+", color = DayflowColors.Muted, fontSize = 9.sp)
                        }
                        SmallTag(if (granted) "مسموح" else "مطلوب", if (granted) "green" else "warn")
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DfChip("طلب الإذن") { if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                        DfChip("اختبار إشعار") { DayflowNotifications.showTestNotification(context); tested = true }
                        DfChip("النظام") {
                            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            runCatching { context.startActivity(intent) }
                        }
                    }
                    if (tested) Text("تم إرسال إشعار تجريبي — افتح درج الإشعارات.", color = DayflowColors.Accent, fontSize = 9sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 6.dp) {
                Column {
                    NotificationToggle("الإشعارات", "تذكيرات المنبهات والعادات", Icons.Rounded.Bell, state.notif.enabled) { repository.setNotif { p -> p.copy(enabled = it) } }
                    NotificationToggle("الصوت", "صوت منبه من اختيارك", Icons.Rounded.VolumeUp, state.notif.sound) { repository.setNotif { p -> p.copy(sound = it) } }
                    NotificationToggle("الاهتزاز", "نمط اهتزاز أصلي", Icons.Rounded.Vibration, state.notif.vibrate) { repository.setNotif { p -> p.copy(vibrate = it) } }
                    NotificationToggle("معاينة التفاصيل", "اسم المنبه أو المهمة", Icons.Rounded.Notifications, state.notif.preview) { repository.setNotif { p -> p.copy(preview = it) } }
                    NotificationToggle("أوقات هادئة", "${state.notif.quietFrom} – ${state.notif.quietTo}", Icons.Rounded.Moon, state.notif.quiet) { repository.setNotif { p -> p.copy(quiet = it) } }
                }
            }
        }
        item {
            NoticeCard("قنوات إشعارات أصلية", "توجد قنوات منفصلة: المنبهات (عالية + شاشة كاملة)، التذكيرات، الرفيق، والتحميلات. المنبهات والصوت يعملان حتى لو التطبيق مغلق. لا توجد أي رسالة ويب داخل النسخة الأصلية.", "green", Icons.Rounded.Shield)
        }
        if (!AlarmScheduler.canScheduleExact(context)) {
            item { NoticeCard("المنبهات الدقيقة", "منح صلاحية المنبهات الدقيقة مطلوب لدقة الرنين.", "warn", Icons.Rounded.Alarm); DfChip("فتح إعدادات المنبه الدقيق") { AlarmScheduler.openExactAlarmSettings(context) } }
        }
    }
}

@Composable
private fun NotificationToggle(title: String, subtitle: String, icon: ImageVector, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, size = 32.dp)
        Spacer(Modifier.width(7.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = DayflowColors.Muted, fontSize = 8.5.sp)
        }
        DfSwitch(checked, onChange, title)
    }
}

@Composable
private fun CompanionSettingsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    var canOverlay by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    val family = DayflowSeasons.forId(CalendarMath.seasonFor())
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("الرفيق", "COMPANION · فوق التطبيقات", "كل الأجهزة مدعومة", action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("me", null) }.padding(8.dp)) }) }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 16.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Robot(size = 96.dp, family = family.id, mood = state.companion.emotion, animate = !state.appearance.reduceMotion)
                    Text("رفيقك ${state.companion.emotion}", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
                    Text("اسحبه في أي مكان، اضغطه يفتحك هنا", color = DayflowColors.Muted, fontSize = 9.5.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DfChip(if (canOverlay) "صلاحية الظهور مسموحة" else "السماح بالظهور فوق التطبيقات") {
                            runCatching {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                            }
                        }
                        DfChip("تحديث الحالة") { canOverlay = Settings.canDrawOverlays(context) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 5.dp)) {
                        DfChip("تشغيل فوق الهاتف") {
                            if (Settings.canDrawOverlays(context)) { CompanionOverlayService.start(context); repository.setCompanion { it.copy(enabled = true, hidden = false) } }
                        }
                        DfChip("إيقاف") { CompanionOverlayService.stop(context) }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                Column {
                    NotificationToggle("تفعيل الرفيق", "داخل التطبيق وفوق باقي التطبيقات", Icons.Rounded.Bot, state.companion.enabled && !state.companion.hidden) { enabled ->
                        repository.setCompanion { prefs -> prefs.copy(enabled = enabled, hidden = !enabled) }
                    }
                    NotificationToggle("الفقاعات والنصائح", "جُمل قصيرة حسب وقتك", Icons.Rounded.AutoAwesome, state.companion.bubbles) { enabled ->
                        repository.setCompanion { prefs -> prefs.copy(bubbles = enabled) }
                    }
                    NotificationToggle("إشعارات الرفيق", "تذكيرات ودّية", Icons.Rounded.Bell, state.companion.notify) { enabled ->
                        repository.setCompanion { prefs -> prefs.copy(notify = enabled) }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    Text("الحجم", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Slider(value = state.companion.size, onValueChange = { repository.setCompanion { p -> p.copy(size = it) } }, valueRange = 0.6f..1.4f, colors = SliderDefaults.colors(thumbColor = DayflowColors.Accent, activeTrackColor = DayflowColors.Accent))
                    Text("الشفافية", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Slider(value = state.companion.opacity, onValueChange = { repository.setCompanion { p -> p.copy(opacity = it) } }, valueRange = 0.4f..1f, colors = SliderDefaults.colors(thumbColor = DayflowColors.Accent, activeTrackColor = DayflowColors.Accent))
                    Text("الحالة", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 3.dp)) {
                        listOf("idle" to "هادي", "happy" to "سعيد", "think" to "بيفكر", "sleep" to "نايم").forEach { (id, label) ->
                            DfChip(label, state.companion.emotion == id) { repository.setCompanion { p -> p.copy(emotion = id) } }
                        }
                    }
                    Text("الزينة", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 3.dp)) {
                        listOf("auto" to "تلقائي", "gold" to "ذهبي/رمضان", "snow" to "شتوي", "national" to "وطني").forEach { (id, label) ->
                            DfChip(label, state.companion.outfit == id) { repository.setCompanion { p -> p.copy(outfit = id) } }
                        }
                    }
                }
            }
        }
        item {
            NoticeCard("Overlay حقيقي", "الرفيق العائم خدمة Foreground بنوع specialUse وTYPE_APPLICATION_OVERLAY. يظهر فوق كل التطبيقات، يُسحب، يفتح التطبيق باللمس، ويتوقف فورًا من إشعار الخدمة أو زر الإيقاف. نفس ملف الرسم يستخدم داخل التطبيق لتطابق كامل.", "green", Icons.Rounded.Layers)
        }
    }
}

@Composable
private fun SettingsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("الإعدادات", "SETTINGS", null, action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("me", null) }.padding(8.dp)) }) }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lock, null, tint = DayflowColors.Accent, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Column { Text("الوقت ١٢ ساعة دائمًا", fontSize = 11.5.sp, fontWeight = FontWeight.Bold); Text("ص/م — لا يوجد خيار ٢٤ ساعة في التطبيق", color = DayflowColors.Muted, fontSize = 9.sp) }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                Column {
                    NotificationToggle("الزخارف والزينة", "صور موسمية واقعية", Icons.Rounded.AutoAwesome, state.appearance.intensity != "off") { repository.setAppearance { p -> p.copy(intensity = if (it) "subtle" else "off") } }
                    NotificationToggle("تقليل الحركة", "أداء أسلم", Icons.Rounded.Moon, state.appearance.reduceMotion) { repository.setAppearance { p -> p.copy(reduceMotion = it) } }
                    NotificationToggle("تغيير الزينة مع الموسم", "رمضان، العيد، الفصول", Icons.Rounded.Settings, state.appearance.autoSeason) { repository.setAppearance { p -> p.copy(autoSeason = it) } }
                    Text("كثافة الزخرفة", color = DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(horizontal = 8.dp)) {
                        listOf("off" to "بسيط", "subtle" to "هادي", "rich" to "غني", "festival" to "مهرجان").forEach { (id, label) ->
                            DfChip(label, state.appearance.intensity == id) { repository.setAppearance { p -> p.copy(intensity = id) } }
                        }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Text("صلاحيات النظام", color = DayflowColors.Text, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    PermissionLine("المنبهات الدقيقة", "SCHEDULE_EXACT_ALARM", AlarmScheduler.canScheduleExact(context)) {
                        AlarmScheduler.openExactAlarmSettings(context)
                    }
                    PermissionLine("الإشعارات", "POST_NOTIFICATIONS", Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)) }
                    }
                    PermissionLine("فوق التطبيقات", "SYSTEM_ALERT_WINDOW", Settings.canDrawOverlays(context)) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))) }
                    }
                    PermissionLine("الموقع", "ACCESS_COARSE_LOCATION", ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))) }
                    }
                    PermissionLine("الملفات والصوت", "OpenDocument + persistable URI", true) { navigate("alarms", null) }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("me", "report") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Shield)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) { Text("مركز الجودة", fontSize = 11.5.sp, fontWeight = FontWeight.Bold); Text("كل المشاكل والإصلاحات — جاهزة للنسخ", color = DayflowColors.Muted, fontSize = 9.sp) }
                    Icon(Icons.Rounded.ChevronLeft, null, tint = DayflowColors.Muted, modifier = Modifier.size(15.dp))
                }
            }
        }
        item {
            NoticeCard("لا WebView للواجهة", "الواجهة Compose والمنطق Kotlin أصلي. لا تظهر رسائل «هذه الميزة تعمل على أندرويد فقط» لأنك داخل تطبيق أندرويد الأصلي. المتصفح يحتوي هذه الرسائل فقط في معاينة الويب.", "green", Icons.Rounded.Smartphone)
        }
    }
}

@Composable
private fun PermissionLine(title: String, permission: String, granted: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.Shield, null, tint = if (granted) DayflowColors.Accent else DayflowColors.Danger, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
            Text(permission, color = DayflowColors.Muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(if (granted) "مفعّل" else "فتح", color = if (granted) DayflowColors.Accent else DayflowColors.Danger, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ReportScreen(navigate: Navigate) {
    val context = LocalContext.current
    val reportLines = listOf(
        "الواجهة والمنطق أصبحا Kotlin + Jetpack Compose بدل WebView/Capacitor",
        "الرفيق يظهر فوق الهاتف عبر Foreground Overlay Service وSYSTEM_ALERT_WINDOW",
        "المنبه يعمل بـ AlarmManager.setAlarmClock + FullScreen + غفوة + نغمة الهاتف",
        "إعادة جدولة كل المنبهات بعد BOOT وتغيير الوقت والمنطقة الزمنية",
        "إشعارات وقنوات حقيقية + طلب POST_NOTIFICATIONS واختبار إشعار",
        "ودجتس AppWidgetProvider + RemoteViews + شاشة اختيار واحدة عند الإضافة",
        "معاينة الروابط عبر OkHttp/Jsoup بدون CORS + DownloadManager",
        "المواقيت: Giza، 17 مدينة، IANA/DST، طريقة مصرية، مذاهب العصر، خطوط العرض العالية",
        "الوقت ١٢ ساعة فقط في كل شاشة وودجت وإشعار وشاشة رنين",
        "الزخارف الواقعية: أزهار وربيع، ورق خريف، فانوس، ثلج، وطنية + صور موسمية",
        "تسريع الأداء: رسم الروبوت على Canvas، رسم إطار دون إعادة تركيب الشاشة، LazyColumn، تحديثات ٢٠–٣٠ ثانية",
        "منبه التركيز يُجدول أصليًا عند الانتهاء ويعمل خارج التطبيق",
    )
    fun copyAll() {
        val text = reportLines.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        clipboard?.setPrimaryClip(ClipData.newPlainText("DAYFLOW fixes", text))
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { ScreenHeader("مركز الجودة", "REPAIR REPORT", "كل المشاكل المصلحة — جاهزة للنسخ", action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("me", null) }.padding(8.dp)) }) }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    Text("تم إصلاح كل البنود الأساسية", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    Text("القائمة الكاملة (${reportLines.size}) موجودة أيضًا في ANDROID_NATIVE_FIXES.md داخل المشروع. نفس الشكل والهوية البصرية محفوظان.", color = DayflowColors.Muted, fontSize = 9.5.sp, lineHeight = 15.sp)
                    Spacer(Modifier.height(8.dp))
                    DfChip("نسخ القائمة كاملة") { copyAll() }
                }
            }
        }
        items(reportLines) { line ->
            DfCard(Modifier.fillMaxWidth(), padding = 12.dp) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = DayflowColors.Accent, modifier = Modifier.padding(top = 1.dp).size(15.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(line, color = DayflowColors.Text, fontSize = 10.5.sp, lineHeight = 17.sp)
                }
            }
        }
        item { NoticeCard("الوصول للملفات", "راجع android/README.md لخطوات البناء، وANDROID_NATIVE_FIXES.md لتقرير المشاكل الكامل مع التقنيات المستخدمة.", "green", Icons.Rounded.Shield) }
    }
}
