package app.dayflow.android.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.DayflowApplication
import app.dayflow.android.R
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.NativeWidget
import app.dayflow.android.domain.NativeWidgetCatalog
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowTheme
import app.dayflow.android.ui.theme.DayflowText
import kotlinx.coroutines.launch
import java.time.ZonedDateTime
import java.time.ZoneId

/**
 * The launcher opens this activity before pinning a widget. It is the same
 * widget-selection screen as inside the app, and the instruction is explicit:
 * «اختار واحدة لتكون هي الودجت».
 */
class WidgetConfigActivity : ComponentActivity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        appWidgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))

        val repository = DayflowApplication.repository(this)
        setContent {
            DayflowTheme {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFAF8F2), DayflowColors.Bg)))) {
                    ConfigContent(
                        onCancel = { finish() },
                        onConfirm = { design, form, style ->
                            val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                                WidgetUpdater.saveChoice(this, appWidgetId, design.id, form, style)
                                WidgetUpdater.updateWidget(this, appWidgetId)
                            }
                            setResult(Activity.RESULT_OK, result)
                            finish()
                        },
                        repository = repository,
                    )
                }
            }
        }
    }
}

@Composable
private fun ConfigContent(
    repository: app.dayflow.android.data.DayflowRepository,
    onCancel: () -> Unit,
    onConfirm: (NativeWidget, String, String) -> Unit,
) {
    val state by repository.state.collectAsState(initial = null)
    var selected by remember { mutableStateOf(NativeWidgetCatalog.widgets.first()) }
    var form by remember { mutableStateOf("4x2") }
    var style by remember { mutableStateOf("oneui") }
    val scope = rememberCoroutineScope()
    val current = state
    val prayer = current?.let {
        val city = repository.activeCity(it)
        val zone = runCatching { ZoneId.of(city.zone) }.getOrDefault(ZoneId.systemDefault())
        PrayerCalculator.forCity(city, PrayerCatalog.method(it.prayer.methodId), it.prayer.asrFactor, ZonedDateTime.now(zone))
    }
    val family = DayflowSeasons.forId(CalendarMath.seasonFor())

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            ScreenHeader(
                title = "الودجتس",
                eyebrow = "WIDGETS · أصلية",
                subtitle = "اختار واحدة لتكون هي الودجت",
                action = {
                    Text("إلغاء", color = DayflowColors.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onCancel() }.padding(8.dp))
                },
            )
        }
        item {
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    .background(
                        Brush.linearGradient(listOf(family.c2, family.c1)),
                        RoundedCornerShape(26.dp),
                    ).padding(16.dp),
            ) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(DayflowTime.fullDate(), color = Color.White.copy(alpha = 0.82f), fontSize = 10.sp)
                            Text(DayflowTime.clock12(ZonedDateTime.now()), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric)
                        }
                        Text("DAYFLOW", color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp, letterSpacing = 1.4.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Column(
                        Modifier.fillMaxWidth().background(Color(0xFFFDFCF7), RoundedCornerShape(20.dp)).padding(14.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Widgets, null, tint = DayflowColors.Accent, modifier = Modifier.size(16.dp))
                            Text(selected.ar, color = DayflowColors.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                            Text(form.replace("x", "×"), color = DayflowColors.Muted, fontSize = 10.sp)
                        }
                        Spacer(Modifier.height(7.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(prayer?.let { "${it.nextLabel} ${it.nextText}" } ?: "مواقيت الصلاة", color = DayflowColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(prayer?.city?.ar ?: "الجيزة", color = DayflowColors.Muted, fontSize = 9.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(selected.desc, color = DayflowColors.Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("معاينة حقيقية لبياناتك · تتحدث تلقائيًا", color = Color.White.copy(alpha = 0.68f), fontSize = 9.sp)
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = DayflowColors.Accent, modifier = Modifier.size(15.dp))
                    Text("اختار واحدة لتكون هي الودجت", color = DayflowColors.AccentStrong, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("التصميم المختار يُثبّت مباشرة في هذه المساحة. يمكنك تغييره لاحقًا من التطبيق.", color = DayflowColors.Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        items(NativeWidgetCatalog.widgets, key = { it.id }) { widget ->
            val isSelected = selected.id == widget.id
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    .background(if (isSelected) DayflowColors.Soft else DayflowColors.Surface, RoundedCornerShape(16.dp))
                    .border(1.dp, if (isSelected) DayflowColors.Accent else DayflowColors.Line, RoundedCornerShape(16.dp))
                    .clickable { selected = widget; form = widget.forms.firstOrNull { it == "4x2" } ?: widget.forms.first() }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(Modifier.size(36.dp).background(DayflowColors.SoftGold, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Icon(if (widget.layoutKind == "alarm") Icons.Rounded.Layers else Icons.Rounded.Widgets, null, tint = DayflowColors.GoldText, modifier = Modifier.size(17.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(widget.ar, color = DayflowColors.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(widget.desc, color = DayflowColors.Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(widget.catAr, color = DayflowColors.Accent, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                }
                if (isSelected) Icon(Icons.Rounded.CheckCircle, null, tint = DayflowColors.Accent, modifier = Modifier.size(20.dp))
            }
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الحجم", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    selected.forms.forEach { f -> DfChip(f.replace("x", "×"), form == f) { form = f } }
                }
                Text("النمط", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("oneui" to "زجاج", "material" to "Material", "paper" to "ورق", "gold" to "ذهبي").forEach { (id, label) ->
                        DfChip(label, style == id) { style = id }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { scope.launch { onConfirm(selected, form, style) } },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DayflowColors.Accent, contentColor = DayflowColors.OnAccent),
                ) {
                    Icon(Icons.Rounded.Widgets, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.size(8.dp))
                    Text("اختار دي لتكون الودجت", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("على أندرويد تستخدم الودجت RemoteViews أصلية وتُحدّث بعد تغيير المنبه أو الصلاة أو المهام.", color = DayflowColors.Muted, fontSize = 9.sp)
            }
        }
    }
}

@Suppress("unused")
private val configHints = listOf(Icons.Rounded.Refresh, Icons.Rounded.Smartphone)
