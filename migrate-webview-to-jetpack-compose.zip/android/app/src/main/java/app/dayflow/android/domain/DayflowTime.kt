package app.dayflow.android.domain

import app.dayflow.android.data.Alarm
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.TextStyle
import java.util.Locale

/**
 * DAYFLOW time formatting. The product requirement is explicit: the whole app
 * uses the 12-hour clock, with Arabic-Indic digits and ص/م. There is no 24-hour
 * code path at all, so no screen can accidentally display a 24-hour value.
 */
object DayflowTime {
    val arabicLocale: Locale = Locale.forLanguageTag("ar-EG-u-nu-arab")
    private const val INDIC = "٠١٢٣٤٥٦٧٨٩"

    fun digits(value: String): String = value.map { ch -> if (ch in '0'..'9') INDIC[ch - '0'] else ch }.joinToString("")
    fun digits(value: Int): String = digits(value.toString())
    fun digits(value: Long): String = digits(value.toString())

    fun clock12(value: LocalTime): String {
        val hour = if (value.hour % 12 == 0) 12 else value.hour % 12
        val suffix = if (value.hour < 12) "ص" else "م"
        return "${digits(hour)}:${digits(value.minute.toString().padStart(2, '0'))} $suffix"
    }

    fun clock12(instant: ZonedDateTime): String = clock12(instant.toLocalTime())

    fun clock12(hhmm: String): String {
        val parts = hhmm.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return "—"
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return clock12(LocalTime.of(hour.coerceIn(0, 23), minute.coerceIn(0, 59)))
    }

    fun toLocalTime(hhmm: String): LocalTime? {
        val parts = hhmm.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return null
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        return LocalTime.of(hour, minute)
    }

    fun dateKey(date: LocalDate = LocalDate.now()): String =
        "${date.year}-${date.monthValue.toString().padStart(2, '0')}-${date.dayOfMonth.toString().padStart(2, '0')}"

    fun todayKey(zone: ZoneId = ZoneId.systemDefault()): String = dateKey(LocalDate.now(zone))

    fun greeting(): String = when (java.time.LocalTime.now().hour) {
        in 0..4 -> "طابت ليلتك"
        in 5..11 -> "صباح الخير"
        in 12..16 -> "طاب يومك"
        else -> "مساء الخير"
    }

    fun fullDate(date: LocalDate = LocalDate.now()): String {
        val day = date.dayOfWeek.getDisplayName(TextStyle.FULL, arabicLocale)
        val month = date.month.getDisplayName(TextStyle.FULL, arabicLocale)
        return "$day ${digits(date.dayOfMonth)} $month"
    }

    fun shortDate(date: LocalDate = LocalDate.now()): String =
        "${date.dayOfWeek.getDisplayName(TextStyle.SHORT, arabicLocale)} ${digits(date.dayOfMonth)} ${date.month.getDisplayName(TextStyle.SHORT, arabicLocale)}"

    fun nextAlarm(alarms: List<Alarm>, from: ZonedDateTime = ZonedDateTime.now()): AlarmOccurrence? =
        alarms.asSequence()
            .filter { it.enabled }
            .mapNotNull { nextOccurrence(it, from) }
            .minByOrNull { it.at.toInstant() }

    fun nextOccurrence(alarm: Alarm, from: ZonedDateTime = ZonedDateTime.now()): AlarmOccurrence? {
        val time = toLocalTime(alarm.time) ?: return null
        val zone = from.zone
        alarm.date?.let { date ->
            val parsed = runCatching { LocalDate.parse(date) }.getOrNull() ?: return@let
            val at = ZonedDateTime.of(parsed, time, zone)
            return if (at.isAfter(from)) AlarmOccurrence(alarm, at) else null
        }
        if (alarm.days.isEmpty()) {
            var at = ZonedDateTime.of(from.toLocalDate(), time, zone)
            if (!at.isAfter(from)) at = at.plusDays(1)
            return AlarmOccurrence(alarm, at)
        }
        val calendarDays = alarm.days.mapNotNull { index ->
            runCatching { DayOfWeek.of(if (index == 0) 7 else index) }.getOrNull()
        }
        for (offset in 0..7) {
            val date = from.toLocalDate().plusDays(offset.toLong())
            if (calendarDays.contains(date.dayOfWeek)) {
                val at = ZonedDateTime.of(date, time, zone)
                if (at.isAfter(from)) return AlarmOccurrence(alarm, at)
            }
        }
        return null
    }

    fun daysLabel(alarm: Alarm): String {
        if (alarm.date != null && alarm.days.isEmpty()) {
            val date = runCatching { LocalDate.parse(alarm.date) }.getOrNull()
            return date?.let { fullDate(it) } ?: "مرة واحدة"
        }
        if (alarm.days.isEmpty()) return "مرة واحدة"
        if (alarm.days.size == 7) return "كل يوم"
        return alarm.days.sortedBy { (it + 1) % 7 }.joinToString(" · ") { DAYS_SHORT_AR.getOrElse(it) { "" } }
    }

    fun countdown(at: ZonedDateTime, from: ZonedDateTime = ZonedDateTime.now()): String {
        val minutes = java.time.Duration.between(from, at).toMinutes().coerceAtLeast(0)
        val days = minutes / 1440
        val hours = (minutes % 1440) / 60
        val mins = minutes % 60
        return when {
            days > 0 -> "بعد ${digits(days)} يوم و${digits(hours)} ساعة"
            hours > 0 -> "بعد ${digits(hours)} ساعة و${digits(mins)} دقيقة"
            else -> "بعد ${digits(mins)} دقيقة"
        }
    }

    fun duration(minutes: Long): String {
        val m = minutes.coerceAtLeast(0)
        return if (m >= 60) "${digits(m / 60)} س ${digits(m % 60)} د" else "${digits(m)} دقيقة"
    }

    fun at(date: LocalDate, hhmm: String, zone: ZoneId): LocalDateTime? = toLocalTime(hhmm)?.let { LocalDateTime.of(date, it) }
}

data class AlarmOccurrence(val alarm: Alarm, val at: ZonedDateTime) {
    val millis: Long get() = at.toInstant().toEpochMilli()
    val clock: String get() = DayflowTime.clock12(at)
}
