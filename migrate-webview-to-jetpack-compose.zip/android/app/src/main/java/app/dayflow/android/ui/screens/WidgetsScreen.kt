package app.dayflow.android.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Launch
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.NativeWidget
import app.dayflow.android.domain.NativeWidgetCatalog
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.components.SectionTitle
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowText
import app.dayflow.android.widget.DayflowWidgetProvider

@Composable
fun WidgetsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    val initial = NativeWidgetCatalog.byId(state.widgets.designId)
    var picked by remember { mutableStateOf(initial) }
    var form by remember { mutableStateOf(state.widgets.form) }
    var style by remember { mutableStateOf(state.widgets.style) }
    var category by remember { mutableStateOf("all") }
    var message by remember { mutableStateOf<String?>(null) }
    val list = NativeWidgetCatalog.widgets.filter { category == "all" || it.cat == category }
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    val nextAlarm = DayflowTime.nextAlarm(state.alarms)
    val tasks = state.tasks.filter { it.date == repository.todayKey(state) }
    val family = DayflowSeasons.forId(CalendarMath.seasonFor())

    fun confirm(pin: Boolean) {
        repository.setWidgetChoice(picked.id, form, style)
        message = if (pin) "تم اختيار «${picked.ar}» لتكون هي الودجت. جاري فتح شاشة التثبيت على الشاشة الرئيسية…"
        else "تم اختيار «${picked.ar}» لتكون هي الودجت وحفظها في التطبيق."
        if (pin) {
            val manager = AppWidgetManager.getInstance(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val success = runCatching {
                    manager.requestPinAppWidget(ComponentName(context, DayflowWidgetProvider::class.java), null, null)
                }.getOrDefault(false)
                if (!success) message = "اللانشر لا يدعم التثبيت البرمجي. أضف ودجت DAYFLOW من الشاشة الرئيسية وسيُفتح هذا الاختيار تلقائيًا."
            }
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("الودجتس", "WIDGETS · أصلية", "كل ودجت هنا لها RemoteViews حقيقية وتفتح شاشة الودجتس نفسها") }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(family.c2, family.c1))).padding(14.dp)) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(DayflowTime.fullDate(), color = Color.White.copy(alpha = 0.8f), fontSize = 9.5.sp)
                            Text(DayflowTime.clock12(java.time.ZonedDateTime.now()), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric)
                        }
                        Text("DAYFLOW", color = Color.White.copy(alpha = 0.72f), fontSize = 9.sp, letterSpacing = 1.4.sp)
                    }
                    Spacer(Modifier.height(9.dp))
                    WidgetPreview(picked, form, style, state, prayer.nextLabel + " " + prayer.nextText, nextAlarm?.clock ?: "—", tasks.count { it.done }, tasks.size)
                }
            }
        }
        item {
            NoticeCard("اختار واحدة لتكون هي الودجت", "التصميم المختار هو الذي سيظهر على الشاشة الرئيسية. اختَر الحجم والنمط ثم اضغط «اختار دي لتكون الودجت».", "green", Icons.Rounded.CheckCircle)
        }
        message?.let { text ->
            item { NoticeCard("تم", text, "green", Icons.Rounded.Check) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                DfChip("الكل", category == "all") { category = "all" }
                NativeWidgetCatalog.categories.take(3).forEach { (id, label) -> DfChip(label, category == id) { category = id } }
            }
        }
        items(list, key = { it.id }) { widget ->
            val selected = picked.id == widget.id
            DfCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = {
                picked = widget
                if (widget.forms.none { it == form }) form = widget.forms.firstOrNull { it == "4x2" } ?: widget.forms.first()
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(if (selected) DayflowColors.Soft else DayflowColors.Surface2), contentAlignment = Alignment.Center) {
                        Icon(if (widget.layoutKind == "alarm") Icons.Rounded.Alarm else Icons.Rounded.Widgets, null, tint = DayflowColors.Accent, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(widget.ar, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                            if (widget.interactive) { Spacer(Modifier.width(4.dp)); SmallTag("تفاعلية", "green") }
                        }
                        Text(widget.desc, color = DayflowColors.Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(widget.forms.joinToString(" · ") { it.replace("x", "×") }, color = DayflowColors.Accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                    }
                    if (selected) Icon(Icons.Rounded.CheckCircle, null, tint = DayflowColors.Accent, modifier = Modifier.size(19.dp))
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Text("الحجم والنمط", color = DayflowColors.Text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Spacer(Modifier.height(5.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { picked.forms.forEach { f -> DfChip(f.replace("x", "×"), form == f) { form = f } } }
                    Spacer(Modifier.height(7.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf("oneui" to "زجاج", "material" to "Material", "paper" to "ورق", "gold" to "ذهبي").forEach { (id, label) -> DfChip(label, style == id) { style = id } }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(DayflowColors.Accent).clickable { confirm(false) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                            Text("اختار دي لتكون الودجت", color = DayflowColors.OnAccent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                        }
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(13.dp)).background(DayflowColors.Soft).clickable { confirm(true) }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Widgets, null, tint = DayflowColors.AccentStrong, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("أضف للشاشة", color = DayflowColors.AccentStrong, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                    Text("على أندرويد يفتح اللانشر هذه الشاشة نفسها عند إضافة الودجت، ويُطلب منك اختيار ودجت واحدة.", color = DayflowColors.Muted, fontSize = 8.5.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (state.widgets.placed.isNotEmpty()) {
            item { SectionTitle("ودجتس مساحتك") { SmallTag(DayflowTime.digits(state.widgets.placed.size), "green") } }
            items(state.widgets.placed, key = { it.id }) { placed ->
                val def = NativeWidgetCatalog.byId(placed.designId)
                DfCard(Modifier.fillMaxWidth(), padding = 11.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBadge(Icons.Rounded.Widgets, size = 32.dp, background = DayflowColors.Soft)
                        Spacer(Modifier.width(7.dp))
                        Column(Modifier.weight(1f)) {
                            Text(def.ar, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${placed.form.replace("x", "×")} · ${placed.style}", color = DayflowColors.Muted, fontSize = 8.5.sp)
                        }
                        Text("اختيار", color = DayflowColors.Accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                            repository.setWidgetChoice(placed.designId, placed.form, placed.style); picked = def; form = placed.form; style = placed.style
                        })
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.Rounded.Delete, "حذف", tint = DayflowColors.Muted, modifier = Modifier.size(15.dp).clickable { repository.deleteWidget(placed.id) })
                    }
                }
            }
        }
        if (state.widgets.placed.isEmpty()) {
            item {
                DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                    Column {
                        Text("لأول مرة: من الشاشة الرئيسية", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("اضغط مطولًا على الشاشة ← الودجتس ← DAYFLOW. سيُفتح تطبيق DAYFLOW على هذه الشاشة ويطلب منك اختيار ودجت واحدة، ثم تتثبت مباشرة. لو تصميمك محفوظ يمكنك أيضًا اختياره من هنا.", color = DayflowColors.Muted, fontSize = 9.5.sp, lineHeight = 15.sp)
                    }
                }
            }
        }
        item {
            NoticeCard("ليست محاكاة", "الودجتس تُحدّث من نفس DataStore بعد تغيير المنبه أو الصلاة أو المهام. الأحجام مدعومة عبر RemoteViews، والتفاعل يفتح الشاشة المناسبة في التطبيق.", "green", Icons.Rounded.Widgets)
        }
    }
}

@Composable
private fun WidgetPreview(
    widget: NativeWidget,
    form: String,
    style: String,
    state: DayflowState,
    nextPrayer: String,
    nextAlarm: String,
    done: Int,
    total: Int,
) {
    val dark = style == "gold"
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(if (dark) Color(0xFF1D342A) else Color(0xFFFDFCF7))
            .padding(13.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(widget.ar, color = if (dark) Color(0xFFF3E6C2) else DayflowColors.Text, fontSize = 10.5.sp, fontWeight = FontWeight.ExtraBold)
            Text("DAYFLOW", color = if (dark) Color(0xFFC9A24A) else DayflowColors.Accent, fontSize = 7.5.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(if (widget.layoutKind == "alarm") nextAlarm else if (widget.layoutKind == "tasks") "$done/$total مهام" else nextPrayer,
            color = if (dark) Color.White else DayflowColors.Text, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric, maxLines = 1)
        Text(widget.desc, color = if (dark) Color(0xFFA9C3B7) else DayflowColors.Muted, fontSize = 8.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            state.habits.take(4).forEach { habit -> Box(Modifier.weight(1f).height(5.dp).clip(CircleShape).background(if (dark) Color(0xFFC9A24A) else DayflowColors.Soft)) }
        }
    }
}
