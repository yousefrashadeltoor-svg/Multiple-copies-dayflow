package app.dayflow.android.alarm

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Snooze
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.DayflowApplication
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.ui.components.DayflowText
import app.dayflow.android.ui.theme.DayflowTheme

class AlarmRingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val alarmId = intent.getStringExtra(AlarmRingService.EXTRA_ALARM_ID) ?: "alarm"
        val label = intent.getStringExtra(AlarmRingService.EXTRA_LABEL).orEmpty()
        val time = intent.getStringExtra(AlarmRingService.EXTRA_TIME) ?: "07:00"
        val snooze = intent.getIntExtra(AlarmRingService.EXTRA_SNOOZE, 10)
        val repository = DayflowApplication.repository(this)

        setContent {
            DayflowTheme {
                val state by repository.state.collectAsState(initial = null)
                val prayer = state?.let { current ->
                    val city = repository.activeCity(current)
                    PrayerCalculator.forCity(city, app.dayflow.android.domain.PrayerCatalog.method(current.prayer.methodId), current.prayer.asrFactor)
                }
                Surface(color = Color(0xFF112019), modifier = Modifier.fillMaxSize()) {
                    RingingContent(
                        label = label,
                        time = time,
                        snooze = snooze,
                        dateText = DayflowTime.fullDate(),
                        nextPrayer = prayer?.let { "${it.nextLabel} ${it.nextText}" } ?: "",
                        onStop = {
                            startService(Intent(this@AlarmRingActivity, AlarmRingService::class.java).setAction(AlarmRingService.ACTION_STOP))
                            finishAndRemoveTask()
                        },
                        onSnooze = {
                            startService(
                                Intent(this@AlarmRingActivity, AlarmRingService::class.java).apply {
                                    action = AlarmRingService.ACTION_SNOOZE
                                    putExtra(AlarmRingService.EXTRA_ALARM_ID, alarmId)
                                    putExtra(AlarmRingService.EXTRA_TIME, time)
                                    putExtra(AlarmRingService.EXTRA_LABEL, label)
                                    putExtra(AlarmRingService.EXTRA_SNOOZE, snooze)
                                },
                            )
                            finishAndRemoveTask()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun RingingContent(
    label: String,
    time: String,
    snooze: Int,
    dateText: String,
    nextPrayer: String,
    onStop: () -> Unit,
    onSnooze: () -> Unit,
) {
    val transition = rememberInfiniteTransition(label = "ring")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulse",
    )
    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Spacer(Modifier.height(18.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .scale(pulse)
                    .background(Color(0xFF23483B), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Alarm, contentDescription = null, tint = Color(0xFFF3E6C2), modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(26.dp))
            Text(dateText, color = Color(0xFFB9CFC3), fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                DayflowTime.clock12(time),
                color = Color(0xFFF6ECD4),
                fontSize = 54.sp,
                fontWeight = FontWeight.ExtraBold,
                style = DayflowText.numeric,
            )
            Spacer(Modifier.height(8.dp))
            Text(label.ifBlank { "منبه" }, color = Color(0xFFE7F1EA), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text(
                if (nextPrayer.isNotBlank()) "الصلاة القادمة: $nextPrayer" else "يومك بهدوء",
                color = Color(0xFFA9C3B7),
                fontSize = 12.sp,
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                "الرنين مستمر حتى تضغط إيقاف — حتى لو الشاشة مقفولة",
                color = Color(0xFF7E9A8C),
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Spacer(Modifier.height(22.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    onClick = onSnooze,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF27483B), contentColor = Color(0xFFF3E6C2)),
                    modifier = Modifier.size(76.dp),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Snooze, contentDescription = null, modifier = Modifier.size(22.dp))
                        Text(DayflowTime.digits(snooze), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Button(
                    onClick = onStop,
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE9F0E7), contentColor = Color(0xFF1F3628)),
                    modifier = Modifier.size(96.dp),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.Alarm, contentDescription = null, modifier = Modifier.size(26.dp))
                        Text("إيقاف", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
