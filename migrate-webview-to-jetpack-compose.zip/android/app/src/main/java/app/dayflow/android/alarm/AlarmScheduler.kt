package app.dayflow.android.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import app.dayflow.android.data.Alarm
import app.dayflow.android.domain.DayflowTime
import java.time.ZonedDateTime

/**
 * Exact alarm scheduling with a real AlarmClockInfo. Shows the system alarm icon,
 * rings while the process is dead, and is restorable after reboot.
 *
 * If the exact-alarm permission is denied we explicitly fall back to an inexact
 * idle-safe alarm and notify the user. We never claim the alarm is exact when it
 * is not.
 */
object AlarmScheduler {
    const val ACTION_FIRE = "app.dayflow.android.ALARM_FIRE"
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_TIME = "alarm_time"
    const val EXTRA_LABEL = "alarm_label"
    const val EXTRA_DAYS = "alarm_days"
    const val EXTRA_DATE = "alarm_date"
    const val EXTRA_SOUND_URI = "alarm_sound_uri"
    const val EXTRA_SOUND_TITLE = "alarm_sound_title"
    const val EXTRA_VIBRATE = "alarm_vibrate"
    const val EXTRA_SNOOZE = "alarm_snooze"
    const val EXTRA_GENTLE = "alarm_gentle"
    const val EXTRA_PREVIEW = "alarm_preview"

    fun canScheduleExact(context: Context): Boolean {
        val manager = context.getSystemService(AlarmManager::class.java) ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) manager.canScheduleExactAlarms() else true
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun schedule(context: Context, alarm: Alarm): Boolean {
        if (!alarm.enabled) { cancel(context, alarm.id); return false }
        val occurrence = DayflowTime.nextOccurrence(alarm) ?: run { cancel(context, alarm.id); return false }
        val manager = context.getSystemService(AlarmManager::class.java) ?: return false
        val pending = firePendingIntent(context, alarm, occurrence.at)
        val exact = canScheduleExact(context)

        return try {
            if (exact) {
                val showIntent = PendingIntent.getActivity(
                    context,
                    alarm.id.hashCode(),
                    Intent(context, AlarmRingActivity::class.java).putExtra(EXTRA_ID, alarm.id),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(occurrence.millis, showIntent), pending)
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, occurrence.millis, pending)
                } else {
                    manager.set(AlarmManager.RTC_WAKEUP, occurrence.millis, pending)
                }
                app.dayflow.android.notifications.DayflowNotifications.showExactAlarmFallback(context)
            }
            true
        } catch (_: SecurityException) {
            runCatching {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, occurrence.millis, pending)
                app.dayflow.android.notifications.DayflowNotifications.showExactAlarmFallback(context)
            }
            false
        }
    }

    /** Synchronises every enabled alarm. Called after mutations, boot, timezone change, etc. */
    fun sync(context: Context, alarms: List<Alarm>) {
        alarms.forEach { alarm -> runCatching { schedule(context, alarm) } }
        alarms.filterNot { it.enabled }.forEach { cancel(context, it.id) }
        app.dayflow.android.widget.WidgetUpdater.updateAll(context)
    }

    fun cancel(context: Context, id: String) {
        val manager = context.getSystemService(AlarmManager::class.java) ?: return
        val intent = Intent(context, AlarmReceiver::class.java).setAction(ACTION_FIRE)
        val pending = PendingIntent.getBroadcast(
            context,
            requestCode(id),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE,
        )
        if (pending != null) manager.cancel(pending)
    }

    fun snooze(context: Context, label: String, minutes: Int, soundUri: String?, vibrate: Boolean, snooze: Int) {
        val at = ZonedDateTime.now().plusMinutes(minutes.toLong().coerceAtLeast(1))
        val alarm = Alarm(
            id = "snooze-${System.currentTimeMillis()}",
            time = "%02d:%02d".format(at.hour, at.minute),
            days = emptyList(),
            label = if (label.isBlank()) "غفوة" else "$label · غفوة",
            sound = app.dayflow.android.data.AlarmSound(uri = soundUri, title = "نغمة المنبه"),
            enabled = true,
            vibrate = vibrate,
            snooze = snooze,
        )
        schedule(context, alarm)
    }

    fun preview(context: Context, alarm: Alarm) {
        val service = Intent(context, AlarmRingService::class.java).apply {
            action = AlarmRingService.ACTION_START
            putExtra(AlarmRingService.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmRingService.EXTRA_LABEL, alarm.label)
            putExtra(AlarmRingService.EXTRA_TIME, alarm.time)
            putExtra(AlarmRingService.EXTRA_SOUND_URI, alarm.sound.uri)
            putExtra(AlarmRingService.EXTRA_VIBRATE, alarm.vibrate)
            putExtra(AlarmRingService.EXTRA_SNOOZE, alarm.snooze)
            putExtra(AlarmRingService.EXTRA_GENTLE, alarm.gentle)
            putExtra(AlarmRingService.EXTRA_PREVIEW, true)
        }
        androidx.core.content.ContextCompat.startForegroundService(context, service)
    }

    private fun firePendingIntent(context: Context, alarm: Alarm, at: ZonedDateTime): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_FIRE
            putExtra(EXTRA_ID, alarm.id)
            putExtra(EXTRA_TIME, alarm.time)
            putExtra(EXTRA_LABEL, alarm.label)
            putExtra(EXTRA_DAYS, alarm.days.toIntArray())
            putExtra(EXTRA_DATE, alarm.date)
            putExtra(EXTRA_SOUND_URI, alarm.sound.uri)
            putExtra(EXTRA_SOUND_TITLE, alarm.sound.title)
            putExtra(EXTRA_VIBRATE, alarm.vibrate)
            putExtra(EXTRA_SNOOZE, alarm.snooze)
            putExtra(EXTRA_GENTLE, alarm.gentle)
        }
        return PendingIntent.getBroadcast(
            context,
            requestCode(alarm.id),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun requestCode(id: String): Int = id.hashCode() and 0x7fffffff
}
