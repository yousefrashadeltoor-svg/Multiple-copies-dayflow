package app.dayflow.android.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import app.dayflow.android.DayflowApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Restores native clocks after reboot, app updates, wall-clock or time-zone changes. */
class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED",
            Intent.ACTION_LOCALE_CHANGED -> Unit
            else -> return
        }
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val repository = DayflowApplication.repository(context)
                val state = repository.snapshot()
                AlarmScheduler.sync(context, state.alarms)
                app.dayflow.android.widget.WidgetUpdater.updateAll(context)
            } catch (t: Throwable) {
                Log.e("DayflowSystem", "Unable to restore alarms after ${intent.action}", t)
            } finally {
                pending.finish()
            }
        }
    }
}
