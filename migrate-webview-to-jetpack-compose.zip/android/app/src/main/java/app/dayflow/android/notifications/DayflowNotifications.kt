package app.dayflow.android.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmRingActivity
import app.dayflow.android.alarm.AlarmRingService

object DayflowNotifications {
    const val CHANNEL_ALARMS = "dayflow_alarms"
    const val CHANNEL_REMINDERS = "dayflow_reminders"
    const val CHANNEL_COMPANION = "dayflow_companion"
    const val CHANNEL_DOWNLOADS = "dayflow_downloads"

    const val ID_ALARM = 7001
    const val ID_COMPANION = 7100
    const val ID_DOWNLOAD = 7200

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val alarmChannel = NotificationChannel(
            CHANNEL_ALARMS,
            context.getString(R.string.channel_alarms),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = context.getString(R.string.channel_alarms_desc)
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 400, 220, 400, 900)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setBypassDnd(true)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
        }

        val reminders = NotificationChannel(
            CHANNEL_REMINDERS,
            context.getString(R.string.channel_reminders),
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply {
            description = context.getString(R.string.channel_reminders_desc)
            enableVibration(true)
        }

        val companion = NotificationChannel(
            CHANNEL_COMPANION,
            context.getString(R.string.channel_companion),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = context.getString(R.string.channel_companion_desc)
            setShowBadge(false)
        }

        val downloads = NotificationChannel(
            CHANNEL_DOWNLOADS,
            context.getString(R.string.channel_downloads),
            NotificationManager.IMPORTANCE_LOW,
        ).apply { description = context.getString(R.string.channel_downloads_desc) }

        manager.createNotificationChannels(listOf(alarmChannel, reminders, companion, downloads))
    }

    fun alarmFullScreenIntent(context: Context, alarmId: String, label: String, time: String, soundUri: String?, vibrate: Boolean, snooze: Int): PendingIntent {
        val intent = Intent(context, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(AlarmRingService.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmRingService.EXTRA_LABEL, label)
            putExtra(AlarmRingService.EXTRA_TIME, time)
            putExtra(AlarmRingService.EXTRA_SOUND_URI, soundUri)
            putExtra(AlarmRingService.EXTRA_VIBRATE, vibrate)
            putExtra(AlarmRingService.EXTRA_SNOOZE, snooze)
        }
        return PendingIntent.getActivity(context, alarmId.hashCode() * 31 + 1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun alarmNotification(
        context: Context,
        alarmId: String,
        label: String,
        time: String,
        soundUri: String?,
        vibrate: Boolean,
        snooze: Int,
    ): Notification {
        val stopIntent = Intent(context, AlarmRingService::class.java).apply {
            action = AlarmRingService.ACTION_STOP
            putExtra(AlarmRingService.EXTRA_ALARM_ID, alarmId)
        }
        val snoozeIntent = Intent(context, AlarmRingService::class.java).apply {
            action = AlarmRingService.ACTION_SNOOZE
            putExtra(AlarmRingService.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmRingService.EXTRA_LABEL, label)
            putExtra(AlarmRingService.EXTRA_TIME, time)
            putExtra(AlarmRingService.EXTRA_SOUND_URI, soundUri)
            putExtra(AlarmRingService.EXTRA_VIBRATE, vibrate)
            putExtra(AlarmRingService.EXTRA_SNOOZE, snooze)
        }
        val stop = PendingIntent.getService(context, alarmId.hashCode() * 31 + 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val snoozePi = PendingIntent.getService(context, alarmId.hashCode() * 31 + 3, snoozeIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val fullScreen = alarmFullScreenIntent(context, alarmId, label, time, soundUri, vibrate, snooze)

        return NotificationCompat.Builder(context, CHANNEL_ALARMS)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setContentTitle(if (label.isBlank()) "منبه DAYFLOW" else label)
            .setContentText("$time · اضغط إيقاف لإيقاف الرنين")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .setSilent(true)
            .addAction(R.drawable.ic_stat_dayflow, context.getString(R.string.alarm_snooze), snoozePi)
            .addAction(R.drawable.ic_stat_dayflow, context.getString(R.string.alarm_stop), stop)
            .build()
    }

    fun companionNotification(context: Context): Notification {
        val open = PendingIntent.getActivity(
            context,
            7201,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            context,
            7202,
            Intent(context, app.dayflow.android.overlay.CompanionOverlayService::class.java).setAction(app.dayflow.android.overlay.CompanionOverlayService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(context, CHANNEL_COMPANION)
            .setSmallIcon(R.drawable.ic_stat_dayflow)
            .setContentTitle("رفيق DAYFLOW شغّال")
            .setContentText("ظاهر فوق التطبيقات — اضغط لإدارة الرفيق أو إيقافه")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(open)
            .addAction(R.drawable.ic_stat_dayflow, context.getString(R.string.overlay_stop), stop)
            .build()
    }

    fun showTestNotification(context: Context) {
        runCatching {
            val open = PendingIntent.getActivity(context, 7301, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setSmallIcon(R.drawable.ic_stat_dayflow)
                .setContentTitle("DAYFLOW — إشعار تجريبي")
                .setContentText("الإشعارات وقنوات النظام جاهزة. المنبهات تُستخدم قناة منفصلة عالية الأولوية.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            NotificationManagerCompat.from(context).notify(7401, notification)
        }
    }

    fun showExactAlarmFallback(context: Context) {
        runCatching {
            val open = PendingIntent.getActivity(context, 7402, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setSmallIcon(R.drawable.ic_stat_dayflow)
                .setContentTitle("المنبهات الدقيقة تحتاج إذنك")
                .setContentText("اسمح بـ «المنبهات والتذكيرات» لتعمل المنبهات في وقتها بدقة. التطبيق جدولها مؤقتًا بشكل غير دقيق.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            NotificationManagerCompat.from(context).notify(7402, notification)
        }
    }
}
