package app.dayflow.android.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Plus
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material.icons.rounded.TaskAlt
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.AlarmSound
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.components.DayflowBackground
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.Robot
import app.dayflow.android.ui.screens.AlarmsScreen
import app.dayflow.android.ui.screens.CalendarScreen
import app.dayflow.android.ui.screens.CompanionChatScreen
import app.dayflow.android.ui.screens.DownloadsScreen
import app.dayflow.android.ui.screens.MeScreen
import app.dayflow.android.ui.screens.TodayScreen
import app.dayflow.android.ui.screens.ToolsScreen
import app.dayflow.android.ui.screens.WidgetsScreen
import app.dayflow.android.ui.theme.DayflowColors
import kotlin.math.roundToInt

private data class TabSpec(val id: String, val label: String, val icon: ImageVector)
private val tabs = listOf(
    TabSpec("today", "النهاردة", Icons.Rounded.LightMode),
    TabSpec("calendar", "التقويم", Icons.Rounded.CalendarMonth),
    TabSpec("alarms", "المنبهات", Icons.Rounded.Alarm),
    TabSpec("tools", "أدوات", Icons.Rounded.GridView),
    TabSpec("ai", "الرفيق", Icons.Rounded.AutoAwesome),
    TabSpec("downloads", "التحميل", Icons.Rounded.Download),
    TabSpec("me", "أنا", Icons.Rounded.Person),
)

typealias Navigate = (String, String?) -> Unit

@Composable
fun DayflowApp(
    repository: DayflowRepository,
    initialTab: String = "today",
    initialSub: String? = null,
    initialLink: String? = null,
    onRequestRouteConsumed: () -> Unit = {},
) {
    val state by repository.state.collectAsState(initial = null)
    var tab by remember { mutableStateOf(initialTab) }
    var sub by remember { mutableStateOf(initialSub) }
    var quickOpen by remember { mutableStateOf(false) }
    val current = state

    LaunchedEffect(initialTab, initialSub) {
        tab = initialTab
        sub = initialSub
    }

    val navigate: Navigate = { nextTab, nextSub ->
        tab = nextTab
        sub = nextSub
    }

    DayflowBackground {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
            topBar = {
                if (current != null) AppTopBar(current, navigate)
            },
            bottomBar = { BottomBar(tab) { next -> navigate(next, null) } },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { quickOpen = true },
                    containerColor = DayflowColors.Accent,
                    contentColor = DayflowColors.OnAccent,
                    shape = CircleShape,
                    modifier = Modifier.size(52.dp),
                ) { Icon(Icons.Rounded.Plus, contentDescription = "اعمل جديد", modifier = Modifier.size(24.dp)) }
            },
        ) { inner ->
            if (current == null) {
                Box(Modifier.fillMaxSize().padding(inner), contentAlignment = Alignment.Center) {
                    Text("DAYFLOW", color = DayflowColors.Accent, fontWeight = FontWeight.ExtraBold)
                }
                return@Scaffold
            }
            Box(Modifier.fillMaxSize().padding(inner)) {
                AnimatedContent(targetState = "$tab|${sub.orEmpty()}", transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "screen") { route ->
                    val routeTab = route.substringBefore('|')
                    val routeSub = route.substringAfter('|').ifBlank { null }
                    when (routeTab) {
                        "today" -> TodayScreen(current, repository, navigate)
                        "calendar" -> CalendarScreen(current, repository, navigate)
                        "alarms" -> AlarmsScreen(current, repository, navigate, startNew = routeSub == "new")
                        "tools" -> if (routeSub == "widgets") WidgetsScreen(current, repository, navigate) else ToolsScreen(current, repository, navigate, routeSub)
                        "ai" -> CompanionChatScreen(current, repository)
                        "downloads" -> DownloadsScreen(current, repository, initialLink, onRequestRouteConsumed, navigate)
                        "me" -> MeScreen(current, repository, navigate, routeSub)
                        else -> Unit
                    }
                }
                if (current.companion.enabled && !current.companion.hidden) {
                    FloatingCompanion(current) { navigate("me", "companion") }
                }
            }
        }
    }

    if (quickOpen) {
        QuickCreateSheet(current, repository, settings = { quickOpen = false }, navigate = navigate)
    }
}

@Composable
private fun AppTopBar(state: DayflowState, navigate: Navigate) {
    val city = PrayerCatalog.city(state.prayer.cityId)
    val prayer = remember(state.prayer, state.prayer.cityId) {
        PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    }
    Surface(color = DayflowColors.Bg.copy(alpha = 0.94f), border = androidx.compose.foundation.BorderStroke(0.5.dp, DayflowColors.Line)) {
        Row(
            Modifier.statusBarsPadding().height(52.dp).fillMaxWidth().padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(Modifier.clickable { navigate("today", null) }, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(10.dp)).background(DayflowColors.Accent), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.LightMode, contentDescription = null, tint = Color(0xFFF4E6C3), modifier = Modifier.size(17.dp))
                }
                Spacer(Modifier.width(7.dp))
                Text("DAYFLOW", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = DayflowColors.Text, letterSpacing = 1.2.sp)
                Spacer(Modifier.width(5.dp))
                Text("أصلي", color = DayflowColors.Accent, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clip(CircleShape).background(DayflowColors.Soft).padding(horizontal = 5.dp, vertical = 2.dp))
            }
            Spacer(Modifier.weight(1f))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { navigate("me", "prayer") }.clip(CircleShape).background(DayflowColors.Soft).padding(horizontal = 8.dp, vertical = 5.dp),
            ) {
                Icon(Icons.Rounded.DarkMode, contentDescription = null, tint = DayflowColors.Accent, modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(3.dp))
                Text(prayer.nextText, color = DayflowColors.AccentStrong, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, style = app.dayflow.android.ui.theme.DayflowText.numeric)
            }
            Spacer(Modifier.width(2.dp))
            Box(Modifier.clip(CircleShape).clickable { navigate("downloads", null) }.padding(8.dp)) {
                Icon(Icons.Rounded.Download, contentDescription = "التحميل", tint = DayflowColors.Text, modifier = Modifier.size(18.dp))
            }
            Box(Modifier.clip(CircleShape).clickable { navigate("me", "notifications") }.padding(8.dp)) {
                Icon(Icons.Rounded.Notifications, contentDescription = "الإشعارات", tint = DayflowColors.Text, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun BottomBar(current: String, onSelect: (String) -> Unit) {
    Surface(color = DayflowColors.Surface.copy(alpha = 0.97f), border = androidx.compose.foundation.BorderStroke(0.5.dp, DayflowColors.Line)) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(66.dp)) {
            tabs.forEach { item ->
                val active = item.id == current
                Column(
                    Modifier.weight(1f).clickable { onSelect(item.id) }.padding(vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.clip(CircleShape).background(if (active) DayflowColors.Soft else Color.Transparent).padding(horizontal = 12.dp, vertical = 3.dp),
                    ) { Icon(item.icon, contentDescription = item.label, tint = if (active) DayflowColors.Accent else DayflowColors.Muted, modifier = Modifier.size(18.dp)) }
                    Text(item.label, color = if (active) DayflowColors.Accent else DayflowColors.Muted, fontSize = 8.7.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun FloatingCompanion(state: DayflowState, onClick: () -> Unit) {
    val family = if (state.companion.outfit == "gold") "ramadan"
    else if (state.companion.outfit == "snow") "winter"
    else if (state.companion.outfit == "national") "national"
    else CalendarSeasons.current()
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val size = 64.dp
    val px = with(density) { size.toPx() }
    val maxX = with(density) { (configuration.screenWidthDp.dp.toPx() - px - 20.dp.toPx()) }
    val maxY = with(density) { (configuration.screenHeightDp.dp.toPx() * 0.44f) }
    var x by remember { mutableStateOf(maxX) }
    var y by remember { mutableStateOf(maxY) }
    Box(
        Modifier
            .padding(start = 8.dp)
            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    x = (x + drag.x).coerceIn(0f, maxX)
                    y = (y + drag.y).coerceIn(-maxY, maxY)
                }
            }
            .clickable { onClick() },
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Robot(size = size, family = family, mood = state.companion.emotion, opacity = state.companion.opacity, animate = !state.appearance.reduceMotion)
            Text("DAYFLOW", color = DayflowColors.Accent, fontSize = 7.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.clip(CircleShape).background(DayflowColors.Surface.copy(alpha = 0.9f)).padding(horizontal = 5.dp, vertical = 1.dp))
        }
    }
}

private object CalendarSeasons {
    fun current(): String = app.dayflow.android.domain.CalendarMath.seasonFor()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickCreateSheet(
    state: DayflowState?,
    repository: DayflowRepository,
    settings: () -> Unit,
    navigate: Navigate,
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var mode by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("18:00") }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(onDismissRequest = settings, sheetState = sheetState, containerColor = DayflowColors.Surface) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 28.dp)) {
            Text(if (mode == null) "اعمل جديد" else when (mode) { "task" -> "مهمة جديدة"; "note" -> "ملاحظة جديدة"; else -> "تذكير جديد" },
                color = DayflowColors.Text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (mode == null) "كل الإضافات تُحفظ على جهازك" else "صيغة الوقت ١٢ ساعة دائمًا",
                color = DayflowColors.Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))

            if (mode == null) {
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickTile("منبه", Icons.Rounded.Alarm) { settings(); navigate("alarms", "new") }
                    QuickTile("مهمة", Icons.Rounded.TaskAlt) { mode = "task" }
                    QuickTile("عادة", Icons.Rounded.LightMode) { settings(); navigate("tools", "habits") }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickTile("ملاحظة", Icons.Rounded.StickyNote2) { mode = "note" }
                    QuickTile("تذكير", Icons.Rounded.Notifications) { mode = "reminder" }
                    QuickTile("ودجت", Icons.Rounded.Widgets) { settings(); navigate("tools", "widgets") }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DfChip("لصق رابط") { settings(); navigate("downloads", null) }
                    DfChip("مواقيت الصلاة") { settings(); navigate("me", "prayer") }
                    DfChip("المزيد") { settings(); navigate("tools", null) }
                }
            } else {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(DayflowColors.Surface2)
                        .border(1.dp, DayflowColors.LineStrong, RoundedCornerShape(13.dp)).padding(12.dp),
                ) {
                    BasicTextField(
                        value = text, onValueChange = { text = it },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = DayflowColors.Text),
                        decorationBox = { if (text.isBlank()) Text("اكتب التفاصيل…", color = DayflowColors.Muted, fontSize = 12.sp); it() },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (mode == "reminder") {
                    Spacer(Modifier.height(10.dp))
                    Text("وقت التذكير — ١٢ ساعة", color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        DfChip("بعد ساعة") {
                            val next = java.time.ZonedDateTime.now().plusHours(1)
                            time = "%02d:%02d".format(next.hour, next.minute)
                        }
                        DfChip("٦ مساءً") { time = "18:00" }
                        DfChip("٨ مساءً") { time = "20:00" }
                    }
                    Text("الوقت المختار: ${DayflowTime.clock12(runCatching { DayflowTime.toLocalTime(time)?.toString()?.take(5) ?: "07:00" }.getOrDefault("07:00"))}",
                        color = DayflowColors.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                }
                if (error != null) Text(error!!, color = DayflowColors.Danger, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { mode = null; error = null }) { Text("رجوع", color = DayflowColors.Muted) }
                    Surface(
                        color = DayflowColors.Accent, shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).clickable {
                            if (text.isBlank()) { error = "اكتب التفاصيل أولًا."; return@clickable }
                            when (mode) {
                                "task" -> repository.addTask(text.trim(), repository.todayKey(state ?: DayflowState()))
                                "note" -> repository.addNote(text.trim())
                                "reminder" -> {
                                    val parsed = DayflowTime.toLocalTime(time)
                                    if (parsed == null) { error = "الوقت غير صحيح. استخدم مثل 18:30"; return@clickable }
                                    val alarm = Alarm(id = repository.newAlarmId(), time = time, label = text.trim(), enabled = true, sound = AlarmSound())
                                    repository.upsertAlarm(alarm)
                                    AlarmScheduler.schedule(context, alarm)
                                }
                            }
                            settings()
                        },
                    ) {
                        Row(Modifier.padding(vertical = 13.dp), horizontalArrangement = Arrangement.Center) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = DayflowColors.OnAccent, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("حفظ", color = DayflowColors.OnAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.QuickTile(label: String, icon: ImageVector, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, DayflowColors.Line, RoundedCornerShape(16.dp))
            .clickable { onClick() }.padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(DayflowColors.Soft), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = DayflowColors.Accent, modifier = Modifier.size(18.dp))
        }
        Text(label, color = DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
    }
}

@Suppress("unused")
private fun requestedNotificationPermission(context: android.content.Context): Boolean =
    Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
