package app.dayflow.android.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Droplet
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Moon
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Plus
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import app.dayflow.android.R
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.HeaderCrown
import app.dayflow.android.ui.components.PrayerStrip
import app.dayflow.android.ui.components.ProgressBar
import app.dayflow.android.ui.components.Robot
import app.dayflow.android.ui.components.SeasonOrnament
import app.dayflow.android.ui.components.SectionTitle
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowText
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    val city = repository.activeCity(state)
    val zone = remember(city.zone) { runCatching { ZoneId.of(city.zone) }.getOrDefault(ZoneId.systemDefault()) }
    var now by remember { mutableStateOf(ZonedDateTime.now(zone)) }
    var quickTask by remember { mutableStateOf("") }
    var exactAllowed by remember { mutableStateOf(AlarmScheduler.canScheduleExact(context)) }
    var notificationAllowed by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> notificationAllowed = granted }
    LaunchedEffect(zone) {
        while (true) { now = ZonedDateTime.now(zone); delay(20_000) }
    }
    val prayer = remember(city.id, state.prayer.methodId, state.prayer.asrFactor, now.minute, now.hour, now.dayOfMonth) {
        PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor, now)
    }
    val nextAlarm = DayflowTime.nextAlarm(state.alarms, now)
    val family = DayflowSeasons.forId(CalendarMath.seasonFor(now.toLocalDate()))
    val today = repository.todayKey(state)
    val tasks = state.tasks.filter { it.date == today }
    val done = tasks.count { it.done }
    val water = state.water[today] ?: 0
    val habitsDone = state.habits.count { today in it.log }
    val hijri = CalendarMath.hijriLabel(now.toLocalDate())
    val coptic = CalendarMath.copticLabel(now.toLocalDate())
    val occasion = CalendarMath.upcomingOccasions(now.toLocalDate(), 1).firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().height(224.dp).clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(family.c2, family.c1))),
            ) {
                Image(
                    painter = painterResource(R.drawable.hero_dawn),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alpha = 0.38f,
                    modifier = Modifier.fillMaxSize(),
                )
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(family.c2.copy(alpha = 0.32f), family.c1.copy(alpha = 0.82f)))))
                HeaderCrown(family.id, Modifier.align(Alignment.TopCenter))
                Column(Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 48.dp)) {
                    Text(DayflowTime.greeting(), color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(DayflowTime.fullDate(now.toLocalDate()), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 31.sp)
                    Text("$hijri${if (coptic.isBlank()) "" else " · $coptic"}", color = Color.White.copy(alpha = 0.82f), fontSize = 10.5.sp, modifier = Modifier.padding(top = 3.dp))
                    Spacer(Modifier.height(9.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        TagWhite(family.ar)
                        if (occasion != null) TagWhite(occasion.ar)
                        Row(Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.16f)).padding(horizontal = 7.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.LocationOn, contentDescription = null, tint = Color.White, modifier = Modifier.size(9.dp))
                            Spacer(Modifier.width(2.dp))
                            Text(city.ar, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                SeasonOrnament(family.id, 100.dp, rotation = -12f, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 4.dp), alpha = 0.92f)
                Box(Modifier.align(Alignment.TopEnd).padding(12.dp).size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f))) {
                    Icon(Icons.Rounded.Settings, contentDescription = "الإعدادات", tint = Color.White, modifier = Modifier.align(Alignment.Center).size(16.dp))
                }
            }
        }

        if (!exactAllowed || !notificationAllowed) {
            item {
                NoticeCard(
                    title = if (!exactAllowed) "المنبهات الدقيقة تحتاج إذنك" else "الإشعارات غير مفعّلة",
                    body = if (!exactAllowed) "اضغط للسماح بـ «المنبهات والتذكيرات» حتى يرن منبهك في وقته بدقة. التطبيق لا يدّعي دقة غير حقيقية." else "اسمح بالإشعارات لتصلك المنبهات والتذكيرات على الشاشة. المنبه يعمل حتى لو التطبيق مغلق.",
                    tone = "warn",
                    icon = Icons.Rounded.Notifications,
                )
            }
        }

        item {
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 12.dp, onClick = { navigate("me", "prayer") }) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🕌", fontSize = 14.sp)
                            Spacer(Modifier.width(5.dp))
                            Text("الصلاة · ${city.ar}", fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold, color = DayflowColors.Text)
                        }
                        Text("القادمة: ${prayer.nextLabel} ${prayer.nextText}", fontSize = 10.sp, color = DayflowColors.Muted, fontWeight = FontWeight.Bold, style = DayflowText.numeric)
                    }
                    Spacer(Modifier.height(7.dp))
                    PrayerStrip(prayer)
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(prayer.method.ar, color = DayflowColors.Muted, fontSize = 8.5.sp)
                        Text("فاضل ${DayflowTime.duration(prayer.next?.let { java.time.Duration.between(now, it.at).toMinutes() } ?: 0L)}", color = DayflowColors.Accent, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DfCard(Modifier.weight(1f), padding = 13.dp, onClick = { navigate("alarms", null) }) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Alarm, contentDescription = null, tint = DayflowColors.Muted, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(4.dp)); Text("المنبه التالي", color = DayflowColors.Muted, fontSize = 9.5.sp)
                        }
                        Text(nextAlarm?.clock ?: "—", color = DayflowColors.Text, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric, maxLines = 1, modifier = Modifier.padding(top = 4.dp))
                        Text(nextAlarm?.let { "${it.alarm.label.ifBlank { "منبه" }} · ${DayflowTime.countdown(it.at, now)}" } ?: "أضف منبهًا حقيقيًا", color = DayflowColors.Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                DfCard(Modifier.weight(1f), padding = 13.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.Center) {
                            ProgressBar(1f, DayflowColors.Line, 8.dp)
                            ProgressBar(((now.hour * 60 + now.minute) / 1440f), DayflowColors.Gold, 8.dp)
                        }
                        Spacer(Modifier.width(9.dp))
                        Column {
                            Text("اليوم", color = DayflowColors.Muted, fontSize = 9.5.sp)
                            Text("${DayflowTime.digits(done)}/${DayflowTime.digits(tasks.size)}", color = DayflowColors.Text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            Text("مهام", color = DayflowColors.Muted, fontSize = 9.sp)
                        }
                    }
                }
            }
        }

        item {
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("tools", "widgets") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Widgets, background = DayflowColors.SoftGold, tint = DayflowColors.GoldText)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ودجت اليوم", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        Text("${app.dayflow.android.domain.NativeWidgetCatalog.byId(state.widgets.designId).ar} · ${state.widgets.form.replace("x", "×")}", color = DayflowColors.Muted, fontSize = 9.5.sp)
                    }
                    Text("تغيير", color = DayflowColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("downloads", null) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Download)
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("التحميل", fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold)
                        Text("الصق أو شارك أي رابط — معاينة حقيقية وتحميل أصلي بدون CORS", color = DayflowColors.Muted, fontSize = 9.5.sp)
                    }
                    Icon(Icons.Rounded.ChevronLeft, contentDescription = null, tint = DayflowColors.Muted, modifier = Modifier.size(15.dp))
                }
            }
        }

        item {
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    SectionTitle("مهام اليوم") { Text("مهام", color = DayflowColors.Muted, fontSize = 9.sp) }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(DayflowColors.Surface2).padding(horizontal = 11.dp, vertical = 10.dp)) {
                            BasicTextField(
                                value = quickTask, onValueChange = { quickTask = it },
                                textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                                decorationBox = { if (quickTask.isBlank()) Text("ضيف مهمة للنهاردة…", color = DayflowColors.Muted, fontSize = 11.sp); it() },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(DayflowColors.Accent).clickable {
                            if (quickTask.isNotBlank()) { repository.addTask(quickTask.trim(), today); quickTask = "" }
                        }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Plus, contentDescription = "إضافة", tint = DayflowColors.OnAccent, modifier = Modifier.size(18.dp)) }
                    }
                    Spacer(Modifier.height(3.dp))
                    if (tasks.isEmpty()) {
                        Text("يوم فاضي وهادي — لسه مفيش حاجة متخططة.", color = DayflowColors.Muted, fontSize = 10.5.sp, modifier = Modifier.padding(vertical = 10.dp))
                    }
                    tasks.take(6).forEach { task ->
                        Row(Modifier.fillMaxWidth().clickable { repository.toggleTask(task.id) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(if (task.done) DayflowColors.Accent else Color.Transparent)
                                .androidxBorder(), contentAlignment = Alignment.Center) {
                                if (task.done) Icon(Icons.Rounded.Check, contentDescription = null, tint = DayflowColors.OnAccent, modifier = Modifier.size(12.dp))
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(task.title, color = if (task.done) DayflowColors.Muted else DayflowColors.Text, fontSize = 11.5.sp,
                                textDecoration = if (task.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            if (task.urgent && !task.done) Box(Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFBF5A45)))
                        }
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DfCard(Modifier.weight(1f), padding = 13.dp) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Droplet, contentDescription = null, tint = DayflowColors.Muted, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(4.dp)); Text("الماء", color = DayflowColors.Muted, fontSize = 9.5.sp)
                        }
                        Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 3.dp)) {
                            Text((water / 1000f).toString().take(4).let { DayflowTime.digits(it) }, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                            Text(" / ${state.waterGoal / 1000} لتر", color = DayflowColors.Muted, fontSize = 9.sp)
                        }
                        Spacer(Modifier.height(5.dp))
                        ProgressBar((water.toFloat() / state.waterGoal).coerceIn(0f, 1f), Color(0xFF4A93B8), 5.dp)
                        Box(Modifier.fillMaxWidth().padding(top = 7.dp).clip(RoundedCornerShape(9.dp)).background(DayflowColors.Soft).clickable { repository.addWater(250) }.padding(vertical = 5.dp), contentAlignment = Alignment.Center) {
                            Text("+٢٥٠ مل", color = DayflowColors.AccentStrong, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                DfCard(Modifier.weight(1f), padding = 13.dp, onClick = { navigate("tools", "habits") }) {
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("العادات", color = DayflowColors.Muted, fontSize = 9.5.sp)
                            SmallTag("${DayflowTime.digits(habitsDone)}/${DayflowTime.digits(state.habits.size)}", "gold")
                        }
                        Spacer(Modifier.height(5.dp))
                        state.habits.take(4).forEach { habit ->
                            Row(Modifier.fillMaxWidth().clickable { repository.toggleHabit(habit.id) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(14.dp).clip(CircleShape).background(if (today in habit.log) DayflowColors.Accent else Color.Transparent).androidxBorder(CircleShape), contentAlignment = Alignment.Center) {
                                    if (today in habit.log) Icon(Icons.Rounded.Check, contentDescription = null, tint = DayflowColors.OnAccent, modifier = Modifier.size(9.dp))
                                }
                                Spacer(Modifier.width(5.dp))
                                Text("${habit.emoji} ${habit.ar}", color = DayflowColors.Text, fontSize = 9.7.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }

        item {
            DfCard(modifier = Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("me", "companion") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Robot(size = 46.dp, family = family.id, mood = state.companion.emotion, animate = !state.appearance.reduceMotion)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("من رفيقك", color = DayflowColors.Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("فاضل ${DayflowTime.duration(prayer.next?.let { java.time.Duration.between(now, it.at).toMinutes() } ?: 0L)} على ${prayer.nextLabel}. خد نفس عميق واستعد.", color = DayflowColors.Text, fontSize = 10.5.sp, lineHeight = 16.sp)
                    }
                    Text("الرفيق", color = DayflowColors.Accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun TagWhite(text: String) {
    Text(
        text,
        color = Color.White,
        fontSize = 9.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

private fun Modifier.androidxBorder(shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(6.dp)): Modifier =
    this.border(1.5.dp, DayflowColors.Accent, shape)
