package app.dayflow.android.alarm

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.notifications.DayflowNotifications

/**
 * A real ringing service. Keeps a wake lock, loops the user's selected sound with
 * USAGE_ALARM, vibrates natively, and exposes stop/snooze from the lock screen.
 */
class AlarmRingService : Service() {
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentId: String = ""
    private var currentLabel: String = ""
    private var currentTime: String = ""
    private var currentSound: String? = null
    private var currentVibrate: Boolean = true
    private var currentSnooze: Int = 10

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DayflowNotifications.createChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY
        when (intent.action) {
            ACTION_STOP -> { stopRinging(); return START_NOT_STICKY }
            ACTION_SNOOZE -> {
                AlarmScheduler.snooze(
                    context = this,
                    label = currentLabel.ifBlank { intent.getStringExtra(EXTRA_LABEL).orEmpty() },
                    minutes = currentSnooze,
                    soundUri = currentSound,
                    vibrate = currentVibrate,
                    snooze = currentSnooze,
                )
                stopRinging()
                return START_NOT_STICKY
            }
            else -> {
                currentId = intent.getStringExtra(EXTRA_ALARM_ID) ?: "alarm"
                currentLabel = intent.getStringExtra(EXTRA_LABEL).orEmpty()
                currentTime = intent.getStringExtra(EXTRA_TIME) ?: "07:00"
                currentSound = intent.getStringExtra(EXTRA_SOUND_URI)
                currentVibrate = intent.getBooleanExtra(EXTRA_VIBRATE, true)
                currentSnooze = intent.getIntExtra(EXTRA_SNOOZE, 10).coerceIn(1, 60)
                val gentle = intent.getBooleanExtra(EXTRA_GENTLE, true)
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(DayflowNotifications.ID_ALARM, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
                } else {
                    startForeground(DayflowNotifications.ID_ALARM, notification)
                }
                acquireWakeLock()
                playSound(currentSound, gentle)
                startVibration()
                if (intent.getBooleanExtra(EXTRA_PREVIEW, false)) {
                    handler.postDelayed({ stopRinging() }, 12_000L)
                }
                return START_NOT_STICKY
            }
        }
    }

    private fun buildNotification(): Notification = DayflowNotifications.alarmNotification(
        this,
        currentId,
        currentLabel,
        DayflowTime.clock12(currentTime),
        currentSound,
        currentVibrate,
        currentSnooze,
    )

    private fun playSound(uriString: String?, gentle: Boolean) {
        player?.release()
        val candidates = listOfNotNull(
            uriString?.let { runCatching { Uri.parse(it) }.getOrNull() },
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
        )
        for (uri in candidates) {
            val media = MediaPlayer()
            media.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val prepared = runCatching {
                media.setDataSource(this, uri)
                media.isLooping = true
                media.prepare()
            }.isSuccess
            if (!prepared) {
                runCatching { media.release() }
                continue
            }
            try {
                media.start()
                player = media
                if (gentle) {
                    media.setVolume(0.12f, 0.12f)
                    listOf(0.25f, 0.4f, 0.6f, 0.8f, 1f).forEachIndexed { index, volume ->
                        handler.postDelayed({
                            runCatching { player?.setVolume(volume, volume) }
                        }, 2500L * (index + 1))
                    }
                }
                return
            } catch (t: Throwable) {
                Log.e("DayflowAlarm", "Unable to start sound", t)
                runCatching { media.release() }
            }
        }
    }

    private fun startVibration() {
        if (!currentVibrate) return
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        }
        val pattern = longArrayOf(0, 600, 300, 600, 1200)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 2))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 2)
            }
        }
    }

    private fun acquireWakeLock() {
        val power = getSystemService(POWER_SERVICE) as? PowerManager ?: return
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DAYFLOW:AlarmRing").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L)
        }
    }

    private fun stopRinging() {
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { vibrator?.cancel() }
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.release() }
        player = null
        runCatching { vibrator?.cancel() }
        runCatching { if (wakeLock?.isHeld == true) wakeLock?.release() }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "app.dayflow.android.ALARM_START"
        const val ACTION_STOP = "app.dayflow.android.ALARM_STOP"
        const val ACTION_SNOOZE = "app.dayflow.android.ALARM_SNOOZE"
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_LABEL = "alarm_label"
        const val EXTRA_TIME = "alarm_time"
        const val EXTRA_SOUND_URI = "alarm_sound_uri"
        const val EXTRA_VIBRATE = "alarm_vibrate"
        const val EXTRA_SNOOZE = "alarm_snooze"
        const val EXTRA_GENTLE = "alarm_gentle"
        const val EXTRA_PREVIEW = "alarm_preview"
    }
}
