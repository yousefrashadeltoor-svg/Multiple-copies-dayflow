package app.dayflow.android.overlay

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat
import app.dayflow.android.DayflowApplication
import app.dayflow.android.MainActivity
import app.dayflow.android.data.CompanionPrefs
import app.dayflow.android.notifications.DayflowNotifications
import app.dayflow.android.ui.components.RobotRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Real system-wide companion overlay. It uses SYSTEM_ALERT_WINDOW and a
 * special-use foreground service, renders with the same RobotRenderer as the
 * Compose UI, supports drag/tap, and stops immediately from its notification.
 */
class CompanionOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var robotView: RobotOverlayView? = null
    private var params: WindowManager.LayoutParams? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collectJob: Job? = null
    private var lastSize = 1f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        DayflowNotifications.createChannels(this)
        startForeground(DayflowNotifications.ID_COMPANION, DayflowNotifications.companionNotification(this))
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showRobot()
        observeSettings()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun observeSettings() {
        collectJob?.cancel()
        collectJob = scope.launch {
            DayflowApplication.repository(this@CompanionOverlayService).state.collectLatest { state ->
                val prefs = state.companion
                if (!prefs.enabled || prefs.hidden) {
                    stopSelf()
                    return@collectLatest
                }
                robotView?.apply {
                    family = if (prefs.outfit == "gold") "ramadan"
                    else if (prefs.outfit == "snow") "winter"
                    else if (prefs.outfit == "national") "national"
                    else app.dayflow.android.domain.CalendarMath.seasonFor()
                    mood = prefs.emotion
                    opacity = prefs.opacity
                    invalidate()
                }
                if (prefs.size != lastSize) {
                    lastSize = prefs.size
                    updateSize(prefs)
                }
            }
        }
    }

    private fun showRobot() {
        val prefs: CompanionPrefs = CompanionPrefs()
        lastSize = prefs.size
        val view = RobotOverlayView(this).apply {
            family = app.dayflow.android.domain.CalendarMath.seasonFor()
            mood = prefs.emotion
            opacity = prefs.opacity
            onTap = { openApp("me", "companion") }
            onLongPress = { openApp("me", "companion") }
            onDrag = { dx, dy -> moveBy(this, dx, dy) }
        }
        robotView = view
        val width = dp(92f * prefs.size.coerceIn(0.6f, 1.4f))
        val height = (width * 1.32f).toInt()
        val layout = WindowManager.LayoutParams(
            width,
            height,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth() - width - dp(14f)
            y = (screenHeight() * 0.62f).toInt()
        }
        params = layout
        runCatching { windowManager.addView(view, layout) }
            .onFailure { Log.e("DayflowOverlay", "Unable to add overlay", it); stopSelf() }
    }

    private fun moveBy(view: View, dx: Float, dy: Float) {
        val layout = params ?: return
        layout.x = (layout.x + dx.toInt()).coerceIn(-24, screenWidth() - layout.width + 24)
        layout.y = (layout.y + dy.toInt()).coerceIn(24, screenHeight() - layout.height - 24)
        runCatching { windowManager.updateViewLayout(view, layout) }
    }

    private fun updateSize(prefs: CompanionPrefs) {
        val view = robotView ?: return
        val layout = params ?: return
        layout.width = dp(92f * prefs.size.coerceIn(0.6f, 1.4f))
        layout.height = (layout.width * 1.32f).toInt()
        layout.x = layout.x.coerceAtMost(screenWidth() - layout.width)
        runCatching { windowManager.updateViewLayout(view, layout) }
    }

    private fun openApp(tab: String, sub: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_OPEN_TAB, tab)
            putExtra(MainActivity.EXTRA_OPEN_SUB, sub)
        }
        runCatching { startActivity(intent) }
            .onFailure { Log.e("DayflowOverlay", "Overlay could not open app", it) }
    }

    private fun screenWidth() = resources.displayMetrics.widthPixels
    private fun screenHeight() = resources.displayMetrics.heightPixels
    private fun dp(value: Float) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        collectJob?.cancel()
        scope.cancel()
        robotView?.let { runCatching { windowManager.removeView(it) } }
        robotView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "app.dayflow.android.OVERLAY_STOP"

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            ContextCompat.startForegroundService(context, Intent(context, CompanionOverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, CompanionOverlayService::class.java))
        }
    }
}

/** Custom Android view. Uses the exact same renderer as the in-app Compose robot. */
@SuppressLint("ViewConstructor")
class RobotOverlayView(context: Context) : View(context) {
    var family: String = "friday"
    var mood: String = "idle"
    var opacity: Float = 1f
    var onTap: (() -> Unit)? = null
    var onLongPress: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null

    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private val handler = Handler(Looper.getMainLooper())
    private val longPress = Runnable { runCatching { onLongPress?.invoke() } }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        RobotRenderer.draw(canvas, width.toFloat(), height.toFloat(), family, mood, opacity)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.rawX
                lastY = event.rawY
                moved = false
                handler.postDelayed(longPress, 650)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastX
                val dy = event.rawY - lastY
                if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 3f) {
                    moved = true
                    handler.removeCallbacks(longPress)
                }
                lastX = event.rawX
                lastY = event.rawY
                onDrag?.invoke(dx, dy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPress)
                if (!moved) performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPress); return true }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        onTap?.invoke()
        return true
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        super.onDetachedFromWindow()
    }
}
