package app.dayflow.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Book
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.Focus
import androidx.compose.material.icons.rounded.Heart
import androidx.compose.material.icons.rounded.Moon
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Plus
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StickyNote2
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.alarm.AlarmScheduler
import app.dayflow.android.data.Alarm
import app.dayflow.android.data.AlarmSound
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.data.DayflowState
import app.dayflow.android.domain.CalendarMath
import app.dayflow.android.domain.DayflowTime
import app.dayflow.android.domain.PrayerCalculator
import app.dayflow.android.domain.PrayerCatalog
import app.dayflow.android.ui.Navigate
import app.dayflow.android.ui.components.DfCard
import app.dayflow.android.ui.components.DfChip
import app.dayflow.android.ui.components.EmptyState
import app.dayflow.android.ui.components.IconBadge
import app.dayflow.android.ui.components.IconRow
import app.dayflow.android.ui.components.NoticeCard
import app.dayflow.android.ui.components.PrayerStrip
import app.dayflow.android.ui.components.ProgressBar
import app.dayflow.android.ui.components.Robot
import app.dayflow.android.ui.components.ScreenHeader
import app.dayflow.android.ui.components.SectionTitle
import app.dayflow.android.ui.components.SmallTag
import app.dayflow.android.ui.theme.DayflowColors
import app.dayflow.android.ui.theme.DayflowSeasons
import app.dayflow.android.ui.theme.DayflowText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var newTask by remember { mutableStateOf("") }
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    val family = DayflowSeasons.forId(CalendarMath.seasonFor(LocalDate.now()))
    val occasions = CalendarMath.upcomingOccasions(LocalDate.now(), 5)
    val key = DayflowTime.dateKey(selected)
    val tasks = state.tasks.filter { it.date == key }
    val firstOffset = month.atDay(1).dayOfWeek.value % 7
    val cells = List(firstOffset) { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    val weeks = cells.chunked(7)
    val locale = Locale.forLanguageTag("ar-EG-u-nu-arab")

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ScreenHeader("التقويم", "CALENDAR · ثلاث تقاويم", DayflowTime.fullDate(), action = { SmallTag(family.ar, "gold") }) }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.ChevronRight, "السابق", tint = DayflowColors.Muted, modifier = Modifier.clip(CircleShape).clickable { month = month.minusMonths(1) }.padding(5.dp).size(18.dp))
                        Text("${month.month.getDisplayName(TextStyle.FULL, locale)} ${DayflowTime.digits(month.year)}", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                        Icon(Icons.Rounded.ChevronLeft, "التالي", tint = DayflowColors.Muted, modifier = Modifier.clip(CircleShape).clickable { month = month.plusMonths(1) }.padding(5.dp).size(18.dp))
                    }
                    Spacer(Modifier.height(7.dp))
                    Row(Modifier.fillMaxWidth()) { listOf("أحد", "اتنين", "تلات", "أربع", "خميس", "جمعة", "سبت").forEach { day -> Text(day, color = DayflowColors.Muted, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
                    Spacer(Modifier.height(4.dp))
                    weeks.forEach { week ->
                        Row(Modifier.fillMaxWidth()) {
                            week.forEach { date ->
                                if (date == null) { Spacer(Modifier.weight(1f)) } else {
                                    val isToday = date == LocalDate.now()
                                    val isSelected = date == selected
                                    Box(
                                        Modifier.weight(1f).padding(1.dp).clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) DayflowColors.Accent else if (isToday) DayflowColors.Soft else Color.Transparent)
                                            .clickable { selected = date }.padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(DayflowTime.digits(date.dayOfMonth), color = if (isSelected) DayflowColors.OnAccent else DayflowColors.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold, style = DayflowText.numeric)
                                            if (state.tasks.any { it.date == DayflowTime.dateKey(date) }) Box(Modifier.padding(top = 1.dp).size(3.dp).clip(CircleShape).background(if (isSelected) Color.White else DayflowColors.Gold))
                                        }
                                    }
                                }
                            }
                            repeat(7 - week.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        CalPill(DayflowTime.digits(selected.dayOfMonth) + " " + selected.month.getDisplayName(TextStyle.SHORT, locale), "ميلادي")
                        CalPill(CalendarMath.hijriLabel(selected).replace(" هـ", ""), "هجري")
                        CalPill(CalendarMath.copticLabel(selected), "قبطي")
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    SectionTitle("مهام ${DayflowTime.shortDate(selected)}") { SmallTag(DayflowTime.digits(tasks.size)) }
                    Spacer(Modifier.height(3.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = newTask, onValueChange = { newTask = it },
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                            decorationBox = { if (newTask.isBlank()) Text("أضف مهمة لهذا اليوم…", color = DayflowColors.Muted, fontSize = 10.5.sp); it() },
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(DayflowColors.Surface2).padding(9.dp),
                        )
                        Spacer(Modifier.width(5.dp))
                        Box(Modifier.size(33.dp).clip(RoundedCornerShape(10.dp)).background(DayflowColors.Accent).clickable { if (newTask.isNotBlank()) { repository.addTask(newTask.trim(), key); newTask = "" } }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.Plus, "إضافة", tint = DayflowColors.OnAccent, modifier = Modifier.size(16.dp))
                        }
                    }
                    if (tasks.isEmpty()) Text("مفيش مهام في اليوم ده.", color = DayflowColors.Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
                    tasks.forEach { task ->
                        Row(Modifier.fillMaxWidth().clickable { repository.toggleTask(task.id) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(18.dp).clip(RoundedCornerShape(5.dp)).background(if (task.done) DayflowColors.Accent else Color.Transparent).border(1.5.dp, DayflowColors.Accent, RoundedCornerShape(5.dp)), contentAlignment = Alignment.Center) {
                                if (task.done) Icon(Icons.Rounded.Check, null, tint = DayflowColors.OnAccent, modifier = Modifier.size(11.dp))
                            }
                            Spacer(Modifier.width(7.dp))
                            Text(task.title, color = if (task.done) DayflowColors.Muted else DayflowColors.Text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    SectionTitle("المناسبات القادمة") { Icon(Icons.Rounded.Star, null, tint = DayflowColors.Gold, modifier = Modifier.size(15.dp)) }
                    Spacer(Modifier.height(4.dp))
                    occasions.forEach { occ ->
                        val days = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), occ.date).coerceAtLeast(0)
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconBadge(Icons.Rounded.Star, background = DayflowColors.SoftGold, tint = DayflowColors.GoldText, size = 30.dp)
                            Spacer(Modifier.width(7.dp))
                            Column(Modifier.weight(1f)) {
                                Text(occ.ar, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(DayflowTime.fullDate(occ.date), color = DayflowColors.Muted, fontSize = 9.sp)
                            }
                            SmallTag(if (days == 0L) "النهاردة" else "بعد ${DayflowTime.digits(days)} يوم", if (days <= 7) "gold" else "soft")
                        }
                    }
                }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 14.dp) {
                Column {
                    SectionTitle("مواقيت الصلاة") { Text(city.ar, color = DayflowColors.Muted, fontSize = 9.sp) }
                    Spacer(Modifier.height(6.dp))
                    PrayerStrip(prayer)
                    Text("${prayer.method.noteAr} · ${prayer.city.zone} · التوقيت الصيفي تلقائي", color = DayflowColors.Muted, fontSize = 8.5.sp, modifier = Modifier.padding(top = 5.dp))
                    Text("عرض المواقيت كاملة", color = DayflowColors.Accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp).clickable { navigate("me", "prayer") })
                }
            }
        }
    }
}

@Composable
private fun CalPill(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value.ifBlank { "—" }, color = DayflowColors.Text, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = DayflowColors.Muted, fontSize = 8.sp)
    }
}

@Composable
fun ToolsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate, sub: String?) {
    when (sub) {
        "habits" -> HabitsScreen(state, repository, navigate)
        "notes" -> NotesScreen(state, repository, navigate)
        "focus" -> FocusScreen(state, repository, navigate)
        else -> ToolsHome(state, repository, navigate)
    }
}

@Composable
private fun ToolsHome(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val today = repository.todayKey(state)
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ScreenHeader("أدوات", "TOOLS", "${DayflowTime.fullDate()} · ${CalendarMath.hijriLabel()}") }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("me", "prayer") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.Moon)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("الصلاة القادمة · ${city.ar}", color = DayflowColors.Muted, fontSize = 9.sp)
                        Text("${prayer.nextLabel} · ${prayer.nextText}", color = DayflowColors.Text, fontSize = 13.5.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric)
                    }
                    Text("المواقيت", color = DayflowColors.Accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolTile("الودجتس", Icons.Rounded.Widgets, gold = true) { navigate("tools", "widgets") }
                ToolTile("التركيز", Icons.Rounded.Focus) { navigate("tools", "focus") }
                ToolTile("العادات", Icons.Rounded.Heart, gold = true) { navigate("tools", "habits") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolTile("الملاحظات", Icons.Rounded.StickyNote2) { navigate("tools", "notes") }
                ToolTile("المنبهات", Icons.Rounded.Alarm, gold = true) { navigate("alarms", null) }
                ToolTile("التحميل", Icons.Rounded.Download) { navigate("downloads", null) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolTile("الرفيق الذكي", Icons.Rounded.AutoAwesome) { navigate("ai", null) }
                ToolTile("مركز الجودة", Icons.Rounded.Shield, gold = true) { navigate("me", "report") }
                ToolTile("الإعدادات", Icons.Rounded.Storage) { navigate("me", "settings") }
            }
        }
        item {
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp, onClick = { navigate("tools", "focus") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.PlayArrow)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("مؤقت التركيز", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("٢٥ دقيقة تركيز — منبه أصلي عند الانتهاء", color = DayflowColors.Muted, fontSize = 9.5.sp)
                    }
                    Icon(Icons.Rounded.ChevronLeft, null, tint = DayflowColors.Muted, modifier = Modifier.size(15.dp))
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DfCard(Modifier.weight(1f), padding = 12.dp) {
                    Column {
                        Text("الماء النهاردة", color = DayflowColors.Muted, fontSize = 9.sp)
                        Text("${(state.water[today] ?: 0) / 1000f}".take(4) + " لتر", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(4.dp))
                        ProgressBar((state.water[today]?.toFloat() ?: 0f) / state.waterGoal, DayflowColors.Water, 5.dp)
                        Spacer(Modifier.height(5.dp))
                        Text("+٢٥٠ مل", color = DayflowColors.Accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { repository.addWater(250) })
                    }
                }
                DfCard(Modifier.weight(1f), padding = 12.dp, onClick = { navigate("tools", "habits") }) {
                    Column {
                        Text("العادات", color = DayflowColors.Muted, fontSize = 9.sp)
                        Text("${DayflowTime.digits(state.habits.count { today in it.log })}/${DayflowTime.digits(state.habits.size)}", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(4.dp))
                        ProgressBar(if (state.habits.isEmpty()) 0f else state.habits.count { today in it.log }.toFloat() / state.habits.size, DayflowColors.Gold, 5.dp)
                        Spacer(Modifier.height(5.dp))
                        Text("تسجيل العادات", color = DayflowColors.Accent, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            NoticeCard("كل شىء يعمل على الجهاز", "المنبهات والودجتس والإشعارات والرفيق فوق التطبيقات كلها مكوّنات أندرويد أصلية. لا تظهر أي رسالة «هذه الميزة تعمل على أندرويد فقط» داخل هذه النسخة.", "green", Icons.Rounded.Shield)
        }
    }
}

@Composable
private fun RowScope.ToolTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, gold: Boolean = false, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(DayflowColors.Surface).border(1.dp, DayflowColors.Line, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(vertical = 11.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(if (gold) DayflowColors.SoftGold else DayflowColors.Soft), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (gold) DayflowColors.GoldText else DayflowColors.Accent, modifier = Modifier.size(16.dp))
        }
        Text(title, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, color = DayflowColors.Text, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
    }
}

@Composable
private fun HabitsScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    var newHabit by remember { mutableStateOf("") }
    val today = repository.todayKey(state)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item {
            ScreenHeader("العادات", "HABITS", "خطوة صغيرة كل يوم", action = {
                Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { navigate("tools", null) }.padding(8.dp))
            })
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = newHabit, onValueChange = { newHabit = it }, textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                    decorationBox = { if (newHabit.isBlank()) Text("عادة جديدة…", color = DayflowColors.Muted, fontSize = 10.5.sp); it() },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(DayflowColors.Surface2).padding(10.dp))
                Spacer(Modifier.width(6.dp))
                DfChip("إضافة") { if (newHabit.isNotBlank()) { repository.addHabit(newHabit.trim()); newHabit = "" } }
            }
        }
        items(state.habits, key = { it.id }) { habit ->
            val done = today in habit.log
            DfCard(Modifier.fillMaxWidth(), padding = 12.dp, onClick = { repository.toggleHabit(habit.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(habit.emoji, fontSize = 20.sp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(habit.ar, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${DayflowTime.digits(habit.log.size)} يوم مسجل", color = DayflowColors.Muted, fontSize = 9.sp)
                    }
                    Box(Modifier.size(24.dp).clip(CircleShape).background(if (done) DayflowColors.Accent else Color.Transparent).border(1.5.dp, DayflowColors.Accent, CircleShape), contentAlignment = Alignment.Center) {
                        if (done) Icon(Icons.Rounded.Check, null, tint = DayflowColors.OnAccent, modifier = Modifier.size(13.dp))
                    }
                }
            }
        }
        if (state.habits.isEmpty()) item { EmptyState("مفيش عادات لسه", "أضف أول عادة صغيرة وابدأ سلسلتك.", emoji = "🌱") }
    }
}

@Composable
private fun NotesScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    var text by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 10.dp, 16.dp, 110.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { ScreenHeader("الملاحظات", "NOTES", "كل فكرة تستاهل تتكتب", action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("tools", null) }.padding(8.dp)) }) }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = text, onValueChange = { text = it }, textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                    decorationBox = { if (text.isBlank()) Text("اكتب ملاحظة…", color = DayflowColors.Muted, fontSize = 10.5.sp); it() },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(DayflowColors.Surface2).padding(10.dp))
                Spacer(Modifier.width(6.dp))
                DfChip("حفظ") { if (text.isNotBlank()) { repository.addNote(text.trim()); text = "" } }
            }
        }
        items(state.notes, key = { it.id }) { note ->
            DfCard(Modifier.fillMaxWidth(), padding = 13.dp) {
                Column {
                    Text(note.text, fontSize = 11.5.sp, lineHeight = 19.sp, color = DayflowColors.Text)
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(DayflowTime.shortDate(java.time.Instant.ofEpochMilli(note.at).atZone(java.time.ZoneId.systemDefault()).toLocalDate()), color = DayflowColors.Muted, fontSize = 8.5.sp)
                        Spacer(Modifier.weight(1f))
                        Text(if (note.pinned) "★" else "☆", color = DayflowColors.Gold, fontSize = 15.sp, modifier = Modifier.clickable { repository.toggleNotePin(note.id) })
                        Spacer(Modifier.width(8.dp))
                        Text("حذف", color = DayflowColors.Danger, fontSize = 8.5.sp, modifier = Modifier.clickable { repository.deleteNote(note.id) })
                    }
                }
            }
        }
        if (state.notes.isEmpty()) item { EmptyState("مفيش ملاحظات", "ابدأ بفكرة صغيرة.", emoji = "📝") }
    }
}

@Composable
private fun FocusScreen(state: DayflowState, repository: DayflowRepository, navigate: Navigate) {
    val context = LocalContext.current
    var remaining by remember { mutableStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var minutes by remember { mutableStateOf(25) }
    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1000)
            remaining -= 1
            if (remaining == 0) {
                running = false
                val end = ZonedDateTime.now().plusSeconds(5)
                val alarm = Alarm(
                    id = repository.newAlarmId(),
                    time = "%02d:%02d".format(end.hour, end.minute),
                    date = DayflowTime.dateKey(end.toLocalDate()),
                    label = "انتهى وقت التركيز — خد استراحة", enabled = true, sound = AlarmSound(),
                )
                repository.upsertAlarm(alarm)
                AlarmScheduler.schedule(context, alarm)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("التركيز", "FOCUS", "مؤقت حقيقي + إشعار عند الانتهاء", action = { Text("رجوع", color = DayflowColors.Accent, fontSize = 10.sp, modifier = Modifier.clickable { navigate("tools", null) }.padding(8.dp)) })
        Spacer(Modifier.height(10.dp))
        DfCard(Modifier.fillMaxWidth(), padding = 22.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(160.dp).clip(CircleShape).background(DayflowColors.Soft), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(String.format("%02d:%02d", remaining / 60, remaining % 60), color = DayflowColors.Text, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, style = DayflowText.numeric)
                        Text(if (running) "جاري التركيز" else "جاهز للبدء", color = DayflowColors.Muted, fontSize = 9.5.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf(25, 15, 5).forEach { value -> DfChip("${DayflowTime.digits(value)} د", minutes == value) { minutes = value; remaining = value * 60; running = false } }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DfChip(if (running) "إيقاف مؤقت" else "ابدأ") { running = !running }
                    DfChip("إعادة") { running = false; remaining = minutes * 60 }
                }
                Spacer(Modifier.height(10.dp))
                NoticeCard("نفس منطق أندرويد", "عند انتهاء المؤقت يُجدول منبه حقيقي عبر AlarmManager، ويظهر إشعار حتى لو التطبيق في الخلفية.", "green", Icons.Rounded.Alarm)
            }
        }
    }
}

@Composable
fun CompanionChatScreen(state: DayflowState, repository: DayflowRepository) {
    val city = repository.activeCity(state)
    val prayer = PrayerCalculator.forCity(city, PrayerCatalog.method(state.prayer.methodId), state.prayer.asrFactor)
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("أهلاً بيك 🌿 أنا رفيق DAYFLOW. بعرف أنظم يومك وأفكرك بالصلاة والمنبه — بدون إرسال بياناتك لأي سيرفر.")) }
    val scope = rememberCoroutineScope()
    val today = repository.todayKey(state)
    val tasks = state.tasks.filter { it.date == today }

    fun answer(text: String): String = when {
        text.contains("منبه") || text.contains("صحيان") -> "المنبه الجاي: ${DayflowTime.nextAlarm(state.alarms)?.let { "${it.clock} — ${it.alarm.label.ifBlank { "منبه" }}" } ?: "مفيش منبه مفعّل"}. تقدر تضيف منبه من تبويب المنبهات بصيغة ١٢ ساعة."
        text.contains("صلاة") || text.contains("فجر") || text.contains("مغرب") -> "في ${city.ar} الصلاة القادمة ${prayer.nextLabel} الساعة ${prayer.nextText}. فاضل ${DayflowTime.duration(prayer.next?.let { java.time.Duration.between(ZonedDateTime.now(), it.at).toMinutes() } ?: 0L)}."
        text.contains("مهم") || text.contains("مهام") -> "عندك ${tasks.count { !it.done }} مهام لسه من ${tasks.size}. نبدأ بأصغر مهمة دقيقتين؟"
        text.contains("ماء") || text.contains("مياه") -> "شربت ${state.water[today] ?: 0} مل من ${state.waterGoal}. اشرب كوباية دلوقتي 💧"
        text.contains("ودجت") -> "الودجتس هنا أصلية: اختار واحدة من «أدوات ← الودجتس» ثم ثبّتها على الشاشة الرئيسية. هتفتح نفس الشاشة وتسألك: اختار واحدة لتكون هي الودجت."
        text.contains("تعب") || text.contains("قلق") -> "خد نفس عميق: ٤ ثواني شهيق، ٤ حبس، ٦ زفير. مفيش حاجة مستعجلة أكتر من هدوءك."
        text.contains("شكرا") -> "دايمًا 🌿 خطوة صغيرة النهاردة أحسن من خطة كبيرة بكرة."
        else -> "فهمت. أقدر أساعدك في المهام، مواقيت الصلاة، المنبهات، أو اختيار ودجت. قولّي نبدأ بإيه؟"
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        ScreenHeader("الرفيق الذكي", "COMPANION · محلي", "بياناتك على الجهاز فقط", action = { SmallTag("خصوصية", "green") })
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Robot(size = 48.dp, family = CalendarMath.seasonFor(), mood = state.companion.emotion)
            Spacer(Modifier.width(8.dp))
            Column { Text("رفيقك مستعد", fontSize = 12.sp, fontWeight = FontWeight.Bold); Text("${prayer.nextLabel} بعد ${DayflowTime.duration(prayer.next?.let { java.time.Duration.between(ZonedDateTime.now(), it.at).toMinutes() } ?: 0L)}", color = DayflowColors.Muted, fontSize = 9.sp) }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp)) {
            items(messages) { message ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    Text(message, color = DayflowColors.Text, fontSize = 11.5.sp, lineHeight = 19.sp,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(DayflowColors.Surface).border(1.dp, DayflowColors.Line, RoundedCornerShape(14.dp)).padding(11.dp).fillMaxWidth(0.9f))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 90.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = input, onValueChange = { input = it }, textStyle = MaterialTheme.typography.bodyMedium.copy(color = DayflowColors.Text),
                decorationBox = { if (input.isBlank()) Text("اكتب لرفيقك…", color = DayflowColors.Muted, fontSize = 10.5.sp); it() },
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(DayflowColors.Surface2).padding(11.dp))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(40.dp).clip(CircleShape).background(DayflowColors.Accent).clickable {
                if (input.isNotBlank()) { messages = messages + input.trim(); messages = messages + answer(input.trim()); input = "" }
            }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.AutoAwesome, null, tint = DayflowColors.OnAccent, modifier = Modifier.size(17.dp)) }
        }
        Spacer(Modifier.height(2.dp))
    }
}
