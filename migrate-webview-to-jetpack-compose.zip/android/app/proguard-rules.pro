# DAYFLOW keeps user data in DataStore. No classes need rules today.
-keep class app.dayflow.android.data.** { *; }
-keepattributes *Annotation*
-dontwarn org.jsoup.**
