// Time-of-day ambience & realistic seasonal art per family.
import dawn from "../assets/photos/dawn.jpg";
import noon from "../assets/photos/noon.jpg";
import asr from "../assets/photos/asr.jpg";
import maghrib from "../assets/photos/maghrib.jpg";
import night from "../assets/photos/night.jpg";
import snowPhoto from "../assets/photos/snow.jpg";
import autumnTree from "../assets/photos/autumn-tree.jpg";
import springBlossom from "../assets/photos/spring-blossom.jpg";

import maple from "../assets/decor/maple.png";
import fallen from "../assets/decor/fallen.png";
import oak from "../assets/decor/oak.png";
import wind from "../assets/decor/wind.png";
import snow from "../assets/decor/snow.png";
import snowman from "../assets/decor/snowman.png";
import fanousMini from "../assets/decor/fanous-mini.png";
import star from "../assets/decor/star.png";
import sparkle from "../assets/decor/sparkle.png";
import crescent from "../assets/decor/crescent.png";
import blossom from "../assets/decor/blossom.png";
import tulip from "../assets/decor/tulip.png";
import jasmine from "../assets/decor/jasmine.png";
import herb from "../assets/decor/herb.png";
import lotus from "../assets/decor/lotus.png";
import wave from "../assets/decor/wave.png";
import seashell from "../assets/decor/seashell.png";
import balloon from "../assets/decor/balloon.png";
import confetti from "../assets/decor/confetti.png";
import gift from "../assets/decor/gift.png";
import heart from "../assets/decor/heart.png";
import dove from "../assets/decor/dove.png";
import books from "../assets/decor/books.png";
import copticCross from "../assets/decor/coptic-cross.png";
import type { Family } from "./calendar";

export type Period = "fajr" | "morning" | "noon" | "asr" | "maghrib" | "night";

export interface PeriodInfo { id: Period; en: string; ar: string; photo: string; theme: string; tint: string }

export const PERIODS: Record<Period, PeriodInfo> = {
  fajr: { id: "fajr", en: "Dawn", ar: "الفجر", photo: dawn, theme: "luxor-dawn", tint: "rgba(40,30,60,.35)" },
  morning: { id: "morning", en: "Morning", ar: "الصباح", photo: noon, theme: "paper-white", tint: "rgba(255,255,255,.18)" },
  noon: { id: "noon", en: "Noon", ar: "الظهر", photo: noon, theme: "nile-blue", tint: "rgba(20,60,110,.18)" },
  asr: { id: "asr", en: "Afternoon", ar: "العصر", photo: asr, theme: "desert-gold", tint: "rgba(120,70,20,.25)" },
  maghrib: { id: "maghrib", en: "Sunset", ar: "المغرب", photo: maghrib, theme: "aswan-sunset", tint: "rgba(60,20,30,.38)" },
  night: { id: "night", en: "Night", ar: "الليل", photo: night, theme: "cairo-night", tint: "rgba(5,8,20,.5)" },
};

export interface PrayerLike { fajr: string; sunrise: string; dhuhr: string; asr: string; maghrib: string; isha: string }
const toMin = (hhmm?: string) => { if (!hhmm || !hhmm.includes(":")) return NaN; const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };

export function periodAt(d: Date, p?: Partial<PrayerLike>): Period {
  const m = d.getHours() * 60 + d.getMinutes();
  const f = toMin(p?.fajr) || 4 * 60 + 30, sr = toMin(p?.sunrise) || 6 * 60, dh = toMin(p?.dhuhr) || 12 * 60;
  const as = toMin(p?.asr) || 15 * 60, mg = toMin(p?.maghrib) || 17 * 60 + 45, is = toMin(p?.isha) || 19 * 60 + 10;
  if (m >= f && m < sr + 60) return "fajr";
  if (m >= sr + 60 && m < dh - 30) return "morning";
  if (m >= dh - 30 && m < as) return "noon";
  if (m >= as && m < mg - 20) return "asr";
  if (m >= mg - 20 && m < is + 30) return "maghrib";
  return "night";
}

/** Realistic high-detail decor art per season family: falling sprites, static corner piece, optional backdrop photo. */
export interface DecorArt { fall: string[]; corner?: string; backdrop?: string; motion: "fall" | "float" | "drift" }
export const DECOR_ART: Record<Family, DecorArt> = {
  autumn: { fall: [maple, fallen, oak, wind, maple], corner: maple, backdrop: autumnTree, motion: "fall" },
  winter: { fall: [snow, snow, sparkle, wind], corner: snowman, backdrop: snowPhoto, motion: "fall" },
  spring: { fall: [blossom, jasmine, tulip, herb], corner: tulip, backdrop: springBlossom, motion: "drift" },
  summer: { fall: [wave, seashell, sparkle], corner: seashell, motion: "float" },
  ramadan: { fall: [fanousMini, crescent, star, sparkle], corner: fanousMini, motion: "float" },
  islamic: { fall: [crescent, star, sparkle], corner: crescent, motion: "float" },
  friday: { fall: [jasmine, dove, sparkle], corner: dove, motion: "float" },
  eid: { fall: [balloon, confetti, gift, star], corner: gift, motion: "float" },
  national: { fall: [dove, star, confetti], corner: dove, motion: "drift" },
  nile: { fall: [lotus, wave, jasmine, herb], corner: lotus, motion: "drift" },
  coptic: { fall: [copticCross, dove, star, sparkle], corner: copticCross, motion: "float" },
  love: { fall: [heart, blossom, jasmine], corner: heart, motion: "float" },
  study: { fall: [books, herb, sparkle], corner: books, motion: "float" },
  birthday: { fall: [balloon, confetti, gift, sparkle], corner: balloon, motion: "float" },
  newyear: { fall: [confetti, sparkle, star, balloon], corner: star, motion: "fall" },
};

export const ART_CREDITS = [
  "Ambient & seasonal photographs: High-resolution realistic photography curated for DAYFLOW periods & Egyptian seasons.",
  "Seasonal botanical & heritage ornaments: Multi-layered realistic shaded botanical, crystal, and brass filigree illustrations.",
  "Geometric friezes: Wikimedia Commons (CC0 / Public domain) SVGs + DAYFLOW procedural tilings.",
];
