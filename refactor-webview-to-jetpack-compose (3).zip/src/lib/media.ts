// Media Hub pure logic + rich cross-platform preview (Android Native HTTP/yt-dlp first, multi-relay oEmbed + OpenGraph fallback in browser).
import { nativeBridge, isAndroidApk } from "./nativeBridge";

export type Site = "youtube" | "vimeo" | "soundcloud" | "instagram" | "x" | "facebook" | "tiktok" | "archive" | "generic";
export interface ParsedUrl { ok: boolean; url: string; host: string; site: Site; kind: "video" | "playlist" | "channel" | "audio" | "image" | "unknown"; id?: string; reason?: string }

const TRACKING = /^(utm_|fbclid|gclid|si$|feature$|igshid|ref_src|mc_)/;

export function normalizeUrl(raw: string): ParsedUrl {
  const text = raw.trim();
  const m = text.match(/https?:\/\/[^\s<>"']+/i) || text.match(/(?:www\.)?[a-z0-9-]+\.[a-z]{2,}\/[^\s<>"']*/i);
  if (!m) return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "no-link" };
  let u: URL;
  try { u = new URL(m[0].startsWith("http") ? m[0] : "https://" + m[0]); } catch { return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "invalid" }; }
  if (u.protocol !== "https:" && u.protocol !== "http:") return { ok: false, url: "", host: "", site: "generic", kind: "unknown", reason: "scheme" };
  for (const k of [...u.searchParams.keys()]) if (TRACKING.test(k)) u.searchParams.delete(k);
  u.hash = u.hash.startsWith("#t=") ? u.hash : "";
  const host = u.hostname.replace(/^(www\.|m\.|music\.)/, "");
  let site: Site = "generic", kind: ParsedUrl["kind"] = "unknown", id: string | undefined;
  if (/(^|\.)youtube\.com$|^youtu\.be$/.test(host)) {
    site = "youtube";
    if (host === "youtu.be") { id = u.pathname.slice(1).split("/")[0]; kind = "video"; const ts = u.searchParams.get("t"); u = new URL("https://www.youtube.com/watch?v=" + id + (ts ? "&t=" + encodeURIComponent(ts) : "")); }
    else if (u.searchParams.get("list") && !u.searchParams.get("v")) { kind = "playlist"; id = u.searchParams.get("list")!; }
    else if (u.searchParams.get("v")) { kind = u.searchParams.get("list") ? "playlist" : "video"; id = u.searchParams.get("v")!; }
    else if (/^\/shorts\//.test(u.pathname)) { kind = "video"; id = u.pathname.split("/")[2]; }
    else if (/^\/live\//.test(u.pathname)) { kind = "video"; id = u.pathname.split("/")[2]; }
    else if (/^\/(@|channel\/|c\/)/.test(u.pathname)) kind = "channel";
  } else if (/vimeo\.com$/.test(host)) { site = "vimeo"; kind = /\/showcase\//.test(u.pathname) ? "playlist" : "video"; id = u.pathname.split("/").filter(Boolean).pop(); }
  else if (/soundcloud\.com$/.test(host)) { site = "soundcloud"; kind = /\/sets\//.test(u.pathname) ? "playlist" : "audio"; }
  else if (/instagram\.com$/.test(host)) { site = "instagram"; kind = /\/p\//.test(u.pathname) ? "image" : "video"; }
  else if (/(^|\.)x\.com$|twitter\.com$/.test(host)) { site = "x"; kind = "video"; }
  else if (/facebook\.com$|fb\.watch$/.test(host)) { site = "facebook"; kind = "video"; }
  else if (/tiktok\.com$/.test(host)) { site = "tiktok"; kind = "video"; }
  else if (/archive\.org$/.test(host)) { site = "archive"; kind = "video"; }
  else if (/\.(mp4|webm|mkv|mov)$/i.test(u.pathname)) kind = "video";
  else if (/\.(mp3|ogg|opus|m4a|flac|wav)$/i.test(u.pathname)) kind = "audio";
  else if (/\.(jpe?g|png|webp|gif)$/i.test(u.pathname)) kind = "image";
  return { ok: true, url: u.toString(), host, site, kind, id };
}

export interface YtFormat { format_id: string; ext: string; vcodec?: string; acodec?: string; height?: number; fps?: number; abr?: number; tbr?: number; filesize?: number; filesize_approx?: number; dynamic_range?: string; url?: string }
export interface Preset { id: string; label: string; height?: number; containers: string[]; fps?: number; hdr?: boolean; size?: number; formatIds: string[]; directUrl?: string }

const est = (f: YtFormat, dur: number) => f.filesize ?? f.filesize_approx ?? (f.tbr && dur ? (f.tbr * 1000 * dur) / 8 : 0);

export function groupFormats(formats: YtFormat[], duration: number) {
  const video = formats.filter((f) => f.vcodec && f.vcodec !== "none");
  const audio = formats.filter((f) => (!f.vcodec || f.vcodec === "none") && f.acodec && f.acodec !== "none");
  const bestAudio = [...audio].sort((a, b) => (b.abr ?? 0) - (a.abr ?? 0))[0];
  const heights = [2160, 1440, 1080, 720, 480, 360, 240, 144];
  const label: Record<number, string> = { 2160: "4K", 1440: "1440p", 1080: "1080p", 720: "720p", 480: "480p", 360: "360p", 240: "240p", 144: "144p" };
  const presets: Preset[] = [];
  for (const h of heights) {
    const at = video.filter((f) => f.height === h);
    if (!at.length) continue;
    const top = [...at].sort((a, b) => (b.tbr ?? 0) - (a.tbr ?? 0))[0];
    const containers = [...new Set(at.map((f) => (f.vcodec?.startsWith("avc") ? "MP4 H.264" : f.vcodec?.startsWith("hev") || f.vcodec?.startsWith("hvc") ? "MP4 HEVC" : f.vcodec?.startsWith("av01") ? "WebM AV1" : f.vcodec?.startsWith("vp9") || f.vcodec?.startsWith("vp09") ? "WebM VP9" : f.ext.toUpperCase())))];
    presets.push({ id: "v" + h, label: label[h], height: h, containers, fps: Math.max(...at.map((f) => f.fps ?? 30)), hdr: at.some((f) => f.dynamic_range && f.dynamic_range !== "SDR"), size: est(top, duration) + (bestAudio && (!top.acodec || top.acodec === "none") ? est(bestAudio, duration) : 0), formatIds: [top.format_id, (!top.acodec || top.acodec === "none") ? bestAudio?.format_id : undefined].filter(Boolean) as string[], directUrl: top.acodec && top.acodec !== "none" ? top.url : undefined });
  }
  if (presets.length) {
    presets.unshift({ ...presets[0], id: "best", label: "Best" });
    const last = presets[presets.length - 1];
    presets.push({ ...last, id: "small", label: "Smallest" });
  }
  const audioOut = formats.length ? [
    ["mp3-320", "MP3 320"], ["mp3-192", "MP3 192"], ["mp3-128", "MP3 128"], ["m4a", "M4A / AAC"], ["opus", "Opus"], ["ogg", "OGG"], ["flac", "FLAC"], ["wav", "WAV"],
  ].map(([id, l]) => {
    const kbps = id.startsWith("mp3-") ? +id.split("-")[1] : id === "flac" ? 900 : id === "wav" ? 1411 : bestAudio?.abr ?? 128;
    return { id, label: l, size: duration ? (kbps * 1000 * duration) / 8 : undefined, copy: (id === "m4a" && bestAudio?.ext === "m4a") || (id === "opus" && bestAudio?.acodec === "opus") };
  }) : [];
  return { presets, audio: audioOut, raw: formats.length };
}

export type DlState = "queued" | "fetching" | "downloading" | "paused" | "post" | "completed" | "failed" | "cancelled";
export type DlEvent = "start" | "info" | "progress" | "pause" | "resume" | "postprocess" | "done" | "error" | "cancel" | "retry";
const T: Record<DlState, Partial<Record<DlEvent, DlState>>> = {
  queued: { start: "fetching", cancel: "cancelled", pause: "paused" },
  fetching: { info: "downloading", error: "failed", cancel: "cancelled", pause: "paused" },
  downloading: { progress: "downloading", pause: "paused", postprocess: "post", done: "completed", error: "failed", cancel: "cancelled" },
  paused: { resume: "queued", cancel: "cancelled" },
  post: { done: "completed", error: "failed", cancel: "cancelled" },
  completed: {}, cancelled: { retry: "queued" }, failed: { retry: "queued", cancel: "cancelled" },
};
export const transition = (s: DlState, e: DlEvent): DlState => T[s][e] ?? s;

export function sanitizeFilename(name: string) {
  return name.replace(/[\u0000-\u001f\u007f<>:"/\\|?*\u202a-\u202e\u2066-\u2069]/g, "").replace(/\s+/g, " ").trim().slice(0, 150) || "download";
}

export const fmtBytes = (b?: number) => (!b || b <= 0 ? "—" : b < 1e6 ? (b / 1e3).toFixed(0) + " KB" : b < 1e9 ? (b / 1e6).toFixed(1) + " MB" : (b / 1e9).toFixed(2) + " GB");

export interface Preview {
  title: string;
  author?: string;
  thumb?: string;
  provider: string;
  kind: ParsedUrl["kind"];
  duration?: number;
  url: string;
  description?: string;
  formats?: YtFormat[];
  direct?: { type: string; size: number } | null;
}

const TIMEOUT = 12000;
const withTimeout = (ms: number) => {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  return { signal: c.signal, clear: () => clearTimeout(t) };
};

export async function fetchPreview(raw: string): Promise<Preview> {
  const p = normalizeUrl(raw);
  if (!p.ok) throw new Error("invalid");

  // 1) In Android native mode, use the zero-CORS native link analyzer + yt-dlp extractor first!
  if (isAndroidApk()) {
    try {
      const res = await nativeBridge.analyzeLink?.({ url: p.url });
      if (res?.json) {
        const nj = JSON.parse(res.json) as {
          title?: string; uploader?: string; author?: string; site?: string; thumbnail?: string;
          description?: string; duration?: number; mimeType?: string; size?: number; direct?: boolean;
          formats?: YtFormat[];
        };
        return {
          title: nj.title || p.url.split("/").pop() || p.host,
          author: nj.uploader || nj.author || nj.site,
          thumb: nj.thumbnail || (p.site === "youtube" && p.id ? `https://i.ytimg.com/vi/${p.id}/hqdefault.jpg` : undefined),
          provider: nj.site || p.host,
          kind: p.kind,
          duration: nj.duration ? Math.round(nj.duration) : undefined,
          url: p.url,
          description: nj.description,
          formats: nj.formats,
          direct: nj.direct && nj.mimeType ? { type: nj.mimeType, size: nj.size || 0 } : null,
        };
      }
    } catch {
      // Fall through to public oEmbed/OpenGraph relays if native probe failed transiently
    }
  }

  const target = encodeURIComponent(p.url);
  const tryJson = async (u: string) => {
    const { signal, clear } = withTimeout(TIMEOUT);
    try {
      const r = await fetch(u, { signal, mode: "cors" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      return await r.json();
    } finally { clear(); }
  };

  let j: Record<string, any> | null = null;
  let provider: string = p.host;

  try {
    if (p.site === "youtube") { j = await tryJson(`https://www.youtube.com/oembed?format=json&url=${target}`); provider = "YouTube"; }
    else if (p.site === "vimeo") { j = await tryJson(`https://vimeo.com/api/oembed.json?url=${target}`); provider = "Vimeo"; }
    else if (p.site === "soundcloud") { j = await tryJson(`https://soundcloud.com/oembed?format=json&url=${target}`); provider = "SoundCloud"; }
    else if (p.site === "tiktok") { j = await tryJson(`https://www.tiktok.com/oembed?url=${target}`); provider = "TikTok"; }
    else { j = await tryJson(`https://noembed.com/embed?url=${target}`); provider = (j?.provider_name as string) || p.host; }
    if (j?.error) j = null;
  } catch {
    j = null;
  }

  // 2) Secondary oEmbed relay
  if (!j) {
    try {
      const k = await tryJson(`https://noembed.com/embed?url=${target}`);
      if (k && !k.error && (k.title || k.thumbnail_url)) {
        j = k;
        provider = k.provider_name || p.host;
      }
    } catch { /* continue */ }
  }

  // 3) Universal OpenGraph / Twitter Card / JSON-LD relay (Microlink public CORS endpoint)
  let og: { title?: string; description?: string; image?: string; author?: string; publisher?: string; duration?: number } | null = null;
  if (!j || !j.thumbnail_url || !j.description) {
    try {
      const ml = await tryJson(`https://api.microlink.io/?url=${target}&audio=true&video=true`);
      if (ml?.status === "success" && ml.data) {
        og = {
          title: ml.data.title,
          description: ml.data.description,
          image: ml.data.image?.url || ml.data.logo?.url,
          author: ml.data.author,
          publisher: ml.data.publisher,
        };
      }
    } catch { /* ignore */ }
  }

  // 4) Direct file HEAD/Range probe
  let direct: Preview["direct"] = null;
  if (p.site === "generic" || /\.(mp4|webm|mp3|ogg|opus|m4a|flac|wav|jpe?g|png|webp|gif|pdf|zip|apk)$/i.test(p.url)) {
    try {
      const { signal, clear } = withTimeout(7000);
      const r = await fetch(p.url, { method: "HEAD", signal });
      clear();
      const ct = r.headers.get("content-type") || "";
      if (r.ok && ct && !ct.includes("text/html")) {
        direct = { type: ct.split(";")[0], size: +(r.headers.get("content-length") || 0) };
      }
    } catch { direct = null; }
  }

  const ytFallbackThumb = p.site === "youtube" && p.id ? `https://i.ytimg.com/vi/${p.id}/hqdefault.jpg` : undefined;
  const imageSelfThumb = p.kind === "image" && /\.(jpe?g|png|webp|gif)$/i.test(p.url) ? p.url : undefined;

  if (!j && !og?.title && !direct && !ytFallbackThumb && !imageSelfThumb) {
    const reason = p.site === "youtube" ? "youtube" : p.site === "generic" ? "blocked" : p.site;
    throw new Error(reason);
  }

  return {
    title: j?.title || og?.title || decodeURIComponent(p.url.split("/").pop() || "") || p.host,
    author: j?.author_name || j?.account_name || og?.author || og?.publisher,
    thumb: j?.thumbnail_url || og?.image || ytFallbackThumb || imageSelfThumb,
    provider: (j && !j.error ? provider : og?.publisher) || p.host,
    kind: p.kind,
    duration: j?.duration ? Math.round(j.duration) : undefined,
    url: p.url,
    description: j?.description || og?.description,
    direct,
  };
}

export async function downloadDirect(url: string, cb: { onProgress: (pct: number, bytes: number) => void; signal: AbortSignal }): Promise<Blob> {
  const r = await fetch(url, { signal: cb.signal });
  if (!r.ok) throw new Error("HTTP " + r.status);
  const total = +(r.headers.get("content-length") || 0);
  const reader = r.body?.getReader();
  if (!reader) { const b = await r.blob(); cb.onProgress(100, b.size); return b; }
  const chunks: Uint8Array[] = []; let got = 0; let last = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value); got += value.length;
    const now = performance.now();
    if (now - last > 90) { last = now; cb.onProgress(total ? Math.min(99, Math.round((got / total) * 100)) : 0, got); }
  }
  cb.onProgress(100, got);
  return new Blob(chunks as BlobPart[], { type: r.headers.get("content-type") || "application/octet-stream" });
}

export const SAMPLE_CC0 = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";
