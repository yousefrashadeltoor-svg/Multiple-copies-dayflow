// Prayer times — high-precision on-device solar astronomical calculation.
// Method: Egyptian General Survey Authority (Fajr 19.5°, Isha 17.5°, Shafi'i Asr shadow factor 1).
// Automatically resolves civil date and Daylight Saving Time (DST) via IANA TimeZone database.

export interface PrayerTimes {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  next: { name: string; nameAr: string; time: string; inMin: number } | null;
}

export interface Location {
  lat: number;
  lng: number;
  city: string;
  cityAr: string;
  tz: number;
  zone?: string;
}

export const CITIES: Location[] = [
  { lat: 30.0131, lng: 31.2089, city: "Giza", cityAr: "الجيزة", tz: 2, zone: "Africa/Cairo" },
  { lat: 30.0444, lng: 31.2357, city: "Cairo", cityAr: "القاهرة", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.2001, lng: 29.9187, city: "Alexandria", cityAr: "الإسكندرية", tz: 2, zone: "Africa/Cairo" },
  { lat: 30.4660, lng: 31.1848, city: "Benha (Qalyubia)", cityAr: "بنها (القليوبية)", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.0409, lng: 31.3785, city: "Mansoura", cityAr: "المنصورة", tz: 2, zone: "Africa/Cairo" },
  { lat: 30.7865, lng: 31.0004, city: "Tanta", cityAr: "طنطا", tz: 2, zone: "Africa/Cairo" },
  { lat: 30.5877, lng: 31.5020, city: "Zagazig", cityAr: "الزقازيق", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.0364, lng: 30.4682, city: "Damanhur", cityAr: "دمنهور", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.1107, lng: 30.9388, city: "Kafr El-Sheikh", cityAr: "كفر الشيخ", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.4175, lng: 31.8144, city: "Damietta", cityAr: "دمياط", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.2653, lng: 32.3019, city: "Port Said", cityAr: "بورسعيد", tz: 2, zone: "Africa/Cairo" },
  { lat: 30.5965, lng: 32.2715, city: "Ismailia", cityAr: "الإسماعيلية", tz: 2, zone: "Africa/Cairo" },
  { lat: 29.9668, lng: 32.5498, city: "Suez", cityAr: "السويس", tz: 2, zone: "Africa/Cairo" },
  { lat: 29.3084, lng: 30.8428, city: "Faiyum", cityAr: "الفيوم", tz: 2, zone: "Africa/Cairo" },
  { lat: 29.0661, lng: 31.0994, city: "Beni Suef", cityAr: "بني سويف", tz: 2, zone: "Africa/Cairo" },
  { lat: 28.1099, lng: 30.7503, city: "Minya", cityAr: "المنيا", tz: 2, zone: "Africa/Cairo" },
  { lat: 27.1810, lng: 31.1837, city: "Assiut", cityAr: "أسيوط", tz: 2, zone: "Africa/Cairo" },
  { lat: 26.5570, lng: 31.6948, city: "Sohag", cityAr: "سوهاج", tz: 2, zone: "Africa/Cairo" },
  { lat: 26.1551, lng: 32.7160, city: "Qena", cityAr: "قنا", tz: 2, zone: "Africa/Cairo" },
  { lat: 25.6872, lng: 32.6396, city: "Luxor", cityAr: "الأقصر", tz: 2, zone: "Africa/Cairo" },
  { lat: 24.0889, lng: 32.8998, city: "Aswan", cityAr: "أسوان", tz: 2, zone: "Africa/Cairo" },
  { lat: 27.2579, lng: 33.8116, city: "Hurghada", cityAr: "الغردقة", tz: 2, zone: "Africa/Cairo" },
  { lat: 27.9158, lng: 34.3299, city: "Sharm El-Sheikh", cityAr: "شرم الشيخ", tz: 2, zone: "Africa/Cairo" },
  { lat: 31.3543, lng: 27.2373, city: "Marsa Matruh", cityAr: "مرسى مطروح", tz: 2, zone: "Africa/Cairo" },
  { lat: 21.4225, lng: 39.8262, city: "Makkah", cityAr: "مكة المكرمة", tz: 3, zone: "Asia/Riyadh" },
  { lat: 24.4686, lng: 39.6142, city: "Madinah", cityAr: "المدينة المنورة", tz: 3, zone: "Asia/Riyadh" },
  { lat: 25.2048, lng: 55.2708, city: "Dubai", cityAr: "دبي", tz: 4, zone: "Asia/Dubai" },
  { lat: 51.5074, lng: -0.1278, city: "London", cityAr: "لندن", tz: 0, zone: "Europe/London" },
];

const rad = (d: number) => (d * Math.PI) / 180;
const deg = (r: number) => (r * 180) / Math.PI;
const fixHour = (h: number) => ((h % 24) + 24) % 24;
const fixAngle = (a: number) => ((a % 360) + 360) % 360;

function resolveZone(loc: Location): string {
  if (loc.zone) return loc.zone;
  if (loc.city === "London") return "Europe/London";
  if (loc.tz === 3) return "Asia/Riyadh";
  if (loc.tz === 4) return "Asia/Dubai";
  return "Africa/Cairo";
}

function zonedParts(date: Date, zone: string) {
  try {
    const parts = new Intl.DateTimeFormat("en-GB", {
      timeZone: zone,
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hourCycle: "h23",
    }).formatToParts(date);
    const get = (t: string) => Number(parts.find((x) => x.type === t)?.value || 0);
    const y = get("year"), m = get("month"), d = get("day");
    const hr = get("hour") % 24, min = get("minute"), sec = get("second");
    const tzOffsetHours = Math.round((Date.UTC(y, m - 1, d, hr, min, sec) - date.getTime()) / 60000) / 60;
    return { y, m, d, hr, min, tzOffsetHours };
  } catch {
    const tzOffsetHours = -date.getTimezoneOffset() / 60;
    return {
      y: date.getFullYear(),
      m: date.getMonth() + 1,
      d: date.getDate(),
      hr: date.getHours(),
      min: date.getMinutes(),
      tzOffsetHours,
    };
  }
}

function julianAtLocalNoon(y: number, m: number, d: number, tzOffsetHours: number) {
  let jy = y, jm = m;
  if (jm <= 2) { jy -= 1; jm += 12; }
  const A = Math.floor(jy / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (jy + 4716)) + Math.floor(30.6001 * (jm + 1)) + d + B - 1524.5 + (12 - tzOffsetHours) / 24;
}

function computeDayTimes(loc: Location, y: number, m: number, day: number, tzOffsetHours: number) {
  const jd = julianAtLocalNoon(y, m, day, tzOffsetHours);
  const n = jd - 2451545.0;
  const g = rad(fixAngle(357.529 + 0.98560028 * n));
  const q = fixAngle(280.459 + 0.98564736 * n);
  const L = rad(fixAngle(q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)));
  const e = rad(23.439 - 0.00000036 * n);
  const RA = fixHour(deg(Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L))) / 15);
  const decl = Math.asin(Math.sin(e) * Math.sin(L));

  let eqt = q / 15 - RA;
  if (eqt > 12) eqt -= 24;
  if (eqt < -12) eqt += 24;

  const midDay = 12 + tzOffsetHours - loc.lng / 15 - eqt;
  const hourAngle = (alt: number) => {
    const cosH = (Math.sin(rad(alt)) - Math.sin(rad(loc.lat)) * Math.sin(decl)) / (Math.cos(rad(loc.lat)) * Math.cos(decl));
    if (cosH > 1 || cosH < -1) return null;
    return deg(Math.acos(cosH)) / 15;
  };
  const atAlt = (alt: number, before = true) => {
    const h = hourAngle(alt);
    if (h === null) return null;
    return fixHour(before ? midDay - h : midDay + h);
  };

  // Egyptian General Survey Authority: Fajr -19.5°, Sunrise/Sunset -0.8333°, Isha -17.5°, Shafi'i Asr (factor 1)
  const fajr = atAlt(-19.5, true);
  const sunrise = atAlt(-0.8333, true);
  const dhuhr = fixHour(midDay);
  const asrAlt = deg(Math.atan(1 / (1 + Math.tan(Math.abs(rad(loc.lat) - decl)))));
  const asr = atAlt(asrAlt, false);
  const maghrib = atAlt(-0.8333, false);
  const isha = atAlt(-17.5, false);

  const fmt = (h: number | null) => {
    if (h === null || !Number.isFinite(h)) return "—";
    const total = Math.round(fixHour(h) * 60);
    const hh = Math.floor(total / 60) % 24;
    const mm = total % 60;
    return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  };

  return {
    fajr: fmt(fajr),
    sunrise: fmt(sunrise),
    dhuhr: fmt(dhuhr),
    asr: fmt(asr),
    maghrib: fmt(maghrib),
    isha: fmt(isha),
  };
}

export function prayerTimes(loc: Location, date = new Date()): PrayerTimes {
  const safeLoc = loc || CITIES[0];
  const zone = resolveZone(safeLoc);
  const { y, m, d, hr, min, tzOffsetHours } = zonedParts(date, zone);
  const times = computeDayTimes(safeLoc, y, m, d, tzOffsetHours);
  const nowMin = hr * 60 + min;

  const list = [
    ["fajr", "الفجر", times.fajr],
    ["sunrise", "الشروق", times.sunrise],
    ["dhuhr", "الظهر", times.dhuhr],
    ["asr", "العصر", times.asr],
    ["maghrib", "المغرب", times.maghrib],
    ["isha", "العشاء", times.isha],
  ] as const;

  let next: PrayerTimes["next"] = null;
  for (const [name, nameAr, time] of list) {
    if (!time.includes(":")) continue;
    const [hh, mm] = time.split(":").map(Number);
    const diff = hh * 60 + mm - nowMin;
    if (diff > 0) {
      next = { name, nameAr, time, inMin: diff };
      break;
    }
  }
  if (!next) {
    const tomorrow = new Date(date.getTime() + 86400_000);
    const zTom = zonedParts(tomorrow, zone);
    const tomTimes = computeDayTimes(safeLoc, zTom.y, zTom.m, zTom.d, zTom.tzOffsetHours);
    const fajrStr = tomTimes.fajr.includes(":") ? tomTimes.fajr : times.fajr;
    const [hh, mm] = fajrStr.split(":").map(Number);
    next = { name: "fajr", nameAr: "الفجر", time: fajrStr, inMin: Math.max(1, 1440 - nowMin + hh * 60 + mm) };
  }
  return { ...times, next };
}

export function nearestCityIndex(lat: number, lng: number): number {
  let best = 0;
  let bestDist = Infinity;
  CITIES.forEach((c, idx) => {
    const d = Math.hypot(c.lat - lat, c.lng - lng);
    if (d < bestDist) {
      bestDist = d;
      best = idx;
    }
  });
  return best;
}

export const PRAYER_NAMES: Array<[keyof Omit<PrayerTimes, "next">, string, string, string]> = [
  ["fajr", "Fajr", "الفجر", "🌅"],
  ["sunrise", "Sunrise", "الشروق", "☀️"],
  ["dhuhr", "Dhuhr", "الظهر", "🕛"],
  ["asr", "Asr", "العصر", "🌤️"],
  ["maghrib", "Maghrib", "المغرب", "🌇"],
  ["isha", "Isha", "العشاء", "🌙"],
];
