import { Capacitor, registerPlugin } from "@capacitor/core";

export interface DayflowNative {
  canScheduleExactAlarms(): Promise<{ granted: boolean }>;
  requestExactAlarmPermission(): Promise<{ granted: boolean; settingsOpened?: boolean }>;
  scheduleAlarm(opts: {
    id: string;
    time: string;
    date?: string;
    days: number[];
    label: string;
    soundUri?: string;
    vibrate: boolean;
    snooze: number;
    gentle?: boolean;
    enabled?: boolean;
  }): Promise<{ scheduled?: boolean }>;
  cancelAlarm(opts: { id: string }): Promise<{ cancelled?: boolean }>;
  scheduleReminder(opts: {
    id: string;
    title: string;
    body: string;
    date?: string;
    time: string;
    days?: number[];
  }): Promise<{ scheduled?: boolean }>;
  cancelReminder(opts: { id: string }): Promise<void>;
  getDeviceTones(): Promise<{ tones: Array<{ title: string; uri: string; type: string }> }>;
  pickCustomSoundUri(): Promise<{ title: string; uri: string }>;
  pinWidget(opts: { designId: string; style: string; w: number; h: number }): Promise<{ pinned: boolean }>;
  getPendingWidgetConfiguration(): Promise<{ widgetId: number; width: number; height: number; form?: string }>;
  configureWidget(opts: {
    widgetId: number;
    designId: string;
    title: string;
    style: string;
    width: number;
    height: number;
  }): Promise<{ configured?: boolean }>;
  openWidgetHub(): Promise<void>;
  requestNotificationsPermission(): Promise<{ granted?: boolean }>;
  showNotification(opts: {
    title: string;
    body: string;
    channel?: string;
    id?: number;
    actions?: boolean;
  }): Promise<void>;
  canDrawOverlays(): Promise<{ granted: boolean }>;
  startCompanionOverlay(opts: {
    enabled: boolean;
    size: number;
    opacity: number;
    emotion?: string;
    outfit?: string;
    bubbleText?: string;
    modelId?: string;
  }): Promise<{ hasPermission: boolean }>;
  updateCompanionOverlay(opts: { png?: string; size: number; opacity: number; bubbleText?: string }): Promise<void>;
  requestOverlayPermission(): Promise<void>;
  enqueueDownload(opts: { url: string; name: string; preset?: string }): Promise<{ downloadId?: number; queued?: boolean }>;
  analyzeLink(opts: { url: string }): Promise<{ json: string }>;
  startDownload(opts: {
    id: string;
    url: string;
    name: string;
    engines: string[];
    format: string;
    quality: string;
    saveDir: string;
    connections: number;
  }): Promise<{ downloadId?: number; queued?: boolean }>;
  pauseDownload(opts: { id: string }): Promise<void>;
  cancelDownload(opts: { id: string }): Promise<void>;
  updateEngines(): Promise<{ ytdlp: string }>;
  openSniffer(opts: { url: string }): Promise<void>;
  getPendingShare(): Promise<{ text: string }>;
  syncState(opts: { json: string }): Promise<void>;
  getCurrentLocation(): Promise<{ lat: number; lng: number; city?: string }>;
}

const DayflowBridge = registerPlugin<DayflowNative>("DayflowBridge");

export const isAndroidApk = (): boolean => {
  if (typeof window === "undefined") return false;
  if (Capacitor.isNativePlatform() && Capacitor.getPlatform() === "android") return true;
  const host = (window as unknown as { DayflowNativeHost?: unknown }).DayflowNativeHost;
  return Boolean(host);
};

const call = <K extends keyof DayflowNative>(
  name: K,
  ...args: Parameters<DayflowNative[K]>
): ReturnType<DayflowNative[K]> | undefined => {
  if (!isAndroidApk()) return undefined;
  const fn = DayflowBridge[name] as (...a: Parameters<DayflowNative[K]>) => ReturnType<DayflowNative[K]>;
  if (typeof fn !== "function") {
    return Promise.reject(new Error("Android native feature unavailable: " + String(name))) as ReturnType<DayflowNative[K]>;
  }
  return fn(...args);
};

export const nativeBridge = {
  canScheduleExactAlarms: () => call("canScheduleExactAlarms"),
  requestExactAlarmPermission: () => call("requestExactAlarmPermission"),
  scheduleAlarm: (o: Parameters<DayflowNative["scheduleAlarm"]>[0]) => call("scheduleAlarm", o),
  cancelAlarm: (o: Parameters<DayflowNative["cancelAlarm"]>[0]) => call("cancelAlarm", o),
  scheduleReminder: (o: Parameters<DayflowNative["scheduleReminder"]>[0]) => call("scheduleReminder", o),
  cancelReminder: (o: Parameters<DayflowNative["cancelReminder"]>[0]) => call("cancelReminder", o),
  getDeviceTones: () => call("getDeviceTones"),
  pickCustomSoundUri: () => call("pickCustomSoundUri"),
  pinWidget: (o: Parameters<DayflowNative["pinWidget"]>[0]) => call("pinWidget", o),
  getPendingWidgetConfiguration: () => call("getPendingWidgetConfiguration"),
  configureWidget: (o: Parameters<DayflowNative["configureWidget"]>[0]) => call("configureWidget", o),
  openWidgetHub: () => call("openWidgetHub"),
  requestNotificationsPermission: () => call("requestNotificationsPermission"),
  showNotification: (o: Parameters<DayflowNative["showNotification"]>[0]) => call("showNotification", o),
  canDrawOverlays: () => call("canDrawOverlays"),
  startCompanionOverlay: (o: Parameters<DayflowNative["startCompanionOverlay"]>[0]) => call("startCompanionOverlay", o),
  updateCompanionOverlay: (o: Parameters<DayflowNative["updateCompanionOverlay"]>[0]) => call("updateCompanionOverlay", o),
  requestOverlayPermission: () => call("requestOverlayPermission"),
  enqueueDownload: (o: Parameters<DayflowNative["enqueueDownload"]>[0]) => call("enqueueDownload", o),
  analyzeLink: (o: Parameters<DayflowNative["analyzeLink"]>[0]) => call("analyzeLink", o),
  startDownload: (o: Parameters<DayflowNative["startDownload"]>[0]) => call("startDownload", o),
  pauseDownload: (o: Parameters<DayflowNative["pauseDownload"]>[0]) => call("pauseDownload", o),
  cancelDownload: (o: Parameters<DayflowNative["cancelDownload"]>[0]) => call("cancelDownload", o),
  updateEngines: () => call("updateEngines"),
  openSniffer: (o: Parameters<DayflowNative["openSniffer"]>[0]) => call("openSniffer", o),
  getPendingShare: () => call("getPendingShare"),
  syncState: (json: string) => call("syncState", { json }),
  getCurrentLocation: () => call("getCurrentLocation"),
};
