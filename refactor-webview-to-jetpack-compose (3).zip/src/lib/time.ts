import { useStore } from "./store";

/**
 * Strict 12-hour clock formatter throughout DAYFLOW.
 * Always displays hours 1–12 with Arabic (ص / م) or English (AM / PM) period markers,
 * while preserving 24-hour HH:mm internal storage for deterministic scheduling.
 */
export function clockParts(value: string | Date, _hour12 = true, lang: "ar" | "en" = "ar", seconds = false) {
  const bits = typeof value === "string"
    ? value.trim().split(":").map(Number)
    : [value.getHours(), value.getMinutes(), value.getSeconds()];
  const [h, m, sec = 0] = bits;
  if (!Number.isFinite(h) || !Number.isFinite(m)) return { time: "—", suffix: "", full: "—" };
  const normH = ((Math.floor(h) % 24) + 24) % 24;
  const normM = ((Math.floor(m) % 60) + 60) % 60;
  const normS = ((Math.floor(sec) % 60) + 60) % 60;
  const number = (s: string) => (lang === "ar" ? s.replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[+d]) : s);
  const hour12Val = normH % 12 || 12;
  const time = number(`${hour12Val}:${String(normM).padStart(2, "0")}${seconds ? ":" + String(normS).padStart(2, "0") : ""}`);
  const suffix = lang === "ar" ? (normH < 12 ? "ص" : "م") : (normH < 12 ? "AM" : "PM");
  return { time, suffix, full: `${time} ${suffix}` };
}

export function formatTime12(value: string | Date, lang: "ar" | "en" = "ar", seconds = false): string {
  return clockParts(value, true, lang, seconds).full;
}

export function to12hComponents(hhmm: string): { hour12: number; minute: number; period: "AM" | "PM" } {
  const [rawH = 7, rawM = 0] = (hhmm || "07:00").split(":").map(Number);
  const h = Number.isFinite(rawH) ? ((rawH % 24) + 24) % 24 : 7;
  const m = Number.isFinite(rawM) ? Math.max(0, Math.min(59, rawM)) : 0;
  return {
    hour12: h % 12 || 12,
    minute: m,
    period: h < 12 ? "AM" : "PM",
  };
}

export function from12hComponents(hour12: number, minute: number, period: "AM" | "PM"): string {
  const clampedH = Math.max(1, Math.min(12, Math.floor(hour12) || 12));
  const clampedM = Math.max(0, Math.min(59, Math.floor(minute) || 0));
  let h24 = clampedH % 12;
  if (period === "PM") h24 += 12;
  return `${String(h24).padStart(2, "0")}:${String(clampedM).padStart(2, "0")}`;
}

export function useClockFormat() {
  const lang = useStore((s) => s.lang);
  return (value: string | Date, seconds = false) => clockParts(value, true, lang, seconds).full;
}
