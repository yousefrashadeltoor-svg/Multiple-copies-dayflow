import { useClockFormat } from "../lib/time";
import { Plus, Trash2, Bell, Smartphone, FolderOpen, Download, Library, Play, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useStore, useT, nextAlarmTime, fmtNum, type Alarm, type SoundSource } from "../lib/store";
import { nativeBridge, isAndroidApk } from "../lib/nativeBridge";
import { FAMILY, tileDataUri } from "../lib/pattern";
import { Card, Honest, ScreenHeader, Sheet, Toggle, Segmented, TimeField12 } from "../components/ui";
import { EmptyState, HeaderCrown, Motif, useDecor, Particles, SeasonArt } from "../components/Decor";
import { dayKey } from "../lib/calendar";
import { futureAt, isValidDay } from "../lib/temporal";

const ORDER = [6, 0, 1, 2, 3, 4, 5]; // Sat → Fri
const dayName = (d: number, lang: string, style: "narrow" | "short" = "short") => new Date(2024, 0, 7 + d).toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { weekday: style });

export function Alarms() {
  const clockFormat = useClockFormat();
  const t = useT();
  const s = useStore();
  const [edit, setEdit] = useState<Alarm | null>(null);
  const [ringing, setRinging] = useState<Alarm | null>(null);
  const decor = useDecor();
  const next = nextAlarmTime(s.alarms);
  const native = isAndroidApk();
  const blank = (): Alarm => ({ id: "", time: "07:00", days: [0, 1, 2, 3, 4], label: "", enabled: true, sound: { source: "device", title: t("Default alarm (device)", "منبه الجهاز الافتراضي") }, vibrate: true, snooze: 10, gentle: true });
  const daysLabel = (a: Alarm) => a.date && !a.days.length ? new Date(`${a.date}T12:00:00`).toLocaleDateString(s.lang === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "short", year: "numeric" }) : a.days.length === 0 ? t("Once", "مرة واحدة") : a.days.length === 7 ? t("Every day", "كل يوم") : ORDER.filter((d) => a.days.includes(d)).map((d) => dayName(d, s.lang)).join(" · ");

  return (
    <div className="pb-4">
      <ScreenHeader
        title={t("Alarms", "المنبهات")}
        subtitle={next ? t(
          `Next: ${next.at.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" })} · ${clockFormat(next.alarm.time)}`,
          `التالي: ${next.at.toLocaleDateString("ar-EG", { weekday: "short", day: "numeric", month: "short" })} · ${clockFormat(next.alarm.time)}`
        ) : t("No alarms on", "لا منبهات مفعّلة")}
        right={<button className="btn btn-primary" onClick={() => setEdit(blank())}><Plus size={18} />{t("New", "جديد")}</button>}
      />
      {s.alarms.length === 0 && <EmptyState family={decor.primary} title={t("No alarms yet", "مفيش منبهات لسه")} hint={t("Create one in a few seconds.", "أنشئ منبهًا في ثوانٍ.")} action={<button className="btn btn-primary" onClick={() => setEdit(blank())}>{t("Create alarm", "اعمل منبه")}</button>} />}
      <div className="space-y-3">
        {[...s.alarms].sort((a, b) => a.time.localeCompare(b.time)).map((a) => (
          <Card key={a.id} className="flex items-center gap-4 p-4" onClick={() => setEdit(a)}>
            <div className="flex-1" style={{ opacity: a.enabled ? 1 : 0.5 }}>
              <p className="text-4xl font-semibold tracking-tight">{clockFormat(a.time)}</p>
              <p className="mt-0.5 text-sm font-medium">{a.label || t("Alarm", "منبه")}</p>
              <p className="text-xs muted">{daysLabel(a)} · {a.sound.title}</p>
            </div>
            <Toggle
              on={a.enabled}
              onChange={async (v) => {
                if (v && native) {
                  const perm = await nativeBridge.canScheduleExactAlarms?.();
                  if (perm && !perm.granted) {
                    await nativeBridge.requestExactAlarmPermission?.();
                    return;
                  }
                }
                try {
                  if (v) await nativeBridge.scheduleAlarm({ id: a.id, date: a.date, time: a.time, days: a.days, label: a.label, soundUri: a.sound.uri, vibrate: a.vibrate, snooze: a.snooze, gentle: a.gentle });
                  else await nativeBridge.cancelAlarm({ id: a.id });
                  s.updateAlarm(a.id, { enabled: v });
                } catch {
                  if (!native) s.updateAlarm(a.id, { enabled: v });
                }
              }}
              label={a.label || clockFormat(a.time)}
            />
          </Card>
        ))}
      </div>
      {!native && <div className="mt-5"><Honest>{t("You are viewing DAYFLOW in a web browser, so alarms ring while this tab is open. On the native Android app, alarms are scheduled with AlarmManager.setAlarmClock() and ring even if the phone is locked or closed.", "أنت تتصفح النسخة عبر المتصفح، لذا يرن المنبه أثناء فتح الصفحة. في تطبيق أندرويد الأصلي تُجدول المنبهات عبر AlarmManager.setAlarmClock() وترن حتى والهاتف مقفل أو التطبيق مغلق.")}</Honest></div>}
      {edit && <AlarmEditor alarm={edit} onClose={() => setEdit(null)} onPreview={(a) => { setEdit(null); setRinging(a); }} />}
      {ringing && <RingScreen alarm={ringing} isPreview onClose={() => setRinging(null)} />}
    </div>
  );
}

function AlarmEditor({ alarm, onClose, onPreview }: { alarm: Alarm; onClose: () => void; onPreview: (a: Alarm) => void }) {
  const t = useT();
  const s = useStore();
  const [a, setA] = useState<Alarm>(alarm);
  const [picker, setPicker] = useState(false);
  const [error, setError] = useState("");
  const native = isAndroidApk();

  const save = async () => {
    if (!a.days.length && !a.date) {
      const now = new Date();
      const [hh, mm] = a.time.split(":").map(Number);
      const cand = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, 0, 0);
      if (cand <= now) cand.setDate(cand.getDate() + 1);
      a.date = dayKey(cand);
    }
    if (a.date && !a.days.length && (!isValidDay(a.date) || !futureAt(a.date, a.time))) {
      setError(t("That date and time have already passed. Pick a future time.", "المعاد ده فات؛ اختار يوم وساعة لسه جايين."));
      return;
    }
    if (a.enabled && native) {
      const permission = await nativeBridge.canScheduleExactAlarms?.();
      if (permission && !permission.granted) {
        await nativeBridge.requestExactAlarmPermission?.();
        setError(t("Allow DAYFLOW to set exact alarms in Android Settings, then tap Save again.", "اسمح لـ DAYFLOW بضبط المنبهات الدقيقة من إعدادات أندرويد، ثم اضغط حفظ مرة أخرى."));
        return;
      }
    }
    const id = a.id ? (s.updateAlarm(a.id, a), a.id) : s.addAlarm(a);
    if (!a.id) setA({ ...a, id });
    try {
      if (a.enabled) await nativeBridge.scheduleAlarm({ id, date: a.date, time: a.time, days: a.days, label: a.label, soundUri: a.sound.uri, vibrate: a.vibrate, snooze: a.snooze, gentle: a.gentle });
      else await nativeBridge.cancelAlarm({ id });
    } catch {
      if (native) {
        setError(t("Android could not schedule this alarm. Check Alarms & reminders access and try again.", "تعذّر على أندرويد جدولة المنبه. تأكد من صلاحية المنبهات والتذكيرات وحاول مجددًا."));
        return;
      }
    }
    onClose();
  };

  const presets = [{ id: "wd", en: "Sun–Thu", ar: "الأحد–الخميس", d: [0, 1, 2, 3, 4] }, { id: "we", en: "Fri–Sat", ar: "الجمعة–السبت", d: [5, 6] }, { id: "all", en: "Every day", ar: "كل يوم", d: [0, 1, 2, 3, 4, 5, 6] }];
  return (
    <Sheet open onClose={onClose} title={a.id ? t("Edit alarm", "تعديل المنبه") : t("New alarm", "منبه جديد")}>
      <TimeField12 large value={a.time} onChange={(val) => setA({ ...a, time: val })} className="mb-4" />
      <div className="mb-2 flex flex-wrap gap-1.5">
        <button className="chip" aria-pressed={!!a.date && !a.days.length} onClick={() => setA({ ...a, date: a.date || dayKey(new Date()), days: [] })}>{t("One specific date", "يوم معيّن")}</button>
        {presets.map((p) => <button key={p.id} className="chip" aria-pressed={!a.date && JSON.stringify([...a.days].sort()) === JSON.stringify(p.d)} onClick={() => setA({ ...a, date: undefined, days: p.d })}>{s.lang === "ar" ? p.ar : p.en}</button>)}
      </div>
      {a.date && !a.days.length && <label className="mb-3 block text-xs font-semibold muted">{t("Alarm date", "تاريخ المنبّه")}<input type="date" className="field mt-1" min={dayKey(new Date())} value={a.date} onChange={(e) => setA({ ...a, date: e.target.value })} /></label>}
      <div className="mb-4 grid grid-cols-7 gap-1">
        {ORDER.map((d) => <button key={d} onClick={() => setA({ ...a, date: undefined, days: a.days.includes(d) ? a.days.filter((x) => x !== d) : [...a.days, d] })} aria-pressed={a.days.includes(d)} className="chip justify-center px-0 py-2">{dayName(d, s.lang, "narrow")}</button>)}
      </div>
      <input value={a.label} onChange={(e) => setA({ ...a, label: e.target.value })} className="field mb-3" placeholder={t("Label (optional)", "الاسم (اختياري)")} />
      <button onClick={() => setPicker(true)} className="card mb-3 flex w-full items-center gap-3 p-3 text-start"><Bell size={18} className="accent" /><span className="flex-1"><span className="block text-sm font-medium">{t("Sound", "الصوت")}</span><span className="block text-xs muted">{a.sound.title}</span></span></button>
      <div className="card mb-3 divide-y divide-[var(--line)]">
        <label className="flex items-center justify-between p-3 text-sm">{t("Vibrate", "اهتزاز")}<Toggle on={a.vibrate} onChange={(v) => setA({ ...a, vibrate: v })} label="vibrate" /></label>
        <label className="flex items-center justify-between p-3 text-sm"><span>{t("Gentle wake", "استيقاظ لطيف")}<span className="block text-xs muted">{t("Volume rises over 60 seconds", "يرتفع الصوت خلال ٦٠ ثانية")}</span></span><Toggle on={a.gentle} onChange={(v) => setA({ ...a, gentle: v })} label="gentle" /></label>
        <label className="flex items-center justify-between p-3 text-sm">{t("Snooze", "الغفوة")}<select className="field w-28 py-1" value={a.snooze} onChange={(e) => setA({ ...a, snooze: +e.target.value })}>{[5, 10, 15, 20].map((m) => <option key={m} value={m}>{fmtNum(m, s.lang)} {t("min", "د")}</option>)}</select></label>
      </div>
      <div className="flex gap-2">
        {a.id && <button className="btn btn-ghost" onClick={() => { s.removeAlarm(a.id); void nativeBridge.cancelAlarm({ id: a.id }); onClose(); }} aria-label={t("Delete", "حذف")}><Trash2 size={16} /></button>}
        <button className="btn btn-soft" onClick={() => onPreview(a)}><Play size={16} />{t("Preview", "معاينة")}</button>
        <button className="btn btn-primary flex-1" onClick={() => void save()}>{t("Save", "حفظ")}</button>
      </div>
      {error && <p role="alert" className="mt-2 text-xs text-red-600">{error}</p>}
      {picker && <SoundPicker value={a.sound} onPick={(snd) => { setA({ ...a, sound: snd }); setPicker(false); }} onClose={() => setPicker(false)} />}
    </Sheet>
  );
}

export function SoundPicker({ value, onPick, onClose }: { value: Alarm["sound"]; onPick: (s: Alarm["sound"]) => void; onClose: () => void }) {
  const t = useT();
  const [src, setSrc] = useState<SoundSource>(value.source);
  const audio = useRef<HTMLAudioElement | null>(null);
  const [file, setFile] = useState<{ name: string; url: string } | null>(null);
  const native = isAndroidApk();
  useEffect(() => () => { audio.current?.pause(); if (file && file.url.startsWith("blob:")) URL.revokeObjectURL(file.url); }, [file]);
  const [nativeTones, setNativeTones] = useState<Array<{ title: string; uri: string }> | null>(null);
  useEffect(() => { nativeBridge.getDeviceTones()?.then((r) => { if (r?.tones?.length) setNativeTones(r.tones.map((x) => ({ title: x.title, uri: x.uri }))); }).catch(() => {}); }, []);
  const device = nativeTones || [
    { title: t("Default alarm (device)", "منبه الجهاز الافتراضي"), uri: "" },
    { title: t("Default ringtone (device)", "نغمة الرنين الافتراضية"), uri: "content://settings/system/ringtone" },
    { title: t("Default notification (device)", "صوت الإشعار الافتراضي"), uri: "content://settings/system/notification_sound" },
  ];

  const pickAndroidAudio = async () => {
    const picked = await nativeBridge.pickCustomSoundUri?.();
    if (picked?.uri) {
      onPick({ source: "files", title: picked.title || "Custom tone", uri: picked.uri });
    }
  };

  return (
    <Sheet open onClose={onClose} title={t("Choose a sound", "اختر صوتًا")}>
      <Segmented value={src} onChange={setSrc} options={[{ id: "library", label: "DAYFLOW" }, { id: "device", label: t("Device", "الجهاز") }, { id: "files", label: t("My files", "ملفاتي") }, { id: "downloaded", label: t("Downloaded", "المنزّلة") }]} />
      <div className="mt-4 min-h-40 max-h-72 overflow-y-auto">
        {src === "library" && <div className="space-y-1">
          {[
            { title: t("Calm Fajr Chime", "رنين الفجر الهادئ"), uri: "dayflow://chime-fajr" },
            { title: t("Nile Morning Harp", "قيثارة الصباح"), uri: "dayflow://chime-nile" },
            { title: t("Classic Brass Bell", "جرس نحاسي كلاسيكي"), uri: "dayflow://chime-bell" },
          ].map((tone) => (
            <button key={tone.uri} onClick={() => onPick({ source: "library", title: tone.title, uri: tone.uri })} className="flex w-full items-center gap-3 py-3 text-start">
              <Library size={18} className="accent" />
              <span className="flex-1">{tone.title}</span>
              {value.title === tone.title && <span className="chip" aria-pressed="true">✓</span>}
            </button>
          ))}
        </div>}
        {src === "device" && <>
          {device.map((d) => <button key={d.uri || d.title} onClick={() => onPick({ source: "device", title: d.title, uri: d.uri })} className="flex w-full items-center gap-3 py-3 text-start"><Smartphone size={18} className="accent" /><span className="flex-1">{d.title}</span>{value.title === d.title && <span className="chip" aria-pressed="true">✓</span>}</button>)}
          {!native && <Honest>{t("A browser can't list your phone's OEM ringtones, so defaults are shown here. On the Android app, RingtoneManager lists every alarm and ringtone on your phone.", "المتصفح لا يستطيع قراءة نغمات الهاتف، لذا تظهر الافتراضية هنا. في تطبيق أندرويد يعرض RingtoneManager كافة نغمات الجهاز.")}</Honest>}
        </>}
        {src === "files" && <div>
          {native ? (
            <button className="btn btn-soft w-full" onClick={() => void pickAndroidAudio()}><FolderOpen size={16} />{t("Pick an audio file from phone", "اختر ملفًا صوتيًا أو موسيقى من الهاتف")}</button>
          ) : (
            <label className="btn btn-soft w-full"><FolderOpen size={16} />{t("Pick an audio file", "اختر ملفًا صوتيًا")}<input type="file" accept="audio/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) setFile({ name: f.name, url: URL.createObjectURL(f) }); }} /></label>
          )}
          {file && <div className="mt-3 flex items-center gap-2"><button className="btn btn-ghost" onClick={() => { audio.current?.pause(); audio.current = new Audio(file.url); audio.current.play().catch(() => {}); }}><Play size={14} /></button><span className="flex-1 truncate text-sm">{file.name}</span><button className="btn btn-primary" onClick={() => onPick({ source: "files", title: file.name, uri: file.url })}>{t("Use", "استخدم")}</button></div>}
        </div>}
        {src === "downloaded" && <div className="text-center py-4"><Download className="mx-auto mb-2 muted" /><p className="text-sm muted">{t("Audio downloaded in DAYFLOW Downloads can be selected from My files or saved directly as an alarm tone.", "الصوتيات المحمّلة عبر قسم التحميلات يمكنك اختيارها مباشرة كنغمة منبه.")}</p></div>}
      </div>
    </Sheet>
  );
}

export function RingScreen({ alarm, isPreview = false, onClose, onSnooze }: { alarm: Alarm; isPreview?: boolean; onClose: () => void; onSnooze?: () => void }) {
  const clockFormat = useClockFormat();
  const t = useT();
  const lang = useStore((s) => s.lang);
  const decor = useDecor();
  const st = useStore();
  const f = FAMILY[decor.primary];
  const look = st.alarmLook;
  const [slide, setSlide] = useState(0);
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const tick = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(tick);
  }, []);

  // Synthesize real pleasant chime / play custom audio + vibrate while RingScreen is active
  useEffect(() => {
    if (alarm.vibrate) navigator.vibrate?.([500, 250, 500, 250, 500]);
    let ctx: AudioContext | null = null;
    let timer: number | null = null;
    let audioEl: HTMLAudioElement | null = null;
    const startAt = Date.now();
    try {
      if (alarm.sound.uri && (alarm.sound.uri.startsWith("blob:") || alarm.sound.uri.startsWith("http"))) {
        audioEl = new Audio(alarm.sound.uri);
        audioEl.loop = true;
        audioEl.volume = alarm.gentle ? 0.15 : 0.9;
        void audioEl.play().catch(() => {});
      } else {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AC) {
          ctx = new AC();
          const playPattern = () => {
            if (!ctx) return;
            const elapsed = (Date.now() - startAt) / 1000;
            const vol = alarm.gentle ? Math.min(0.4, 0.05 + (elapsed / 60) * 0.35) : 0.35;
            const notes = alarm.sound.uri === "dayflow://chime-bell" ? [587.33, 880, 1174.66] : [523.25, 659.25, 783.99, 1046.5];
            notes.forEach((freq, idx) => {
              if (!ctx) return;
              const osc = ctx.createOscillator();
              const gain = ctx.createGain();
              osc.type = "sine";
              osc.frequency.value = freq;
              const t0 = ctx.currentTime + idx * 0.18;
              gain.gain.setValueAtTime(0.001, t0);
              gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.04);
              gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.55);
              osc.connect(gain);
              gain.connect(ctx.destination);
              osc.start(t0);
              osc.stop(t0 + 0.6);
            });
          };
          playPattern();
          timer = window.setInterval(playPattern, 2200);
        }
      }
    } catch { /* audio autoplay blocked */ }
    return () => {
      navigator.vibrate?.(0);
      if (timer !== null) clearInterval(timer);
      audioEl?.pause();
      void ctx?.close().catch(() => {});
    };
  }, [alarm.vibrate, alarm.gentle, alarm.sound.uri]);

  useEffect(() => { if (slide >= 95) onClose(); }, [slide, onClose]);

  const handleSnooze = () => {
    if (onSnooze) onSnooze();
    else {
      const snoozeAt = new Date(Date.now() + alarm.snooze * 60_000);
      const hhmm = `${String(snoozeAt.getHours()).padStart(2, "0")}:${String(snoozeAt.getMinutes()).padStart(2, "0")}`;
      const dKey = dayKey(snoozeAt);
      const id = st.addAlarm({ ...alarm, date: dKey, time: hhmm, days: [], label: `${alarm.label || t("Alarm", "منبه")} (${t("Snooze", "غفوة")})`, enabled: true });
      void nativeBridge.scheduleAlarm({ id, date: dKey, time: hhmm, days: [], label: alarm.label || "DAYFLOW", soundUri: alarm.sound.uri, vibrate: alarm.vibrate, snooze: alarm.snooze, gentle: false })?.catch(() => {});
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex flex-col items-center justify-between overflow-hidden p-8 pb-[calc(2rem+var(--safe-b))] text-white fade-in" style={{ background: look.gradient ? `linear-gradient(170deg, ${f.c2}, #0b0f1a)` : "#0b0f1a" }} role="alertdialog" aria-label={t("Alarm ringing", "المنبه يرن")}>
      <div className="absolute inset-0" style={{ backgroundImage: tileDataUri(decor.primary, "#fff", 0.12, 70) }} />
      <Particles family={decor.primary} intensity="rich" />
      <SeasonArt family={decor.primary} size={64} style={{ top: 70, insetInlineStart: 22, opacity: .95 }} />
      <SeasonArt family={decor.primary} size={44} style={{ bottom: 150, insetInlineEnd: 26, opacity: .8, transform: "rotate(-14deg)" }} />
      <div className="absolute inset-x-0 top-0"><HeaderCrown family={decor.primary} height={70} /></div>
      <button onClick={onClose} className="absolute end-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-white/15" aria-label="Close"><X size={16} /></button>
      <div className="relative mt-20 text-center">
        <p className="text-sm uppercase tracking-[.3em] opacity-70">{isPreview ? t("Preview", "معاينة") : t("Alarm", "منبه")}</p>
        <p className="mt-4 font-extralight leading-none tracking-tight" style={{ fontSize: look.layout === "minimal" ? "3.8rem" : "4.6rem", letterSpacing: look.layout === "ornate" ? "0" : "-.02em" }}>
          {clockFormat(isPreview ? alarm.time : now, look.showSeconds)}
        </p>
        <p className="mt-3 text-lg opacity-90">{alarm.label || t("Alarm", "منبه")}</p>
        <p className="text-sm opacity-60">{now.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", { weekday: "long", day: "numeric", month: "long" })}</p>
      </div>
      <div className="relative grid place-items-center">
        <span className="absolute h-36 w-36 rounded-full border-2 border-white/40" style={{ animation: "ring-pulse 2s infinite" }} />
        <div className="grid h-36 w-36 place-items-center rounded-full" style={{ background: "rgba(255,255,255,.12)" }}><Motif family={decor.primary} size={80} mono="#fff" /></div>
      </div>
      <div className="relative w-full max-w-sm space-y-4">
        <button onClick={handleSnooze} className="w-full rounded-full bg-white/15 py-4 text-lg font-semibold backdrop-blur">{t(`Snooze ${alarm.snooze} min`, `غفوة ${fmtNum(alarm.snooze, lang)} دقائق`)}</button>
        <label className="relative block">
          <span className="sr-only">{t("Slide to dismiss", "اسحب للإيقاف")}</span>
          <input type="range" min={0} max={100} value={slide} onChange={(e) => setSlide(+e.target.value)} onPointerUp={() => slide < 95 && setSlide(0)} className="h-16 w-full cursor-pointer appearance-none rounded-full bg-white/20 accent-white" />
          <span className="pointer-events-none absolute inset-0 grid place-items-center text-sm font-semibold opacity-80">{t("Slide to dismiss →", "← اسحب للإيقاف")}</span>
        </label>
      </div>
    </div>
  );
}
