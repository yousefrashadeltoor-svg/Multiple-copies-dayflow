import { useEffect, useMemo, useRef, useState } from "react";
import { Search, Plus, Minus, Trash2, LayoutGrid, Hand, MousePointerClick, CheckCircle2, Sparkles } from "lucide-react";
import { useStore, useT } from "../lib/store";
import { nativeBridge, isAndroidApk } from "../lib/nativeBridge";
import { WIDGETS, WCATS, WSTYLES, FORMS, formSize, resolveForm, type WidgetDef, type Form, type WStyle, type WCat } from "../lib/widgets";
import { Card, Honest, ScreenHeader, Segmented, Sheet, Toggle } from "../components/ui";
import { WidgetRenderer } from "../components/WidgetRenderer";

function LazyWidgetTile({ def, form, style, onClick }: { def: WidgetDef; form: Form; style: WStyle; onClick: () => void }) {
  const lang = useStore((s) => s.lang);
  const t = useT();
  const ref = useRef<HTMLButtonElement | null>(null);
  const [visible, setVisible] = useState(false);
  const [w, h] = formSize(form);
  const W = w * 58 + (w - 1) * 8, H = h * 58 + (h - 1) * 8;

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") { setVisible(true); return; }
    const io = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) { setVisible(true); io.disconnect(); }
    }, { rootMargin: "180px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <button ref={ref} onClick={onClick} className="flex-none text-start">
      <div className="pointer-events-none" style={{ width: W, height: H }}>
        {visible ? <WidgetRenderer def={def} form={form} style={style} cell={58} gap={8} live={false} /> : <div className="h-full w-full rounded-[22px] bg-white/15 shimmer" />}
      </div>
      <p className="mt-1.5 max-w-[124px] truncate text-xs font-semibold text-white drop-shadow">{lang === "ar" ? def.ar : def.en}</p>
      <p className="text-[10px] text-white/70">{def.forms.length} {t("forms", "أشكال")}{def.interactive ? " · " + t("interactive", "تفاعلي") : ""}</p>
    </button>
  );
}

export function WidgetHub({ onBack }: { onBack: () => void }) {
  const t = useT();
  const s = useStore();
  const pending = s.pendingWidgetConfig;
  const native = isAndroidApk();
  const [mode, setMode] = useState<"catalog" | "board">("catalog");
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<WCat | "all">("all");
  const [size, setSize] = useState<Form | "any">(pending?.form || "any");
  const [style, setStyle] = useState<WStyle>("oneui");
  const [sel, setSel] = useState<WidgetDef | null>(null);
  const [boundNotice, setBoundNotice] = useState("");

  useEffect(() => {
    if (pending?.form) {
      setMode("catalog");
      setSize(pending.form);
    }
  }, [pending?.widgetId, pending?.form]);

  const list = useMemo(() => WIDGETS.filter((w) => (cat === "all" || w.cat === cat) && (size === "any" || w.forms.includes(size)) && (!q || (w.en + w.ar).toLowerCase().includes(q.toLowerCase()))), [cat, size, q]);
  const grouped = WCATS.map((c) => ({ c, items: list.filter((w) => w.cat === c.id) })).filter((g) => g.items.length);

  return (
    <div className="pb-4">
      <ScreenHeader title={t("Widgets", "الودجات")} subtitle={t(`${WIDGETS.length} designs · every one changes shape when resized`, `${WIDGETS.length} تصميمًا · كل تصميم يتغير شكله عند تغيير الحجم`)} onBack={onBack} />

      {pending && (
        <Card className="mb-3 border-2 p-3.5 fade-in" style={{ borderColor: "var(--accent)", background: "color-mix(in oklch, var(--accent) 12%, var(--surface))" }}>
          <div className="flex items-start gap-2.5">
            <span className="grid h-9 w-9 flex-none place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--on-accent)" }}><Sparkles size={18} /></span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">
                {t(`Choose a widget for your Home Screen (${pending.w}×${pending.h})`, `اختر واحدة لتكون هي الويدجيت على شاشتك الرئيسية (${pending.w}×${pending.h})`)}
              </p>
              <p className="mt-0.5 text-xs muted">
                {t("Tap any design below, customize its style, and confirm to place it directly on your phone home screen.", "اضغط على أي تصميم بالأسفل واختر نمطه ليتم تعيينه فورًا في الويدجيت الذي أضفته على شاشة الهاتف.")}
              </p>
            </div>
          </div>
        </Card>
      )}

      {boundNotice && (
        <Card className="mb-3 flex items-center gap-2 p-3 text-xs font-semibold accent fade-in">
          <CheckCircle2 size={16} />
          <span>{boundNotice}</span>
        </Card>
      )}

      <Segmented value={mode} onChange={setMode} options={[{ id: "catalog", label: t("Catalog", "الكتالوج") }, { id: "board", label: t(`Home preview (${s.placed.length})`, `معاينة الشاشة (${s.placed.length})`) }]} />

      {mode === "catalog" && <>
        <div className="relative my-3"><Search size={16} className="muted absolute start-3 top-1/2 -translate-y-1/2" /><input value={q} onChange={(e) => setQ(e.target.value)} className="field ps-9" placeholder={t("Search widgets", "ابحث في الودجات")} /></div>
        <div className="scroll-hide -mx-4 mb-2 flex gap-1.5 overflow-x-auto px-4">
          <button className="chip" aria-pressed={cat === "all"} onClick={() => setCat("all")}>{t("All", "الكل")}</button>
          {WCATS.map((c) => <button key={c.id} className="chip" aria-pressed={cat === c.id} onClick={() => setCat(c.id)}>{s.lang === "ar" ? c.ar : c.en}</button>)}
        </div>
        <div className="scroll-hide -mx-4 mb-2 flex gap-1.5 overflow-x-auto px-4">
          <button className="chip" aria-pressed={size === "any"} onClick={() => setSize("any")}>{t("Any size", "أي حجم")}</button>
          {FORMS.map((f) => <button key={f} className="chip" aria-pressed={size === f} onClick={() => setSize(f)}>{f.replace("x", "×")}</button>)}
        </div>
        <div className="scroll-hide -mx-4 mb-4 flex gap-1.5 overflow-x-auto px-4">
          {WSTYLES.map((w) => <button key={w.id} className="chip" aria-pressed={style === w.id} onClick={() => setStyle(w.id)}>{s.lang === "ar" ? w.ar : w.en}</button>)}
        </div>
        {grouped.map(({ c, items }) => (
          <section key={c.id} className="mb-6">
            <h3 className="mb-2 px-1 font-bold">{s.lang === "ar" ? c.ar : c.en} <span className="text-xs font-normal muted">{items.length}</span></h3>
            <div className="wallpaper scroll-hide -mx-4 flex gap-3 overflow-x-auto px-4 py-4">
              {items.map((w) => {
                const f: Form = size !== "any" ? size : pending?.form && w.forms.includes(pending.form) ? pending.form : w.forms.includes("2x2") ? "2x2" : w.forms[0];
                return <LazyWidgetTile key={w.id} def={w} form={f} style={style} onClick={() => setSel(w)} />;
              })}
            </div>
          </section>
        ))}
        {!native && <Honest>{t("When you add any DAYFLOW widget size (1×1, 2×1, 2×2, 4×1, 4×2, 4×4) on your Android home screen, DAYFLOW opens directly here so you can pick the exact design for that widget.", "عند إضافة أي حجم ويدجيت لـ DAYFLOW من شاشة الهاتف الرئيسية (١×١، ٢×١، ٢×٢، ٤×١، ٤×٢، ٤×٤)، يفتح التطبيق مباشرة على هذه الشاشة لتختار التصميم الذي تريده لذلك الويدجيت.")}</Honest>}
      </>}

      {mode === "board" && <Board />}

      {sel && (
        <WidgetDetail
          def={sel}
          initialForm={pending?.form && sel.forms.includes(pending.form) ? pending.form : size !== "any" && sel.forms.includes(size) ? size : undefined}
          initialStyle={style}
          onClose={() => setSel(null)}
          onAdded={(msg) => {
            setSel(null);
            if (msg) setBoundNotice(msg);
            else setMode("board");
          }}
        />
      )}
    </div>
  );
}

function WidgetDetail({ def, initialForm, initialStyle, onClose, onAdded }: { def: WidgetDef; initialForm?: Form; initialStyle: WStyle; onClose: () => void; onAdded: (msg?: string) => void }) {
  const t = useT(); const s = useStore();
  const pending = s.pendingWidgetConfig;
  const native = isAndroidApk();
  const [form, setForm] = useState<Form>(initialForm || (def.forms.includes("2x2") ? "2x2" : def.forms[0]));
  const [style, setStyle] = useState<WStyle>(initialStyle);
  const [w, h] = formSize(form);

  const confirmWidget = async () => {
    if (pending) {
      s.placeWidget(def.id, pending.w, pending.h, style, pending.widgetId);
      await nativeBridge.configureWidget?.({
        widgetId: pending.widgetId,
        designId: def.id,
        title: s.lang === "ar" ? def.ar : def.en,
        style,
        width: pending.w,
        height: pending.h,
      })?.catch(() => {});
      s.set({ pendingWidgetConfig: null });
      onAdded(t(`Widget "${def.en}" assigned to your home screen!`, `تم تعيين ويدجيت «${def.ar}» على الشاشة الرئيسية بنجاح!`));
      return;
    }
    s.placeWidget(def.id, w, h, style);
    await nativeBridge.pinWidget?.({ designId: def.id, style, w, h })?.catch(() => {});
    onAdded();
  };

  return (
    <Sheet open onClose={onClose} title={s.lang === "ar" ? def.ar : def.en} wide>
      <div className="wallpaper -mx-5 mb-4 grid min-h-[300px] place-items-center p-4 overflow-x-auto">
        <WidgetRenderer def={def} form={form} style={style} cell={w >= 4 ? 70 : 80} gap={10} />
      </div>
      <p className="mb-1.5 text-xs font-semibold muted">{t("Form (resize)", "الشكل (تغيير الحجم)")}</p>
      <div className="mb-3 flex flex-wrap gap-1.5">{def.forms.map((f) => <button key={f} className="chip" aria-pressed={form === f} onClick={() => setForm(f)}>{f.replace("x", "×")}</button>)}</div>
      <p className="mb-1.5 text-xs font-semibold muted">{t("Style", "النمط")}</p>
      <div className="mb-4 flex flex-wrap gap-1.5">{WSTYLES.map((x) => <button key={x.id} className="chip" aria-pressed={style === x.id} onClick={() => setStyle(x.id)}>{s.lang === "ar" ? x.ar : x.en}</button>)}</div>
      <p className="mb-4 flex items-center gap-2 text-xs muted">{def.interactive ? <><MousePointerClick size={14} />{t("Interactive buttons and checkboxes respond immediately.", "الأزرار والمربعات التفاعلية تستجيب فورًا.")}</> : <><Hand size={14} />{t("Tapping opens DAYFLOW directly.", "النقر عليه يفتح DAYFLOW مباشرة.")}</>}</p>
      <button className="btn btn-primary w-full" onClick={() => void confirmWidget()}>
        <Plus size={16} />
        {pending
          ? t(`Set as Home Screen Widget (${pending.w}×${pending.h})`, `تعيين كـ ويدجيت الشاشة الرئيسية (${pending.w}×${pending.h})`)
          : native
            ? t("Pin to Home Screen", "تثبيت على الشاشة الرئيسية")
            : t("Add to home preview", "أضف إلى معاينة الشاشة")}
      </button>
    </Sheet>
  );
}

function Board() {
  const t = useT(); const s = useStore();
  const [cell, gap] = [72, 10];
  const [editing, setEditing] = useState<string | null>(null);
  if (!s.placed.length) return <div className="wallpaper mt-4 grid min-h-[380px] place-items-center rounded-3xl p-6 text-center text-white"><div><LayoutGrid className="mx-auto mb-2" /><p className="font-semibold">{t("Your home preview is empty", "معاينة الشاشة فارغة")}</p><p className="mt-1 text-sm opacity-75">{t("Add widgets from the catalog, then resize them here to watch them change form.", "أضف ودجات من الكتالوج ثم غيّر حجمها هنا لترى تغير شكلها.")}</p></div></div>;
  return (
    <div className="mt-4">
      <div className="wallpaper mx-auto overflow-hidden rounded-[2rem] p-4" style={{ maxWidth: cell * 4 + gap * 3 + 32 }}>
        <div className="flex flex-wrap" style={{ gap }}>
          {s.placed.map((p) => {
            const def = WIDGETS.find((w) => w.id === p.designId); if (!def) return null;
            const form = resolveForm(def, p.w, p.h);
            const [fw, fh] = formSize(form);
            return (
              <div key={p.id} className="relative" onContextMenu={(e) => { e.preventDefault(); setEditing(p.id); }}>
                <div style={{ width: p.w * cell + (p.w - 1) * gap, height: p.h * cell + (p.h - 1) * gap }} className="grid place-items-center" onDoubleClick={() => setEditing(p.id)}>
                  <WidgetRenderer def={def} form={form} style={p.style} cell={cell} gap={gap} />
                </div>
                <button onClick={() => setEditing(editing === p.id ? null : p.id)} className="absolute -end-1.5 -top-1.5 z-10 grid h-6 w-6 place-items-center rounded-full bg-white text-xs font-bold text-black shadow" aria-label={t("Edit widget", "تعديل الودجت")}>⋯</button>
                {editing === p.id && (
                  <div className="absolute inset-x-0 -bottom-2 z-20 translate-y-full rounded-2xl bg-white p-2 text-black shadow-xl" style={{ minWidth: 220 }}>
                    <p className="mb-1 text-[11px] font-semibold">{t("Size", "الحجم")} {p.w}×{p.h} → {t("form", "الشكل")} {fw}×{fh}</p>
                    <div className="mb-2 flex items-center gap-1 text-xs">
                      W <button className="rounded bg-black/10 p-1" onClick={() => s.updatePlaced(p.id, { w: Math.max(1, p.w - 1) })}><Minus size={12} /></button><button className="rounded bg-black/10 p-1" onClick={() => s.updatePlaced(p.id, { w: Math.min(4, p.w + 1) })}><Plus size={12} /></button>
                      <span className="w-3" />H <button className="rounded bg-black/10 p-1" onClick={() => s.updatePlaced(p.id, { h: Math.max(1, p.h - 1) })}><Minus size={12} /></button><button className="rounded bg-black/10 p-1" onClick={() => s.updatePlaced(p.id, { h: Math.min(4, p.h + 1) })}><Plus size={12} /></button>
                    </div>
                    <select className="mb-2 w-full rounded border p-1 text-xs" value={p.style} onChange={(e) => s.updatePlaced(p.id, { style: e.target.value as WStyle })}>{WSTYLES.map((x) => <option key={x.id} value={x.id}>{s.lang === "ar" ? x.ar : x.en}</option>)}</select>
                    {!def.interactive && <label className="mb-2 flex items-center justify-between text-xs">{t("Tap opens DAYFLOW", "النقر يفتح DAYFLOW")}<Toggle on={p.tapOpens} onChange={(v) => s.updatePlaced(p.id, { tapOpens: v })} label="tap" /></label>}
                    <div className="flex gap-1"><button className="flex-1 rounded bg-black/10 py-1 text-xs" onClick={() => setEditing(null)}>{t("Done", "تم")}</button><button className="rounded bg-red-500/15 px-2 text-red-600" onClick={() => { s.removePlaced(p.id); setEditing(null); }} aria-label={t("Remove", "إزالة")}><Trash2 size={13} /></button></div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
      <p className="mt-3 text-center text-xs muted">{t("Tap ⋯ to resize. The form resolver picks the best design for each size, like Android 12+ responsive widgets.", "اضغط ⋯ لتغيير الحجم. يختار محلل الأشكال أفضل تصميم لكل حجم، مثل ودجات أندرويد ١٢+ المتجاوبة.")}</p>
    </div>
  );
}
