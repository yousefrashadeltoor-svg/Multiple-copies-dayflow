import sharp from "sharp";
import fs from "fs";

fs.mkdirSync("src/assets/decor", { recursive: true });

const W = 192;

const SPRITES = {
  // 1. Realistic Crimson Maple Leaf with stem, serrated lobes & veins
  maple: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="mlg" x1="0.2" y1="0.1" x2="0.85" y2="0.95">
        <stop offset="0%" stop-color="#e85d2a"/>
        <stop offset="45%" stop-color="#c6331e"/>
        <stop offset="85%" stop-color="#8b1b13"/>
        <stop offset="100%" stop-color="#5c110c"/>
      </linearGradient>
      <radialGradient id="mlh" cx="38%" cy="32%" r="55%">
        <stop offset="0%" stop-color="#ffb347" stop-opacity="0.65"/>
        <stop offset="100%" stop-color="#ffb347" stop-opacity="0"/>
      </radialGradient>
      <filter id="ds" x="-15%" y="-15%" width="130%" height="130%">
        <feDropShadow dx="0" dy="3" stdDeviation="3" flood-color="#2a0800" flood-opacity="0.35"/>
      </filter>
    </defs>
    <g filter="url(#ds)">
      <path d="M64 8 L72 30 L88 22 L83 43 L108 38 L95 57 L118 65 L92 76 L98 92 L74 86 L66 102 L62 102 L54 86 L30 92 L36 76 L10 65 L33 57 L20 38 L45 43 L40 22 L56 30 Z" fill="url(#mlg)" stroke="#5e120b" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M64 8 L72 30 L88 22 L83 43 L108 38 L95 57 L118 65 L92 76 L98 92 L74 86 L66 102 L62 102 L54 86 L30 92 L36 76 L10 65 L33 57 L20 38 L45 43 L40 22 L56 30 Z" fill="url(#mlh)"/>
      <path d="M64 100 C64 110 61 118 57 123" fill="none" stroke="#5a2612" stroke-width="3.2" stroke-linecap="round"/>
      <g stroke="#f5a25d" stroke-opacity="0.55" stroke-width="1.3" stroke-linecap="round" fill="none">
        <path d="M64 16 L64 98"/>
        <path d="M64 52 L98 42"/><path d="M64 52 L30 42"/>
        <path d="M64 68 L104 65"/><path d="M64 68 L24 65"/>
        <path d="M64 80 L88 87"/><path d="M64 80 L40 87"/>
        <path d="M64 36 L82 26"/><path d="M64 36 L46 26"/>
      </g>
    </g>
  </svg>`,

  // 2. Realistic Golden-Amber Fallen Autumn Leaf (Curled Birch/Beech leaf)
  fallen: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="flg" x1="0.15" y1="0.1" x2="0.9" y2="0.9">
        <stop offset="0%" stop-color="#f5c249"/>
        <stop offset="48%" stop-color="#d9822b"/>
        <stop offset="88%" stop-color="#9c4b1a"/>
        <stop offset="100%" stop-color="#6b2e0e"/>
      </linearGradient>
      <filter id="fds"><feDropShadow dx="1" dy="3" stdDeviation="2.8" flood-opacity="0.32"/></filter>
    </defs>
    <g filter="url(#fds)" transform="rotate(-22 64 64)">
      <path d="M64 14 C92 30 102 64 84 94 C74 106 66 108 64 108 C62 108 54 106 44 94 C26 64 36 30 64 14 Z" fill="url(#flg)" stroke="#6e3310" stroke-width="1.2"/>
      <path d="M64 14 C80 34 86 66 64 108" fill="#ffffff" fill-opacity="0.12"/>
      <path d="M64 18 L64 120" stroke="#612c0c" stroke-width="2.6" stroke-linecap="round"/>
      <g stroke="#7c3811" stroke-opacity="0.55" stroke-width="1.2" fill="none" stroke-linecap="round">
        <path d="M64 34 Q78 28 84 26"/><path d="M64 38 Q50 32 44 30"/>
        <path d="M64 50 Q82 43 90 40"/><path d="M64 54 Q46 47 38 44"/>
        <path d="M64 66 Q82 59 90 56"/><path d="M64 70 Q46 63 38 60"/>
        <path d="M64 82 Q78 76 83 73"/><path d="M64 86 Q50 80 45 77"/>
      </g>
    </g>
  </svg>`,

  // 3. Realistic Bronze Oak Leaf with Acorn
  oak: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="okg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#d8923b"/><stop offset="55%" stop-color="#a45722"/><stop offset="100%" stop-color="#693112"/>
      </linearGradient>
    </defs>
    <g transform="rotate(16 64 64)">
      <path d="M64 12 C74 12 78 22 72 28 C84 26 92 36 82 46 C96 46 100 60 86 68 C96 72 94 86 80 88 C84 96 76 104 66 102 L62 102 C52 104 44 96 48 88 C34 86 32 72 42 68 C28 60 32 46 46 46 C36 36 44 26 56 28 C50 22 54 12 64 12 Z" fill="url(#okg)" stroke="#53240b" stroke-width="1.3"/>
      <path d="M64 16 L64 118" stroke="#4d2109" stroke-width="2.5" stroke-linecap="round"/>
      <path d="M64 42 L80 36 M64 58 L84 52 M64 74 L80 70 M64 46 L48 40 M64 62 L44 56 M64 78 L48 74" stroke="#f2ba6d" stroke-opacity="0.45" stroke-width="1.2" stroke-linecap="round"/>
    </g>
  </svg>`,

  // 4. Translucent Breeze Ribbon & Seed Fluff
  wind: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="wdg" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0"/>
        <stop offset="45%" stop-color="#d8ecfa" stop-opacity="0.85"/>
        <stop offset="100%" stop-color="#8bbce0" stop-opacity="0.2"/>
      </linearGradient>
    </defs>
    <path d="M12 58 C38 42 66 72 96 52 C108 44 114 34 104 28 C96 24 88 32 94 38" fill="none" stroke="url(#wdg)" stroke-width="4.5" stroke-linecap="round"/>
    <path d="M22 76 C50 64 76 88 112 70" fill="none" stroke="url(#wdg)" stroke-width="3" stroke-linecap="round"/>
    <circle cx="96" cy="34" r="2.5" fill="#fff" opacity="0.8"/>
  </svg>`,

  // 5. Realistic Macro 3D Dendritic Ice Crystal Snowflake
  snow: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="sng" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="65%" stop-color="#dff2ff"/>
        <stop offset="100%" stop-color="#9ad0f5"/>
      </radialGradient>
      <filter id="sngl"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#4da6e8" flood-opacity="0.45"/></filter>
    </defs>
    <g filter="url(#sngl)" stroke="url(#sng)" stroke-linecap="round" stroke-linejoin="round" fill="none">
      ${[0, 60, 120, 180, 240, 300].map((a) => `<g transform="rotate(${a} 64 64)">
        <line x1="64" y1="64" x2="64" y2="12" stroke-width="3.2"/>
        <path d="M52 26 L64 17 L76 26" stroke-width="2.4"/>
        <path d="M48 40 L64 29 L80 40" stroke-width="2.2"/>
        <path d="M54 51 L64 43 L74 51" stroke-width="2"/>
        <circle cx="64" cy="11" r="2.2" fill="#ffffff" stroke="none"/>
      </g>`).join("")}
      <polygon points="64,52 74,58 74,70 64,76 54,70 54,58" stroke="#ffffff" stroke-width="2" fill="#ffffff" fill-opacity="0.28"/>
    </g>
  </svg>`,

  // 6. Realistic Handcrafted Winter Snowman with Knit Scarf & Pine Hat
  snowman: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="smb" cx="38%" cy="32%" r="65%">
        <stop offset="0%" stop-color="#ffffff"/><stop offset="68%" stop-color="#e3eef8"/><stop offset="100%" stop-color="#b2cbe0"/>
      </radialGradient>
      <filter id="smds"><feDropShadow dx="0" dy="4" stdDeviation="3" flood-opacity="0.28"/></filter>
    </defs>
    <g filter="url(#smds)">
      <ellipse cx="64" cy="92" rx="30" ry="26" fill="url(#smb)"/>
      <circle cx="64" cy="52" r="20" fill="url(#smb)"/>
      <path d="M45 64 Q64 73 83 64 L85 73 Q64 82 43 73 Z" fill="#c93b2b"/>
      <path d="M72 70 L79 92 L69 91 Z" fill="#b02c1e"/>
      <rect x="46" y="29" width="36" height="6" rx="3" fill="#232a36"/>
      <path d="M51 14 H77 L75 31 H53 Z" fill="#2c3545"/>
      <rect x="52" y="25" width="24" height="4" fill="#c93b2b"/>
      <circle cx="57" cy="48" r="2.2" fill="#1e2430"/><circle cx="71" cy="48" r="2.2" fill="#1e2430"/>
      <path d="M64 51 L77 55 L64 57 Z" fill="#e87425"/>
      <circle cx="64" cy="83" r="2.3" fill="#2c3545"/><circle cx="64" cy="94" r="2.3" fill="#2c3545"/>
    </g>
  </svg>`,

  // 7. Ornate Glowing Brass Ramadan Fanous Lantern
  "fanous-mini": `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="brs" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#f8dc81"/><stop offset="50%" stop-color="#c99228"/><stop offset="100%" stop-color="#7c5310"/>
      </linearGradient>
      <radialGradient id="fgl" cx="50%" cy="54%" r="42%">
        <stop offset="0%" stop-color="#fff8c4"/><stop offset="45%" stop-color="#ffc947"/><stop offset="100%" stop-color="#d96b18" stop-opacity="0.85"/>
      </radialGradient>
      <filter id="fglow"><feDropShadow dx="0" dy="0" stdDeviation="5" flood-color="#ffbe3b" flood-opacity="0.55"/></filter>
    </defs>
    <g filter="url(#fglow)">
      <circle cx="64" cy="13" r="5" fill="none" stroke="url(#brs)" stroke-width="2.6"/>
      <path d="M52 28 Q64 14 76 28 Z" fill="url(#brs)"/>
      <rect x="46" y="28" width="36" height="6" rx="2" fill="url(#brs)"/>
      <polygon points="46,34 82,34 90,62 78,94 50,94 38,62" fill="url(#fgl)" stroke="url(#brs)" stroke-width="3"/>
      <line x1="64" y1="34" x2="64" y2="94" stroke="url(#brs)" stroke-width="2.2"/>
      <path d="M38 62 H90" stroke="url(#brs)" stroke-width="2"/>
      <polygon points="48,94 80,94 86,106 42,106" fill="url(#brs)"/>
      <circle cx="64" cy="64" r="8" fill="#ffffff" fill-opacity="0.7"/>
    </g>
  </svg>`,

  // 8. 3D Gilded Islamic Crescent Moon (Hilal) with Filigree Star
  crescent: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="crg" x1="0.15" y1="0.1" x2="0.85" y2="0.9">
        <stop offset="0%" stop-color="#fff1a8"/><stop offset="45%" stop-color="#e5b53a"/><stop offset="100%" stop-color="#9b6c14"/>
      </linearGradient>
      <filter id="crds"><feDropShadow dx="0" dy="3" stdDeviation="3.5" flood-color="#5c3c05" flood-opacity="0.38"/></filter>
    </defs>
    <g filter="url(#crds)">
      <path d="M76 18 A46 46 0 1 0 106 86 A37 37 0 1 1 76 18 Z" fill="url(#crg)" stroke="#fff5c0" stroke-width="0.9"/>
      <polygon points="84,40 87,49 96,49 89,54 92,63 84,57 76,63 79,54 72,49 81,49" fill="url(#crg)"/>
    </g>
  </svg>`,

  // 9. 8-Pointed Mamluk Gilded Star
  star: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="stg" cx="40%" cy="35%" r="60%">
        <stop offset="0%" stop-color="#fff8cc"/><stop offset="50%" stop-color="#f0be42"/><stop offset="100%" stop-color="#a87416"/>
      </radialGradient>
      <filter id="stds"><feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#ffd25a" flood-opacity="0.5"/></filter>
    </defs>
    <g filter="url(#stds)">
      <polygon points="64,12 76,42 108,30 90,58 116,74 84,80 92,110 64,90 36,110 44,80 12,74 38,58 20,30 52,42" fill="url(#stg)" stroke="#fff4b8" stroke-width="1"/>
      <circle cx="64" cy="64" r="11" fill="#fff7d6" fill-opacity="0.55"/>
    </g>
  </svg>`,

  // 10. Optical Diamond Lens Flare Sparkle
  sparkle: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="spg" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#ffffff"/><stop offset="40%" stop-color="#fff3b0"/><stop offset="100%" stop-color="#f3b73f" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <circle cx="64" cy="64" r="42" fill="url(#spg)"/>
    <path d="M64 10 Q67 58 118 64 Q67 70 64 118 Q61 70 10 64 Q61 58 64 10 Z" fill="#ffffff"/>
    <path d="M64 34 Q66 60 94 64 Q66 68 64 94 Q62 68 34 64 Q62 60 64 34 Z" fill="#fff6c4"/>
  </svg>`,

  // 11. Realistic Pink Sakura / Almond Spring Blossom with Stamens
  blossom: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="blg" cx="50%" cy="65%" r="60%">
        <stop offset="0%" stop-color="#d94f7a"/><stop offset="45%" stop-color="#f7a8c4"/><stop offset="100%" stop-color="#ffe8f1"/>
      </radialGradient>
      <filter id="blds"><feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-color="#7a1e3d" flood-opacity="0.28"/></filter>
    </defs>
    <g filter="url(#blds)">
      ${[0, 72, 144, 216, 288].map((a) => `<path transform="rotate(${a} 64 64)" d="M64 60 C46 46 42 20 56 14 C61 12 64 18 64 18 C64 18 67 12 72 14 C86 20 82 46 64 60 Z" fill="url(#blg)" stroke="#f291b4" stroke-width="0.8"/>`).join("")}
      <circle cx="64" cy="64" r="8" fill="#e65c8a"/>
      ${[0, 45, 90, 135, 180, 225, 270, 315].map((a) => `<g transform="rotate(${a} 64 64)"><line x1="64" y1="64" x2="64" y2="49" stroke="#fff0f5" stroke-width="1.2"/><circle cx="64" cy="48" r="2" fill="#ffd15c"/></g>`).join("")}
    </g>
  </svg>`,

  // 12. Botanical Crimson-Rose Tulip with Fresh Green Leaves
  tulip: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="tlg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#ff8fab"/><stop offset="55%" stop-color="#e03e6d"/><stop offset="100%" stop-color="#8f193c"/>
      </linearGradient>
      <linearGradient id="tll" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#7bc95a"/><stop offset="100%" stop-color="#2f6e28"/>
      </linearGradient>
    </defs>
    <path d="M64 66 L64 118" stroke="#3c8232" stroke-width="4" stroke-linecap="round"/>
    <path d="M64 114 C40 102 32 78 40 60 C50 74 58 92 64 114 Z" fill="url(#tll)"/>
    <path d="M64 114 C88 102 96 78 88 60 C78 74 70 92 64 114 Z" fill="url(#tll)"/>
    <path d="M64 16 C48 26 44 50 54 66 C60 72 68 72 74 66 C84 50 80 26 64 16 Z" fill="url(#tlg)"/>
    <path d="M46 24 C38 42 44 64 64 68 C54 54 52 36 46 24 Z" fill="#f25784"/>
    <path d="M82 24 C90 42 84 64 64 68 C74 54 76 36 82 24 Z" fill="#d93264"/>
  </svg>`,

  // 13. Fresh Botanical Olive / Mint Herb Sprig
  herb: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="hbg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#9be16b"/><stop offset="55%" stop-color="#4ea13b"/><stop offset="100%" stop-color="#255c1d"/>
      </linearGradient>
    </defs>
    <g transform="rotate(20 64 64)">
      <path d="M64 18 Q60 64 66 114" fill="none" stroke="#356e26" stroke-width="3" stroke-linecap="round"/>
      <path d="M64 18 C52 28 54 44 64 48 C74 44 76 28 64 18 Z" fill="url(#hbg)"/>
      <path d="M62 52 C40 44 30 58 42 70 C50 76 58 66 62 52 Z" fill="url(#hbg)"/>
      <path d="M64 56 C86 48 96 62 84 74 C76 80 68 70 64 56 Z" fill="url(#hbg)"/>
      <path d="M63 78 C42 72 34 86 46 96 C54 102 60 92 63 78 Z" fill="url(#hbg)"/>
      <path d="M65 82 C86 76 94 90 82 100 C74 106 68 96 65 82 Z" fill="url(#hbg)"/>
    </g>
  </svg>`,

  // 14. Egyptian Sacred Blue & Rose Nile Lotus Blossom
  lotus: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="ltp" x1="0.5" y1="0" x2="0.5" y2="1">
        <stop offset="0%" stop-color="#ffd6e7"/><stop offset="50%" stop-color="#eb7aa8"/><stop offset="100%" stop-color="#9e3566"/>
      </linearGradient>
      <linearGradient id="ltb" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#5ec49e"/><stop offset="100%" stop-color="#1e6b52"/>
      </linearGradient>
      <filter id="ltds"><feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-opacity="0.28"/></filter>
    </defs>
    <g filter="url(#ltds)">
      <ellipse cx="64" cy="92" rx="46" ry="12" fill="url(#ltb)"/>
      <path d="M64 88 C36 84 18 64 24 44 C40 52 54 68 64 88 Z" fill="url(#ltp)" opacity="0.9"/>
      <path d="M64 88 C92 84 110 64 104 44 C88 52 74 68 64 88 Z" fill="url(#ltp)" opacity="0.9"/>
      <path d="M64 88 C42 74 36 46 46 28 C58 42 62 64 64 88 Z" fill="url(#ltp)"/>
      <path d="M64 88 C86 74 92 46 82 28 C70 42 66 64 64 88 Z" fill="url(#ltp)"/>
      <path d="M64 20 C50 40 50 68 64 88 C78 68 78 40 64 20 Z" fill="url(#ltp)"/>
      <circle cx="64" cy="74" r="7" fill="#ffd257"/>
    </g>
  </svg>`,

  // 15. Mediterranean Turquoise Wave Crest & Seafoam
  wave: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="wvg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#aef2ff"/><stop offset="45%" stop-color="#2db5d8"/><stop offset="100%" stop-color="#0d5b85"/>
      </linearGradient>
    </defs>
    <path d="M12 84 C26 52 56 32 86 42 C70 46 62 60 72 68 C86 78 106 68 116 58 C110 88 82 104 46 102 C28 101 16 94 12 84 Z" fill="url(#wvg)"/>
    <path d="M44 42 C62 32 82 34 92 44 C78 42 66 48 64 58" fill="none" stroke="#ffffff" stroke-width="4" stroke-linecap="round"/>
    <circle cx="96" cy="36" r="3" fill="#ffffff"/><circle cx="105" cy="44" r="2" fill="#e0faff"/>
  </svg>`,

  // 16. Peace Dove with Olive Branch (Friday / National / Coptic)
  dove: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="dvg" x1="0.2" y1="0.1" x2="0.8" y2="0.9">
        <stop offset="0%" stop-color="#ffffff"/><stop offset="65%" stop-color="#e6eef6"/><stop offset="100%" stop-color="#b8cadb"/>
      </linearGradient>
      <filter id="dvds"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-opacity="0.26"/></filter>
    </defs>
    <g filter="url(#dvds)">
      <path d="M56 56 C42 32 22 22 16 28 C22 44 34 58 48 64 Z" fill="#d3e0ed"/>
      <path d="M68 58 C64 30 44 14 30 18 C36 38 46 54 58 64 Z" fill="url(#dvg)"/>
      <path d="M26 84 C44 86 62 82 78 70 C92 60 98 48 92 42 C86 36 78 42 74 50 C62 56 44 62 20 74 Z" fill="url(#dvg)"/>
      <path d="M94 45 L105 47 L95 50 Z" fill="#e69a28"/>
      <circle cx="89" cy="45" r="1.8" fill="#1e293b"/>
      <path d="M102 48 Q112 54 116 64" fill="none" stroke="#4f8f38" stroke-width="2" stroke-linecap="round"/>
      <ellipse cx="110" cy="54" rx="4" ry="2" transform="rotate(-25 110 54)" fill="#62ad44"/>
      <ellipse cx="114" cy="60" rx="4" ry="2" transform="rotate(20 114 60)" fill="#62ad44"/>
    </g>
  </svg>`,

  // 17. Glossy 3D Festive Balloon
  balloon: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="blng" cx="35%" cy="30%" r="65%">
        <stop offset="0%" stop-color="#ff9ebb"/><stop offset="45%" stop-color="#e83e75"/><stop offset="100%" stop-color="#8c143d"/>
      </radialGradient>
      <filter id="blnds"><feDropShadow dx="0" dy="4" stdDeviation="3" flood-opacity="0.28"/></filter>
    </defs>
    <g filter="url(#blnds)">
      <path d="M64 88 Q58 104 68 120" fill="none" stroke="#c9a87c" stroke-width="1.8"/>
      <path d="M64 14 C86 14 98 32 94 56 C90 74 74 86 64 88 C54 86 38 74 34 56 C30 32 42 14 64 14 Z" fill="url(#blng)"/>
      <polygon points="60,88 68,88 71,93 57,93" fill="#b82557"/>
      <ellipse cx="49" cy="34" rx="7" ry="13" transform="rotate(-22 49 34)" fill="#ffffff" fill-opacity="0.45"/>
    </g>
  </svg>`,

  // 18. Metallic Festive Confetti Ribbons
  confetti: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <path d="M28 24 Q44 38 30 56 Q18 72 36 86" fill="none" stroke="#f5b82e" stroke-width="6" stroke-linecap="round"/>
    <path d="M84 20 Q98 36 82 52 Q68 66 86 84" fill="none" stroke="#36c997" stroke-width="6" stroke-linecap="round"/>
    <rect x="56" y="50" width="14" height="8" rx="2" transform="rotate(-32 63 54)" fill="#ff5c8a"/>
    <circle cx="54" cy="28" r="5" fill="#5a8dee"/>
    <circle cx="62" cy="96" r="5" fill="#f59e0b"/>
  </svg>`,

  // 19. Luxury Wrapped Eid / Birthday Gift Box with Gold Satin Bow
  gift: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="gfb" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#e85d4a"/><stop offset="100%" stop-color="#9e281b"/>
      </linearGradient>
      <linearGradient id="gfr" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#ffe58f"/><stop offset="100%" stop-color="#c98a1e"/>
      </linearGradient>
      <filter id="gfds"><feDropShadow dx="0" dy="4" stdDeviation="3" flood-opacity="0.3"/></filter>
    </defs>
    <g filter="url(#gfds)">
      <rect x="28" y="50" width="72" height="58" rx="8" fill="url(#gfb)"/>
      <rect x="24" y="38" width="80" height="16" rx="5" fill="#d94836"/>
      <rect x="57" y="38" width="14" height="70" fill="url(#gfr)"/>
      <rect x="28" y="72" width="72" height="12" fill="url(#gfr)"/>
      <path d="M64 38 C46 18 32 28 46 38 Z" fill="url(#gfr)"/>
      <path d="M64 38 C82 18 96 28 82 38 Z" fill="url(#gfr)"/>
      <circle cx="64" cy="37" r="5" fill="#ffd666"/>
    </g>
  </svg>`,

  // 20. 3D Ruby Velvet Heart
  heart: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="hrg" cx="36%" cy="30%" r="68%">
        <stop offset="0%" stop-color="#ff8fa8"/><stop offset="45%" stop-color="#e02e56"/><stop offset="100%" stop-color="#7a0d27"/>
      </radialGradient>
      <filter id="hrds"><feDropShadow dx="0" dy="4" stdDeviation="3.2" flood-color="#59081b" flood-opacity="0.36"/></filter>
    </defs>
    <g filter="url(#hrds)">
      <path d="M64 106 C20 78 14 42 36 26 C50 16 62 26 64 36 C66 26 78 16 92 26 C114 42 108 78 64 106 Z" fill="url(#hrg)"/>
      <ellipse cx="42" cy="40" rx="9" ry="5" transform="rotate(-32 42 40)" fill="#ffffff" fill-opacity="0.38"/>
    </g>
  </svg>`,

  // 21. Stacked Hardcover Leather Study Books with Bookmark
  books: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <filter id="bkds"><feDropShadow dx="0" dy="4" stdDeviation="3" flood-opacity="0.3"/></filter>
    </defs>
    <g filter="url(#bkds)">
      <rect x="22" y="78" width="84" height="20" rx="5" fill="#2b547e"/>
      <rect x="28" y="82" width="74" height="12" rx="2" fill="#f6f1e3"/>
      <rect x="26" y="56" width="78" height="20" rx="5" fill="#9e3628"/>
      <rect x="32" y="60" width="68" height="12" rx="2" fill="#fbf7eb"/>
      <rect x="30" y="34" width="70" height="20" rx="5" fill="#2f6f5e"/>
      <rect x="36" y="38" width="60" height="12" rx="2" fill="#fdfaf0"/>
      <polygon points="78,46 86,46 86,68 82,64 78,68" fill="#e0a028"/>
    </g>
  </svg>`,

  // 22. Seashell for Summer Coast
  seashell: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="shg" cx="50%" cy="80%" r="70%">
        <stop offset="0%" stop-color="#ffe6d0"/><stop offset="55%" stop-color="#f2a97e"/><stop offset="100%" stop-color="#c46d45"/>
      </radialGradient>
      <filter id="shds"><feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-opacity="0.28"/></filter>
    </defs>
    <g filter="url(#shds)">
      <path d="M64 98 L50 104 L78 104 Z" fill="#b8603a"/>
      <path d="M64 98 C24 90 14 52 34 32 C48 18 80 18 94 32 C114 52 104 90 64 98 Z" fill="url(#shg)"/>
      <g stroke="#fff3e8" stroke-opacity="0.65" stroke-width="1.6" fill="none">
        <path d="M64 96 L64 24"/><path d="M64 96 L46 28"/><path d="M64 96 L82 28"/><path d="M64 96 L30 42"/><path d="M64 96 L98 42"/>
      </g>
    </g>
  </svg>`,

  // 23. Ornate Gilded Coptic Cross
  "coptic-cross": `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <linearGradient id="cpg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#fae29c"/><stop offset="50%" stop-color="#c9932b"/><stop offset="100%" stop-color="#7c5211"/>
      </linearGradient>
      <filter id="cpds"><feDropShadow dx="0" dy="3" stdDeviation="3" flood-opacity="0.32"/></filter>
    </defs>
    <g filter="url(#cpds)" fill="url(#cpg)">
      <rect x="57" y="18" width="14" height="92" rx="4"/>
      <rect x="18" y="57" width="92" height="14" rx="4"/>
      <circle cx="64" cy="18" r="9"/><circle cx="64" cy="110" r="9"/>
      <circle cx="18" cy="64" r="9"/><circle cx="110" cy="64" r="9"/>
      <circle cx="64" cy="64" r="14" fill="none" stroke="url(#cpg)" stroke-width="4"/>
    </g>
  </svg>`,

  // 24. Fragrant White Egyptian Jasmine Flower (Foll)
  jasmine: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="${W}" height="${W}">
    <defs>
      <radialGradient id="jsg" cx="50%" cy="50%" r="55%">
        <stop offset="0%" stop-color="#fff8d6"/><stop offset="45%" stop-color="#ffffff"/><stop offset="100%" stop-color="#dce8dc"/>
      </radialGradient>
      <filter id="jsds"><feDropShadow dx="0" dy="3" stdDeviation="2.5" flood-opacity="0.25"/></filter>
    </defs>
    <g filter="url(#jsds)">
      ${[0, 60, 120, 180, 240, 300].map((a) => `<ellipse cx="64" cy="34" rx="13" ry="24" transform="rotate(${a} 64 64)" fill="url(#jsg)"/>`).join("")}
      <circle cx="64" cy="64" r="9" fill="#f2c94c"/>
    </g>
  </svg>`,
};

(async () => {
  for (const [name, svg] of Object.entries(SPRITES)) {
    await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toFile(`src/assets/decor/${name}.png`);
    console.log("generated realistic sprite:", name);
  }
  console.log("ALL REALISTIC SEASONAL SPRITES GENERATED.");
})();
