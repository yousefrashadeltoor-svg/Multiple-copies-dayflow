package app.dayflow.android.ui.screens

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.NativeDownloadEngine
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.DayflowState
import app.dayflow.android.model.DownloadItem
import app.dayflow.android.model.LinkAnalysis
import app.dayflow.android.system.DownloadForegroundService
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsComposeScreen(
    state: DayflowState,
    pendingShare: String?,
    go: (String, String?) -> Unit
) {
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lang = state.lang
    val ar = lang == "ar"

    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf("") }
    var analysis by remember { mutableStateOf<LinkAnalysis?>(null) }
    var pickedFormatId by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var snifferUrl by remember { mutableStateOf<String?>(null) }

    fun triggerAnalyze(target: String) {
        if (target.isBlank()) return
        url = target
        busy = true
        err = ""
        analysis = null
        scope.launch {
            runCatching { NativeDownloadEngine.analyzeLink(target) }
                .onSuccess { res ->
                    analysis = res
                    pickedFormatId = res.formats.firstOrNull()?.id.orEmpty()
                    busy = false
                }
                .onFailure { e ->
                    err = e.message ?: if (ar) "تعذّر تحليل الرابط" else "Could not analyze link"
                    busy = false
                }
        }
    }

    LaunchedEffect(pendingShare) {
        if (!pendingShare.isNullOrBlank()) {
            DayflowRepository.setPendingSharedLink(null)
            triggerAnalyze(pendingShare)
        }
    }

    val totalSaved = state.downloads.filter { it.state == "completed" }.sumOf { it.size }
    val filteredItems = remember(state.downloads, filter) {
        state.downloads.filter {
            when (filter) {
                "active" -> it.state == "downloading" || it.state == "queued"
                "completed" -> it.state == "completed"
                "failed" -> it.state == "failed" || it.state == "cancelled"
                else -> true
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(
            title = if (ar) "التحميل" else "Downloads",
            subtitle = if (ar) "${Time12h.fmtNum(state.downloads.size, "ar")} عنصر · ${NativeDownloadEngine.formatBytes(totalSaved)} محفوظ"
            else "${state.downloads.size} items · ${NativeDownloadEngine.formatBytes(totalSaved)} saved"
        )

        DayflowCard(contentPadding = PaddingValues(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    placeholder = { Text(if (ar) "الصق أي رابط هنا…" else "Paste any link…", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
                FilledTonalIconButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val pasted = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                    val clean = NativeDownloadEngine.extractFirstUrl(pasted) ?: pasted.trim()
                    if (clean.isNotBlank()) triggerAnalyze(clean)
                }) {
                    Icon(Icons.Default.ContentPaste, contentDescription = "Paste")
                }
                Button(
                    onClick = { triggerAnalyze(url) },
                    enabled = !busy && url.isNotBlank(),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = c.onAccent)
                    } else {
                        Icon(Icons.Default.Search, contentDescription = "Analyze")
                    }
                }
            }

            if (err.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(err, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
            }

            // Rich Native Link Preview (Cover, Title, Host, Author, Description, Duration, Size & Formats!)
            if (analysis != null) {
                val an = analysis!!
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (!an.thumb.isNullOrBlank()) {
                        AsyncImage(
                            model = an.thumb,
                            contentDescription = an.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .width(120.dp)
                                .height(80.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(c.soft)
                        )
                    } else {
                        Box(
                            modifier = Modifier.size(80.dp).clip(RoundedCornerShape(14.dp)).background(c.soft),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PermMedia, contentDescription = null, tint = c.accent, modifier = Modifier.size(30.dp))
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(an.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${an.site.uppercase()} · ${an.host}", fontSize = 11.sp, color = c.accent)
                        if (!an.author.isNullOrBlank()) {
                            Text(an.author, fontSize = 11.5.sp, color = c.muted, maxLines = 1)
                        }
                        if (!an.description.isNullOrBlank()) {
                            Text(an.description, fontSize = 11.sp, color = c.muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                            if (an.duration != null) {
                                Text("⏱ ${an.duration / 60}:${(an.duration % 60).toString().padStart(2, '0')}", fontSize = 10.5.sp, color = c.muted)
                            }
                            if (an.size != null && an.size > 0) {
                                Text(NativeDownloadEngine.formatBytes(an.size), fontSize = 10.5.sp, color = c.muted)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                an.formats.forEach { fmt ->
                    val selected = pickedFormatId == fmt.id
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { pickedFormatId = fmt.id },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) c.soft else Color.Transparent,
                        border = BorderStroke(1.dp, if (selected) c.accent else c.line)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = when (fmt.kind) {
                                    "audio" -> Icons.Default.MusicNote
                                    "image" -> Icons.Default.Image
                                    else -> Icons.Default.Movie
                                },
                                contentDescription = null,
                                tint = c.accent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(fmt.label, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text(fmt.detail, fontSize = 11.sp, color = c.muted, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (fmt.size > 0L) {
                                Text(NativeDownloadEngine.formatBytes(fmt.size), fontSize = 11.sp, color = c.muted)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val chosen = an.formats.find { it.id == pickedFormatId } ?: an.formats.firstOrNull()
                            val ext = when (chosen?.kind) {
                                "audio" -> if (chosen.id == "m4a") ".m4a" else ".mp3"
                                "image" -> ".jpg"
                                "video" -> ".mp4"
                                else -> ""
                            }
                            val baseName = an.filename
                            val finalName = if (ext.isNotEmpty() && !baseName.endsWith(ext, true)) "$baseName$ext" else baseName
                            val newItem = DownloadItem(
                                id = DayflowRepository.newId(),
                                url = an.url,
                                name = finalName,
                                kind = chosen?.kind ?: an.kind,
                                host = an.host,
                                site = an.site,
                                secure = an.secure,
                                thumb = an.thumb,
                                quality = chosen?.label,
                                format = chosen?.id,
                                size = chosen?.size ?: (an.size ?: 0L),
                                variantUrl = chosen?.url
                            )
                            DayflowRepository.addDownload(newItem)
                            DownloadForegroundService.enqueue(context, newItem.id)
                            analysis = null
                            url = ""
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (ar) "تحميل الآن" else "Download Now", fontWeight = FontWeight.Bold)
                    }

                    FilledTonalButton(
                        onClick = { snifferUrl = an.url },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (ar) "اكتشاف الوسائط" else "Sniffer", fontSize = 12.sp)
                    }
                }
            }
        }

        SegmentedBar(
            value = filter,
            options = listOf(
                "all" to (if (ar) "الكل" else "All"),
                "active" to (if (ar) "نشط" else "Active"),
                "completed" to (if (ar) "مكتمل" else "Done"),
                "failed" to (if (ar) "فشل" else "Failed")
            ),
            onSelect = { filter = it }
        )

        if (filteredItems.isEmpty()) {
            DayflowCard {
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = c.accent, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.height(6.dp))
                    Text(if (ar) "الصق رابطًا بالأعلى أو شاركه من أي تطبيق للبدء." else "Paste or share any link to start downloading.", fontSize = 13.sp, color = c.muted)
                }
            }
        } else {
            filteredItems.forEach { item ->
                val pct = if (item.size > 0) ((item.got.toFloat() / item.size) * 100f).coerceIn(0f, 100f) else if (item.state == "completed") 100f else 0f
                DayflowCard(contentPadding = PaddingValues(13.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (!item.thumb.isNullOrBlank()) {
                            AsyncImage(
                                model = item.thumb,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                text = listOfNotNull(item.state.uppercase(), item.quality, item.engine).joinToString(" · "),
                                fontSize = 11.sp,
                                color = c.muted
                            )
                        }
                        IconButton(onClick = {
                            NativeDownloadEngine.cancelDownload(item.id)
                            DayflowRepository.removeDownload(item.id)
                        }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = c.muted)
                        }
                    }
                    if (item.state == "downloading" || item.state == "queued") {
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { pct / 100f },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
                            color = c.accent,
                            trackColor = c.line
                        )
                    }
                    if (!item.error.isNullOrBlank() && item.state == "failed") {
                        Text(item.error, color = MaterialTheme.colorScheme.error, fontSize = 11.5.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    if (item.state == "completed" && !item.savedPath.isNullOrBlank()) {
                        Text(item.savedPath, fontSize = 10.5.sp, color = c.accent, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }

    // Optional Embedded Media Stream Sniffer (The ONLY place WebView is used, strictly on-demand!)
    if (snifferUrl != null) {
        MediaSnifferModal(
            targetUrl = snifferUrl!!,
            ar = ar,
            onPickedStream = { stream ->
                snifferUrl = null
                triggerAnalyze(stream)
            },
            onDismiss = { snifferUrl = null }
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MediaSnifferModal(
    targetUrl: String,
    ar: Boolean,
    onPickedStream: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalDayflowColors.current
    val discovered = remember { mutableStateListOf<String>() }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (ar) "مستكشف الوسائط المباشر" else "Media Stream Sniffer", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (discovered.isNotEmpty()) {
                discovered.take(5).forEach { mediaUrl ->
                    DayflowChip(
                        selected = true,
                        label = mediaUrl.takeLast(44),
                        onClick = { onPickedStream(mediaUrl) }
                    )
                }
            } else {
                Text(if (ar) "شغّل الفيديو داخل الصفحة لالتقاط رابط البث المباشر تلقائيًا…" else "Play media on the page to capture direct stream URLs…", fontSize = 12.sp, color = c.muted)
            }
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): android.webkit.WebResourceResponse? {
                                val u = request?.url?.toString().orEmpty()
                                if (u.matches(Regex("(?i).*\\.(m3u8|mp4|mpd|m4a|mp3)(\\?.*)?$")) && !discovered.contains(u)) {
                                    post { discovered.add(u) }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }
                        loadUrl(targetUrl)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(340.dp).clip(RoundedCornerShape(16.dp))
            )
        }
    }
}
