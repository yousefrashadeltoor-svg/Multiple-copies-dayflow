package app.dayflow.android.system

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import app.dayflow.android.MainActivity
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.AlarmItem
import app.dayflow.android.model.AlarmSound
import app.dayflow.android.model.DayflowState
import java.util.Calendar

object AlarmAndReminderManager {

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(intent) }
        }
    }

    fun scheduleAlarm(context: Context, alarm: AlarmItem): Boolean {
        if (!alarm.enabled) {
            cancelAlarm(context, alarm.id)
            return true
        }
        if (!canScheduleExactAlarms(context)) return false
        val nextMillis = Time12h.nextTriggerForAlarm(alarm) ?: return false
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val receiverIntent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("alarmId", alarm.id)
            putExtra("label", alarm.label)
            putExtra("soundUri", alarm.sound.uri)
            putExtra("vibrate", alarm.vibrate)
            putExtra("snooze", alarm.snooze)
            putExtra("gentle", alarm.gentle)
        }
        val reqCode = alarm.id.hashCode() and 0x7fffffff
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            receiverIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = Intent(context, MainActivity::class.java).apply {
            putExtra("openTab", "alarms")
        }
        val showPi = PendingIntent.getActivity(
            context,
            reqCode,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return runCatching {
            val clockInfo = AlarmManager.AlarmClockInfo(nextMillis, showPi)
            am.setAlarmClock(clockInfo, pi)
            true
        }.getOrDefault(false)
    }

    fun cancelAlarm(context: Context, alarmId: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val reqCode = alarmId.hashCode() and 0x7fffffff
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            Intent(context, AlarmReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(reqCode)
    }

    fun scheduleReminder(
        context: Context,
        key: String,
        title: String,
        body: String,
        date: String?,
        time24: String,
        days: List<Int>
    ) {
        val bits = time24.split(":")
        if (bits.size < 2) return
        val h = bits[0].toIntOrNull() ?: return
        val m = bits[1].toIntOrNull() ?: return
        val now = System.currentTimeMillis()

        val tempAlarm = AlarmItem(id = key, time = "%02d:%02d".format(h, m), date = date, days = days, enabled = true)
        val triggerAt = Time12h.nextTriggerForAlarm(tempAlarm, now) ?: return

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("reminderKey", key)
            putExtra("title", title)
            putExtra("body", body)
            putExtra("time", time24)
            putExtra("days", days.toIntArray())
        }
        val reqCode = ("rem_$key").hashCode() and 0x7fffffff
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        runCatching {
            if (canScheduleExactAlarms(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        }
    }

    fun cancelReminder(context: Context, key: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val reqCode = ("rem_$key").hashCode() and 0x7fffffff
        val pi = PendingIntent.getBroadcast(
            context,
            reqCode,
            Intent(context, ReminderReceiver::class.java),
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    fun restoreAllScheduled(context: Context, state: DayflowState) {
        for (a in state.alarms) {
            if (a.enabled) scheduleAlarm(context, a)
        }
        for (t in state.tasks) {
            if (!t.done && !t.dueTime.isNullOrBlank()) {
                scheduleReminder(context, "task_${t.id}", "DAYFLOW", t.title, t.date, t.dueTime, emptyList())
            }
        }
        for (h in state.habits) {
            if (!h.reminder.isNullOrBlank()) {
                scheduleReminder(context, "habit_${h.id}", "DAYFLOW", h.en, null, h.reminder, h.days)
            }
        }
    }

    fun listDeviceTones(context: Context): List<AlarmSound> {
        val result = mutableListOf<AlarmSound>()
        runCatching {
            val rm = RingtoneManager(context)
            rm.setType(RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_NOTIFICATION)
            val cursor: Cursor? = rm.cursor
            if (cursor != null) {
                var idx = 0
                while (cursor.moveToNext()) {
                    val uri = rm.getRingtoneUri(idx++) ?: continue
                    val title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: "Device tone $idx"
                    result.add(AlarmSound(source = "device", title = title, uri = uri.toString()))
                }
                cursor.close()
            }
        }
        if (result.isEmpty()) {
            result.add(AlarmSound("device", "منبه الجهاز الافتراضي", Settings.System.DEFAULT_ALARM_ALERT_URI?.toString().orEmpty()))
            result.add(AlarmSound("device", "نغمة الرنين الافتراضية", Settings.System.DEFAULT_RINGTONE_URI?.toString().orEmpty()))
        }
        return result.distinctBy { it.uri }
    }

    fun persistCustomSoundUri(context: Context, uri: Uri): AlarmSound {
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        var displayName = uri.lastPathSegment ?: "ملف صوتي"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    displayName = c.getString(0) ?: displayName
                }
            }
        }
        return AlarmSound(source = "files", title = displayName, uri = uri.toString())
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DayflowRepository.init(context)
        val alarmId = intent.getStringExtra("alarmId") ?: return
        val label = intent.getStringExtra("label").orEmpty()
        val soundUri = intent.getStringExtra("soundUri").orEmpty()
        val vibrate = intent.getBooleanExtra("vibrate", true)
        val snooze = intent.getIntExtra("snooze", 10)
        val gentle = intent.getBooleanExtra("gentle", true)

        NotificationController.postAlarmFullScreenNotification(
            context = context,
            alarmId = alarmId,
            label = label,
            soundUri = soundUri,
            vibrate = vibrate,
            snooze = snooze,
            gentle = gentle
        )

        val stored = DayflowRepository.state.value.alarms.find { it.id == alarmId }
        if (stored != null) {
            if (stored.days.isEmpty()) {
                // One-shot alarm: mark disabled after firing
                DayflowRepository.updateState { s ->
                    s.copy(alarms = s.alarms.map { if (it.id == alarmId) it.copy(enabled = false) else it })
                }
            } else {
                // Repeating weekday alarm: schedule next occurrence immediately
                AlarmAndReminderManager.scheduleAlarm(context, stored)
            }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DayflowRepository.init(context)
        val state = DayflowRepository.state.value
        val nowHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (state.notif.quiet && (nowHour >= 23 || nowHour < 6)) return

        val key = intent.getStringExtra("reminderKey") ?: "reminder"
        val title = intent.getStringExtra("title") ?: "DAYFLOW"
        val body = intent.getStringExtra("body") ?: ""
        val time = intent.getStringExtra("time") ?: ""
        val days = intent.getIntArrayExtra("days")?.toList() ?: emptyList()

        NotificationController.showInteractiveReminder(
            context = context,
            notifId = key.hashCode() and 0x7fff,
            reminderKey = key,
            title = title,
            body = body
        )

        if (days.isNotEmpty() && time.isNotBlank()) {
            AlarmAndReminderManager.scheduleReminder(context, key, title, body, null, time, days)
        }
    }
}

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DayflowRepository.init(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        when (intent.action) {
            ACTION_COMPLETE -> {
                val notifId = intent.getIntExtra("notifId", 0)
                val key = intent.getStringExtra("reminderKey").orEmpty()
                if (key.startsWith("task_")) {
                    DayflowRepository.toggleTask(key.removePrefix("task_"))
                } else if (key.startsWith("habit_")) {
                    DayflowRepository.toggleHabit(key.removePrefix("habit_"))
                }
                nm.cancel(notifId)
            }
            ACTION_SNOOZE -> {
                val notifId = intent.getIntExtra("notifId", 0)
                val key = intent.getStringExtra("reminderKey").orEmpty()
                val title = intent.getStringExtra("title") ?: "DAYFLOW"
                val body = intent.getStringExtra("body") ?: ""
                nm.cancel(notifId)
                val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, 10) }
                val hhmm = "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
                val date = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
                AlarmAndReminderManager.scheduleReminder(context, "${key}_snooze", title, body, date, hhmm, emptyList())
            }
            ACTION_RESTORE_COMPANION -> {
                nm.cancel(9202)
                DayflowRepository.updateState { s ->
                    s.copy(companion = s.companion.copy(hidden = false, enabled = true))
                }
                CompanionOverlayService.syncIfPermitted(context, DayflowRepository.state.value)
            }
            ACTION_STOP_OVERLAY -> {
                context.stopService(Intent(context, CompanionOverlayService::class.java))
                DayflowRepository.updateState { s ->
                    s.copy(companion = s.companion.copy(overlayActive = false))
                }
            }
        }
    }

    companion object {
        const val ACTION_COMPLETE = "app.dayflow.android.NOTIF_COMPLETE"
        const val ACTION_SNOOZE = "app.dayflow.android.NOTIF_SNOOZE"
        const val ACTION_RESTORE_COMPANION = "app.dayflow.android.RESTORE_COMPANION"
        const val ACTION_STOP_OVERLAY = "app.dayflow.android.STOP_OVERLAY"
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        DayflowRepository.init(context)
        val state = DayflowRepository.state.value
        AlarmAndReminderManager.restoreAllScheduled(context, state)
        DayflowWidgetRenderer.refreshAllWidgets(context, state)
        if (state.companion.enabled && state.companion.overlayActive && !state.companion.hidden) {
            CompanionOverlayService.syncIfPermitted(context, state)
        }
    }
}
