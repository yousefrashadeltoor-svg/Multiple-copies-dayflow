package app.dayflow.android.domain

data class WidgetDef(
    val id: String,
    val en: String,
    val ar: String,
    val cat: String,
    val arche: String,
    val variant: Int,
    val interactive: Boolean,
    val forms: List<String>
)

object WidgetsCatalog {
    val FORMS = listOf("1x1", "2x1", "2x2", "4x1", "4x2", "4x4")

    val WCATS = listOf(
        Triple("clock", "Clock", "الساعة"),
        Triple("alarms", "Alarms", "المنبهات"),
        Triple("calendar", "Calendar", "التقويم"),
        Triple("occasions", "Occasions", "المناسبات"),
        Triple("plan", "Plan & today", "الخطة واليوم"),
        Triple("tasks", "Tasks & notes", "المهام والملاحظات"),
        Triple("habits", "Habits & health", "العادات والصحة"),
        Triple("focus", "Focus & study", "التركيز والدراسة"),
        Triple("review", "Review & stats", "المراجعة والإحصاءات"),
        Triple("media", "Media Hub", "مركز الوسائط"),
        Triple("utility", "Utility", "أدوات"),
        Triple("companion", "Companion", "الرفيق")
    )

    val WSTYLES = listOf(
        Triple("oneui", "One UI Glass", "زجاج One UI"),
        Triple("material", "Material You", "Material You"),
        Triple("ios", "iOS-inspired", "مستوحى من iOS"),
        Triple("editorial", "Editorial", "تحريري"),
        Triple("neon", "Neon", "نيون"),
        Triple("paper", "Paper", "ورق"),
        Triple("clay", "Soft Clay", "صلصال"),
        Triple("outline", "Minimal Outline", "خطوط بسيطة"),
        Triple("amoled", "AMOLED", "أموليد"),
        Triple("seasonal", "Seasonal", "موسمي")
    )

    val WIDGET_FONTS = listOf(
        Triple("sans", "System sans", "خط النظام"),
        Triple("naskh", "Naskh (serif)", "نسخ"),
        Triple("kufi", "Kufi", "كوفي"),
        Triple("cairo", "Cairo", "القاهرة"),
        Triple("rounded", "Rounded", "مستدير"),
        Triple("mono", "Mono numerals", "أرقام ثابتة")
    )

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')

    private data class Spec(val en: String, val ar: String, val arche: String, val inter: Boolean)

    private val RAW: Map<String, List<Spec>> = linkedMapOf(
        "clock" to listOf(
            Spec("Minimal digital", "رقمية بسيطة", "digital", false),
            Spec("Bold block", "كتلة عريضة", "digital", false),
            Spec("Split flap", "لوحة متقلبة", "flip", false),
            Spec("Flip clock", "ساعة قلّابة", "flip", false),
            Spec("Dot-matrix", "مصفوفة نقطية", "digital", false),
            Spec("Stacked words", "كلمات متراصة", "digital", false),
            Spec("Analog classic", "عقارب كلاسيكية", "analog", false),
            Spec("Analog skeleton", "عقارب هيكلية", "analog", false),
            Spec("Analog luxury", "عقارب فاخرة", "analog", false),
            Spec("Analog minimal", "عقارب بسيطة", "analog", false),
            Spec("Sun-arc clock", "ساعة قوس الشمس", "sunarc", false),
            Spec("Orbit clock", "ساعة المدار", "analog", false),
            Spec("World clock", "ساعة عالمية", "world", false),
            Spec("Dual-time", "توقيت مزدوج", "world", false),
            Spec("Clock + day summary", "ساعة + ملخص اليوم", "digital", false),
            Spec("Bedside clock", "ساعة السرير", "digital", false)
        ),
        "alarms" to listOf(
            Spec("Next alarm pill", "كبسولة المنبه التالي", "countdown", true),
            Spec("Alarm ring-dial", "قرص المنبه", "dial", true),
            Spec("Alarm list + toggles", "قائمة المنبهات", "checklist", true),
            Spec("Alarm timeline strip", "شريط المنبهات الزمني", "timeline", false),
            Spec("Alarm week grid", "شبكة أسبوع المنبهات", "week", false),
            Spec("Countdown to alarm", "عد تنازلي للمنبه", "countdown", false),
            Spec("Sleep-alarm combo", "النوم والمنبه", "dial", true),
            Spec("Snooze tracker", "متتبع الغفوة", "bars", false)
        ),
        "calendar" to listOf(
            Spec("Month compact", "شهر مدمج", "month", false),
            Spec("Month with artwork", "شهر بالزخارف", "month", false),
            Spec("Month heatmap", "خريطة حرارية شهرية", "heatmap", false),
            Spec("Week strip", "شريط الأسبوع", "week", false),
            Spec("Week columns", "أعمدة الأسبوع", "week", false),
            Spec("Agenda list", "قائمة الأجندة", "list", false),
            Spec("Agenda with artwork", "أجندة بالزخارف", "list", false),
            Spec("Year dots", "نقاط السنة", "mosaic", false),
            Spec("Hijri month", "الشهر الهجري", "month", false),
            Spec("Coptic month", "الشهر القبطي", "month", false),
            Spec("Tri-calendar date card", "بطاقة التقاويم الثلاثة", "tri", false),
            Spec("Day ring (24h)", "حلقة اليوم", "ring", false),
            Spec("Schedule river", "نهر الجدول", "timeline", false),
            Spec("Date flip", "تاريخ قلاب", "flip", false)
        ),
        "occasions" to listOf(
            Spec("Occasion hero", "بطل المناسبة", "hero", false),
            Spec("Occasion countdown ring", "حلقة العد للمناسبة", "ring", false),
            Spec("Upcoming carousel", "المناسبات القادمة", "list", false),
            Spec("Ramadan imsakiya", "إمساكية رمضان", "list", false),
            Spec("Iftar countdown", "العد للإفطار", "countdown", false),
            Spec("Eid greeting card", "بطاقة تهنئة العيد", "hero", false),
            Spec("Season greeting", "تحية الموسم", "hero", false),
            Spec("Nile & Egyptian seasons", "النيل والمواسم المصرية", "hero", false),
            Spec("National-day card", "بطاقة اليوم الوطني", "hero", false),
            Spec("Friday card", "بطاقة الجمعة", "hero", false),
            Spec("Hijri date card", "بطاقة التاريخ الهجري", "tri", false)
        ),
        "plan" to listOf(
            Spec("Current activity", "النشاط الحالي", "timeline", false),
            Spec("Now · Next · Later", "الآن · التالي · لاحقًا", "list", false),
            Spec("Timeline vertical", "خط زمني رأسي", "timeline", false),
            Spec("Timeline horizontal", "خط زمني أفقي", "timeline", false),
            Spec("Free-time gauge", "مقياس الوقت الحر", "dial", false),
            Spec("Day progress ring", "حلقة تقدم اليوم", "ring", false),
            Spec("Daily brief", "موجز اليوم", "list", false),
            Spec("Top priorities", "أهم الأولويات", "checklist", true),
            Spec("Focus window", "نافذة التركيز", "timeline", false),
            Spec("Plan board", "لوحة الخطة", "kanban", false),
            Spec("Yesterday · Today · Tomorrow", "أمس · اليوم · غدًا", "week", false),
            Spec("Schedule health", "صحة الجدول", "ring", false),
            Spec("Routine checklist", "قائمة الروتين", "checklist", true)
        ),
        "tasks" to listOf(
            Spec("Checklist", "قائمة تحقق", "checklist", true),
            Spec("Task rings", "حلقات المهام", "ring", false),
            Spec("Eisenhower matrix", "مصفوفة أيزنهاور", "matrix", true),
            Spec("Kanban strip", "شريط كانبان", "kanban", false),
            Spec("Quick-add bar", "شريط إضافة سريعة", "quick", true),
            Spec("Pinned note paper", "ورقة ملاحظة مثبتة", "note", false),
            Spec("Sticky-note stack", "كومة ملاحظات لاصقة", "note", false),
            Spec("Notes grid", "شبكة الملاحظات", "mosaic", false),
            Spec("Handwritten note", "ملاحظة بخط اليد", "note", false),
            Spec("Checklist cards", "بطاقات تحقق", "checklist", true),
            Spec("Overdue list", "المتأخرات", "list", false),
            Spec("Subtasks tree", "شجرة المهام الفرعية", "list", true),
            Spec("Shopping list", "قائمة التسوق", "checklist", true),
            Spec("Voice-note button", "زر ملاحظة صوتية", "quick", true),
            Spec("Journal prompt", "سؤال اليوميات", "note", false)
        ),
        "habits" to listOf(
            Spec("Habit grid", "شبكة العادات", "heatmap", true),
            Spec("Habit heatmap", "خريطة العادات", "heatmap", false),
            Spec("Streak card", "بطاقة السلسلة", "counter", false),
            Spec("Water drop", "قطرة ماء", "drop", true),
            Spec("Water bottle", "زجاجة ماء", "drop", true),
            Spec("Water cups", "أكواب الماء", "bars", true),
            Spec("Sleep dial", "قرص النوم", "dial", false),
            Spec("Bedtime countdown", "العد لوقت النوم", "countdown", false),
            Spec("Workout today", "تمرين اليوم", "ring", true),
            Spec("Workout week", "تمارين الأسبوع", "bars", false),
            Spec("Medication schedule", "جدول الأدوية", "checklist", true),
            Spec("Mood strip", "شريط المزاج", "mosaic", true)
        ),
        "focus" to listOf(
            Spec("Focus timer ring", "حلقة مؤقت التركيز", "ring", true),
            Spec("Pomodoro cycle", "دورة بومودورو", "dial", true),
            Spec("Study planner", "مخطط الدراسة", "list", false),
            Spec("Exam countdown stack", "عد الامتحانات", "countdown", false),
            Spec("Subject progress", "تقدم المواد", "bars", false),
            Spec("Deep-work block", "فترة عمل عميق", "timeline", false),
            Spec("Break reminder", "تذكير الاستراحة", "countdown", false),
            Spec("Study streak", "سلسلة الدراسة", "counter", false)
        ),
        "review" to listOf(
            Spec("Daily score ring", "حلقة نتيجة اليوم", "ring", false),
            Spec("Weekly radar", "رادار الأسبوع", "radar", false),
            Spec("Yearly mosaic", "فسيفساء السنة", "mosaic", false),
            Spec("Strengths card", "بطاقة نقاط القوة", "bars", false),
            Spec("What you did", "ماذا أنجزت", "list", false),
            Spec("Productivity sparkline", "خط الإنتاجية", "spark", false),
            Spec("Time-budget donut", "دونات ميزانية الوقت", "donut", false),
            Spec("Consistency calendar", "تقويم الاستمرارية", "heatmap", false),
            Spec("Trend arrow", "سهم الاتجاه", "spark", false),
            Spec("Milestone card", "بطاقة الإنجاز", "counter", false),
            Spec("Personal records", "الأرقام الشخصية", "bars", false)
        ),
        "media" to listOf(
            Spec("Active downloads", "التنزيلات النشطة", "download", true),
            Spec("Paste-link tile", "بلاطة لصق الرابط", "quick", true),
            Spec("Download history", "سجل التنزيلات", "list", false),
            Spec("Recent audio", "أحدث الصوتيات", "list", false),
            Spec("Recent video", "أحدث الفيديو", "mosaic", false),
            Spec("Storage usage", "استخدام التخزين", "donut", false)
        ),
        "utility" to listOf(
            Spec("Battery ring", "حلقة البطارية", "battery", false),
            Spec("Battery detail", "تفاصيل البطارية", "battery", false),
            Spec("Quick actions grid", "شبكة الإجراءات السريعة", "quick", true),
            Spec("Stopwatch", "ساعة إيقاف", "digital", true),
            Spec("Timer", "مؤقت", "ring", true),
            Spec("Unit tile", "بلاطة الوحدات", "quick", false),
            Spec("Tasbih counter", "عداد التسبيح", "counter", true),
            Spec("Khatma tracker", "متتبع الختمة", "bars", true),
            Spec("Prayer schedule", "جدول الصلوات", "prayer", false),
            Spec("Qibla compass", "بوصلة القبلة", "compass", false),
            Spec("Prayer times strip", "شريط مواقيت الصلاة", "prayer", false),
            Spec("Next prayer", "الصلاة القادمة", "nextprayer", false),
            Spec("Prayer times (ornate)", "المواقيت بالزخرفة", "prayer", false),
            Spec("Next prayer ring", "حلقة الصلاة القادمة", "nextprayer", false),
            Spec("Fajr & Maghrib card", "بطاقة الفجر والمغرب", "nextprayer", false),
            Spec("Mosque board", "لوحة المسجد", "prayer", false),
            Spec("Adhkar & Tasbih", "الأذكار والتسبيح", "counter", true),
            Spec("Khatma + prayer", "الختمة والصلاة", "bars", false),
            Spec("Countdown", "عد تنازلي", "countdown", false),
            Spec("Anniversary card", "بطاقة الذكرى", "hero", false),
            Spec("Date calculator", "حاسبة التاريخ", "tri", false),
            Spec("QR quick scan", "مسح QR سريع", "quick", true)
        ),
        "companion" to listOf(
            Spec("Companion portrait", "صورة الرفيق", "portrait", false),
            Spec("Companion quick-actions", "إجراءات الرفيق", "quick", true),
            Spec("Companion mood", "مزاج الرفيق", "portrait", false),
            Spec("Companion tip", "نصيحة الرفيق", "portrait", false)
        )
    )

    val WIDGETS: List<WidgetDef> = RAW.flatMap { (cat, specs) ->
        specs.mapIndexed { idx, s ->
            val allowedForms = when (s.arche) {
                "matrix", "kanban", "month" -> listOf("2x2", "4x2", "4x4")
                "note" -> listOf("2x1", "2x2", "4x2", "4x4")
                else -> FORMS
            }
            WidgetDef(
                id = "$cat-${slug(s.en)}",
                en = s.en,
                ar = s.ar,
                cat = cat,
                arche = s.arche,
                variant = idx,
                interactive = s.inter,
                forms = allowedForms
            )
        }
    }

    fun formSize(f: String): Pair<Int, Int> {
        val bits = f.split("x")
        return (bits.getOrNull(0)?.toIntOrNull() ?: 2) to (bits.getOrNull(1)?.toIntOrNull() ?: 2)
    }

    fun resolveForm(def: WidgetDef, w: Int, h: Int): String {
        var best = def.forms.first()
        var bestScore = Int.MIN_VALUE
        for (f in def.forms) {
            val (fw, fh) = formSize(f)
            if (fw > w || fh > h) continue
            val score = fw * fh * 10 - (w - fw) - (h - fh)
            if (score > bestScore) {
                bestScore = score
                best = f
            }
        }
        return best
    }
}
