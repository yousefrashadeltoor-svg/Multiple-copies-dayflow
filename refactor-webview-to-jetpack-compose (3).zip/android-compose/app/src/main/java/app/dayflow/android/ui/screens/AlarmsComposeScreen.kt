package app.dayflow.android.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.AlarmItem
import app.dayflow.android.model.AlarmSound
import app.dayflow.android.model.DayflowState
import app.dayflow.android.system.AlarmAndReminderManager
import app.dayflow.android.system.AlarmRingActivity
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import java.time.LocalDate
import java.util.Calendar

private val DAY_ORDER = listOf(6, 0, 1, 2, 3, 4, 5) // Sat -> Fri

@Composable
fun AlarmsComposeScreen(state: DayflowState) {
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val lang = state.lang
    val ar = lang == "ar"
    var editing by remember { mutableStateOf<AlarmItem?>(null) }
    var permissionNotice by remember { mutableStateOf("") }

    val next = remember(state.alarms) { Time12h.nextAlarmTime(state.alarms) }
    val dayNamesShort = if (ar) mapOf(6 to "سبت", 0 to "أحد", 1 to "اثنين", 2 to "ثلاثاء", 3 to "أربعاء", 4 to "خميس", 5 to "جمعة")
    else mapOf(6 to "Sat", 0 to "Sun", 1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri")

    fun blankAlarm() = AlarmItem(
        id = "",
        time = "07:00",
        days = listOf(0, 1, 2, 3, 4),
        label = "",
        enabled = true,
        sound = AlarmSound("device", if (ar) "منبه الجهاز الافتراضي" else "Default alarm (device)", ""),
        vibrate = true,
        snooze = 10,
        gentle = true
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(
            title = if (ar) "المنبهات" else "Alarms",
            subtitle = if (next != null) {
                val t12 = Time12h.formatHhMm(next.alarm.time, lang).full
                if (ar) "التالي: $t12" else "Next: $t12"
            } else {
                if (ar) "لا منبهات مفعّلة" else "No alarms on"
            },
            right = {
                Button(
                    onClick = { editing = blankAlarm() },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (ar) "جديد" else "New", fontWeight = FontWeight.Bold)
                }
            }
        )

        if (permissionNotice.isNotBlank()) {
            DayflowCard {
                Text(permissionNotice, fontSize = 12.5.sp, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(6.dp))
                Button(onClick = {
                    permissionNotice = ""
                    AlarmAndReminderManager.openExactAlarmSettings(context)
                }) {
                    Text(if (ar) "تفعيل صلاحية المنبهات الدقيقة" else "Grant Exact Alarm Access")
                }
            }
        }

        if (state.alarms.isEmpty()) {
            DayflowCard {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    MotifCanvas(family = CalendarsAndDecor.resolveDecor().primary, size = 64.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(if (ar) "مفيش منبهات لسه" else "No alarms yet", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(if (ar) "أنشئ منبهًا حقيقيًا يرن حتى والهاتف مقفل." else "Create an exact alarm that rings on lockscreen.", fontSize = 12.5.sp, color = c.muted)
                }
            }
        }

        state.alarms.sortedBy { it.time }.forEach { alarm ->
            val t12 = Time12h.formatHhMm(alarm.time, lang)
            val scheduleLabel = when {
                !alarm.date.isNullOrBlank() && alarm.days.isEmpty() -> alarm.date
                alarm.days.size == 7 -> if (ar) "كل يوم" else "Every day"
                alarm.days.isEmpty() -> if (ar) "مرة واحدة" else "Once"
                else -> DAY_ORDER.filter { alarm.days.contains(it) }.joinToString(" · ") { dayNamesShort[it] ?: "" }
            }

            DayflowCard(onClick = { editing = alarm }) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f).alpha(if (alarm.enabled) 1f else 0.5f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(t12.time, fontSize = 36.sp, fontWeight = FontWeight.SemiBold, color = c.text)
                            Spacer(Modifier.width(6.dp))
                            Text(t12.suffix, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = c.accent, modifier = Modifier.padding(bottom = 5.dp))
                        }
                        Text(alarm.label.ifBlank { if (ar) "منبه" else "Alarm" }, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = c.text)
                        Text("$scheduleLabel · ${alarm.sound.title}", fontSize = 11.5.sp, color = c.muted)
                    }
                    DayflowToggle(
                        checked = alarm.enabled,
                        onCheckedChange = { nextEnabled ->
                            if (nextEnabled && !AlarmAndReminderManager.canScheduleExactAlarms(context)) {
                                permissionNotice = if (ar) "يرجى السماح لـ DAYFLOW بضبط المنبهات الدقيقة من إعدادات أندرويد." else "Please allow Exact Alarms in Android Settings."
                            } else {
                                DayflowRepository.toggleAlarm(alarm.id, nextEnabled)
                            }
                        }
                    )
                }
            }
        }
    }

    if (editing != null) {
        AlarmEditorSheet(
            initial = editing!!,
            lang = lang,
            onDismiss = { editing = null },
            onSaved = { editing = null },
            onNeedExactPermission = {
                editing = null
                permissionNotice = if (ar) "اسمح بصلاحية المنبهات الدقيقة ثم احفظ المنبه." else "Allow Exact Alarms access then save again."
                AlarmAndReminderManager.openExactAlarmSettings(context)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AlarmEditorSheet(
    initial: AlarmItem,
    lang: String,
    onDismiss: () -> Unit,
    onSaved: () -> Unit,
    onNeedExactPermission: () -> Unit
) {
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val ar = lang == "ar"
    var draft by remember { mutableStateOf(initial) }
    var soundSheet by remember { mutableStateOf(false) }

    val dayNarrow = if (ar) mapOf(6 to "س", 0 to "ح", 1 to "ن", 2 to "ث", 3 to "ر", 4 to "خ", 5 to "ج")
    else mapOf(6 to "S", 0 to "S", 1 to "M", 2 to "T", 3 to "W", 4 to "T", 5 to "F")

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (draft.id.isBlank()) (if (ar) "منبه جديد" else "New alarm") else (if (ar) "تعديل المنبه" else "Edit alarm"),
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TimePicker12h(
                    value24 = draft.time,
                    lang = lang,
                    onValueChange = { draft = draft.copy(time = it) },
                    large = true
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                DayflowChip(
                    selected = draft.days.isEmpty(),
                    label = if (ar) "مرة واحدة" else "Once",
                    onClick = { draft = draft.copy(days = emptyList(), date = CalendarsAndDecor.todayKey()) }
                )
                DayflowChip(
                    selected = draft.days.sorted() == listOf(0, 1, 2, 3, 4),
                    label = if (ar) "الأحد–الخميس" else "Sun–Thu",
                    onClick = { draft = draft.copy(days = listOf(0, 1, 2, 3, 4), date = null) }
                )
                DayflowChip(
                    selected = draft.days.sorted() == listOf(5, 6),
                    label = if (ar) "الجمعة–السبت" else "Fri–Sat",
                    onClick = { draft = draft.copy(days = listOf(5, 6), date = null) }
                )
                DayflowChip(
                    selected = draft.days.size == 7,
                    label = if (ar) "كل يوم" else "Every day",
                    onClick = { draft = draft.copy(days = listOf(0, 1, 2, 3, 4, 5, 6), date = null) }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                DAY_ORDER.forEach { d ->
                    val active = draft.days.contains(d)
                    DayflowChip(
                        selected = active,
                        label = dayNarrow[d] ?: "",
                        onClick = {
                            val nextDays = if (active) draft.days - d else draft.days + d
                            draft = draft.copy(days = nextDays, date = null)
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            OutlinedTextField(
                value = draft.label,
                onValueChange = { draft = draft.copy(label = it) },
                placeholder = { Text(if (ar) "الاسم (اختياري)" else "Label (optional)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            DayflowCard(onClick = { soundSheet = true }, contentPadding = PaddingValues(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.Notifications, contentDescription = null, tint = c.accent)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (ar) "الصوت / النغمة" else "Sound", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(draft.sound.title, fontSize = 12.sp, color = c.muted)
                    }
                }
            }

            DayflowCard(contentPadding = PaddingValues(0.dp)) {
                RowItem(
                    title = if (ar) "اهتزاز" else "Vibrate",
                    trailing = { DayflowToggle(checked = draft.vibrate, onCheckedChange = { draft = draft.copy(vibrate = it) }) }
                )
                HorizontalDivider(color = c.line)
                RowItem(
                    title = if (ar) "استيقاظ لطيف" else "Gentle wake",
                    hint = if (ar) "يرتفع الصوت تدريجيًا خلال ٦٠ ثانية" else "Volume rises over 60 seconds",
                    trailing = { DayflowToggle(checked = draft.gentle, onCheckedChange = { draft = draft.copy(gentle = it) }) }
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (draft.id.isNotBlank()) {
                    OutlinedButton(onClick = {
                        DayflowRepository.deleteAlarm(draft.id)
                        onDismiss()
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete")
                    }
                }
                FilledTonalButton(onClick = {
                    val previewIntent = Intent(context, AlarmRingActivity::class.java).apply {
                        putExtra("alarmId", "")
                        putExtra("label", draft.label.ifBlank { if (ar) "معاينة المنبه" else "Alarm preview" })
                        putExtra("soundUri", draft.sound.uri)
                        putExtra("vibrate", draft.vibrate)
                        putExtra("snooze", draft.snooze)
                        putExtra("gentle", draft.gentle)
                    }
                    context.startActivity(previewIntent)
                }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Text(if (ar) "معاينة" else "Preview")
                }
                Button(
                    onClick = {
                        if (!AlarmAndReminderManager.canScheduleExactAlarms(context)) {
                            onNeedExactPermission()
                            return@Button
                        }
                        var finalDraft = draft
                        if (finalDraft.days.isEmpty()) {
                            val bits = finalDraft.time.split(":")
                            val hh = bits[0].toInt()
                            val mm = bits[1].toInt()
                            val cal = Calendar.getInstance()
                            val targetDate = if (hh * 60 + mm <= cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)) {
                                CalendarsAndDecor.dayKey(LocalDate.now().plusDays(1))
                            } else CalendarsAndDecor.todayKey()
                            finalDraft = finalDraft.copy(date = targetDate)
                        }
                        if (DayflowRepository.saveAlarm(finalDraft)) {
                            onSaved()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    Text(if (ar) "حفظ" else "Save", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (soundSheet) {
        SoundPickerModal(
            current = draft.sound,
            lang = lang,
            onPick = {
                draft = draft.copy(sound = it)
                soundSheet = false
            },
            onDismiss = { soundSheet = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SoundPickerModal(
    current: AlarmSound,
    lang: String,
    onPick: (AlarmSound) -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val ar = lang == "ar"
    var tab by remember { mutableStateOf(current.source.ifBlank { "device" }) }
    val deviceTones = remember { AlarmAndReminderManager.listDeviceTones(context) }

    val audioLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val picked = AlarmAndReminderManager.persistCustomSoundUri(context, uri)
            onPick(picked)
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (ar) "اختر نغمة المنبه" else "Choose alarm sound", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            SegmentedBar(
                value = tab,
                options = listOf(
                    "device" to (if (ar) "نغمات الهاتف" else "Device"),
                    "files" to (if (ar) "ملفاتي والموسيقى" else "My files")
                ),
                onSelect = { tab = it }
            )

            if (tab == "device") {
                Column(modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                    deviceTones.forEach { tone ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(tone) }
                                .padding(vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = c.accent)
                            Text(tone.title, modifier = Modifier.weight(1f), fontSize = 14.sp, color = c.text)
                            if (current.uri == tone.uri || current.title == tone.title) {
                                Text("✓", color = c.accent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                Button(
                    onClick = { audioLauncher.launch(arrayOf("audio/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (ar) "اختر ملف صوتي أو موسيقى من الهاتف" else "Pick audio file from device")
                }
            }
        }
    }
}
