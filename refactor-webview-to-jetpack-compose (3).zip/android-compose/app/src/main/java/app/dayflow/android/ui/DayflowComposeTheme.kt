package app.dayflow.android.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import app.dayflow.android.domain.PrayerEngine
import app.dayflow.android.domain.ThemesCatalog
import app.dayflow.android.model.DayflowState
import app.dayflow.android.model.ThemePack
import java.util.Calendar

data class DayflowColors(
    val pack: ThemePack,
    val bg: Color,
    val surface: Color,
    val text: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val muted: Color,
    val line: Color,
    val soft: Color,
    val isDark: Boolean,
    val periodId: String
)

val LocalDayflowColors = staticCompositionLocalOf {
    val def = ThemesCatalog.THEMES.first()
    DayflowColors(
        pack = def,
        bg = Color(0xFFF7F5F0),
        surface = Color.White,
        text = Color(0xFF1D1C1A),
        accent = Color(0xFF2F6F5E),
        accent2 = Color(0xFFC9A24A),
        onAccent = Color.White,
        muted = Color(0xFF6E6A63),
        line = Color(0x1F1D1C1A),
        soft = Color(0x1F2F6F5E),
        isDark = false,
        periodId = "morning"
    )
}

fun hexColor(hex: String): Color = Color(ThemesCatalog.parseHexColor(hex))

@Composable
fun DayflowComposeTheme(
    state: DayflowState,
    content: @Composable () -> Unit
) {
    val allThemes = remember(state.customThemes) { ThemesCatalog.THEMES + state.customThemes }
    val city = state.customLocation ?: PrayerEngine.CITIES.getOrElse(state.cityIndex) { PrayerEngine.CITIES.first() }
    val prayer = remember(city) { PrayerEngine.calculate(city) }
    val cal = remember { Calendar.getInstance() }
    val periodId = remember(prayer) {
        ThemesCatalog.periodAt(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), prayer)
    }
    val periodInfo = ThemesCatalog.PERIODS[periodId] ?: ThemesCatalog.PERIODS["morning"]!!
    val autoThemeId = state.periodThemes[periodId] ?: periodInfo.defaultThemeId

    val activePack = remember(state.autoTimeTheme, state.themeId, autoThemeId, allThemes) {
        if (state.autoTimeTheme) {
            allThemes.find { it.id == autoThemeId } ?: allThemes.find { it.id == state.themeId } ?: allThemes.first()
        } else {
            allThemes.find { it.id == state.themeId } ?: allThemes.first()
        }
    }

    val bg = hexColor(activePack.bg)
    val surface = hexColor(activePack.surface)
    val text = hexColor(activePack.text)
    val accent = hexColor(activePack.accent)
    val accent2 = hexColor(activePack.accent2)
    val onAccent = if (accent.luminance() > 0.45f) Color(0xFF111111) else Color.White
    val isDark = activePack.mode == "dark"
    val muted = text.copy(alpha = 0.60f)
    val line = text.copy(alpha = if (isDark) 0.16f else 0.11f)
    val soft = accent.copy(alpha = if (isDark) 0.20f else 0.13f)

    val colors = DayflowColors(
        pack = activePack,
        bg = bg,
        surface = surface,
        text = text,
        accent = accent,
        accent2 = accent2,
        onAccent = onAccent,
        muted = muted,
        line = line,
        soft = soft,
        isDark = isDark,
        periodId = periodId
    )

    val m3Scheme = if (isDark) {
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            secondary = accent2,
            background = bg,
            surface = surface,
            onBackground = text,
            onSurface = text
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            secondary = accent2,
            background = bg,
            surface = surface,
            onBackground = text,
            onSurface = text
        )
    }

    val dir = if (state.lang == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalDayflowColors provides colors,
        LocalLayoutDirection provides dir
    ) {
        MaterialTheme(
            colorScheme = m3Scheme,
            content = content
        )
    }
}
