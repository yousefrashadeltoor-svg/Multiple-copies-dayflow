package app.dayflow.android.system

import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.AlarmItem
import app.dayflow.android.ui.components.MotifCanvas
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

class AlarmRingActivity : ComponentActivity() {
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val volumeHandler = Handler(Looper.getMainLooper())
    private var currentVolume = 1.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        }
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )

        DayflowRepository.init(this)
        val alarmId = intent.getStringExtra("alarmId") ?: ""
        val label = intent.getStringExtra("label").orEmpty()
        val soundUri = intent.getStringExtra("soundUri").orEmpty()
        val vibrate = intent.getBooleanExtra("vibrate", true)
        val snooze = intent.getIntExtra("snooze", 10)
        val gentle = intent.getBooleanExtra("gentle", true)

        startAlarmAudioAndVibration(soundUri, vibrate, gentle)

        setContent {
            val state by DayflowRepository.state.collectAsState()
            val lang = state.lang
            val decor = remember { CalendarsAndDecor.resolveDecor(LocalDate.now(), state.userDays) }
            val pal = CalendarsAndDecor.familyOf(decor.primary)
            var nowCal by remember { mutableStateOf(Calendar.getInstance()) }
            var sliderVal by remember { mutableFloatStateOf(0f) }

            LaunchedEffect(Unit) {
                while (true) {
                    delay(1000L)
                    nowCal = Calendar.getInstance()
                }
            }

            val infinite = rememberInfiniteTransition(label = "pulse")
            val pulseScale by infinite.animateFloat(
                initialValue = 1f,
                targetValue = 1.65f,
                animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing)),
                label = "ringPulse"
            )

            val bgBrush = if (state.alarmLook.gradient) {
                Brush.verticalGradient(listOf(Color(pal.c2), Color(0xFF0B0F1A)))
            } else {
                Brush.verticalGradient(listOf(Color(0xFF0B0F1A), Color(0xFF0B0F1A)))
            }

            val timeParts = Time12h.formatCalendar(nowCal, lang, state.alarmLook.showSeconds)
            val dateStr = remember(lang) {
                LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE، d MMMM", if (lang == "ar") Locale("ar", "EG") else Locale.ENGLISH))
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgBrush)
                    .systemBarsPadding()
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 36.dp)) {
                        Text(
                            text = if (lang == "ar") "منبه DAYFLOW" else "DAYFLOW ALARM",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 13.sp,
                            letterSpacing = 3.sp
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = timeParts.time,
                                color = Color.White,
                                fontSize = if (state.alarmLook.layout == "minimal") 56.sp else 68.sp,
                                fontWeight = FontWeight.ExtraLight
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = timeParts.suffix,
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(bottom = 10.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = label.ifBlank { if (lang == "ar") "منبه" else "Alarm" },
                            color = Color.White.copy(alpha = 0.92f),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(text = dateStr, color = Color.White.copy(alpha = 0.65f), fontSize = 14.sp)
                    }

                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(144.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.12f))
                        )
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            MotifCanvas(family = decor.primary, size = 76.dp, tint = Color.White)
                        }
                    }

                    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Button(
                            onClick = { snoozeAndFinish(alarmId, label, soundUri, vibrate, snooze) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f), contentColor = Color.White)
                        ) {
                            Text(
                                text = if (lang == "ar") "غفوة ${Time12h.fmtNum(snooze, "ar")} دقائق" else "Snooze $snooze min",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .clip(RoundedCornerShape(32.dp))
                                .background(Color.White.copy(alpha = 0.22f))
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (lang == "ar") "اسحب للإيقاف ←" else "Slide to dismiss →",
                                color = Color.White.copy(alpha = 0.85f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Slider(
                                value = sliderVal,
                                onValueChange = { v ->
                                    sliderVal = v
                                    if (v >= 0.92f) {
                                        dismissAndFinish(alarmId)
                                    }
                                },
                                onValueChangeFinished = {
                                    if (sliderVal < 0.92f) sliderVal = 0f
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = Color.White,
                                    activeTrackColor = Color.White.copy(alpha = 0.45f),
                                    inactiveTrackColor = Color.Transparent
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    private fun startAlarmAudioAndVibration(soundUri: String, vibrate: Boolean, gentle: Boolean) {
        val targetUri: Uri = if (soundUri.isNotBlank() && !soundUri.startsWith("dayflow://")) {
            runCatching { Uri.parse(soundUri) }.getOrNull()
        } else null ?: Settings.System.DEFAULT_ALARM_ALERT_URI ?: Settings.System.DEFAULT_RINGTONE_URI

        runCatching {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            try {
                mp.setDataSource(this, targetUri)
            } catch (_: Exception) {
                mp.reset()
                mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                mp.setDataSource(this, Settings.System.DEFAULT_ALARM_ALERT_URI)
            }
            mp.isLooping = true
            mp.prepare()
            currentVolume = if (gentle) 0.08f else 1.0f
            mp.setVolume(currentVolume, currentVolume)
            mp.start()
            mediaPlayer = mp

            if (gentle) {
                val ramp = object : Runnable {
                    override fun run() {
                        val p = mediaPlayer ?: return
                        if (currentVolume < 1.0f) {
                            currentVolume = (currentVolume + 0.03f).coerceAtMost(1.0f)
                            runCatching { p.setVolume(currentVolume, currentVolume) }
                            volumeHandler.postDelayed(this, 1800L)
                        }
                    }
                }
                volumeHandler.postDelayed(ramp, 1800L)
            }
        }

        if (vibrate) {
            vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            runCatching {
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 300, 600), 0))
            }
        }
    }

    private fun snoozeAndFinish(alarmId: String, label: String, soundUri: String, vibrate: Boolean, snoozeMin: Int) {
        stopMedia()
        if (alarmId.isNotBlank()) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(alarmId.hashCode() and 0x7fffffff)
        }
        val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, snoozeMin.coerceAtLeast(1)) }
        val hhmm = "%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE))
        val dateStr = "%04d-%02d-%02d".format(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val snoozeItem = AlarmItem(
            id = DayflowRepository.newId(),
            time = hhmm,
            date = dateStr,
            days = emptyList(),
            label = if (label.isBlank()) "غفوة" else "$label (غفوة)",
            enabled = true,
            sound = app.dayflow.android.model.AlarmSound("device", "Snooze", soundUri),
            vibrate = vibrate,
            snooze = snoozeMin,
            gentle = false
        )
        DayflowRepository.saveAlarm(snoozeItem)
        finish()
    }

    private fun dismissAndFinish(alarmId: String) {
        stopMedia()
        if (alarmId.isNotBlank()) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(alarmId.hashCode() and 0x7fffffff)
        }
        finish()
    }

    private fun stopMedia() {
        volumeHandler.removeCallbacksAndMessages(null)
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null
        runCatching { vibrator?.cancel() }
        vibrator = null
    }

    override fun onDestroy() {
        stopMedia()
        super.onDestroy()
    }
}
