package app.dayflow.android.domain

import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.model.*
import java.time.LocalDate
import java.util.Calendar
import kotlin.math.roundToInt

data class ReviewDimScore(
    val id: String,
    val en: String,
    val ar: String,
    val score: Int?, // null if not recorded
    val evidenceEn: String,
    val evidenceAr: String,
    val formulaEn: String,
    val formulaAr: String
)

data class DayReviewResult(
    val date: String,
    val score: Int,
    val narrativeEn: String,
    val narrativeAr: String,
    val wins: List<Pair<String, String>>,
    val suggestions: List<Triple<String, String, String>>,
    val priorityEn: String,
    val priorityAr: String,
    val dims: List<ReviewDimScore>
)

data class RobotBubble(
    val id: String,
    val text: String,
    val mood: String,
    val actionTab: String? = null,
    val actionSub: String? = null
)

data class LocalBrainReply(
    val text: String,
    val mood: String,
    val records: List<ActionRecord> = emptyList()
)

object ReviewAndSoulEngine {
    private val GREET_MORNING = listOf(
        "صباح الفل يا صاحبي ☀️",
        "صباح الخير يا نجم، قوم نبدأ يومنا بهدوء",
        "صباح الجدعنة ☕ إيه خطة النهاردة؟",
        "النهاردة يوم جديد، يلا نرتبه صح 💛"
    )
    private val GREET_EVENING = listOf(
        "مساء الجمال يا فندم 🌙",
        "مسا الخير، نلخص يومنا شوية؟",
        "شكل اليوم كان طويل، خد نفسك وارتاح",
        "مساء السكينة، إيه أحلى حاجة حصلت النهاردة؟"
    )
    private val TIPS = listOf(
        "اشرب كوباية ماية، دماغك هتشكرك 💧",
        "خد نفس عميق ٤ ثواني، وطلعه في ٦",
        "خطّط ٣ حاجات بس للنهاردة، وهتخلصهم",
        "قسّم الشغل الكبير لخطوات صغيرة وابدأ بأسهل واحدة"
    )

    fun evaluateDay(state: DayflowState, date: LocalDate = LocalDate.now()): DayReviewResult {
        val key = CalendarsAndDecor.dayKey(date)
        val dayTasks = state.tasks.filter { it.date == key }
        val doneCount = dayTasks.count { it.done }
        val waterMl = state.water[key] ?: if (state.sampleData) 2000 else 0
        val scheduledHabits = state.habits.filter { it.days.isEmpty() || it.days.contains(date.dayOfWeek.value % 7) }
        val habitsDone = scheduledHabits.count { it.log.contains(key) }
        val journalEntry = state.journal.find { it.date == key }

        val taskScore = if (dayTasks.isNotEmpty()) ((doneCount.toFloat() / dayTasks.size) * 100).roundToInt() else if (state.sampleData) 82 else null
        val habitScore = if (scheduledHabits.isNotEmpty()) ((habitsDone.toFloat() / scheduledHabits.size) * 100).roundToInt() else if (state.sampleData) 76 else null
        val waterScore = if (waterMl > 0 || state.sampleData) ((waterMl.toFloat() / state.waterGoal.coerceAtLeast(500)) * 100).coerceAtMost(100f).roundToInt() else null
        val moodScore = journalEntry?.let { it.mood * 20 } ?: if (state.sampleData) 80 else null
        val spiritualScore = if (state.spiritual) ((state.tasbih.coerceAtMost(100) + state.khatma * 3).coerceAtMost(100)) else null

        val dims = listOf(
            ReviewDimScore("tasks", "Task completion", "إنجاز المهام", taskScore, "$doneCount/${dayTasks.size} completed", "$doneCount من ${dayTasks.size} مكتملة", "completed ÷ planned × 100", "المنجزة ÷ المخططة × ١٠٠"),
            ReviewDimScore("consistency", "Habit consistency", "استمرارية العادات", habitScore, "$habitsDone/${scheduledHabits.size} habits", "$habitsDone من ${scheduledHabits.size} عادات", "scheduled habits done ÷ due", "العادات المنجزة ÷ المجدولة"),
            ReviewDimScore("hydration", "Hydration", "شرب الماء", waterScore, "$waterMl / ${state.waterGoal} ml", "$waterMl / ${state.waterGoal} مل", "ml ÷ daily goal × 100", "الكمية ÷ الهدف اليومي × ١٠٠"),
            ReviewDimScore("reflection", "Journal & mood", "التدوين والمزاج", moodScore, if (journalEntry != null) "Recorded" else "Optional", if (journalEntry != null) "مسجل" else "اختياري", "mood 1..5 × 20", "المزاج ١..٥ × ٢٠"),
            ReviewDimScore("spiritual", "Spiritual routine", "الورد الروحي", spiritualScore, "Tasbih ${state.tasbih}", "التسبيح ${state.tasbih}", "opt-in adhkar & juz progress", "اختياري: الأذكار والختمة")
        )

        val counted = dims.mapNotNull { it.score }
        val finalScore = if (counted.isNotEmpty()) counted.average().roundToInt() else 72

        val wins = mutableListOf<Pair<String, String>>()
        if ((taskScore ?: 0) >= 70) wins.add("Completed most planned tasks" to "أنجزت معظم مهامك المخططة اليوم")
        if ((waterScore ?: 0) >= 80) wins.add("Stayed well hydrated" to "حافظت على شرب الماء بانتظام")
        if ((habitScore ?: 0) >= 70) wins.add("Kept your habit streak alive" to "حافظت على سلسلة عاداتك اليومية")
        if (wins.isEmpty()) wins.add("Showed up calmly for your day" to "بدأت يومك بهدوء وتنظيم")

        val suggestions = listOf(
            Triple("s_water", "Add one glass of water before afternoon focus.", "اشرب كوب ماء قبل جلسة التركيز القادمة."),
            Triple("s_top3", "Pick at most 3 important tasks for tomorrow morning.", "حدّد ٣ مهام مهمة كحد أقصى لصباح الغد.")
        )

        val narrativeEn = "Score $finalScore/100 based on ${counted.size} recorded dimensions."
        val narrativeAr = "نتيجتك ${Time12h.fmtNum(finalScore, "ar")} من ١٠٠ بناءً على ${Time12h.fmtNum(counted.size, "ar")} أبعاد مسجلة فعليًا."

        return DayReviewResult(
            date = key,
            score = finalScore,
            narrativeEn = narrativeEn,
            narrativeAr = narrativeAr,
            wins = wins,
            suggestions = suggestions,
            priorityEn = dayTasks.firstOrNull { !it.done }?.title ?: "Plan tomorrow's top task",
            priorityAr = dayTasks.firstOrNull { !it.done }?.title ?: "حدّد أهم مهمة واحدة لبكرة",
            dims = dims
        )
    }

    fun guardNarrative(text: String, allowedNumbers: Set<String>): Pair<Boolean, List<String>> {
        val found = Regex("\\d+(\\.\\d+)?").findAll(text).map { it.value }.toList()
        val bad = found.filterNot { allowedNumbers.contains(it) }
        return (bad.isEmpty()) to bad
    }

    fun currentBubble(state: DayflowState): RobotBubble {
        val lang = state.lang
        val nextAlarm = Time12h.nextAlarmTime(state.alarms)
        if (nextAlarm != null) {
            val mins = ((nextAlarm.triggerMillis - System.currentTimeMillis()) / 60_000L).coerceAtLeast(1)
            val hh = mins / 60
            val mm = mins % 60
            val t12 = Time12h.formatHhMm(nextAlarm.alarm.time, lang).full
            val whenAr = if (hh > 0) "${Time12h.fmtNum(hh, "ar")} ساعة و${Time12h.fmtNum(mm, "ar")} د" else "${Time12h.fmtNum(mm, "ar")} دقيقة"
            val whenEn = if (hh > 0) "${hh}h ${mm}m" else "${mm}m"
            val label = nextAlarm.alarm.label.ifBlank { if (lang == "ar") "المنبه" else "Alarm" }
            return RobotBubble(
                id = "alarm_${nextAlarm.alarm.id}",
                text = if (lang == "ar") "فاضل $whenAr على منبه «$label» ($t12) ⏰" else "Alarm “$label” ($t12) in $whenEn ⏰",
                mood = "worried",
                actionTab = "alarms"
            )
        }

        val today = CalendarsAndDecor.todayKey()
        val openTasks = state.tasks.filter { it.date == today && !it.done }
        if (openTasks.isNotEmpty()) {
            val first = openTasks.first()
            val dueStr = first.dueTime?.let { " (${Time12h.formatHhMm(it, lang).full})" } ?: ""
            return RobotBubble(
                id = "task_${first.id}",
                text = if (lang == "ar") "فاكر «${first.title}»$dueStr؟ لسه مستنياك 📌" else "“${first.title}”$dueStr is waiting 📌",
                mood = "idle",
                actionTab = "tools",
                actionSub = "tasks"
            )
        }

        val doneToday = state.tasks.any { it.date == today && it.done }
        if (doneToday) {
            return RobotBubble(
                id = "celebrate",
                text = if (lang == "ar") "خلصت كل مهام النهاردة! أنا فخور بيك 🎉" else "All today's tasks are done! 🎉",
                mood = "celebrate"
            )
        }

        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val line = if (lang == "en") {
            if (hr < 12) "Good morning! Ready when you are ☀️" else "Calm evening — need anything? 🌙"
        } else {
            val pool = if (hr < 12) GREET_MORNING else if (hr >= 18) GREET_EVENING else TIPS
            pool[((System.currentTimeMillis() / 9000L) % pool.size).toInt()]
        }
        return RobotBubble("mood_idle", line, if (hr < 5) "sleep" else "idle")
    }

    /** Fast offline Egyptian Arabic & English local intent engine */
    fun processLocalCommand(rawInput: String, state: DayflowState, onNavigate: (String, String?) -> Unit): LocalBrainReply {
        val western = rawInput
            .map { ch ->
                val idx = "٠١٢٣٤٥٦٧٨٩".indexOf(ch)
                if (idx >= 0) ('0' + idx) else ch
            }
            .joinToString("")
            .trim()
        val q = western.lowercase()
        val ar = state.lang == "ar"

        // Water command
        if (Regex("(ماية|ماء|water|اشرب)").containsMatchIn(q)) {
            DayflowRepository.addWater(250)
            return LocalBrainReply(
                text = if (ar) "سجلتلك كوباية ٢٥٠ مل 💧 بالهنا والشفا!" else "Logged 250 ml of water 💧",
                mood = "happy"
            )
        }

        // Alarm command: e.g. "اعمل منبه 7 الصبح" or "alarm 6:30 pm"
        if (Regex("(منبه|نبهني|صحيني|alarm|wake)").containsMatchIn(q)) {
            val timeMatch = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(الصبح|صباحا|صباح|مساء|بالليل|م|ص|am|pm)?").find(q)
            if (timeMatch == null) {
                return LocalBrainReply(
                    text = if (ar) "أظبط المنبّه الساعة كام؟ قولّي مثلاً: اعمل منبه ٧:٠٠ ص بكرة" else "What time? Try: Set alarm 7:00 AM tomorrow",
                    mood = "think"
                )
            }
            var hh = timeMatch.groupValues[1].toIntOrNull() ?: 7
            val mm = timeMatch.groupValues[2].toIntOrNull() ?: 0
            val mer = timeMatch.groupValues[3]
            if (mer.contains("م") || mer.contains("ليل") || mer == "pm") {
                if (hh < 12) hh += 12
            } else if (mer.contains("ص") || mer == "am") {
                if (hh == 12) hh = 0
            }
            val hhmm = "%02d:%02d".format(hh.coerceIn(0, 23), mm.coerceIn(0, 59))
            val tomorrow = q.contains("بكر") || q.contains("غد") || q.contains("tomorrow")
            val targetDate = if (tomorrow) LocalDate.now().plusDays(1) else {
                val nowCal = Calendar.getInstance()
                val nowMin = nowCal.get(Calendar.HOUR_OF_DAY) * 60 + nowCal.get(Calendar.MINUTE)
                if (hh * 60 + mm <= nowMin) LocalDate.now().plusDays(1) else LocalDate.now()
            }
            val dateStr = CalendarsAndDecor.dayKey(targetDate)
            val alarm = AlarmItem(
                id = DayflowRepository.newId(),
                time = hhmm,
                date = dateStr,
                days = emptyList(),
                label = if (ar) "منبه من الرفيق" else "Companion alarm",
                enabled = true
            )
            val scheduled = DayflowRepository.saveAlarm(alarm)
            val disp = Time12h.formatHhMm(hhmm, state.lang).full
            return if (scheduled) {
                LocalBrainReply(
                    text = if (ar) "تمام! ضبطت منبّه الساعة $disp ليوم $dateStr ⏰" else "Saved alarm for $disp on $dateStr ⏰",
                    mood = "happy",
                    records = listOf(ActionRecord("alarm", alarm.label, dateStr, hhmm))
                )
            } else {
                onNavigate("alarms", null)
                LocalBrainReply(
                    text = if (ar) "اسمح بصلاحية المنبهات الدقيقة من الإعدادات لحفظ المنبه الساعة $disp." else "Please grant Exact Alarms access in Settings to schedule $disp.",
                    mood = "worried"
                )
            }
        }

        // Task command
        if (Regex("(مهمة|تاسك|ضيف|أضف|task|todo)").containsMatchIn(q)) {
            val cleanTitle = western
                .replace(Regex("(?i)(ضيف|أضف|اعمل|مهمة|تاسك|task|todo|بكرة|بكره|غدا|النهاردة|النهارده|اليوم|tomorrow|today)"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (cleanTitle.length < 2) {
                return LocalBrainReply(
                    text = if (ar) "قولي اسم المهمة وأنا أسجلها فورًا 📝" else "Tell me the task title 📝",
                    mood = "think"
                )
            }
            val targetDate = if (q.contains("بكر") || q.contains("غد") || q.contains("tomorrow")) {
                CalendarsAndDecor.dayKey(LocalDate.now().plusDays(1))
            } else CalendarsAndDecor.todayKey()
            val added = DayflowRepository.addTask(cleanTitle, targetDate)
            return LocalBrainReply(
                text = if (ar) "سجّلت مهمة «${added.title}» ليوم $targetDate ✅" else "Added task “${added.title}” for $targetDate ✅",
                mood = "happy",
                records = listOf(ActionRecord("task", added.title, targetDate))
            )
        }

        // Task count
        if (Regex("(كام مهمة|مهامي|المهام|tasks)").containsMatchIn(q)) {
            val left = state.tasks.count { !it.done }
            return LocalBrainReply(
                text = if (ar) "فاضل عندك ${Time12h.fmtNum(left, "ar")} مهام مفتوحة." else "You have $left open tasks.",
                mood = if (left == 0) "celebrate" else "idle"
            )
        }

        return LocalBrainReply(
            text = if (ar) "أنا رفيق DAYFLOW الأصلي على أندرويد! تقدر تقولي: «اعمل منبه ٧ الصبح»، «ضيف مهمة مذاكرة»، أو «اشرب ماية» — أو اربط مفتاح API لنماذج أكبر."
            else "I'm your native DAYFLOW companion! Try: “Set alarm 7 AM”, “Add task Read chapter”, or “Log water”.",
            mood = "welcome"
        )
    }
}
