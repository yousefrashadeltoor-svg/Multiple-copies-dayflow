package app.dayflow.android.domain

import app.dayflow.android.model.UserDay
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import kotlin.math.floor

data class CalParts(val y: Int, val m: Int, val d: Int)

data class FamilyPalette(
    val id: String,
    val c1: Long,
    val c2: Long,
    val c3: Long,
    val en: String,
    val ar: String,
    val cornerAsset: String,
    val fallAssets: List<String>,
    val backdropAsset: String? = null,
    val motion: String = "float" // "fall" | "float" | "drift"
)

data class Occasion(
    val id: String,
    val en: String,
    val ar: String,
    val family: String,
    val priority: Int,
    val kind: String,
    val strength: Float = 1f
)

data class DecorLayer(
    val source: String,
    val family: String,
    val en: String,
    val ar: String,
    val strength: Float
)

data class DecorStack(
    val layers: List<DecorLayer>,
    val primary: String,
    val occasions: List<Occasion>
)

object CalendarsAndDecor {
    val HIJRI_MONTHS_EN = listOf("Muharram", "Safar", "Rabi' I", "Rabi' II", "Jumada I", "Jumada II", "Rajab", "Sha'ban", "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah")
    val HIJRI_MONTHS_AR = listOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")

    val COPTIC_MONTHS_EN = listOf("Thout", "Paopi", "Hathor", "Koiak", "Tobi", "Meshir", "Paremhat", "Parmouti", "Pashons", "Paoni", "Epip", "Mesori", "Nasie")
    val COPTIC_MONTHS_AR = listOf("توت", "بابه", "هاتور", "كيهك", "طوبة", "أمشير", "برمهات", "برمودة", "بشنس", "بؤونة", "أبيب", "مسرى", "نسيء")

    val FAMILIES: Map<String, FamilyPalette> = linkedMapOf(
        "ramadan" to FamilyPalette("ramadan", 0xFFD4A237, 0xFF1F4E5F, 0xFFF3DFA2, "Ramadan lantern", "فانوس رمضان", "decor/fanous-mini.png", listOf("decor/fanous-mini.png", "decor/crescent.png", "decor/star.png", "decor/sparkle.png"), "art/fanous.jpg", "float"),
        "islamic" to FamilyPalette("islamic", 0xFF1E7A5F, 0xFFC9A24A, 0xFFE8F1EA, "Islamic geometry", "هندسة إسلامية", "decor/crescent.png", listOf("decor/crescent.png", "decor/star.png", "decor/sparkle.png"), "art/cairo-night.jpg", "float"),
        "eid" to FamilyPalette("eid", 0xFFC8962C, 0xFF7A2E5C, 0xFFFBE8B8, "Eid festive", "زينة العيد", "decor/gift.png", listOf("decor/balloon.png", "decor/confetti.png", "decor/gift.png", "decor/star.png"), "art/fanous.jpg", "float"),
        "winter" to FamilyPalette("winter", 0xFF7FB2D9, 0xFF2F5A80, 0xFFE8F3FB, "Winter crystal", "بلورات الشتاء", "decor/snowman.png", listOf("decor/snow.png", "decor/snow.png", "decor/sparkle.png", "decor/wind.png"), "photos/snow.jpg", "fall"),
        "spring" to FamilyPalette("spring", 0xFFE98AA6, 0xFF5E9E4F, 0xFFFDE9EF, "Spring floral", "زهور الربيع", "decor/tulip.png", listOf("decor/blossom.png", "decor/jasmine.png", "decor/tulip.png", "decor/herb.png"), "photos/spring-blossom.jpg", "drift"),
        "summer" to FamilyPalette("summer", 0xFF2FA3C4, 0xFFF2A541, 0xFFE3F6FB, "Summer wave", "موج الصيف", "decor/seashell.png", listOf("decor/wave.png", "decor/seashell.png", "decor/sparkle.png"), null, "float"),
        "autumn" to FamilyPalette("autumn", 0xFFC46A2F, 0xFF8A5A2B, 0xFFF8E6D4, "Autumn leaf", "أوراق الخريف", "decor/maple.png", listOf("decor/maple.png", "decor/fallen.png", "decor/oak.png", "decor/wind.png"), "photos/autumn-tree.jpg", "fall"),
        "national" to FamilyPalette("national", 0xFFCE1126, 0xFFC09300, 0xFFF5F5F5, "National ribbon", "شريط وطني", "decor/dove.png", listOf("decor/dove.png", "decor/star.png", "decor/confetti.png"), "art/cairo-night.jpg", "drift"),
        "nile" to FamilyPalette("nile", 0xFF2B6CB0, 0xFF3AA17E, 0xFFE5F0FA, "Nile lotus", "لوتس النيل", "decor/lotus.png", listOf("decor/lotus.png", "decor/wave.png", "decor/jasmine.png", "decor/herb.png"), "art/cairo-night.jpg", "drift"),
        "coptic" to FamilyPalette("coptic", 0xFF8B5A2B, 0xFFB8860B, 0xFFF6ECDC, "Coptic geometric", "زخرفة قبطية", "decor/coptic-cross.png", listOf("decor/coptic-cross.png", "decor/dove.png", "decor/star.png"), null, "float"),
        "love" to FamilyPalette("love", 0xFFD6456B, 0xFFF08FA8, 0xFFFDE4EA, "Hearts", "قلوب", "decor/heart.png", listOf("decor/heart.png", "decor/blossom.png", "decor/jasmine.png"), null, "float"),
        "study" to FamilyPalette("study", 0xFF4F6BD8, 0xFF7A8FE0, 0xFFE8ECFB, "Study", "دراسة", "decor/books.png", listOf("decor/books.png", "decor/herb.png", "decor/sparkle.png"), null, "float"),
        "birthday" to FamilyPalette("birthday", 0xFFE0A020, 0xFFD6456B, 0xFFFFF2D6, "Birthday sparkle", "بريق الميلاد", "decor/balloon.png", listOf("decor/balloon.png", "decor/confetti.png", "decor/gift.png", "decor/sparkle.png"), null, "float"),
        "friday" to FamilyPalette("friday", 0xFF2E7D6B, 0xFF9BC4B6, 0xFFE6F2EE, "Friday accent", "لمسة الجمعة", "decor/dove.png", listOf("decor/jasmine.png", "decor/dove.png", "decor/sparkle.png"), "art/cairo-night.jpg", "float"),
        "newyear" to FamilyPalette("newyear", 0xFFC9A227, 0xFF3B3F8F, 0xFFF5EFD9, "New Year", "العام الجديد", "decor/star.png", listOf("decor/confetti.png", "decor/sparkle.png", "decor/star.png", "decor/balloon.png"), null, "fall")
    )

    fun familyOf(id: String): FamilyPalette = FAMILIES[id] ?: FAMILIES["islamic"]!!

    fun todayKey(): String = dayKey(LocalDate.now())

    fun dayKey(date: LocalDate): String =
        "%04d-%02d-%02d".format(date.year, date.monthValue, date.dayOfMonth)

    fun parseDayKey(key: String): LocalDate =
        runCatching { LocalDate.parse(key) }.getOrElse { LocalDate.now() }

    /** Official Umm al-Qura Hijri conversion built into java.time.chrono.HijrahDate */
    fun hijri(date: LocalDate): CalParts {
        return runCatching {
            val h = HijrahDate.from(date)
            CalParts(
                y = h.get(ChronoField.YEAR),
                m = h.get(ChronoField.MONTH_OF_YEAR),
                d = h.get(ChronoField.DAY_OF_MONTH)
            )
        }.getOrDefault(CalParts(1448, 1, 1))
    }

    /** Exact Coptic (Alexandrian Martyrs Era) conversion via Julian Day Number */
    fun coptic(date: LocalDate): CalParts {
        var y = date.year
        var m = date.monthValue
        val d = date.dayOfMonth
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = y / 100
        val b = 2 - a + a / 4
        val jdn = floor(365.25 * (y + 4716)).toLong() + floor(30.6001 * (m + 1)).toLong() + d + b - 1524
        val r = (jdn - 1825030L)
        val cy = ((4 * r + 1463) / 1461).toInt()
        val firstOfYear = 1825030L + 365L * (cy - 1) + (cy / 4)
        val dayOfYear = (jdn - firstOfYear).toInt().coerceAtLeast(0)
        val cm = (dayOfYear / 30 + 1).coerceIn(1, 13)
        val cd = (dayOfYear % 30 + 1).coerceIn(1, 30)
        return CalParts(cy, cm, cd)
    }

    fun orthodoxEaster(year: Int): LocalDate {
        val a = year % 4
        val b = year % 7
        val c = year % 19
        val d = (19 * c + 15) % 30
        val e = (2 * a + 4 * b - d + 34) % 7
        val month = (d + e + 114) / 31
        val day = ((d + e + 114) % 31) + 1
        return LocalDate.of(year, month, day).plusDays(13)
    }

    fun occasionsOn(date: LocalDate): List<Occasion> {
        val out = mutableListOf<Occasion>()
        val m = date.monthValue
        val d = date.dayOfMonth

        val fixed = listOf(
            Triple(1, 1, Occasion("newyear", "New Year", "رأس السنة الميلادية", "newyear", 70, "civil")),
            Triple(1, 7, Occasion("coptic-christmas", "Coptic Christmas", "عيد الميلاد المجيد", "coptic", 75, "coptic")),
            Triple(1, 19, Occasion("epiphany", "Epiphany", "عيد الغطاس", "coptic", 70, "coptic")),
            Triple(1, 25, Occasion("jan25", "25 January", "ثورة ٢٥ يناير", "national", 70, "national")),
            Triple(2, 14, Occasion("valentine", "Valentine's Day", "عيد الحب", "love", 30, "civil")),
            Triple(3, 21, Occasion("mothers", "Mother's Day", "عيد الأم", "love", 75, "civil")),
            Triple(4, 25, Occasion("sinai", "Sinai Liberation Day", "عيد تحرير سيناء", "national", 75, "national")),
            Triple(5, 1, Occasion("labour", "Labour Day", "عيد العمال", "national", 45, "civil")),
            Triple(6, 30, Occasion("jun30", "June 30 Revolution", "ثورة ٣٠ يونيو", "national", 70, "national")),
            Triple(7, 23, Occasion("jul23", "July 23 Revolution", "ثورة ٢٣ يوليو", "national", 70, "national")),
            Triple(8, 15, Occasion("wafaa", "Wafaa El-Nil", "عيد وفاء النيل", "nile", 75, "national")),
            Triple(9, 11, Occasion("nayrouz", "Nayrouz (Coptic New Year)", "عيد النيروز", "coptic", 70, "coptic")),
            Triple(9, 27, Occasion("cross", "Feast of the Cross", "عيد الصليب", "coptic", 45, "coptic"))
        )
        for ((fm, fd, occ) in fixed) {
            if (fm == m && fd == d) out.add(occ)
        }

        if (m == 10 && d in 6..24) {
            val strength = if (d == 6) 1f else if (d == 24) 0.7f else (1f - (d - 6) / 18f).coerceAtLeast(0.25f)
            out.add(
                Occasion(
                    id = "october",
                    en = if (d == 6) "October Victory" else if (d == 24) "Suez National Day" else "October Victory season",
                    ar = if (d == 6) "انتصارات أكتوبر" else if (d == 24) "العيد القومي للسويس" else "موسم انتصارات أكتوبر",
                    family = "national",
                    priority = if (d == 6) 90 else 45,
                    kind = "national",
                    strength = strength
                )
            )
        }

        val h = hijri(date)
        if (h.m == 9) {
            val lastTen = h.d > 20
            out.add(
                Occasion(
                    id = "ramadan",
                    en = if (lastTen) "Ramadan · Last ten nights" else "Ramadan · Day ${h.d}",
                    ar = if (lastTen) "رمضان · العشر الأواخر" else "رمضان · اليوم ${Time12h.fmtNum(h.d, "ar")}",
                    family = "ramadan",
                    priority = 85,
                    kind = "islamic",
                    strength = if (lastTen) 1f else 0.75f
                )
            )
        }
        val hijriOccs = listOf(
            Triple(1, 1..1, Occasion("hijri-newyear", "Islamic New Year", "رأس السنة الهجرية", "islamic", 80, "islamic")),
            Triple(3, 12..12, Occasion("mawlid", "Mawlid an-Nabi", "المولد النبوي الشريف", "islamic", 85, "islamic")),
            Triple(7, 27..27, Occasion("isra", "Isra and Mi'raj", "الإسراء والمعراج", "islamic", 80, "islamic")),
            Triple(8, 15..15, Occasion("midshaban", "Mid-Sha'ban", "ليلة النصف من شعبان", "islamic", 80, "islamic")),
            Triple(9, 27..27, Occasion("qadr", "Laylat al-Qadr", "ليلة القدر", "ramadan", 95, "islamic")),
            Triple(10, 1..3, Occasion("eid-fitr", "Eid al-Fitr", "عيد الفطر المبارك", "eid", 100, "islamic")),
            Triple(12, 9..9, Occasion("arafah", "Day of Arafah", "يوم عرفة", "islamic", 95, "islamic")),
            Triple(12, 10..13, Occasion("eid-adha", "Eid al-Adha", "عيد الأضحى المبارك", "eid", 100, "islamic"))
        )
        for ((hm, range, occ) in hijriOccs) {
            if (h.m == hm && h.d in range) out.add(occ)
        }

        val easter = orthodoxEaster(date.year)
        if (date == easter) out.add(Occasion("easter", "Easter", "عيد القيامة المجيد", "coptic", 75, "coptic"))
        if (date == easter.plusDays(1)) out.add(Occasion("sham", "Sham El-Nessim", "شم النسيم", "spring", 85, "national"))

        return out.sortedByDescending { it.priority }
    }

    fun climateSeason(date: LocalDate): Triple<String, String, String> {
        val m = date.monthValue
        return when {
            m == 12 || m <= 2 -> Triple("winter", "Winter", "الشتاء")
            m <= 5 -> Triple("spring", "Spring", "الربيع")
            m <= 8 -> Triple("summer", "Summer", "الصيف")
            else -> Triple("autumn", "Autumn", "الخريف")
        }
    }

    fun resolveDecor(
        date: LocalDate = LocalDate.now(),
        userDays: List<UserDay> = emptyList(),
        budget: Int = 3,
        examSeason: Boolean = false
    ): DecorStack {
        val occ = occasionsOn(date)
        val layers = mutableListOf<DecorLayer>()
        for (o in occ) layers.add(DecorLayer("occasion", o.family, o.en, o.ar, o.strength))
        val m = date.monthValue
        if (examSeason && (m == 1 || m == 5 || m == 6)) {
            layers.add(DecorLayer("season", "study", "Exam season", "موسم الامتحانات", 0.5f))
        }
        if ((m == 9 && date.dayOfMonth >= 15) || (m == 10 && date.dayOfMonth <= 5)) {
            layers.add(DecorLayer("season", "study", "Back to school", "العودة للمدارس", 0.4f))
        }
        if (date.dayOfWeek.value == 5) { // Friday
            layers.add(DecorLayer("weekday", "friday", "Friday", "الجمعة", 0.35f))
        }
        val md = "%02d-%02d".format(date.monthValue, date.dayOfMonth)
        for (u in userDays) {
            if (u.date == md) layers.add(DecorLayer("user", u.family, u.en, u.ar, 0.9f))
        }
        val (cf, cen, car) = climateSeason(date)
        layers.add(DecorLayer("climate", cf, cen, car, 0.3f))

        val seen = mutableSetOf<String>()
        val deduped = layers.filter { seen.add(it.family) }.take(budget.coerceAtLeast(1))
        return DecorStack(
            layers = deduped,
            primary = deduped.firstOrNull()?.family ?: "islamic",
            occasions = occ
        )
    }

    fun upcomingOccasions(from: LocalDate = LocalDate.now(), count: Int = 6): List<Pair<LocalDate, Occasion>> {
        val out = mutableListOf<Pair<LocalDate, Occasion>>()
        val seen = mutableSetOf<String>()
        var offset = 0L
        while (offset < 400L && out.size < count) {
            val d = from.plusDays(offset)
            for (o in occasionsOn(d)) {
                val key = if (o.id == "ramadan" || o.id == "october") o.id else "${o.id}_${d.year}"
                if (seen.add(key)) {
                    out.add(d to o)
                    if (out.size >= count) break
                }
            }
            offset++
        }
        return out
    }
}
