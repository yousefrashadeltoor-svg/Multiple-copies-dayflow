package app.dayflow.android.domain

import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class ProviderSpec(
    val id: String,
    val name: String,
    val kind: String, // "openai" | "anthropic" | "gemini"
    val baseUrl: String,
    val keyPrefix: String,
    val logoSlug: String,
    val defaultModels: List<LiveModelMeta>
)

object AiStreamingClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    val PROVIDERS: List<ProviderSpec> = listOf(
        ProviderSpec("openrouter", "OpenRouter", "openai", "https://openrouter.ai/api/v1", "sk-or-v1-", "openrouter", listOf(
            LiveModelMeta("meta-llama/llama-3.3-70b-instruct:free", "Llama 3.3 70B (Free)", 131072, true),
            LiveModelMeta("deepseek/deepseek-r1:free", "DeepSeek R1 (Free)", 128000, true, reasoning = true),
            LiveModelMeta("google/gemini-2.5-flash", "Gemini 2.5 Flash", 1000000, false, supportsImage = true, supportsDoc = true)
        )),
        ProviderSpec("groq", "Groq", "openai", "https://api.groq.com/openai/v1", "gsk_", "groq", listOf(
            LiveModelMeta("llama-3.3-70b-versatile", "Llama 3.3 70B Versatile", 128000, true),
            LiveModelMeta("deepseek-r1-distill-llama-70b", "DeepSeek R1 Distill 70B", 128000, true, reasoning = true),
            LiveModelMeta("llama-3.1-8b-instant", "Llama 3.1 8B Instant", 128000, true)
        )),
        ProviderSpec("gemini", "Google Gemini", "gemini", "https://generativelanguage.googleapis.com/v1beta", "AIza", "gemini-color", listOf(
            LiveModelMeta("gemini-2.5-flash", "Gemini 2.5 Flash", 1000000, true, supportsImage = true, supportsDoc = true, reasoning = true),
            LiveModelMeta("gemini-2.5-pro", "Gemini 2.5 Pro", 2000000, false, supportsImage = true, supportsDoc = true, reasoning = true)
        )),
        ProviderSpec("openai", "OpenAI", "openai", "https://api.openai.com/v1", "sk-", "openai", listOf(
            LiveModelMeta("gpt-4o-mini", "GPT-4o mini", 128000, false, supportsImage = true),
            LiveModelMeta("gpt-4o", "GPT-4o", 128000, false, supportsImage = true)
        )),
        ProviderSpec("anthropic", "Anthropic Claude", "anthropic", "https://api.anthropic.com/v1", "sk-ant-", "claude-color", listOf(
            LiveModelMeta("claude-3-5-sonnet-latest", "Claude 3.5 Sonnet", 200000, false, supportsImage = true, supportsDoc = true),
            LiveModelMeta("claude-3-5-haiku-latest", "Claude 3.5 Haiku", 200000, false, supportsImage = true)
        )),
        ProviderSpec("deepseek", "DeepSeek", "openai", "https://api.deepseek.com/v1", "sk-", "deepseek-color", listOf(
            LiveModelMeta("deepseek-chat", "DeepSeek V3", 64000, false),
            LiveModelMeta("deepseek-reasoner", "DeepSeek R1", 64000, false, reasoning = true)
        )),
        ProviderSpec("mistral", "Mistral", "openai", "https://api.mistral.ai/v1", "", "mistral-color", listOf(
            LiveModelMeta("mistral-small-latest", "Mistral Small", 128000, false)
        )),
        ProviderSpec("cerebras", "Cerebras", "openai", "https://api.cerebras.ai/v1", "csk-", "cerebras-color", listOf(
            LiveModelMeta("llama-3.3-70b", "Llama 3.3 70B", 128000, true)
        )),
        ProviderSpec("together", "Together AI", "openai", "https://api.together.xyz/v1", "", "together-color", listOf(
            LiveModelMeta("meta-llama/Llama-3.3-70B-Instruct-Turbo", "Llama 3.3 70B Turbo", 128000, false)
        )),
        ProviderSpec("xai", "xAI Grok", "openai", "https://api.x.ai/v1", "xai-", "grok", listOf(
            LiveModelMeta("grok-2-latest", "Grok 2", 131072, false)
        )),
        ProviderSpec("cohere", "Cohere", "openai", "https://api.cohere.ai/compatibility/v1", "", "cohere-color", listOf(
            LiveModelMeta("command-r-plus", "Command R+", 128000, false)
        )),
        ProviderSpec("perplexity", "Perplexity", "openai", "https://api.perplexity.ai", "pplx-", "perplexity-color", listOf(
            LiveModelMeta("sonar-pro", "Sonar Pro", 128000, false)
        ))
    )

    fun detectProvider(key: String): String? {
        val k = key.trim()
        return when {
            k.startsWith("sk-or-v1-") || k.startsWith("sk-or-") -> "openrouter"
            k.startsWith("gsk_") -> "groq"
            k.startsWith("sk-ant-") -> "anthropic"
            k.startsWith("AIza") -> "gemini"
            k.startsWith("csk-") -> "cerebras"
            k.startsWith("xai-") -> "xai"
            k.startsWith("pplx-") -> "perplexity"
            k.startsWith("sk-") -> "openai"
            else -> null
        }
    }

    fun providerById(id: String): ProviderSpec = PROVIDERS.find { it.id == id } ?: PROVIDERS.first()

    private fun isChatModelId(id: String): Boolean {
        val lower = id.lowercase()
        val nonChat = listOf("whisper", "tts", "orpheus", "embed", "moderation", "guard", "dall-e", "imagen", "rerank", "audio")
        return nonChat.none { lower.contains(it) }
    }

    /** Zero-Token API Key Verifier & Working Model Sorter */
    suspend fun verifyKeyZeroTokens(entry: ApiKeyEntry): Triple<Boolean, String, List<LiveModelMeta>> = withContext(Dispatchers.IO) {
        val spec = providerById(entry.provider)
        val base = (entry.baseOverride?.takeIf { it.isNotBlank() } ?: spec.baseUrl).trimEnd('/')
        try {
            if (spec.kind == "anthropic") {
                return@withContext Triple(true, "Anthropic key saved · ${spec.defaultModels.size} models ready", spec.defaultModels)
            }
            val url = if (spec.kind == "gemini") "$base/models?key=${entry.key}" else "$base/models"
            val reqBuilder = Request.Builder().url(url).get()
            if (spec.kind != "gemini") {
                reqBuilder.header("Authorization", "Bearer ${entry.key}")
            }
            http.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return@withContext Triple(false, "HTTP ${resp.code} — تأكد من صحة المفتاح", spec.defaultModels)
                }
                val body = resp.body?.string().orEmpty()
                val root = JSONObject(body)
                val arr = root.optJSONArray("data") ?: root.optJSONArray("models") ?: JSONArray()
                val discovered = mutableListOf<LiveModelMeta>()
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val rawId = item.optString("id").ifBlank { item.optString("name").removePrefix("models/") }
                    if (rawId.isBlank() || !isChatModelId(rawId)) continue
                    val name = item.optString("displayName").ifBlank { item.optString("name").removePrefix("models/").ifBlank { rawId } }
                    val ctx = item.optInt("context_length", item.optInt("inputTokenLimit", 128000))
                    val free = rawId.endsWith(":free") || spec.id == "groq"
                    val reasoning = rawId.contains("r1") || rawId.contains("reason") || rawId.contains("thinking")
                    val vision = rawId.contains("vision") || rawId.contains("4o") || rawId.contains("gemini") || rawId.contains("claude")
                    discovered.add(LiveModelMeta(rawId, name, ctx, free, vision, vision, reasoning))
                }
                val sorted = discovered.sortedWith(compareByDescending<LiveModelMeta> { it.free }.thenBy { it.name })
                val finalModels = if (sorted.isNotEmpty()) sorted else spec.defaultModels
                Triple(true, "تم التحقق بـ ٠ توكن · ${finalModels.size} نموذج شغّال", finalModels)
            }
        } catch (e: Exception) {
            Triple(false, e.message ?: "تعذّر الاتصال بالمزوّد", spec.defaultModels)
        }
    }

    private fun systemPrompt(state: DayflowState): String {
        val today = CalendarsAndDecor.todayKey()
        return """
            You are DAYFLOW's calm, helpful assistant. Reply in ${if (state.lang == "ar") "warm Egyptian Arabic" else "clear concise English"}.
            Always display times to the user in 12-hour format (AM/PM or ص/م).
            Today's ISO date is $today.
            When the user asks to create an alarm or task, include an action tag at the end of your reply on its own line:
            <dayflow-action>{"intent":"addAlarm","time":"07:00","date":"$today","label":"الصباح"}</dayflow-action>
            or
            <dayflow-action>{"intent":"addTask","title":"مذاكرة","date":"$today"}</dayflow-action>
        """.trimIndent()
    }

    suspend fun streamCompletion(
        entry: ApiKeyEntry,
        modelId: String,
        history: List<AiMessage>,
        state: DayflowState,
        onDelta: (reasoningDelta: String?, textDelta: String?) -> Unit
    ): Pair<String, String> = withContext(Dispatchers.IO) {
        val spec = providerById(entry.provider)
        val base = (entry.baseOverride?.takeIf { it.isNotBlank() } ?: spec.baseUrl).trimEnd('/')
        val sys = systemPrompt(state)

        if (spec.kind == "gemini") {
            val contents = JSONArray()
            for (m in history.takeLast(14)) {
                contents.put(JSONObject().apply {
                    put("role", if (m.role == "assistant") "model" else "user")
                    put("parts", JSONArray().put(JSONObject().put("text", m.content)))
                })
            }
            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                put("contents", contents)
            }
            val req = Request.Builder()
                .url("$base/models/$modelId:generateContent?key=${entry.key}")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}: ${raw.take(180)}")
                val j = JSONObject(raw)
                val txt = j.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text").orEmpty()
                onDelta(null, txt)
                return@withContext "" to txt
            }
        }

        if (spec.kind == "anthropic") {
            val msgs = JSONArray()
            for (m in history.takeLast(14)) {
                msgs.put(JSONObject().put("role", m.role).put("content", m.content))
            }
            val payload = JSONObject().apply {
                put("model", modelId)
                put("max_tokens", 2048)
                put("system", sys)
                put("messages", msgs)
            }
            val req = Request.Builder()
                .url("$base/messages")
                .header("x-api-key", entry.key)
                .header("anthropic-version", "2023-06-01")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}: ${raw.take(180)}")
                val j = JSONObject(raw)
                val txt = j.optJSONArray("content")?.optJSONObject(0)?.optString("text").orEmpty()
                onDelta(null, txt)
                return@withContext "" to txt
            }
        }

        // OpenAI-compatible SSE streaming (OpenRouter, Groq, OpenAI, DeepSeek, Cerebras, Mistral, Together, xAI, Perplexity)
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
        for (m in history.takeLast(16)) {
            msgs.put(JSONObject().put("role", m.role).put("content", m.content))
        }
        val payload = JSONObject().apply {
            put("model", modelId)
            put("messages", msgs)
            put("stream", true)
        }
        val reqBuilder = Request.Builder()
            .url("$base/chat/completions")
            .header("Authorization", "Bearer ${entry.key}")
            .header("Accept", "text/event-stream")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
        if (spec.id == "openrouter") {
            reqBuilder.header("HTTP-Referer", "https://dayflow.app")
            reqBuilder.header("X-Title", "DAYFLOW")
        }

        val fullText = StringBuilder()
        val fullReasoning = StringBuilder()

        http.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                val errBody = resp.body?.string().orEmpty()
                throw RuntimeException("HTTP ${resp.code}: ${errBody.take(180)}")
            }
            val stream = resp.body?.byteStream() ?: throw RuntimeException("Empty stream")
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val l = line!!.trim()
                    if (!l.startsWith("data:")) continue
                    val data = l.removePrefix("data:").trim()
                    if (data == "[DONE]") break
                    runCatching {
                        val chunk = JSONObject(data)
                        val delta = chunk.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                        if (delta != null) {
                            val rDelta = delta.optString("reasoning_content").ifBlank { delta.optString("reasoning") }
                            val cDelta = delta.optString("content")
                            if (rDelta.isNotEmpty()) {
                                fullReasoning.append(rDelta)
                                onDelta(rDelta, null)
                            }
                            if (cDelta.isNotEmpty()) {
                                fullText.append(cDelta)
                                onDelta(null, cDelta)
                            }
                        }
                    }
                }
            }
        }
        fullReasoning.toString() to fullText.toString()
    }

    fun applyParsedActions(rawReply: String): Pair<String, List<ActionRecord>> {
        val records = mutableListOf<ActionRecord>()
        val tagRegex = Regex("<dayflow-action>\\s*(\\{.*?\\})\\s*</dayflow-action>", setOf(RegexOption.DOT_MATCHES_ALL))
        for (match in tagRegex.findAll(rawReply)) {
            runCatching {
                val obj = JSONObject(match.groupValues[1])
                when (obj.optString("intent")) {
                    "addTask" -> {
                        val title = obj.optString("title").trim()
                        val date = obj.optString("date").ifBlank { CalendarsAndDecor.todayKey() }
                        val time = obj.optString("time").takeIf { it.isNotBlank() }
                        if (title.isNotEmpty()) {
                            DayflowRepository.addTask(title, date, dueTime = time)
                            records.add(ActionRecord("task", title, date, time))
                        }
                    }
                    "addAlarm" -> {
                        val time = obj.optString("time")
                        val date = obj.optString("date").ifBlank { CalendarsAndDecor.todayKey() }
                        val label = obj.optString("label", "منبه من المساعد")
                        if (time.contains(":")) {
                            val alarm = AlarmItem(id = DayflowRepository.newId(), time = time, date = date, label = label, enabled = true)
                            if (DayflowRepository.saveAlarm(alarm)) {
                                records.add(ActionRecord("alarm", label, date, time))
                            }
                        }
                    }
                    "addWater" -> {
                        DayflowRepository.addWater(obj.optInt("ml", 250))
                    }
                }
            }
        }
        val cleaned = rawReply.replace(tagRegex, "").trim()
        return cleaned to records
    }
}
