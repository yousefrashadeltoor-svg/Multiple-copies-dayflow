package app.dayflow.android

import android.app.Application
import android.util.Log
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.system.NotificationController
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DayflowApplication : Application() {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    var ytdlpReady: Boolean = false
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        NotificationController.ensureChannels(this)
        DayflowRepository.init(this)

        appScope.launch {
            try {
                YoutubeDL.getInstance().init(this@DayflowApplication)
                runCatching { FFmpeg.getInstance().init(this@DayflowApplication) }
                runCatching { Aria2c.getInstance().init(this@DayflowApplication) }
                ytdlpReady = true
            } catch (e: Throwable) {
                Log.w("DAYFLOW", "Native media extractor init deferred: ${e.message}")
            }
        }
    }

    companion object {
        lateinit var instance: DayflowApplication
            private set
    }
}
