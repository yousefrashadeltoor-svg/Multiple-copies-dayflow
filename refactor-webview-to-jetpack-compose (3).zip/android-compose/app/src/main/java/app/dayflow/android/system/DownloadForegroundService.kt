package app.dayflow.android.system

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import app.dayflow.android.R
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.NativeDownloadEngine
import kotlinx.coroutines.*

class DownloadForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NotificationController.ensureChannels(this)
        val notif = NotificationCompat.Builder(this, NotificationController.CH_DOWNLOADS)
            .setSmallIcon(R.drawable.ic_dayflow_notif)
            .setContentTitle("DAYFLOW Downloads")
            .setContentText("جاري تحضير التنزيل...")
            .setOngoing(true)
            .build()
        startForeground(9401, notif)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val itemId = intent?.getStringExtra("itemId")
        if (itemId.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        scope.launch {
            NativeDownloadEngine.executeDownload(this@DownloadForegroundService, itemId) { pct, name ->
                val progressNotif = NotificationCompat.Builder(this@DownloadForegroundService, NotificationController.CH_DOWNLOADS)
                    .setSmallIcon(R.drawable.ic_dayflow_notif)
                    .setContentTitle(name)
                    .setContentText("$pct%")
                    .setProgress(100, pct.coerceIn(0, 100), false)
                    .setOngoing(true)
                    .build()
                nm.notify(9401, progressNotif)
            }
            val anyRunning = DayflowRepository.state.value.downloads.any { it.state == "downloading" }
            if (!anyRunning) {
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun enqueue(context: Context, itemId: String) {
            val intent = Intent(context, DownloadForegroundService::class.java).putExtra("itemId", itemId)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                runCatching { context.startForegroundService(intent) }
            } else {
                runCatching { context.startService(intent) }
            }
        }
    }
}
