package app.dayflow.android.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.*
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.delay
import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Locale

private data class ToolEntry(val id: String, val icon: ImageVector, val en: String, val ar: String)

private val ALL_TOOLS = listOf(
    ToolEntry("tasks", Icons.Default.Checklist, "Tasks", "المهام"),
    ToolEntry("habits", Icons.Default.Repeat, "Habits", "العادات"),
    ToolEntry("focus", Icons.Default.Timer, "Focus", "التركيز"),
    ToolEntry("study", Icons.Default.School, "Study", "الدراسة"),
    ToolEntry("workout", Icons.Default.FitnessCenter, "Workout", "التمارين"),
    ToolEntry("water", Icons.Default.WaterDrop, "Water", "الماء"),
    ToolEntry("notes", Icons.Default.StickyNote2, "Notes", "الملاحظات"),
    ToolEntry("media", Icons.Default.Link, "Media Hub", "مركز الوسائط"),
    ToolEntry("countdowns", Icons.Default.HourglassBottom, "Countdowns", "العد التنازلي"),
    ToolEntry("convert", Icons.Default.Straighten, "Converters", "المحولات"),
    ToolEntry("tasbih", Icons.Default.Adjust, "Tasbih & Khatma", "التسبيح والختمة"),
    ToolEntry("datecalc", Icons.Default.DateRange, "Date calculator", "حاسبة التاريخ"),
    ToolEntry("journal", Icons.Default.FavoriteBorder, "Journal & mood", "اليوميات والمزاج"),
    ToolEntry("meds", Icons.Default.Medication, "Medication", "الأدوية"),
    ToolEntry("bedside", Icons.Default.NightsStay, "Bedside clock", "ساعة السرير"),
    ToolEntry("qr", Icons.Default.QrCode, "QR generator", "صانع QR"),
    ToolEntry("imgtools", Icons.Default.Image, "Image converter", "محول وضغط الصور"),
    ToolEntry("breath", Icons.Default.Air, "Breathing", "تمارين التنفس"),
    ToolEntry("texttools", Icons.Default.Notes, "Text & counter", "عدّاد النصوص"),
    ToolEntry("stopwatch", Icons.Default.Watch, "Stopwatch", "ساعة إيقاف")
)

@Composable
fun ToolsComposeScreen(
    state: DayflowState,
    sub: String?,
    go: (String, String?) -> Unit
) {
    val c = LocalDayflowColors.current
    val lang = state.lang
    val ar = lang == "ar"
    var search by remember { mutableStateOf("") }

    if (sub == "bedside") {
        BedsideClockFullscreen(lang = lang, onExit = { go("tools", null) })
        return
    }
    if (sub == "media") {
        DownloadsComposeScreen(state = state, pendingShare = null, go = go)
        return
    }

    if (!sub.isNullOrBlank()) {
        val meta = ALL_TOOLS.find { it.id == sub }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 148.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHeader(
                title = if (meta != null) (if (ar) meta.ar else meta.en) else sub,
                onBack = { go("tools", null) }
            )
            when (sub) {
                "tasks" -> TasksSubScreen(state)
                "habits" -> HabitsSubScreen(state)
                "focus", "study" -> FocusSubScreen(state, isStudy = sub == "study")
                "workout" -> WorkoutSubScreen(state)
                "water" -> WaterSubScreen(state)
                "notes" -> NotesSubScreen(state)
                "countdowns" -> CountdownsSubScreen(state)
                "convert" -> ConvertersSubScreen(lang)
                "tasbih" -> TasbihSubScreen(state)
                "datecalc" -> DateCalcSubScreen(lang)
                "journal" -> JournalSubScreen(state)
                "meds" -> MedsSubScreen(state)
                "qr" -> QrStudioSubScreen(lang)
                "imgtools" -> ImageConverterSubScreen(lang)
                "breath" -> BreathingSubScreen(lang)
                "texttools" -> TextToolsSubScreen(lang)
                "stopwatch" -> StopwatchSubScreen(lang)
            }
        }
        return
    }

    val visibleTools = remember(search) {
        ALL_TOOLS.filter { search.isBlank() || (it.en + " " + it.ar).contains(search, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader(title = if (ar) "الأدوات" else "Tools")
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text(if (ar) "ابحث في الأدوات…" else "Search tools…") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        )

        visibleTools.chunked(3).forEach { rowTools ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowTools.forEach { item ->
                    DayflowCard(
                        modifier = Modifier.weight(1f).height(106.dp),
                        onClick = { go("tools", item.id) },
                        contentPadding = PaddingValues(10.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(c.soft),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(item.icon, contentDescription = null, tint = c.accent, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = if (ar) item.ar else item.en,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                maxLines = 2
                            )
                        }
                    }
                }
                repeat(3 - rowTools.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun TasksSubScreen(state: DayflowState) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    var view by remember { mutableStateOf("list") }
    var txt by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(CalendarsAndDecor.todayKey()) }
    var dueTime by remember { mutableStateOf<String?>(null) }
    var urgent by remember { mutableStateOf(false) }
    var important by remember { mutableStateOf(true) }

    SegmentedBar(
        value = view,
        options = listOf("list" to (if (ar) "قائمة" else "List"), "matrix" to (if (ar) "المصفوفة" else "Matrix"), "kanban" to "Kanban"),
        onSelect = { view = it }
    )

    DayflowCard {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = txt,
                onValueChange = { txt = it },
                placeholder = { Text(if (ar) "مهمة جديدة" else "New task") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if (txt.isNotBlank()) {
                    DayflowRepository.addTask(txt, date, urgent, important, dueTime)
                    txt = ""
                }
            }) { Icon(Icons.Default.Add, contentDescription = null) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            DayflowChip(selected = urgent, label = if (ar) "عاجل" else "Urgent", onClick = { urgent = !urgent })
            DayflowChip(selected = important, label = if (ar) "مهم" else "Important", onClick = { important = !important })
            if (dueTime == null) {
                DayflowChip(selected = false, label = if (ar) "+ تحديد وقت" else "+ Time", onClick = { dueTime = "09:00" })
            } else {
                TimePicker12h(value24 = dueTime!!, lang = state.lang, onValueChange = { dueTime = it })
            }
        }
    }

    when (view) {
        "list" -> {
            state.tasks.forEach { t ->
                DayflowCard(contentPadding = PaddingValues(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Checkbox(checked = t.done, onCheckedChange = { DayflowRepository.toggleTask(t.id) })
                        Column(modifier = Modifier.weight(1f)) {
                            Text(t.title, fontWeight = FontWeight.Medium)
                            Text(
                                text = listOfNotNull(t.date, t.dueTime?.let { Time12h.formatHhMm(it, state.lang).full }).joinToString(" · "),
                                fontSize = 11.sp,
                                color = c.muted
                            )
                        }
                        IconButton(onClick = { DayflowRepository.removeTask(t.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = c.muted)
                        }
                    }
                }
            }
        }
        "matrix" -> {
            val quads = listOf(
                Triple(true to true, if (ar) "نفّذ الآن" else "Do now", Color(0xFFE5484D)),
                Triple(false to true, if (ar) "جدول" else "Schedule", Color(0xFF3E63DD)),
                Triple(true to false, if (ar) "فوّض" else "Delegate", Color(0xFFF5A623)),
                Triple(false to false, if (ar) "احذف" else "Drop", Color(0xFF8B8D98))
            )
            quads.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    pair.forEach { (flags, label, col) ->
                        DayflowCard(modifier = Modifier.weight(1f).heightIn(min = 120.dp)) {
                            Text(label, color = col, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            state.tasks.filter { it.urgent == flags.first && it.important == flags.second && !it.done }.forEach { t ->
                                Text("○ ${t.title}", fontSize = 12.5.sp, modifier = Modifier.clickable { DayflowRepository.toggleTask(t.id) }.padding(vertical = 3.dp))
                            }
                        }
                    }
                }
            }
        }
        "kanban" -> {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                listOf("todo" to (if (ar) "للتنفيذ" else "To do"), "doing" to (if (ar) "جارٍ" else "Doing"), "done" to (if (ar) "تم" else "Done")).forEach { (st, lbl) ->
                    Column(modifier = Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(c.soft).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(lbl, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        state.tasks.filter { it.status == st }.forEach { t ->
                            DayflowCard(contentPadding = PaddingValues(8.dp), onClick = {
                                val next = when (st) { "todo" -> "doing"; "doing" -> "done"; else -> "todo" }
                                DayflowRepository.updateTaskStatus(t.id, next)
                            }) {
                                Text(t.title, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HabitsSubScreen(state: DayflowState) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    var newName by remember { mutableStateOf("") }
    var reminderTime by remember { mutableStateOf<String?>(null) }
    val todayKey = CalendarsAndDecor.todayKey()
    val last28 = remember { (27 downTo 0).map { CalendarsAndDecor.dayKey(LocalDate.now().minusDays(it.toLong())) } }

    DayflowCard {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text(if (ar) "اسم العادة الجديدة (مثل: مشي ٢٠ د)" else "Habit name (e.g. Walk 20m)") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                if (newName.isNotBlank()) {
                    DayflowRepository.saveHabit(HabitItem(id = "", en = newName.trim(), reminder = reminderTime))
                    newName = ""
                    reminderTime = null
                }
            }) { Icon(Icons.Default.Add, contentDescription = null) }
        }
        Spacer(Modifier.height(8.dp))
        if (reminderTime == null) {
            DayflowChip(selected = false, label = if (ar) "⏰ إضافة تذكير ١٢ ساعة" else "⏰ Set 12h reminder", onClick = { reminderTime = "08:00" })
        } else {
            TimePicker12h(value24 = reminderTime!!, lang = state.lang, onValueChange = { reminderTime = it })
        }
    }

    state.habits.forEach { h ->
        val doneToday = h.log.contains(todayKey)
        DayflowCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (doneToday) c.accent else c.soft)
                        .clickable { DayflowRepository.toggleHabit(h.id, todayKey) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (doneToday) "✓" else h.emoji, color = if (doneToday) c.onAccent else c.text, fontSize = 18.sp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(h.en, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    if (!h.reminder.isNullOrBlank()) {
                        Text("⏰ ${Time12h.formatHhMm(h.reminder, state.lang).full}", fontSize = 11.5.sp, color = c.accent)
                    }
                }
                IconButton(onClick = { DayflowRepository.removeHabit(h.id) }) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = c.muted)
                }
            }
            Spacer(Modifier.height(10.dp))
            last28.chunked(14).forEach { rowDays ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    rowDays.forEach { d ->
                        val active = h.log.contains(d)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (active) c.accent else c.line)
                                .clickable { DayflowRepository.toggleHabit(h.id, d) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FocusSubScreen(state: DayflowState, isStudy: Boolean) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    var minutes by remember { mutableIntStateOf(25) }
    var remainingSec by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var subject by remember { mutableStateOf("") }

    LaunchedEffect(running) {
        while (running && remainingSec > 0) {
            delay(1000L)
            remainingSec--
            if (remainingSec == 0) running = false
        }
    }

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        if (isStudy) {
            OutlinedTextField(value = subject, onValueChange = { subject = it }, placeholder = { Text(if (ar) "المادة الدراسية" else "Subject") }, modifier = Modifier.fillMaxWidth())
        }
        RingProgress(progress = 1f - remainingSec.toFloat() / (minutes * 60f).coerceAtLeast(1f), size = 220.dp, strokeWidth = 12.dp) {
            val mm = (remainingSec / 60).toString().padStart(2, '0')
            val ss = (remainingSec % 60).toString().padStart(2, '0')
            Text(Time12h.fmtNum("$mm:$ss", state.lang), fontSize = 42.sp, fontWeight = FontWeight.Light, color = c.text)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 25, 45, 60).forEach { m ->
                DayflowChip(selected = minutes == m, label = "${Time12h.fmtNum(m, state.lang)}′", onClick = { minutes = m; remainingSec = m * 60; running = false })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { running = !running }, colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)) {
                Text(if (running) (if (ar) "إيقاف مؤقت" else "Pause") else (if (ar) "ابدأ التركيز" else "Start"))
            }
            OutlinedButton(onClick = { running = false; remainingSec = minutes * 60 }) {
                Text(if (ar) "إعادة" else "Reset")
            }
        }
    }
}

@Composable
private fun WorkoutSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    val todayKey = CalendarsAndDecor.todayKey()
    val logs = state.workoutLogs[todayKey] ?: emptyList()
    var name by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("20") }
    val total = logs.sumOf { it.second }

    DayflowCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            RingProgress(progress = total / 30f, size = 68.dp) { Text("${Time12h.fmtNum(total, state.lang)}′", fontWeight = FontWeight.Bold) }
            Column {
                Text(if (ar) "تمرين اليوم" else "Today's workout", fontWeight = FontWeight.Bold)
                Text(if (ar) "الهدف ٣٠ دقيقة" else "Goal 30 min", fontSize = 12.sp)
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, placeholder = { Text(if (ar) "النشاط (مشي، جري…)" else "Activity") }, modifier = Modifier.weight(1f))
        OutlinedTextField(value = mins, onValueChange = { mins = it }, modifier = Modifier.width(76.dp))
        Button(onClick = {
            if (name.isNotBlank()) {
                val m = mins.toIntOrNull() ?: 20
                DayflowRepository.updateState { s -> s.copy(workoutLogs = s.workoutLogs + (todayKey to (logs + (name.trim() to m)))) }
                name = ""
            }
        }) { Icon(Icons.Default.Add, contentDescription = null) }
    }
    logs.forEach { (act, m) ->
        DayflowCard(contentPadding = PaddingValues(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(act, fontWeight = FontWeight.Medium)
                Text("${Time12h.fmtNum(m, state.lang)} ${if (ar) "د" else "min"}")
            }
        }
    }
}

@Composable
private fun WaterSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    val water = state.water[CalendarsAndDecor.todayKey()] ?: 0
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        RingProgress(progress = water.toFloat() / state.waterGoal.coerceAtLeast(500), size = 210.dp, strokeWidth = 14.dp, color = Color(0xFF3AA0FF)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(Time12h.fmtNum(String.format(Locale.US, "%.2f", water / 1000.0), state.lang), fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Text("/ ${Time12h.fmtNum(state.waterGoal / 1000.0, state.lang)} L", fontSize = 13.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(150, 250, 500).forEach { ml ->
                FilledTonalButton(onClick = { DayflowRepository.addWater(ml) }, modifier = Modifier.weight(1f)) {
                    Text("+${Time12h.fmtNum(ml, state.lang)} ml")
                }
            }
        }
        OutlinedButton(onClick = { DayflowRepository.addWater(-250) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (ar) "تراجع ٢٥٠ مل" else "Undo 250 ml")
        }
    }
}

@Composable
private fun NotesSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    var text by remember { mutableStateOf("") }
    DayflowCard {
        OutlinedTextField(value = text, onValueChange = { text = it }, placeholder = { Text(if (ar) "اكتب ملاحظة…" else "Write a note…") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { if (text.isNotBlank()) { DayflowRepository.addNote(text); text = "" } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)) {
            Text(if (ar) "حفظ الملاحظة" else "Save note")
        }
    }
    state.notes.sortedWith(compareByDescending<NoteItem> { it.pinned }.thenByDescending { it.at }).forEach { n ->
        DayflowCard {
            Text(n.text, fontSize = 14.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = { DayflowRepository.toggleNotePin(n.id) }) {
                    Icon(Icons.Default.PushPin, contentDescription = null, tint = if (n.pinned) c.accent else c.muted)
                }
                IconButton(onClick = { DayflowRepository.removeNote(n.id) }) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = c.muted)
                }
            }
        }
    }
}

@Composable
private fun CountdownsSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(CalendarsAndDecor.dayKey(LocalDate.now().plusDays(30))) }
    DayflowCard {
        OutlinedTextField(value = title, onValueChange = { title = it }, placeholder = { Text(if (ar) "اسم الحدث" else "Event title") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (title.isNotBlank()) {
                DayflowRepository.updateState { s -> s.copy(countdowns = s.countdowns + CountdownItem(DayflowRepository.newId(), title.trim(), date)) }
                title = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "إضافة عد تنازلي" else "Add countdown") }
    }
    state.countdowns.forEach { cd ->
        val days = ChronoUnit.DAYS.between(LocalDate.now(), CalendarsAndDecor.parseDayKey(cd.date)).toInt()
        DayflowCard {
            Text(Time12h.fmtNum(days, state.lang), fontSize = 34.sp, fontWeight = FontWeight.Bold, color = c.accent)
            Text("${cd.title} (${cd.date})", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun ConvertersSubScreen(lang: String) {
    val ar = lang == "ar"
    var km by remember { mutableStateOf("1") }
    var celsius by remember { mutableStateOf("25") }
    DayflowCard {
        Text(if (ar) "تحويل المسافة (كم ↔ متر)" else "Length (km ↔ m)", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = km, onValueChange = { km = it }, modifier = Modifier.fillMaxWidth())
        val m = (km.toDoubleOrNull() ?: 0.0) * 1000.0
        Text("= ${Time12h.fmtNum(m, lang)} m", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
    DayflowCard {
        Text(if (ar) "درجة الحرارة (°C ↔ °F)" else "Temperature (°C ↔ °F)", fontWeight = FontWeight.Bold)
        OutlinedTextField(value = celsius, onValueChange = { celsius = it }, modifier = Modifier.fillMaxWidth())
        val f = ((celsius.toDoubleOrNull() ?: 0.0) * 9.0 / 5.0) + 32.0
        Text("= ${Time12h.fmtNum(String.format(Locale.US, "%.1f", f), lang)} °F", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TasbihSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    var target by remember { mutableIntStateOf(33) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            modifier = Modifier
                .size(220.dp)
                .clip(CircleShape)
                .background(c.surface)
                .clickable { DayflowRepository.incrementTasbih() },
            contentAlignment = Alignment.Center
        ) {
            RingProgress(progress = (state.tasbih % target) / target.toFloat(), size = 200.dp, strokeWidth = 10.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Time12h.fmtNum(state.tasbih, state.lang), fontSize = 48.sp, fontWeight = FontWeight.Light)
                    Text(if (ar) "اضغط للتسبيح" else "Tap to count", fontSize = 12.sp, color = c.muted)
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100).forEach { n ->
                DayflowChip(selected = target == n, label = Time12h.fmtNum(n, state.lang), onClick = { target = n })
            }
            DayflowChip(selected = false, label = if (ar) "تصفير" else "Reset", onClick = { DayflowRepository.updateState { it.copy(tasbih = 0) } })
        }
        DayflowCard {
            Text("${if (ar) "متتبع الختمة" else "Khatma tracker"} (${Time12h.fmtNum(state.khatma, state.lang)} / ${Time12h.fmtNum(30, state.lang)})", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            (1..30).chunked(10).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    row.forEach { juz ->
                        val done = juz <= state.khatma
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (done) c.accent else c.line)
                                .clickable { DayflowRepository.updateState { it.copy(khatma = if (state.khatma == juz) juz - 1 else juz) } },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(Time12h.fmtNum(juz, state.lang), fontSize = 10.sp, color = if (done) c.onAccent else c.text)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DateCalcSubScreen(lang: String) {
    val ar = lang == "ar"
    var d1 by remember { mutableStateOf(CalendarsAndDecor.todayKey()) }
    var d2 by remember { mutableStateOf(CalendarsAndDecor.dayKey(LocalDate.now().plusDays(30))) }
    val date1 = CalendarsAndDecor.parseDayKey(d1)
    val date2 = CalendarsAndDecor.parseDayKey(d2)
    val diff = ChronoUnit.DAYS.between(date1, date2).toInt()
    val hj = CalendarsAndDecor.hijri(date1)
    val cp = CalendarsAndDecor.coptic(date1)

    DayflowCard {
        OutlinedTextField(value = d1, onValueChange = { d1 = it }, label = { Text(if (ar) "التاريخ الأول" else "Start date") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(value = d2, onValueChange = { d2 = it }, label = { Text(if (ar) "التاريخ الثاني" else "End date") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("${Time12h.fmtNum(diff, lang)} ${if (ar) "يوم" else "days"}", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("${Time12h.fmtNum(hj.d, lang)}/${Time12h.fmtNum(hj.m, lang)}/${Time12h.fmtNum(hj.y, lang)} هـ · ${Time12h.fmtNum(cp.d, lang)}/${Time12h.fmtNum(cp.m, lang)}/${Time12h.fmtNum(cp.y, lang)} ش", fontSize = 13.sp)
    }
}

@Composable
private fun JournalSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    var mood by remember { mutableIntStateOf(4) }
    var text by remember { mutableStateOf("") }
    val faces = listOf("😞", "😕", "😐", "🙂", "😄")

    DayflowCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            faces.forEachIndexed { idx, f ->
                Box(
                    modifier = Modifier.size(46.dp).clip(CircleShape).background(if (mood == idx + 1) LocalDayflowColors.current.soft else Color.Transparent).clickable { mood = idx + 1 },
                    contentAlignment = Alignment.Center
                ) { Text(f, fontSize = 24.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = text, onValueChange = { text = it }, placeholder = { Text(if (ar) "كيف كان يومك؟" else "How was your day?") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (text.isNotBlank()) {
                DayflowRepository.updateState { s -> s.copy(journal = listOf(JournalEntry(DayflowRepository.newId(), CalendarsAndDecor.todayKey(), mood, text.trim())) + s.journal) }
                text = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "حفظ التدوين" else "Save entry") }
    }
    state.journal.forEach { j ->
        DayflowCard(contentPadding = PaddingValues(12.dp)) {
            Text("${j.date} ${faces[(j.mood - 1).coerceIn(0, 4)]}", fontSize = 12.sp)
            Text(j.text, fontSize = 14.sp)
        }
    }
}

@Composable
private fun MedsSubScreen(state: DayflowState) {
    val ar = state.lang == "ar"
    var name by remember { mutableStateOf("") }
    var time24 by remember { mutableStateOf("09:00") }
    val today = CalendarsAndDecor.todayKey()

    DayflowCard {
        OutlinedTextField(value = name, onValueChange = { name = it }, placeholder = { Text(if (ar) "اسم الدواء أو المكمل" else "Medication name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        TimePicker12h(value24 = time24, lang = state.lang, onValueChange = { time24 = it })
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (name.isNotBlank()) {
                DayflowRepository.updateState { s -> s.copy(meds = s.meds + MedItem(DayflowRepository.newId(), name.trim(), listOf(time24))) }
                name = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (ar) "إضافة" else "Add") }
    }
    state.meds.forEach { med ->
        val takenToday = med.taken[today]?.contains(med.times.firstOrNull()) == true
        val t12 = Time12h.formatHhMm(med.times.firstOrNull() ?: "09:00", state.lang).full
        DayflowCard(contentPadding = PaddingValues(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(med.name, fontWeight = FontWeight.Bold)
                    Text(t12, fontSize = 12.sp)
                }
                DayflowChip(
                    selected = takenToday,
                    label = if (takenToday) (if (ar) "أُخذ ✓" else "Taken ✓") else t12,
                    onClick = {
                        val tm = med.times.firstOrNull() ?: "09:00"
                        DayflowRepository.updateState { s ->
                            s.copy(meds = s.meds.map {
                                if (it.id == med.id) {
                                    val cur = it.taken[today] ?: emptyList()
                                    val next = if (cur.contains(tm)) cur - tm else cur + tm
                                    it.copy(taken = it.taken + (today to next))
                                } else it
                            })
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun BedsideClockFullscreen(lang: String, onExit: () -> Unit) {
    var nowCal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            nowCal = Calendar.getInstance()
        }
    }
    val parts = Time12h.formatCalendar(nowCal, lang)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { onExit() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(parts.full, color = Color.White.copy(alpha = 0.82f), fontSize = 64.sp, fontWeight = FontWeight.ExtraLight)
            Spacer(Modifier.height(8.dp))
            Text(if (lang == "ar") "اضغط في أي مكان للخروج" else "Tap anywhere to exit", color = Color.White.copy(alpha = 0.35f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun QrStudioSubScreen(lang: String) {
    val ar = lang == "ar"
    val context = LocalContext.current
    var mode by remember { mutableStateOf("create") }
    var payload by remember { mutableStateOf("https://dayflow.app") }
    var decodedResult by remember { mutableStateOf("") }

    val qrBitmap = remember(payload) {
        runCatching {
            if (payload.isBlank()) return@runCatching null
            val hints = mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H, EncodeHintType.CHARACTER_SET to "UTF-8", EncodeHintType.MARGIN to 2)
            val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, 512, 512, hints)
            val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
            for (x in 0 until 512) {
                for (y in 0 until 512) {
                    bmp.setPixel(x, y, if (matrix.get(x, y)) android.graphics.Color.parseColor("#1D1C1A") else android.graphics.Color.WHITE)
                }
            }
            bmp.asImageBitmap()
        }.getOrNull()
    }

    val qrImageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream) ?: return@use
                    val pixels = IntArray(bmp.width * bmp.height)
                    bmp.getPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                    val source = RGBLuminanceSource(bmp.width, bmp.height, pixels)
                    val binary = BinaryBitmap(HybridBinarizer(source))
                    decodedResult = MultiFormatReader().decode(binary).text
                }
            }.onFailure {
                decodedResult = if (ar) "لم يتم العثور على رمز QR واضح في الصورة." else "No readable QR found."
            }
        }
    }

    SegmentedBar(
        value = mode,
        options = listOf("create" to (if (ar) "إنشاء رمز QR" else "Create QR"), "scan" to (if (ar) "قراءة QR من صورة" else "Read QR")),
        onSelect = { mode = it }
    )

    if (mode == "create") {
        DayflowCard {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (qrBitmap != null) {
                    Image(bitmap = qrBitmap, contentDescription = "QR", modifier = Modifier.size(220.dp).clip(RoundedCornerShape(16.dp)))
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = payload, onValueChange = { payload = it }, label = { Text(if (ar) "الرابط أو النص" else "URL or text") }, modifier = Modifier.fillMaxWidth())
        }
    } else {
        DayflowCard {
            Button(onClick = { qrImageLauncher.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (ar) "اختر صورة تحتوي على رمز QR" else "Pick QR image")
            }
            if (decodedResult.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(decodedResult, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun ImageConverterSubScreen(lang: String) {
    val ar = lang == "ar"
    val context = LocalContext.current
    var quality by remember { mutableFloatStateOf(0.85f) }
    var infoText by remember { mutableStateOf("") }

    val imgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream) ?: return@use
                    val out = ByteArrayOutputStream()
                    @Suppress("DEPRECATION")
                    bmp.compress(Bitmap.CompressFormat.WEBP, (quality * 100).toInt(), out)
                    infoText = if (ar) "تم ضغط الصورة بنجاح (${bmp.width}×${bmp.height}) ← ${out.size() / 1024} كيلوبايت WebP"
                    else "Compressed (${bmp.width}×${bmp.height}) → ${out.size() / 1024} KB WebP"
                }
            }
        }
    }

    DayflowCard {
        Text("${if (ar) "الجودة" else "Quality"}: ${(quality * 100).toInt()}%", fontWeight = FontWeight.Bold)
        Slider(value = quality, onValueChange = { quality = it }, valueRange = 0.2f..1.0f)
        Button(onClick = { imgLauncher.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (ar) "اختر صورة لضغطها وتحويلها" else "Pick image to compress")
        }
        if (infoText.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(infoText, fontSize = 13.sp, color = LocalDayflowColors.current.accent)
        }
    }
}

@Composable
private fun BreathingSubScreen(lang: String) {
    val ar = lang == "ar"
    var running by remember { mutableStateOf(false) }
    var sec by remember { mutableIntStateOf(0) }
    LaunchedEffect(running) {
        while (running) {
            delay(1000L)
            sec = (sec + 1) % 19
        }
    }
    val phaseLabel = when {
        sec < 4 -> if (ar) "شهيق (${4 - sec})" else "Inhale (${4 - sec})"
        sec < 11 -> if (ar) "احبس النفس (${11 - sec})" else "Hold (${11 - sec})"
        else -> if (ar) "زفير (${19 - sec})" else "Exhale (${19 - sec})"
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(modifier = Modifier.size(200.dp).clip(CircleShape).background(LocalDayflowColors.current.soft), contentAlignment = Alignment.Center) {
            Text(phaseLabel, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Button(onClick = { running = !running }) {
            Text(if (running) (if (ar) "إيقاف" else "Pause") else (if (ar) "ابدأ تمرين ٤-٧-٨" else "Start 4-7-8"))
        }
    }
}

@Composable
private fun TextToolsSubScreen(lang: String) {
    val ar = lang == "ar"
    var txt by remember { mutableStateOf("") }
    val words = if (txt.isBlank()) 0 else txt.trim().split(Regex("\\s+")).size
    DayflowCard {
        OutlinedTextField(value = txt, onValueChange = { txt = it }, placeholder = { Text(if (ar) "الصق النص هنا…" else "Paste text…") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        Spacer(Modifier.height(8.dp))
        Text("${if (ar) "الكلمات" else "Words"}: ${Time12h.fmtNum(words, lang)} · ${if (ar) "الحروف" else "Chars"}: ${Time12h.fmtNum(txt.length, lang)}", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DayflowChip(selected = false, label = if (ar) "إزالة التشكيل" else "Strip diacritics", onClick = { txt = txt.replace(Regex("[\\u064B-\\u065F\\u0670]"), "") })
            DayflowChip(selected = false, label = if (ar) "مسح" else "Clear", onClick = { txt = "" })
        }
    }
}

@Composable
private fun StopwatchSubScreen(lang: String) {
    val ar = lang == "ar"
    var running by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    val laps = remember { mutableStateListOf<Long>() }

    LaunchedEffect(running) {
        val start = System.currentTimeMillis() - elapsedMs
        while (running) {
            delay(50L)
            elapsedMs = System.currentTimeMillis() - start
        }
    }
    fun fmtMs(ms: Long): String = "%02d:%02d.%02d".format(ms / 60000, (ms / 1000) % 60, (ms % 1000) / 10)

    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(Time12h.fmtNum(fmtMs(elapsedMs), lang), fontSize = 46.sp, fontFamily = FontFamily.Monospace)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { running = !running }) { Text(if (running) (if (ar) "إيقاف" else "Pause") else (if (ar) "ابدأ" else "Start")) }
            FilledTonalButton(onClick = { if (elapsedMs > 0) laps.add(0, elapsedMs) }) { Text(if (ar) "لفة" else "Lap") }
            OutlinedButton(onClick = { running = false; elapsedMs = 0L; laps.clear() }) { Text(if (ar) "تصفير" else "Reset") }
        }
        laps.forEachIndexed { idx, l ->
            Text("#${laps.size - idx}   ${Time12h.fmtNum(fmtMs(l), lang)}", fontFamily = FontFamily.Monospace)
        }
    }
}
