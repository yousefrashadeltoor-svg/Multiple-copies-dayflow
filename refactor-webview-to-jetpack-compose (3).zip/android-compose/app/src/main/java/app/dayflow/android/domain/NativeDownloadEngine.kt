package app.dayflow.android.domain

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.text.Html
import android.webkit.URLUtil
import app.dayflow.android.DayflowApplication
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.model.DownloadFormatOption
import app.dayflow.android.model.DownloadItem
import app.dayflow.android.model.LinkAnalysis
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URI
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object NativeDownloadEngine {
    private val http = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val activeCancelled = ConcurrentHashMap<String, Boolean>()

    fun sanitizeFilename(name: String): String =
        name.replace(Regex("[\\u0000-\\u001f<>:\"/\\\\|?*]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(140)
            .ifBlank { "download" }

    fun formatBytes(bytes: Long): String = when {
        bytes <= 0L -> "—"
        bytes < 1_000_000L -> "${bytes / 1000L} KB"
        bytes < 1_000_000_000L -> String.format(Locale.US, "%.1f MB", bytes / 1_000_000.0)
        else -> String.format(Locale.US, "%.2f GB", bytes / 1_000_000_000.0)
    }

    fun detectSite(host: String): String {
        val h = host.lowercase(Locale.ROOT).removePrefix("www.").removePrefix("m.")
        return when {
            h.contains("youtube.com") || h == "youtu.be" -> "youtube"
            h.contains("tiktok.com") -> "tiktok"
            h.contains("instagram.com") -> "instagram"
            h == "x.com" || h.contains("twitter.com") -> "x"
            h.contains("facebook.com") || h == "fb.watch" -> "facebook"
            h.contains("soundcloud.com") -> "soundcloud"
            h.contains("vimeo.com") -> "vimeo"
            h.contains("archive.org") -> "archive"
            else -> "generic"
        }
    }

    fun extractFirstUrl(raw: String): String? {
        val m = Pattern.compile("(?:https?://|www\\.)[^\\s<>\"']+").matcher(raw.trim())
        if (!m.find()) return null
        val found = m.group().trimEnd(')', ']', '}', '.', ',', ';', '!')
        return if (found.startsWith("http")) found else "https://$found"
    }

    /**
     * Zero-CORS Native Android Link Analyzer:
     * 1) Runs yt-dlp --dump-single-json when supported for real stream resolutions, cover, uploader, duration & sizes.
     * 2) Falls back to native OkHttp OpenGraph / Twitter Card / oEmbed / HTTP Range header inspection so EVERY link shows
     *    its cover thumbnail, title, author/site, description, MIME type, and file size without ANY browser CORS error!
     */
    suspend fun analyzeLink(rawInput: String): LinkAnalysis = withContext(Dispatchers.IO) {
        val url = extractFirstUrl(rawInput) ?: throw IllegalArgumentException("الرابط غير صالح")
        val uri = URI(url)
        val host = (uri.host ?: "link").removePrefix("www.")
        val site = detectSite(host)
        val secure = url.startsWith("https://", ignoreCase = true)
        val pathLower = (uri.path ?: "").lowercase(Locale.ROOT)

        val directExtKind = when {
            pathLower.endsWith(".m3u8") -> "hls"
            pathLower.matches(Regex(".*\\.(mp4|webm|mkv|mov|m4v)$")) -> "video"
            pathLower.matches(Regex(".*\\.(mp3|m4a|aac|flac|wav|ogg|opus)$")) -> "audio"
            pathLower.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)$")) -> "image"
            pathLower.matches(Regex(".*\\.(pdf|zip|apk|rar|7z|docx|xlsx)$")) -> "file"
            else -> "page"
        }

        // A) Try real yt-dlp JSON extraction for video/social platforms
        if (directExtKind == "page" && DayflowApplication.instance.ytdlpReady) {
            runCatching {
                val req = YoutubeDLRequest(url).apply {
                    addOption("--dump-single-json")
                    addOption("--no-playlist")
                    addOption("--socket-timeout", "12")
                }
                val resp = YoutubeDL.getInstance().execute(req, null, null)
                if (resp.out.isNotBlank()) {
                    val j = JSONObject(resp.out)
                    val title = j.optString("title").ifBlank { host }
                    val uploader = j.optString("uploader").ifBlank { j.optString("channel").ifBlank { site } }
                    val thumb = j.optString("thumbnail").takeIf { it.isNotBlank() }
                    val desc = j.optString("description").takeIf { it.isNotBlank() }?.take(240)
                    val duration = j.optDouble("duration", 0.0).toInt().takeIf { it > 0 }
                    val formatsJson = j.optJSONArray("formats")
                    val options = mutableListOf<DownloadFormatOption>()

                    if (formatsJson != null) {
                        val heights = listOf(2160, 1440, 1080, 720, 480, 360)
                        for (h in heights) {
                            var bestSize = 0L
                            var found = false
                            for (i in 0 until formatsJson.length()) {
                                val f = formatsJson.optJSONObject(i) ?: continue
                                if (f.optInt("height", 0) == h && f.optString("vcodec", "none") != "none") {
                                    found = true
                                    val sz = f.optLong("filesize", f.optLong("filesize_approx", 0L))
                                    if (sz > bestSize) bestSize = sz
                                }
                            }
                            if (found) {
                                val lbl = if (h == 2160) "4K (2160p)" else "${h}p MP4"
                                options.add(DownloadFormatOption("v$h", lbl, "MP4 · yt-dlp + FFmpeg", bestSize, "video", url, h))
                            }
                        }
                    }
                    if (options.isNotEmpty()) {
                        options.add(0, DownloadFormatOption("best", "Best Quality", "أعلى جودة فيديو وصوت مدمجة", options.first().size, "video", url, options.first().height))
                    } else {
                        options.add(DownloadFormatOption("best", "Best Video MP4", "yt-dlp + FFmpeg", 0L, "video", url))
                    }
                    options.add(DownloadFormatOption("mp3-320", "MP3 320 kbps", "استخراج صوت عالي النقاء · FFmpeg", 0L, "audio", url))
                    options.add(DownloadFormatOption("m4a", "M4A / AAC", "ملف صوتي أصلي سريع", 0L, "audio", url))
                    if (thumb != null) {
                        options.add(DownloadFormatOption("cover", "صورة الغلاف (Cover)", "JPG بأعلى دقة", 0L, "image", thumb))
                    }

                    return@withContext LinkAnalysis(
                        url = url,
                        kind = "video",
                        host = host,
                        site = site,
                        secure = secure,
                        title = title,
                        thumb = thumb,
                        author = uploader,
                        description = desc,
                        duration = duration,
                        filename = sanitizeFilename(title),
                        formats = options,
                        engines = listOf("yt-dlp", "FFmpeg", "aria2c")
                    )
                }
            }
        }

        // B) Native OkHttp inspection (Zero CORS!) + OpenGraph + oEmbed
        var title = host
        var thumb: String? = null
        var author: String? = null
        var desc: String? = null
        var mime: String? = null
        var size: Long? = null
        var rangeOk = false
        var finalUrl = url
        var isHtml = false

        runCatching {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
                .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
                .header("Range", "bytes=0-131071")
                .build()
            http.newCall(req).execute().use { resp ->
                finalUrl = resp.request.url.toString()
                mime = resp.header("Content-Type")?.substringBefore(";")?.trim()
                rangeOk = resp.code == 206 || resp.header("Accept-Ranges")?.contains("bytes", true) == true
                val contentRangeTotal = resp.header("Content-Range")?.substringAfter("/")?.toLongOrNull()
                size = contentRangeTotal ?: resp.header("Content-Length")?.toLongOrNull()
                isHtml = mime?.contains("text/html", ignoreCase = true) == true
                val disposition = resp.header("Content-Disposition")
                title = URLUtil.guessFileName(finalUrl, disposition, mime)

                if (isHtml) {
                    val html = resp.body?.string().orEmpty()
                    val ogTitle = extractMeta(html, "og:title").ifBlank { extractMeta(html, "twitter:title").ifBlank { extractTag(html, "title") } }
                    if (ogTitle.isNotBlank()) title = ogTitle
                    thumb = extractMeta(html, "og:image").ifBlank { extractMeta(html, "twitter:image") }.takeIf { it.isNotBlank() }
                    desc = extractMeta(html, "og:description").ifBlank { extractMeta(html, "description") }.takeIf { it.isNotBlank() }
                    author = extractMeta(html, "og:site_name").ifBlank { extractMeta(html, "author") }.takeIf { it.isNotBlank() }
                }
            }
        }

        // C) Supplement with YouTube/TikTok/Vimeo oEmbed if needed
        if ((thumb == null || title == host) && site in listOf("youtube", "tiktok", "vimeo", "soundcloud")) {
            runCatching {
                val enc = URLEncoder.encode(url, "UTF-8")
                val oembedUrl = when (site) {
                    "youtube" -> "https://www.youtube.com/oembed?format=json&url=$enc"
                    "tiktok" -> "https://www.tiktok.com/oembed?url=$enc"
                    "vimeo" -> "https://vimeo.com/api/oembed.json?url=$enc"
                    else -> "https://soundcloud.com/oembed?format=json&url=$enc"
                }
                http.newCall(Request.Builder().url(oembedUrl).build()).execute().use { r ->
                    if (r.isSuccessful) {
                        val oj = JSONObject(r.body?.string().orEmpty())
                        if (oj.optString("title").isNotBlank()) title = oj.optString("title")
                        if (oj.optString("author_name").isNotBlank()) author = oj.optString("author_name")
                        if (oj.optString("thumbnail_url").isNotBlank()) thumb = oj.optString("thumbnail_url")
                    }
                }
            }
        }

        val formats = mutableListOf<DownloadFormatOption>()
        if (!isHtml && directExtKind != "page") {
            val ext = title.substringAfterLast('.', mime?.substringAfterLast('/') ?: "file").uppercase(Locale.ROOT)
            formats.add(
                DownloadFormatOption(
                    id = "direct",
                    label = "$ext · ملف مباشر",
                    detail = listOfNotNull(mime, if (rangeOk) "يدعم الاستكمال السريع" else null).joinToString(" · "),
                    size = size ?: 0L,
                    kind = directExtKind,
                    url = finalUrl
                )
            )
            if (directExtKind == "image") thumb = finalUrl
        } else {
            formats.add(DownloadFormatOption("best", "Best Video MP4", "yt-dlp + FFmpeg", 0L, "video", finalUrl))
            formats.add(DownloadFormatOption("v1080", "1080p Full HD", "MP4 H.264", 0L, "video", finalUrl, 1080))
            formats.add(DownloadFormatOption("v720", "720p HD", "MP4 H.264", 0L, "video", finalUrl, 720))
            formats.add(DownloadFormatOption("v480", "480p SD", "MP4 H.264", 0L, "video", finalUrl, 480))
            formats.add(DownloadFormatOption("mp3-320", "MP3 320 kbps", "استخراج صوتي · FFmpeg", 0L, "audio", finalUrl))
            if (thumb != null) {
                formats.add(DownloadFormatOption("cover", "صورة الغلاف الأصلية", "JPG Image", 0L, "image", thumb))
            }
        }

        LinkAnalysis(
            url = finalUrl,
            kind = if (!isHtml) directExtKind else "page",
            host = host,
            site = site,
            secure = secure,
            title = title,
            thumb = thumb,
            author = author,
            description = desc,
            size = size,
            mime = mime,
            rangeOk = rangeOk,
            filename = sanitizeFilename(title),
            formats = formats,
            engines = if (!isHtml) listOf("OkHttp Range", "DownloadManager") else listOf("yt-dlp", "FFmpeg", "aria2c")
        )
    }

    private fun extractMeta(html: String, key: String): String {
        val patterns = listOf(
            "(?is)<meta[^>]+(?:property|name)=[\"']${Pattern.quote(key)}[\"'][^>]+content=[\"']([^\"']*)[\"']",
            "(?is)<meta[^>]+content=[\"']([^\"']*)[\"'][^>]+(?:property|name)=[\"']${Pattern.quote(key)}[\"']"
        )
        for (p in patterns) {
            val m = Pattern.compile(p).matcher(html)
            if (m.find()) {
                return Html.fromHtml(m.group(1) ?: "", Html.FROM_HTML_MODE_LEGACY).toString().trim()
            }
        }
        return ""
    }

    private fun extractTag(html: String, tag: String): String {
        val m = Pattern.compile("(?is)<$tag[^>]*>(.*?)</$tag>").matcher(html)
        return if (m.find()) Html.fromHtml(m.group(1) ?: "", Html.FROM_HTML_MODE_LEGACY).toString().trim() else ""
    }

    fun cancelDownload(id: String) {
        activeCancelled[id] = true
        runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
        DayflowRepository.patchDownload(id) { it.copy(state = "cancelled", speed = 0L) }
    }

    /** Executes real native download into Public Downloads/DayFlow folder */
    suspend fun executeDownload(context: Context, itemId: String, onProgressNotify: (Int, String) -> Unit) = withContext(Dispatchers.IO) {
        val item = DayflowRepository.state.value.downloads.find { it.id == itemId } ?: return@withContext
        activeCancelled.remove(itemId)
        val outDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "DayFlow").apply { mkdirs() }
        val targetUrl = item.variantUrl ?: item.url
        val fmt = item.format ?: "best"

        DayflowRepository.patchDownload(itemId) { it.copy(state = "downloading", error = null) }

        try {
            val isDirectBinary = fmt == "direct" || fmt == "cover" || targetUrl.matches(Regex("(?i).*\\.(mp4|webm|mp3|m4a|wav|flac|ogg|jpg|jpeg|png|webp|gif|pdf|zip|apk)(\\?.*)?$"))

            if (!isDirectBinary && DayflowApplication.instance.ytdlpReady) {
                DayflowRepository.patchDownload(itemId) { it.copy(engine = "yt-dlp") }
                val req = YoutubeDLRequest(item.url).apply {
                    addOption("--no-playlist")
                    addOption("-o", "${outDir.absolutePath}/${sanitizeFilename(item.name.substringBeforeLast('.'))}.%(ext)s")
                    when {
                        fmt.startsWith("mp3") -> {
                            addOption("-x")
                            addOption("--audio-format", "mp3")
                            addOption("--audio-quality", "0")
                        }
                        fmt == "m4a" -> {
                            addOption("-f", "bestaudio[ext=m4a]/bestaudio")
                        }
                        fmt.startsWith("v") -> {
                            val h = fmt.removePrefix("v").toIntOrNull() ?: 720
                            addOption("-f", "bestvideo[height<=$h][ext=mp4]+bestaudio[ext=m4a]/best[height<=$h]/best")
                            addOption("--merge-output-format", "mp4")
                        }
                        else -> {
                            addOption("-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best")
                            addOption("--merge-output-format", "mp4")
                        }
                    }
                }
                YoutubeDL.getInstance().execute(req, itemId) { progress, etaInSeconds, _ ->
                    val pct = progress.coerceIn(0f, 100f)
                    DayflowRepository.patchDownload(itemId) { cur ->
                        val estGot = if (cur.size > 0) ((pct / 100f) * cur.size).toLong() else (pct * 10_000L).toLong()
                        cur.copy(got = estGot, eta = etaInSeconds.coerceAtLeast(0L))
                    }
                    onProgressNotify(pct.toInt(), item.name)
                }
                DayflowRepository.patchDownload(itemId) { cur ->
                    cur.copy(
                        state = "completed",
                        got = if (cur.size > 0) cur.size else 100L,
                        size = if (cur.size > 0) cur.size else 100L,
                        doneAt = System.currentTimeMillis(),
                        savedPath = "${outDir.absolutePath}/${item.name}"
                    )
                }
                return@withContext
            }

            // Direct Native OkHttp Streaming Download (Zero CORS!) with Fallback to System DownloadManager
            DayflowRepository.patchDownload(itemId) { it.copy(engine = "OkHttp Native") }
            val safeName = if (item.name.contains('.')) sanitizeFilename(item.name) else "${sanitizeFilename(item.name)}.jpg"
            val destFile = File(outDir, safeName)
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) Chrome/126.0 Mobile")
                .build()

            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw RuntimeException("HTTP ${resp.code}")
                val body = resp.body ?: throw RuntimeException("Empty response body")
                val total = body.contentLength().coerceAtLeast(item.size)
                var downloaded = 0L
                var lastTick = System.currentTimeMillis()
                var bytesSinceTick = 0L

                body.byteStream().use { input ->
                    FileOutputStream(destFile).use { output ->
                        val buffer = ByteArray(32 * 1024)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            if (activeCancelled[itemId] == true) throw InterruptedException("Cancelled")
                            output.write(buffer, 0, read)
                            downloaded += read
                            bytesSinceTick += read
                            val now = System.currentTimeMillis()
                            if (now - lastTick >= 400L) {
                                val speed = (bytesSinceTick * 1000L) / (now - lastTick).coerceAtLeast(1L)
                                val eta = if (total > downloaded && speed > 0) (total - downloaded) / speed else 0L
                                val pct = if (total > 0) ((downloaded * 100L) / total).toInt() else 50
                                DayflowRepository.patchDownload(itemId) {
                                    it.copy(got = downloaded, size = total.coerceAtLeast(downloaded), speed = speed, eta = eta)
                                }
                                onProgressNotify(pct, safeName)
                                lastTick = now
                                bytesSinceTick = 0L
                            }
                        }
                    }
                }
                DayflowRepository.patchDownload(itemId) {
                    it.copy(
                        state = "completed",
                        got = downloaded,
                        size = downloaded,
                        speed = 0L,
                        eta = 0L,
                        doneAt = System.currentTimeMillis(),
                        savedPath = destFile.absolutePath
                    )
                }
            }
        } catch (e: InterruptedException) {
            DayflowRepository.patchDownload(itemId) { it.copy(state = "cancelled", speed = 0L) }
        } catch (e: Exception) {
            // Fallback to Android System DownloadManager for direct HTTP/HTTPS links
            val enqueued = runCatching {
                val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val dmReq = DownloadManager.Request(Uri.parse(targetUrl))
                    .setTitle(item.name)
                    .setDescription("DAYFLOW Download")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setAllowedOverMetered(true)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "DayFlow/${sanitizeFilename(item.name)}")
                dm.enqueue(dmReq)
            }.isSuccess

            if (enqueued) {
                DayflowRepository.patchDownload(itemId) {
                    it.copy(state = "completed", engine = "DownloadManager", doneAt = System.currentTimeMillis(), savedPath = "Downloads/DayFlow/${item.name}")
                }
            } else {
                DayflowRepository.patchDownload(itemId) {
                    it.copy(state = "failed", speed = 0L, error = e.message ?: "تعذّر إكمال التحميل")
                }
            }
        }
    }
}
