package app.dayflow.android.system

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.DayflowRepository

object NotificationController {
    const val CH_ALARMS = "dayflow_alarms_v2"
    const val CH_REMINDERS = "dayflow_reminders_v2"
    const val CH_COMPANION = "dayflow_companion_v2"
    const val CH_DOWNLOADS = "dayflow_downloads_v2"

    fun hasPermission(context: Context): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val alarmCh = NotificationChannel(CH_ALARMS, "DAYFLOW Alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "High-priority lockscreen alarms"
            enableVibration(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setSound(
                Settings.System.DEFAULT_ALARM_ALERT_URI,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        val remCh = NotificationChannel(CH_REMINDERS, "DAYFLOW Reminders", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Scheduled task, habit, and evening review reminders"
            enableVibration(true)
        }
        val compCh = NotificationChannel(CH_COMPANION, "DAYFLOW Floating Companion", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Floating companion robot status"
        }
        val dlCh = NotificationChannel(CH_DOWNLOADS, "DAYFLOW Downloads", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Media and file download progress"
        }

        nm.createNotificationChannels(listOf(alarmCh, remCh, compCh, dlCh))
    }

    fun showInteractiveReminder(
        context: Context,
        notifId: Int,
        reminderKey: String,
        title: String,
        body: String
    ) {
        if (!hasPermission(context)) return
        ensureChannels(context)
        val state = DayflowRepository.state.value
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(
            context,
            notifId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_COMPLETE
            putExtra("notifId", notifId)
            putExtra("reminderKey", reminderKey)
        }
        val completePi = PendingIntent.getBroadcast(
            context,
            notifId + 10000,
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_SNOOZE
            putExtra("notifId", notifId)
            putExtra("reminderKey", reminderKey)
            putExtra("title", title)
            putExtra("body", body)
        }
        val snoozePi = PendingIntent.getBroadcast(
            context,
            notifId + 20000,
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val displayBody = if (state.notif.preview) body else if (state.lang == "ar") "لديك تذكير مجدول" else "Scheduled reminder"
        val ar = state.lang == "ar"

        val notif = NotificationCompat.Builder(context, CH_REMINDERS)
            .setSmallIcon(R.drawable.ic_dayflow_notif)
            .setContentTitle(title)
            .setContentText(displayBody)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .setVisibility(if (state.notif.preview) NotificationCompat.VISIBILITY_PUBLIC else NotificationCompat.VISIBILITY_PRIVATE)
            .addAction(0, if (ar) "تم ✓" else "Complete ✓", completePi)
            .addAction(0, if (ar) "غفوة ١٠ د" else "Snooze 10m", snoozePi)
            .addAction(0, if (ar) "فتح" else "Open", openPi)
            .build()

        nm.notify(notifId, notif)
    }

    fun showCompanionHiddenNotification(context: Context) {
        if (!hasPermission(context)) return
        ensureChannels(context)
        val ar = DayflowRepository.state.value.lang == "ar"
        val restoreIntent = Intent(context, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_RESTORE_COMPANION
        }
        val restorePi = PendingIntent.getBroadcast(
            context,
            9202,
            restoreIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(context, CH_COMPANION)
            .setSmallIcon(R.drawable.ic_dayflow_notif)
            .setContentTitle(if (ar) "DAYFLOW — الرفيق مستخفي" else "DAYFLOW — Companion hidden")
            .setContentText(if (ar) "اضغط هنا لإعادة إظهار الرفيق العائم في أي وقت 👋" else "Tap here to bring the floating companion back 👋")
            .setAutoCancel(true)
            .setContentIntent(restorePi)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(9202, notif)
    }

    fun postAlarmFullScreenNotification(
        context: Context,
        alarmId: String,
        label: String,
        soundUri: String,
        vibrate: Boolean,
        snooze: Int,
        gentle: Boolean
    ) {
        ensureChannels(context)
        val ringIntent = Intent(context, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("alarmId", alarmId)
            putExtra("label", label)
            putExtra("soundUri", soundUri)
            putExtra("vibrate", vibrate)
            putExtra("snooze", snooze)
            putExtra("gentle", gentle)
        }
        val reqCode = (alarmId.hashCode() and 0x7fffffff)
        val fullScreenPi = PendingIntent.getActivity(
            context,
            reqCode,
            ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && soundUri.isNotBlank()) {
            val customChId = "dayflow_alarm_${soundUri.hashCode()}"
            if (nm.getNotificationChannel(customChId) == null) {
                val parsed = runCatching { Uri.parse(soundUri) }.getOrDefault(Settings.System.DEFAULT_ALARM_ALERT_URI)
                val ch = NotificationChannel(customChId, "DAYFLOW Alarm Tone", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(
                        parsed,
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    enableVibration(vibrate)
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                }
                nm.createNotificationChannel(ch)
            }
            customChId
        } else CH_ALARMS

        val notif = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_dayflow_notif)
            .setContentTitle(label.ifBlank { "DAYFLOW" })
            .setContentText(if (DayflowRepository.state.value.lang == "ar") "المنبه يرن الآن" else "Alarm is ringing")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setAutoCancel(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPi, true)
            .setContentIntent(fullScreenPi)
            .build()

        nm.notify(reqCode, notif)
        runCatching { context.startActivity(ringIntent) }
    }
}
