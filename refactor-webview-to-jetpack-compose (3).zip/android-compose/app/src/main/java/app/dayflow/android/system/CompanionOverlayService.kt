package app.dayflow.android.system

import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.ReviewAndSoulEngine
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.DayflowState
import kotlin.math.*

/**
 * Genuine System-Wide Floating Robot Companion Service (SYSTEM_ALERT_WINDOW).
 * Renders the articulated physics robot + Egyptian Arabic speech bubbles ABOVE ALL APPS on the phone,
 * with smooth drag, edge-docking, and an interactive QuickPanel overlay right over any screen!
 */
class CompanionOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var rootContainer: LinearLayout? = null
    private var bubbleTextView: TextView? = null
    private var robotView: ArticulatedRobotOverlayView? = null
    private var quickPopupView: View? = null
    private lateinit var overlayParams: WindowManager.LayoutParams
    private val mainHandler = Handler(Looper.getMainLooper())

    private val bubbleRunnable = object : Runnable {
        override fun run() {
            refreshStateFromRepo()
            mainHandler.postDelayed(this, 9000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        DayflowRepository.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(9201, buildForegroundNotification())
    }

    private fun buildForegroundNotification(): Notification {
        NotificationController.ensureChannels(this)
        val ar = DayflowRepository.state.value.lang == "ar"
        val stopIntent = Intent(this, NotificationActionReceiver::class.java).apply {
            action = NotificationActionReceiver.ACTION_STOP_OVERLAY
        }
        val stopPi = PendingIntent.getBroadcast(
            this,
            9209,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this,
            9208,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotificationController.CH_COMPANION)
            .setSmallIcon(R.drawable.ic_dayflow_notif)
            .setContentTitle(if (ar) "رفيق DAYFLOW العائم نشط" else "DAYFLOW Floating Companion")
            .setContentText(if (ar) "يظهر فوق جميع تطبيقات الهاتف — اضغط للإعدادات" else "Floating across your screen")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, if (ar) "إيقاف التعويم" else "Stop overlay", stopPi)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (rootContainer == null) {
            mountOverlayWindow()
        }
        refreshStateFromRepo()
        mainHandler.removeCallbacks(bubbleRunnable)
        mainHandler.postDelayed(bubbleRunnable, 9000L)
        return START_STICKY
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).roundToInt()

    @SuppressLint("ClickableViewAccessibility")
    private fun mountOverlayWindow() {
        val state = DayflowRepository.state.value
        val scale = state.companion.size.coerceIn(0.7f, 1.5f)
        val robotW = dp(92f * scale)
        val robotH = dp(118f * scale)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END or Gravity.BOTTOM
            clipChildren = false
            clipToPadding = false
        }

        val bubbleTv = TextView(this).apply {
            maxWidth = dp(200f)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.parseColor("#1D1C1A"))
            setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F5FFFFFF"))
                cornerRadius = dp(14f).toFloat()
                setStroke(dp(1f), Color.parseColor("#26000000"))
            }
            elevation = dp(4f).toFloat()
        }
        val bubbleLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(2f)
        }
        container.addView(bubbleTv, bubbleLp)

        val rView = ArticulatedRobotOverlayView(this)
        container.addView(rView, LinearLayout.LayoutParams(robotW, robotH))

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels - robotW - dp(14f)).coerceAtLeast(dp(8f))
            y = (resources.displayMetrics.heightPixels * 0.58f).roundToInt()
        }

        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var downTime = 0L

        rView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    startX = overlayParams.x
                    startY = overlayParams.y
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downRawX).roundToInt()
                    val dy = (ev.rawY - downRawY).roundToInt()
                    overlayParams.x = (startX + dx).coerceIn(0, resources.displayMetrics.widthPixels - dp(80f))
                    overlayParams.y = (startY + dy).coerceIn(dp(24f), resources.displayMetrics.heightPixels - dp(130f))
                    rView.onVelocity(ev.rawX - downRawX)
                    runCatching { wm.updateViewLayout(container, overlayParams) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = hypot(ev.rawX - downRawX, ev.rawY - downRawY)
                    if (moved < dp(10f) && System.currentTimeMillis() - downTime < 450L) {
                        toggleFloatingQuickPanel()
                    } else {
                        // Gentle snap toward nearest screen edge
                        val screenW = resources.displayMetrics.widthPixels
                        overlayParams.x = if (overlayParams.x + container.width / 2 < screenW / 2) dp(6f)
                        else (screenW - container.width - dp(6f)).coerceAtLeast(dp(6f))
                        container.gravity = if (overlayParams.x < screenW / 2) Gravity.START else Gravity.END
                        rView.onVelocity(0f)
                        runCatching { wm.updateViewLayout(container, overlayParams) }
                    }
                    true
                }
                else -> false
            }
        }

        bubbleTv.setOnClickListener { toggleFloatingQuickPanel() }

        rootContainer = container
        bubbleTextView = bubbleTv
        robotView = rView
        runCatching { wm.addView(container, overlayParams) }
    }

    private fun refreshStateFromRepo() {
        val state = DayflowRepository.state.value
        if (!state.companion.enabled || state.companion.hidden) {
            removeQuickPopup()
            stopSelf()
            return
        }
        val scale = state.companion.size.coerceIn(0.7f, 1.5f)
        rootContainer?.alpha = state.companion.opacity.coerceIn(0.35f, 1f)
        robotView?.let { rv ->
            val lp = rv.layoutParams
            lp.width = dp(92f * scale)
            lp.height = dp(118f * scale)
            rv.layoutParams = lp
            val family = when (state.companion.outfit) {
                "gold" -> "ramadan"
                "snow" -> "winter"
                "national" -> "national"
                "none" -> "friday"
                else -> CalendarsAndDecor.resolveDecor(java.time.LocalDate.now(), state.userDays).primary
            }
            val bubble = ReviewAndSoulEngine.currentBubble(state)
            rv.mood = bubble.mood.ifBlank { state.companion.emotion }
            rv.family = family
            bubbleTextView?.visibility = if (state.companion.bubbles) View.VISIBLE else View.GONE
            bubbleTextView?.text = bubble.text
        }
    }

    private fun toggleFloatingQuickPanel() {
        if (quickPopupView != null) {
            removeQuickPopup()
            return
        }
        val state = DayflowRepository.state.value
        val ar = state.lang == "ar"

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(14f), dp(16f), dp(14f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FCFAF5"))
                cornerRadius = dp(22f).toFloat()
                setStroke(dp(1f), Color.parseColor("#22000000"))
            }
            elevation = dp(12f).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = if (ar) "رفيق DAYFLOW السريع" else "DAYFLOW Companion"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#1D1C1A"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = TextView(this).apply {
            text = "✕"
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            setTextColor(Color.parseColor("#555555"))
            setOnClickListener { removeQuickPopup() }
        }
        header.addView(titleTv)
        header.addView(closeBtn)
        card.addView(header)

        val replyTv = TextView(this).apply {
            text = ReviewAndSoulEngine.currentBubble(state).text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.parseColor("#2F6F5E"))
            setPadding(0, dp(8f), 0, dp(8f))
        }
        card.addView(replyTv)

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val inputEt = EditText(this).apply {
            hint = if (ar) "اكتب أمرًا… (اعمل منبه ٧ الصبح)" else "Ask anything… (Set alarm 7 AM)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#1D1C1A"))
            setHintTextColor(Color.parseColor("#888888"))
            setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EFECE4"))
                cornerRadius = dp(12f).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sendBtn = Button(this).apply {
            text = if (ar) "إرسال" else "Send"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2F6F5E"))
                cornerRadius = dp(12f).toFloat()
            }
            setOnClickListener {
                val cmd = inputEt.text?.toString().orEmpty().trim()
                if (cmd.isNotEmpty()) {
                    val res = ReviewAndSoulEngine.processLocalCommand(cmd, DayflowRepository.state.value) { _, _ -> }
                    replyTv.text = res.text
                    inputEt.setText("")
                    refreshStateFromRepo()
                }
            }
        }
        val sendLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38f)).apply {
            marginStart = dp(6f)
        }
        inputRow.addView(inputEt)
        inputRow.addView(sendBtn, sendLp)
        card.addView(inputRow)

        val actionsGrid = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10f), 0, 0)
        }

        fun makeActionChip(label: String, onClick: () -> Unit): TextView {
            return TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(Color.parseColor("#1D1C1A"))
                setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#E6EFEA"))
                    cornerRadius = dp(12f).toFloat()
                }
                setOnClickListener { onClick() }
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(4f)
                }
            }
        }

        actionsGrid.addView(makeActionChip(if (ar) "💧 +٢٥٠ مل" else "💧 +250 ml") {
            DayflowRepository.addWater(250)
            val total = DayflowRepository.state.value.water[CalendarsAndDecor.todayKey()] ?: 250
            replyTv.text = if (ar) "تم تسجيل ٢٥٠ مل (الإجمالي ${Time12h.fmtNum(total, "ar")} مل)" else "Logged +250 ml ($total ml today)"
        })
        actionsGrid.addView(makeActionChip(if (ar) "افتح التطبيق" else "Open App") {
            removeQuickPopup()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        })
        actionsGrid.addView(makeActionChip(if (ar) "إخفاء مؤقت" else "Hide") {
            removeQuickPopup()
            if (DayflowRepository.state.value.companion.notify) {
                NotificationController.showCompanionHiddenNotification(this)
            }
            DayflowRepository.updateState { s -> s.copy(companion = s.companion.copy(hidden = true)) }
            stopSelf()
        })
        card.addView(actionsGrid)

        val popupParams = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.86f).roundToInt().coerceAtMost(dp(340f)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        card.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_OUTSIDE) {
                removeQuickPopup()
                true
            } else false
        }

        quickPopupView = card
        runCatching { wm.addView(card, popupParams) }
    }

    private fun removeQuickPopup() {
        quickPopupView?.let { v ->
            runCatching { wm.removeView(v) }
        }
        quickPopupView = null
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        removeQuickPopup()
        rootContainer?.let { v -> runCatching { wm.removeView(v) } }
        rootContainer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun canDraw(context: Context): Boolean = Settings.canDrawOverlays(context)

        fun requestPermission(context: Context) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(intent) }
        }

        fun syncIfPermitted(context: Context, state: DayflowState) {
            if (!state.companion.enabled || state.companion.hidden || !state.companion.overlayActive) {
                context.stopService(Intent(context, CompanionOverlayService::class.java))
                return
            }
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, CompanionOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                runCatching { context.startForegroundService(intent) }
            } else {
                runCatching { context.startService(intent) }
            }
        }
    }
}

/**
 * Hardware-accelerated custom Android Canvas View drawing the EXACT DAYFLOW articulated robot
 * with spring-physics limbs, visor eyes, 9 moods, and seasonal outfits at smooth 30fps!
 */
private class ArticulatedRobotOverlayView(context: Context) : View(context) {
    var mood: String = "idle"
    var family: String = "islamic"
    private var tiltDeg: Float = 0f
    private var phase: Float = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val limbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val animator = object : Runnable {
        override fun run() {
            phase += 0.12f
            tiltDeg *= 0.88f
            invalidate()
            postDelayed(this, 33L) // Smooth 30fps, ultra-low battery & CPU
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(animator)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(animator)
        super.onDetachedFromWindow()
    }

    fun onVelocity(dx: Float) {
        tiltDeg = (-dx * 0.08f).coerceIn(-22f, 22f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width / 120f
        val sy = height / 160f
        val s = min(sx, sy)
        canvas.save()
        canvas.translate((width - 120f * s) / 2f, (height - 154f * s) / 2f)
        canvas.scale(s, s)
        canvas.rotate(tiltDeg, 60f, 80f)

        val bob = sin(phase) * 2.2f
        val swing = sin(phase * 0.8f) * 3.5f

        // Ground shadow
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(38, 0, 0, 0)
        canvas.drawOval(RectF(34f, 142f, 86f, 150f), paint)

        // Legs
        limbPaint.color = Color.parseColor("#8D9BB0")
        limbPaint.strokeWidth = 9f
        canvas.drawLine(48f, 118f + bob, 46f - swing * 0.3f, 136f, limbPaint)
        canvas.drawLine(72f, 118f + bob, 74f + swing * 0.3f, 136f, limbPaint)

        // Arms
        limbPaint.strokeWidth = 8f
        canvas.drawLine(34f, 78f + bob, 21f - swing, 112f + bob, limbPaint)
        canvas.drawLine(86f, 78f + bob, 99f + swing, 112f + bob, limbPaint)
        paint.color = Color.parseColor("#E7EDF5")
        canvas.drawCircle(21f - swing, 112f + bob, 5.5f, paint)
        canvas.drawCircle(99f + swing, 112f + bob, 5.5f, paint)

        // Torso
        paint.color = if (mood == "cold") Color.parseColor("#CFE3F5") else Color.parseColor("#E3EAF4")
        canvas.drawRoundRect(RectF(34f, 66f + bob, 86f, 122f + bob), 18f, 18f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        paint.color = Color.parseColor("#7F8CA2")
        canvas.drawRoundRect(RectF(34f, 66f + bob, 86f, 122f + bob), 18f, 18f, paint)

        // Chest Core
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#0F1A2C")
        canvas.drawRoundRect(RectF(47f, 80f + bob, 73f, 96f + bob), 5f, 5f, paint)
        paint.color = Color.parseColor("#2F6F5E")
        canvas.drawCircle(60f, 88f + bob, 4.2f, paint)

        // Head + Antennae
        canvas.save()
        canvas.rotate(sin(phase * 0.6f) * 3f, 60f, 64f + bob)
        limbPaint.strokeWidth = 2.6f
        limbPaint.color = Color.parseColor("#7D8AA0")
        canvas.drawLine(50f, 22f + bob, 40f - swing * 0.4f, 3f + bob, limbPaint)
        canvas.drawLine(70f, 22f + bob, 80f + swing * 0.4f, 3f + bob, limbPaint)
        paint.color = Color.parseColor("#C9A24A")
        canvas.drawCircle(40f - swing * 0.4f, 3f + bob, 4f, paint)
        canvas.drawCircle(80f + swing * 0.4f, 3f + bob, 4f, paint)

        paint.color = Color.parseColor("#EDF2F8")
        canvas.drawRoundRect(RectF(30f, 20f + bob, 90f, 66f + bob), 20f, 20f, paint)
        paint.style = Paint.Style.STROKE
        paint.color = Color.parseColor("#7F8CA2")
        canvas.drawRoundRect(RectF(30f, 20f + bob, 90f, 66f + bob), 20f, 20f, paint)

        // Visor
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#131D33")
        canvas.drawRoundRect(RectF(37f, 29f + bob, 83f, 57f + bob), 13f, 13f, paint)

        // Eyes
        paint.color = Color.parseColor("#7FD6FF")
        val blinking = (phase % 14f) > 13.5f || mood == "sleep"
        if (blinking) {
            limbPaint.color = Color.parseColor("#7FD6FF")
            limbPaint.strokeWidth = 2.5f
            canvas.drawLine(46f, 44f + bob, 54f, 44f + bob, limbPaint)
            canvas.drawLine(66f, 44f + bob, 74f, 44f + bob, limbPaint)
        } else {
            canvas.drawOval(RectF(46f, 38f + bob, 54f, 48f + bob), paint)
            canvas.drawOval(RectF(66f, 38f + bob, 74f, 48f + bob), paint)
        }
        canvas.restore()

        // Seasonal Outfit Accents
        paint.style = Paint.Style.FILL
        if (family == "winter") {
            paint.color = Color.parseColor("#C8453B")
            canvas.drawRoundRect(RectF(40f, 63f + bob, 80f, 73f + bob), 5f, 5f, paint)
        } else if (family == "ramadan") {
            paint.color = Color.parseColor("#FFD36B")
            canvas.drawCircle(99f + swing, 124f + bob, 6f, paint)
        }

        canvas.restore()
    }
}
