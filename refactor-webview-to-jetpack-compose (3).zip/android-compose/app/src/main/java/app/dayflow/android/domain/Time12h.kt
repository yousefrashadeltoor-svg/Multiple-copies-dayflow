package app.dayflow.android.domain

import app.dayflow.android.model.AlarmItem
import java.util.Calendar

data class ClockParts12(
    val time: String,
    val suffix: String,
    val full: String
)

object Time12h {
    private val ARABIC_DIGITS = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')

    fun fmtNum(value: Any, lang: String): String {
        val raw = value.toString()
        if (lang != "ar") return raw
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (ch in '0'..'9') sb.append(ARABIC_DIGITS[ch - '0']) else sb.append(ch)
        }
        return sb.toString()
    }

    fun formatHhMm(hhmm: String, lang: String = "ar", showSeconds: Boolean = false, sec: Int = 0): ClockParts12 {
        val parts = hhmm.trim().split(":")
        if (parts.size < 2) return ClockParts12("—", "", "—")
        val h24 = ((parts[0].toIntOrNull() ?: return ClockParts12("—", "", "—")) % 24 + 24) % 24
        val m = ((parts[1].toIntOrNull() ?: return ClockParts12("—", "", "—")) % 60 + 60) % 60
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val base = buildString {
            append(h12)
            append(":")
            append(m.toString().padStart(2, '0'))
            if (showSeconds) {
                append(":")
                append((sec % 60).toString().padStart(2, '0'))
            }
        }
        val localizedTime = fmtNum(base, lang)
        val suffix = if (lang == "ar") (if (h24 < 12) "ص" else "م") else (if (h24 < 12) "AM" else "PM")
        return ClockParts12(localizedTime, suffix, "$localizedTime $suffix")
    }

    fun formatCalendar(cal: Calendar, lang: String = "ar", showSeconds: Boolean = false): ClockParts12 {
        val hh = cal.get(Calendar.HOUR_OF_DAY)
        val mm = cal.get(Calendar.MINUTE)
        val ss = cal.get(Calendar.SECOND)
        return formatHhMm("${hh.toString().padStart(2, '0')}:${mm.toString().padStart(2, '0')}", lang, showSeconds, ss)
    }

    fun to24h(hour12: Int, minute: Int, isPm: Boolean): String {
        val clampedH = hour12.coerceIn(1, 12)
        val clampedM = minute.coerceIn(0, 59)
        var h24 = clampedH % 12
        if (isPm) h24 += 12
        return "${h24.toString().padStart(2, '0')}:${clampedM.toString().padStart(2, '0')}"
    }

    fun split12h(hhmm: String): Triple<Int, Int, Boolean> {
        val bits = hhmm.split(":")
        val h24 = ((bits.getOrNull(0)?.toIntOrNull() ?: 7) % 24 + 24) % 24
        val m = (bits.getOrNull(1)?.toIntOrNull() ?: 0).coerceIn(0, 59)
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return Triple(h12, m, h24 >= 12)
    }

    data class NextAlarmMatch(val alarm: AlarmItem, val triggerMillis: Long)

    fun nextAlarmTime(alarms: List<AlarmItem>, nowMillis: Long = System.currentTimeMillis()): NextAlarmMatch? {
        var best: NextAlarmMatch? = null
        for (a in alarms) {
            if (!a.enabled) continue
            val t = nextTriggerForAlarm(a, nowMillis) ?: continue
            if (best == null || t < best.triggerMillis) {
                best = NextAlarmMatch(a, t)
            }
        }
        return best
    }

    fun nextTriggerForAlarm(alarm: AlarmItem, nowMillis: Long = System.currentTimeMillis()): Long? {
        val bits = alarm.time.split(":")
        if (bits.size < 2) return null
        val h = bits[0].toIntOrNull() ?: return null
        val m = bits[1].toIntOrNull() ?: return null
        val now = Calendar.getInstance().apply { timeInMillis = nowMillis }

        if (!alarm.date.isNullOrBlank() && alarm.days.isEmpty()) {
            val dParts = alarm.date.split("-").mapNotNull { it.toIntOrNull() }
            if (dParts.size != 3) return null
            val oneOff = Calendar.getInstance().apply {
                set(dParts[0], dParts[1] - 1, dParts[2], h, m, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return if (oneOff.timeInMillis > nowMillis) oneOff.timeInMillis else null
        }

        for (offset in 0..7) {
            val cand = (now.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (cand.timeInMillis <= nowMillis) continue
            val jsDay = cand.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY // 0=Sun..6=Sat
            if (alarm.days.isNotEmpty() && !alarm.days.contains(jsDay)) continue
            if (!alarm.date.isNullOrBlank()) {
                val candKey = String.format("%04d-%02d-%02d", cand.get(Calendar.YEAR), cand.get(Calendar.MONTH) + 1, cand.get(Calendar.DAY_OF_MONTH))
                if (candKey < alarm.date) continue
            }
            return cand.timeInMillis
        }
        return null
    }
}
