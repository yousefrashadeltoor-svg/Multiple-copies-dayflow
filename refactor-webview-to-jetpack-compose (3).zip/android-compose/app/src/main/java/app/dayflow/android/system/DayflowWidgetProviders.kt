package app.dayflow.android.system

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.BatteryManager
import android.os.Bundle
import android.widget.RemoteViews
import app.dayflow.android.MainActivity
import app.dayflow.android.R
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.*
import app.dayflow.android.model.DayflowState
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale
import kotlin.math.*

/**
 * High-DPI Native Home-Screen Widget Renderer & 6 Gateway AppWidgetProviders.
 * Renders ANY of the 137 widget designs + 10 visual styles onto the real Android Home Screen
 * with strict 12-hour clock (ص/م · AM/PM), seasonal artwork, and interactive click actions!
 */
object DayflowWidgetRenderer {
    const val ACTION_WIDGET_TAP = "app.dayflow.android.WIDGET_TAP_ACTION"

    fun providerClasses(): List<Class<out AppWidgetProvider>> = listOf(
        Widget1x1Provider::class.java,
        Widget2x1Provider::class.java,
        Widget2x2Provider::class.java,
        Widget4x1Provider::class.java,
        Widget4x2Provider::class.java,
        Widget4x4Provider::class.java
    )

    fun defaultCellsForWidget(context: Context, appWidgetId: Int): Pair<Int, Int> {
        val mgr = AppWidgetManager.getInstance(context)
        val info = mgr.getAppWidgetInfo(appWidgetId)
        val clsName = info?.provider?.className.orEmpty()
        return when {
            clsName.contains("1x1") -> 1 to 1
            clsName.contains("2x1") -> 2 to 1
            clsName.contains("4x1") -> 4 to 1
            clsName.contains("4x2") -> 4 to 2
            clsName.contains("4x4") -> 4 to 4
            else -> 2 to 2
        }
    }

    fun refreshAllWidgets(context: Context, state: DayflowState) {
        val mgr = AppWidgetManager.getInstance(context)
        for (cls in providerClasses()) {
            val ids = mgr.getAppWidgetIds(ComponentName(context, cls)) ?: continue
            for (id in ids) {
                updateSingleWidget(context, mgr, id, state)
            }
        }
    }

    fun updateSingleWidget(context: Context, mgr: AppWidgetManager, appWidgetId: Int, state: DayflowState) {
        val (defW, defH) = defaultCellsForWidget(context, appWidgetId)
        val opts = mgr.getAppWidgetOptions(appWidgetId)
        val minW = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, defW * 74)
        val minH = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, defH * 74)
        val wCells = (minW / 70).coerceIn(1, 4).let { if (defW > it && minW == 0) defW else it }
        val hCells = (minH / 70).coerceIn(1, 4).let { if (defH > it && minH == 0) defH else it }

        val placed = state.placed.find { it.appWidgetId == appWidgetId }
            ?: state.placed.lastOrNull()
        val def = WidgetsCatalog.WIDGETS.find { it.id == placed?.designId }
            ?: WidgetsCatalog.WIDGETS.first()
        val style = placed?.style ?: "oneui"
        val resolvedForm = WidgetsCatalog.resolveForm(def, wCells, hCells)

        val density = context.resources.displayMetrics.density
        val pxW = (max(minW, defW * 74) * density).roundToInt().coerceIn(180, 1200)
        val pxH = (max(minH, defH * 74) * density).roundToInt().coerceIn(180, 1200)

        val bmp = renderWidgetBitmap(context, state, def, resolvedForm, style, pxW, pxH)
        val views = RemoteViews(context.packageName, R.layout.dayflow_widget_host)
        views.setImageViewBitmap(R.id.widget_canvas_image, bmp)

        // Interactive action vs open app
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", when (def.cat) {
                "alarms" -> "alarms"
                "calendar", "occasions" -> "calendar"
                "media" -> "downloads"
                else -> "today"
            })
        }
        val openPi = PendingIntent.getActivity(
            context,
            appWidgetId * 10 + 1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (def.interactive) {
            val actIntent = Intent(context, Widget2x2Provider::class.java).apply {
                action = ACTION_WIDGET_TAP
                putExtra("appWidgetId", appWidgetId)
                putExtra("arche", def.arche)
                putExtra("designId", def.id)
            }
            val actPi = PendingIntent.getBroadcast(
                context,
                appWidgetId * 10 + 2,
                actIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_action_primary, actPi)
            views.setOnClickPendingIntent(R.id.widget_action_secondary, openPi)
        } else {
            views.setOnClickPendingIntent(R.id.widget_action_primary, openPi)
            views.setOnClickPendingIntent(R.id.widget_action_secondary, openPi)
        }

        mgr.updateAppWidget(appWidgetId, views)
    }

    fun renderWidgetBitmap(
        context: Context,
        state: DayflowState,
        def: WidgetDef,
        form: String,
        style: String,
        pxW: Int,
        pxH: Int
    ): Bitmap {
        val bmp = Bitmap.createBitmap(pxW, pxH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val lang = state.lang
        val ar = lang == "ar"
        val nowCal = Calendar.getInstance()
        val today = LocalDate.now()
        val decor = CalendarsAndDecor.resolveDecor(today, state.userDays)
        val pal = CalendarsAndDecor.familyOf(decor.primary)
        val city = state.customLocation ?: PrayerEngine.CITIES.getOrElse(state.cityIndex) { PrayerEngine.CITIES.first() }
        val prayer = PrayerEngine.calculate(city)
        val clock12 = Time12h.formatCalendar(nowCal, lang)

        val dark = style in listOf("neon", "amoled", "outline", "seasonal")
        val textColor = when (style) {
            "neon" -> Color.parseColor("#F0E9FF")
            "amoled", "outline", "seasonal" -> Color.WHITE
            "paper" -> Color.parseColor("#3A2F1C")
            "clay" -> Color.parseColor("#3A332B")
            else -> Color.parseColor("#141A22")
        }
        val accentColor = if (style == "seasonal") pal.c3.toInt() else Color.parseColor("#2F6F5E")
        val radius = min(pxW, pxH) * 0.16f
        val rect = RectF(4f, 4f, pxW - 4f, pxH - 4f)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        when (style) {
            "seasonal" -> bgPaint.shader = LinearGradient(0f, 0f, pxW.toFloat(), pxH.toFloat(), pal.c2.toInt(), pal.c1.toInt(), Shader.TileMode.CLAMP)
            "amoled" -> bgPaint.color = Color.BLACK
            "neon" -> bgPaint.color = Color.parseColor("#0B0820")
            "paper" -> bgPaint.color = Color.parseColor("#F4ECD8")
            "clay" -> bgPaint.color = Color.parseColor("#ECE6DD")
            "editorial" -> bgPaint.color = Color.parseColor("#FAF7F0")
            "material" -> bgPaint.color = Color.parseColor("#E3EFEA")
            "outline" -> bgPaint.color = Color.argb(45, 20, 25, 35)
            else -> bgPaint.color = Color.argb(232, 255, 255, 255)
        }
        c.drawRoundRect(rect, radius, radius, bgPaint)

        if (style in listOf("outline", "neon", "oneui")) {
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.style = Paint.Style.STROKE
                strokeWidth = 3f
                color = if (style == "neon") accentColor else Color.argb(160, 255, 255, 255)
            }
            c.drawRoundRect(rect, radius, radius, borderPaint)
        }

        val pad = min(pxW, pxH) * 0.11f
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            alpha = 180
            textSize = (min(pxW, pxH) * 0.095f).coerceIn(22f, 38f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = (min(pxW, pxH) * 0.24f).coerceIn(36f, 110f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            alpha = 165
            textSize = (min(pxW, pxH) * 0.085f).coerceIn(20f, 34f)
        }

        val (fw, fh) = WidgetsCatalog.formSize(form)
        val small = fw == 1 && fh == 1

        when (def.arche) {
            "analog" -> {
                val cx = pxW / 2f
                val cy = pxH / 2f
                val r = min(pxW, pxH) * 0.38f
                val dialP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.style = Paint.Style.STROKE
                    strokeWidth = 4f
                    color = textColor
                    alpha = 70
                }
                c.drawCircle(cx, cy, r, dialP)
                val hAngle = ((nowCal.get(Calendar.HOUR) + nowCal.get(Calendar.MINUTE) / 60f) * 30f - 90f) * (Math.PI / 180.0)
                val mAngle = (nowCal.get(Calendar.MINUTE) * 6f - 90f) * (Math.PI / 180.0)
                dialP.alpha = 255
                dialP.strokeCap = Paint.Cap.ROUND
                dialP.strokeWidth = 8f
                c.drawLine(cx, cy, (cx + r * 0.52f * cos(hAngle)).toFloat(), (cy + r * 0.52f * sin(hAngle)).toFloat(), dialP)
                dialP.strokeWidth = 5f
                c.drawLine(cx, cy, (cx + r * 0.78f * cos(mAngle)).toFloat(), (cy + r * 0.78f * sin(mAngle)).toFloat(), dialP)
                bgPaint.shader = null
                bgPaint.color = accentColor
                c.drawCircle(cx, cy, 7f, bgPaint)
            }
            "prayer", "nextprayer" -> {
                val nx = prayer.next
                val nxTime = Time12h.formatHhMm(nx.time24, lang).full
                val nxName = if (ar) nx.nameAr else nx.nameEn
                c.drawText(if (ar) "الصلاة القادمة · ${city.cityAr}" else "Next · ${city.city}", pad, pad + titlePaint.textSize, titlePaint)
                mainPaint.color = accentColor
                mainPaint.textSize = (min(pxW, pxH) * 0.18f).coerceIn(32f, 76f)
                c.drawText("$nxName  $nxTime", pad, pxH * 0.54f, mainPaint)
                if (!small) {
                    val f12 = Time12h.formatHhMm(prayer.fajr, lang).full
                    val m12 = Time12h.formatHhMm(prayer.maghrib, lang).full
                    c.drawText(if (ar) "الفجر $f12  ·  المغرب $m12" else "Fajr $f12  ·  Maghrib $m12", pad, pxH * 0.80f, subPaint)
                }
            }
            "drop" -> {
                val waterMl = state.water[CalendarsAndDecor.todayKey()] ?: 0
                c.drawText(if (ar) "شرب الماء (+٢٥٠ مل باللمس)" else "Hydration (Tap +250ml)", pad, pad + titlePaint.textSize, titlePaint)
                mainPaint.color = Color.parseColor("#3AA0FF")
                val liters = String.format(Locale.US, "%.2f", waterMl / 1000.0)
                c.drawText("${Time12h.fmtNum(liters, lang)} L", pad, pxH * 0.58f, mainPaint)
                c.drawText("/ ${Time12h.fmtNum(state.waterGoal / 1000.0, lang)} L", pad, pxH * 0.80f, subPaint)
            }
            "counter" -> {
                val isTasbih = def.id.contains("tasbih") || def.id.contains("adhkar")
                val countVal = if (isTasbih) state.tasbih else 12
                c.drawText(if (ar) def.ar else def.en, pad, pad + titlePaint.textSize, titlePaint)
                mainPaint.color = accentColor
                c.drawText(Time12h.fmtNum(countVal, lang), pad, pxH * 0.62f, mainPaint)
                if (!small) c.drawText(if (ar) "اضغط للتسبيح والعد" else "Tap to count", pad, pxH * 0.84f, subPaint)
            }
            "checklist", "list", "matrix", "kanban" -> {
                val todayKey = CalendarsAndDecor.todayKey()
                val tasks = state.tasks.filter { it.date == todayKey }
                val done = tasks.count { it.done }
                c.drawText("${if (ar) def.ar else def.en} (${Time12h.fmtNum(done, lang)}/${Time12h.fmtNum(tasks.size, lang)})", pad, pad + titlePaint.textSize, titlePaint)
                if (tasks.isEmpty()) {
                    c.drawText(if (ar) "لا توجد مهام متبقية اليوم ✨" else "All clear today ✨", pad, pxH * 0.55f, subPaint)
                } else {
                    tasks.take(if (fh >= 4) 5 else 3).forEachIndexed { i, t ->
                        val mark = if (t.done) "✓" else "○"
                        c.drawText("$mark ${t.title.take(28)}", pad, pad + titlePaint.textSize + (i + 1) * (subPaint.textSize * 1.55f), subPaint)
                    }
                }
            }
            "battery" -> {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
                c.drawText(if (ar) "البطارية" else "Battery", pad, pad + titlePaint.textSize, titlePaint)
                mainPaint.color = accentColor
                c.drawText("${Time12h.fmtNum(pct, lang)}%", pad, pxH * 0.62f, mainPaint)
            }
            "tri", "month", "week", "hero" -> {
                val hj = CalendarsAndDecor.hijri(today)
                val cp = CalendarsAndDecor.coptic(today)
                val hMonth = (if (ar) CalendarsAndDecor.HIJRI_MONTHS_AR else CalendarsAndDecor.HIJRI_MONTHS_EN)[(hj.m - 1).coerceIn(0, 11)]
                val cMonth = (if (ar) CalendarsAndDecor.COPTIC_MONTHS_AR else CalendarsAndDecor.COPTIC_MONTHS_EN)[(cp.m - 1).coerceIn(0, 12)]
                c.drawText(today.format(DateTimeFormatter.ofPattern("EEEE d MMMM", if (ar) Locale("ar", "EG") else Locale.ENGLISH)), pad, pad + titlePaint.textSize, titlePaint)
                mainPaint.color = accentColor
                mainPaint.textSize = (min(pxW, pxH) * 0.16f).coerceIn(28f, 64f)
                c.drawText("${Time12h.fmtNum(hj.d, lang)} $hMonth ${Time12h.fmtNum(hj.y, lang)}", pad, pxH * 0.56f, mainPaint)
                if (!small) c.drawText("${Time12h.fmtNum(cp.d, lang)} $cMonth ${Time12h.fmtNum(cp.y, lang)}", pad, pxH * 0.80f, subPaint)
            }
            else -> {
                // Digital / Flip / Countdown / Ring / Default 12-hour Clock + Summary
                c.drawText(if (ar) def.ar else def.en, pad, pad + titlePaint.textSize, titlePaint)
                c.drawText(clock12.full, pad, pxH * 0.56f, mainPaint)
                if (!small) {
                    val nextA = Time12h.nextAlarmTime(state.alarms)
                    val bottomLine = if (nextA != null) {
                        "⏰ ${Time12h.formatHhMm(nextA.alarm.time, lang).full}"
                    } else {
                        today.format(DateTimeFormatter.ofPattern("EEE d MMM", if (ar) Locale("ar", "EG") else Locale.ENGLISH))
                    }
                    c.drawText(bottomLine, pad, pxH * 0.82f, subPaint)
                }
            }
        }

        // Realistic Seasonal Corner Art from assets/decor/
        if (state.decorSurfaces["widgets"] == true && state.intensity != "off" && !small) {
            runCatching {
                context.assets.open(pal.cornerAsset).use { stream ->
                    val artBmp = BitmapFactory.decodeStream(stream)
                    if (artBmp != null) {
                        val sz = (min(pxW, pxH) * 0.22f).roundToInt().coerceIn(32, 96)
                        val dst = RectF(
                            (pxW - sz - pad * 0.5f),
                            (pxH - sz - pad * 0.5f),
                            (pxW - pad * 0.5f),
                            (pxH - pad * 0.5f)
                        )
                        c.drawBitmap(artBmp, null, dst, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                    }
                }
            }
        }

        return bmp
    }
}

open class BaseDayflowWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        DayflowRepository.init(context)
        val state = DayflowRepository.state.value
        for (id in appWidgetIds) {
            DayflowWidgetRenderer.updateSingleWidget(context, appWidgetManager, id, state)
        }
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        DayflowRepository.init(context)
        DayflowWidgetRenderer.updateSingleWidget(context, appWidgetManager, appWidgetId, DayflowRepository.state.value)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == DayflowWidgetRenderer.ACTION_WIDGET_TAP) {
            DayflowRepository.init(context)
            val arche = intent.getStringExtra("arche").orEmpty()
            val designId = intent.getStringExtra("designId").orEmpty()
            when {
                arche == "drop" || designId.contains("water") || designId.contains("cups") -> DayflowRepository.addWater(250)
                arche == "counter" && (designId.contains("tasbih") || designId.contains("adhkar")) -> DayflowRepository.incrementTasbih()
                arche == "checklist" -> {
                    val today = CalendarsAndDecor.todayKey()
                    val firstOpen = DayflowRepository.state.value.tasks.firstOrNull { it.date == today && !it.done }
                    if (firstOpen != null) DayflowRepository.toggleTask(firstOpen.id)
                }
            }
            DayflowWidgetRenderer.refreshAllWidgets(context, DayflowRepository.state.value)
        }
    }
}

class Widget1x1Provider : BaseDayflowWidgetProvider()
class Widget2x1Provider : BaseDayflowWidgetProvider()
class Widget2x2Provider : BaseDayflowWidgetProvider()
class Widget4x1Provider : BaseDayflowWidgetProvider()
class Widget4x2Provider : BaseDayflowWidgetProvider()
class Widget4x4Provider : BaseDayflowWidgetProvider()
