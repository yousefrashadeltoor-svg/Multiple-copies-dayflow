package app.dayflow.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.DayflowState
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarComposeScreen(state: DayflowState) {
    val c = LocalDayflowColors.current
    val lang = state.lang
    val ar = lang == "ar"
    val today = remember { LocalDate.now() }
    var cursor by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var newTaskTitle by remember { mutableStateOf("") }

    val firstDay = cursor.atDay(1)
    val daysInMonth = cursor.lengthOfMonth()
    // Week starts Saturday (Egypt): Sat=0, Sun=1, Mon=2, Tue=3, Wed=4, Thu=5, Fri=6
    val startOffset = (firstDay.dayOfWeek.value + 1) % 7
    val weekdays = if (ar) listOf("سبت", "أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة")
    else listOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")

    val hFirst = remember(cursor) { CalendarsAndDecor.hijri(firstDay) }
    val hLast = remember(cursor) { CalendarsAndDecor.hijri(cursor.atEndOfMonth()) }
    val hMonths = if (ar) CalendarsAndDecor.HIJRI_MONTHS_AR else CalendarsAndDecor.HIJRI_MONTHS_EN
    val hijriSub = buildString {
        append(hMonths[(hFirst.m - 1).coerceIn(0, 11)])
        if (hLast.m != hFirst.m) {
            append(" – ")
            append(hMonths[(hLast.m - 1).coerceIn(0, 11)])
        }
        append(" ")
        append(Time12h.fmtNum(hLast.y, lang))
    }

    val monthOccasions = remember(cursor) {
        (1..daysInMonth).flatMap { d ->
            val date = cursor.atDay(d)
            CalendarsAndDecor.occasionsOn(date)
                .filter { it.priority >= 70 && (it.id != "ramadan" || CalendarsAndDecor.hijri(date).d == 1) && (it.id != "october" || d == 6) }
                .map { date to it }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader(
            title = firstDay.format(DateTimeFormatter.ofPattern("MMMM yyyy", if (ar) Locale("ar", "EG") else Locale.ENGLISH)),
            subtitle = hijriSub,
            right = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { cursor = cursor.minusMonths(1) }) {
                        Icon(if (ar) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Prev")
                    }
                    DayflowChip(selected = false, label = if (ar) "اليوم" else "Today", onClick = { cursor = YearMonth.now() })
                    IconButton(onClick = { cursor = cursor.plusMonths(1) }) {
                        Icon(if (ar) Icons.AutoMirrored.Filled.KeyboardArrowLeft else Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next")
                    }
                }
            }
        )

        DayflowCard(contentPadding = PaddingValues(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                weekdays.forEach { w ->
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(w, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = c.muted)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            val totalCells = startOffset + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (col in 0 until 7) {
                        val idx = r * 7 + col
                        val dayNum = idx - startOffset + 1
                        if (dayNum !in 1..daysInMonth) {
                            Spacer(modifier = Modifier.weight(1f).height(52.dp))
                        } else {
                            val cellDate = cursor.atDay(dayNum)
                            val isToday = cellDate == today
                            val hj = CalendarsAndDecor.hijri(cellDate)
                            val occ = CalendarsAndDecor.occasionsOn(cellDate).firstOrNull()
                            val cellBg = when {
                                isToday -> c.accent
                                hj.m == 9 -> Color(0x24D4A237)
                                occ != null && occ.priority >= 70 -> Color(CalendarsAndDecor.familyOf(occ.family).c1).copy(alpha = 0.14f)
                                else -> Color.Transparent
                            }

                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(cellBg)
                                    .clickable { selectedDate = cellDate }
                                    .padding(vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = Time12h.fmtNum(dayNum, lang),
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isToday) c.onAccent else c.text
                                )
                                Text(
                                    text = Time12h.fmtNum(hj.d, lang),
                                    fontSize = 9.5.sp,
                                    color = if (isToday) c.onAccent.copy(alpha = 0.8f) else c.muted
                                )
                                if (occ != null && occ.priority >= 70) {
                                    Spacer(Modifier.weight(1f))
                                    Box(
                                        modifier = Modifier
                                            .size(5.dp)
                                            .clip(CircleShape)
                                            .background(if (isToday) c.onAccent else Color(CalendarsAndDecor.familyOf(occ.family).c1))
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }

        Text(if (ar) "هذا الشهر" else "This month", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text)
        if (monthOccasions.isEmpty()) {
            Text(if (ar) "لا مناسبات كبرى هذا الشهر." else "No major occasions this month.", fontSize = 13.sp, color = c.muted)
        } else {
            monthOccasions.forEach { (d, occ) ->
                val pal = CalendarsAndDecor.familyOf(occ.family)
                DayflowCard(onClick = { selectedDate = d }, contentPadding = PaddingValues(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(pal.c3)),
                            contentAlignment = Alignment.Center
                        ) {
                            MotifCanvas(family = occ.family, size = 28.dp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(if (ar) occ.ar else occ.en, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, color = c.text)
                            Text(
                                text = d.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", if (ar) Locale("ar", "EG") else Locale.ENGLISH)),
                                fontSize = 12.sp,
                                color = c.muted
                            )
                        }
                    }
                }
            }
        }
    }

    if (selectedDate != null) {
        val sel = selectedDate!!
        val selKey = CalendarsAndDecor.dayKey(sel)
        val selDecor = CalendarsAndDecor.resolveDecor(sel, state.userDays, 3, state.examSeason)
        val pal = CalendarsAndDecor.familyOf(selDecor.primary)
        val hh = CalendarsAndDecor.hijri(sel)
        val cc = CalendarsAndDecor.coptic(sel)
        val cMonths = if (ar) CalendarsAndDecor.COPTIC_MONTHS_AR else CalendarsAndDecor.COPTIC_MONTHS_EN
        val selTasks = state.tasks.filter { it.date == selKey }

        ModalBottomSheet(onDismissRequest = { selectedDate = null }, containerColor = c.surface) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(Color(pal.c2), Color(pal.c1))))
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = sel.format(DateTimeFormatter.ofPattern("EEEE، d MMMM yyyy", if (ar) Locale("ar", "EG") else Locale.ENGLISH)),
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${Time12h.fmtNum(hh.d, lang)} ${hMonths[(hh.m - 1).coerceIn(0, 11)]} ${Time12h.fmtNum(hh.y, lang)} · ${Time12h.fmtNum(cc.d, lang)} ${cMonths[(cc.m - 1).coerceIn(0, 12)]} ${Time12h.fmtNum(cc.y, lang)}",
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 13.sp
                        )
                    }
                }

                Text(if (ar) "المهام" else "Tasks", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = c.text)
                selTasks.forEach { t ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { DayflowRepository.toggleTask(t.id) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = t.done, onCheckedChange = { DayflowRepository.toggleTask(t.id) })
                        Text(t.title, fontSize = 14.sp, color = c.text)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newTaskTitle,
                        onValueChange = { newTaskTitle = it },
                        placeholder = { Text(if (ar) "خطط لشيء في هذا اليوم…" else "Plan something for this day…") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (newTaskTitle.isNotBlank()) {
                                DayflowRepository.addTask(newTaskTitle, selKey)
                                newTaskTitle = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                    }
                }
            }
        }
    }
}
