package app.dayflow.android.data

import android.content.Context
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.model.*
import app.dayflow.android.system.AlarmAndReminderManager
import app.dayflow.android.system.CompanionOverlayService
import app.dayflow.android.system.DayflowWidgetRenderer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

object DayflowRepository {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
    }

    private lateinit var appContext: Context
    private lateinit var stateFile: File

    private val _state = MutableStateFlow(DayflowState())
    val state: StateFlow<DayflowState> = _state.asStateFlow()

    private val _pendingWidget = MutableStateFlow<PendingWidgetConfig?>(null)
    val pendingWidget: StateFlow<PendingWidgetConfig?> = _pendingWidget.asStateFlow()

    private val _pendingSharedLink = MutableStateFlow<String?>(null)
    val pendingSharedLink: StateFlow<String?> = _pendingSharedLink.asStateFlow()

    fun newId(): String = UUID.randomUUID().toString().replace("-", "").take(10)

    fun init(context: Context) {
        appContext = context.applicationContext
        stateFile = File(appContext.filesDir, "dayflow_compose_state.json")
        if (stateFile.exists()) {
            runCatching {
                val loaded = json.decodeFromString<DayflowState>(stateFile.readText())
                _state.value = loaded.copy(hour12 = true)
            }
        } else {
            // Preserve data if upgrading from previous Capacitor/SharedPreferences build
            val defaultLang = if (Locale.getDefault().language.startsWith("ar")) "ar" else "en"
            var migrated = DayflowState(lang = defaultLang, hour12 = true)
            runCatching {
                val legacyRaw = appContext.getSharedPreferences("dayflow_native", Context.MODE_PRIVATE)
                    .getString("state", null)
                if (!legacyRaw.isNullOrBlank()) {
                    val obj = JSONObject(legacyRaw)
                    val l = obj.optString("lang", defaultLang)
                    val ci = obj.optInt("cityIndex", 0)
                    migrated = migrated.copy(lang = l, cityIndex = ci, hour12 = true)
                }
            }
            _state.value = migrated
            persistNow(migrated)
        }
    }

    private fun persistNow(snapshot: DayflowState) {
        if (!::stateFile.isInitialized) return
        scope.launch {
            runCatching {
                val tmp = File(stateFile.parentFile, "dayflow_compose_state.tmp")
                tmp.writeText(json.encodeToString(snapshot))
                tmp.renameTo(stateFile)
            }
            runCatching {
                DayflowWidgetRenderer.refreshAllWidgets(appContext, snapshot)
            }
            if (snapshot.companion.enabled && snapshot.companion.overlayActive && !snapshot.companion.hidden) {
                runCatching { CompanionOverlayService.syncIfPermitted(appContext, snapshot) }
            }
        }
    }

    fun updateState(transform: (DayflowState) -> DayflowState) {
        _state.update { current ->
            val next = transform(current).copy(hour12 = true)
            persistNow(next)
            next
        }
    }

    fun exportBackupJson(): String = json.encodeToString(_state.value)

    fun importBackupJson(raw: String): Boolean {
        return runCatching {
            val imported = json.decodeFromString<DayflowState>(raw).copy(hour12 = true)
            _state.value = imported
            persistNow(imported)
            AlarmAndReminderManager.restoreAllScheduled(appContext, imported)
            true
        }.getOrDefault(false)
    }

    fun eraseAllData() {
        val fresh = DayflowState(lang = _state.value.lang, hour12 = true)
        _state.value.alarms.forEach { AlarmAndReminderManager.cancelAlarm(appContext, it.id) }
        _state.value = fresh
        persistNow(fresh)
    }

    fun setPendingWidgetConfig(cfg: PendingWidgetConfig?) {
        _pendingWidget.value = cfg
    }

    fun setPendingSharedLink(url: String?) {
        _pendingSharedLink.value = url
    }

    // ---- Domain Mutations with Real Native Side Effects ----

    fun saveAlarm(alarm: AlarmItem): Boolean {
        val clean = if (alarm.id.isBlank()) alarm.copy(id = newId()) else alarm
        if (clean.enabled) {
            val ok = AlarmAndReminderManager.scheduleAlarm(appContext, clean)
            if (!ok) return false
        } else {
            AlarmAndReminderManager.cancelAlarm(appContext, clean.id)
        }
        updateState { s ->
            val exists = s.alarms.any { it.id == clean.id }
            val nextList = if (exists) s.alarms.map { if (it.id == clean.id) clean else it } else s.alarms + clean
            s.copy(alarms = nextList)
        }
        return true
    }

    fun toggleAlarm(id: String, enabled: Boolean): Boolean {
        val target = _state.value.alarms.find { it.id == id } ?: return false
        val updated = target.copy(enabled = enabled)
        if (enabled) {
            if (!AlarmAndReminderManager.scheduleAlarm(appContext, updated)) return false
        } else {
            AlarmAndReminderManager.cancelAlarm(appContext, id)
        }
        updateState { s -> s.copy(alarms = s.alarms.map { if (it.id == id) updated else it }) }
        return true
    }

    fun deleteAlarm(id: String) {
        AlarmAndReminderManager.cancelAlarm(appContext, id)
        updateState { s -> s.copy(alarms = s.alarms.filterNot { it.id == id }) }
    }

    fun addTask(title: String, date: String = CalendarsAndDecor.todayKey(), urgent: Boolean = false, important: Boolean = true, dueTime: String? = null): TaskItem {
        val item = TaskItem(
            id = newId(),
            title = title.trim(),
            date = date,
            dueTime = dueTime?.takeIf { it.isNotBlank() },
            done = false,
            urgent = urgent,
            important = important,
            status = "todo"
        )
        updateState { s -> s.copy(tasks = listOf(item) + s.tasks) }
        if (item.dueTime != null) {
            AlarmAndReminderManager.scheduleReminder(appContext, "task_${item.id}", "DAYFLOW", item.title, item.date, item.dueTime, emptyList())
        }
        return item
    }

    fun toggleTask(id: String) {
        updateState { s ->
            val nextTasks = s.tasks.map { t ->
                if (t.id == id) {
                    val nextDone = !t.done
                    if (nextDone) AlarmAndReminderManager.cancelReminder(appContext, "task_$id")
                    else if (t.dueTime != null) AlarmAndReminderManager.scheduleReminder(appContext, "task_$id", "DAYFLOW", t.title, t.date, t.dueTime, emptyList())
                    t.copy(done = nextDone, status = if (nextDone) "done" else "todo")
                } else t
            }
            s.copy(tasks = nextTasks)
        }
    }

    fun updateTaskStatus(id: String, status: String) {
        updateState { s ->
            s.copy(tasks = s.tasks.map { if (it.id == id) it.copy(status = status, done = status == "done") else it })
        }
    }

    fun removeTask(id: String) {
        AlarmAndReminderManager.cancelReminder(appContext, "task_$id")
        updateState { s -> s.copy(tasks = s.tasks.filterNot { it.id == id }) }
    }

    fun addWater(ml: Int) {
        val key = CalendarsAndDecor.todayKey()
        updateState { s ->
            val cur = s.water[key] ?: 0
            s.copy(water = s.water + (key to (cur + ml).coerceAtLeast(0)))
        }
    }

    fun addNote(text: String) {
        val n = NoteItem(id = newId(), text = text.trim())
        updateState { s -> s.copy(notes = listOf(n) + s.notes) }
    }

    fun toggleNotePin(id: String) {
        updateState { s -> s.copy(notes = s.notes.map { if (it.id == id) it.copy(pinned = !it.pinned) else it }) }
    }

    fun removeNote(id: String) {
        updateState { s -> s.copy(notes = s.notes.filterNot { it.id == id }) }
    }

    fun saveHabit(habit: HabitItem) {
        val clean = if (habit.id.isBlank()) habit.copy(id = newId()) else habit
        updateState { s ->
            val exists = s.habits.any { it.id == clean.id }
            s.copy(habits = if (exists) s.habits.map { if (it.id == clean.id) clean else it } else s.habits + clean)
        }
        if (!clean.reminder.isNullOrBlank()) {
            AlarmAndReminderManager.scheduleReminder(appContext, "habit_${clean.id}", "DAYFLOW", clean.en, null, clean.reminder, clean.days)
        } else {
            AlarmAndReminderManager.cancelReminder(appContext, "habit_${clean.id}")
        }
    }

    fun toggleHabit(id: String, day: String = CalendarsAndDecor.todayKey()) {
        updateState { s ->
            s.copy(habits = s.habits.map { h ->
                if (h.id == id && (h.startDate == null || day >= h.startDate)) {
                    val nextLog = if (h.log.contains(day)) h.log - day else h.log + day
                    h.copy(log = nextLog)
                } else h
            })
        }
    }

    fun removeHabit(id: String) {
        AlarmAndReminderManager.cancelReminder(appContext, "habit_$id")
        updateState { s -> s.copy(habits = s.habits.filterNot { it.id == id }) }
    }

    fun assignWidgetDesign(designId: String, w: Int, h: Int, style: String, appWidgetId: Int? = null) {
        updateState { s ->
            val filtered = if (appWidgetId != null) s.placed.filterNot { it.appWidgetId == appWidgetId } else s.placed
            s.copy(placed = filtered + PlacedWidget(id = newId(), designId = designId, w = w, h = h, style = style, tapOpens = true, appWidgetId = appWidgetId))
        }
    }

    fun incrementTasbih() {
        updateState { s -> s.copy(tasbih = s.tasbih + 1) }
    }

    fun patchDownload(id: String, transform: (DownloadItem) -> DownloadItem) {
        updateState { s ->
            s.copy(downloads = s.downloads.map { if (it.id == id) transform(it) else it })
        }
    }

    fun addDownload(item: DownloadItem) {
        updateState { s -> s.copy(downloads = listOf(item) + s.downloads) }
    }

    fun removeDownload(id: String) {
        updateState { s -> s.copy(downloads = s.downloads.filterNot { it.id == id }) }
    }
}
