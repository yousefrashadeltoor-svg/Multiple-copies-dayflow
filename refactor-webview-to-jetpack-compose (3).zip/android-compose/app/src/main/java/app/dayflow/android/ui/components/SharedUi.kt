package app.dayflow.android.ui.components

import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import app.dayflow.android.domain.CalendarsAndDecor
import app.dayflow.android.domain.Time12h
import app.dayflow.android.domain.WidgetDef
import app.dayflow.android.model.DayflowState
import app.dayflow.android.system.DayflowWidgetRenderer
import app.dayflow.android.ui.LocalDayflowColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun AssetBitmapImage(
    assetPath: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    alpha: Float = 1f
) {
    val context = LocalContext.current
    val imageBitmap = remember(assetPath) {
        runCatching {
            context.assets.open(assetPath).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
        }.getOrNull()
    }
    if (imageBitmap != null) {
        Image(
            bitmap = imageBitmap,
            contentDescription = null,
            modifier = modifier,
            contentScale = contentScale,
            alpha = alpha
        )
    }
}

@Composable
fun DayflowCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val c = LocalDayflowColors.current
    val mat = c.pack.material
    val shape = RoundedCornerShape(24.dp)

    val bg = containerColor ?: when (mat) {
        "glass" -> c.surface.copy(alpha = if (c.isDark) 0.72f else 0.78f)
        "outlined" -> Color.Transparent
        "blueprint" -> c.surface.copy(alpha = 0.75f)
        "neon" -> c.surface.copy(alpha = 0.90f)
        else -> c.surface
    }

    val borderStroke: BorderStroke? = when {
        containerColor != null -> null
        mat == "flat" || mat == "matte" || mat == "clay" -> null
        mat == "outlined" -> BorderStroke(1.5.dp, c.text.copy(alpha = 0.65f))
        mat == "neon" -> BorderStroke(1.2.dp, c.accent.copy(alpha = 0.7f))
        mat == "glass" -> BorderStroke(1.dp, Color.White.copy(alpha = if (c.isDark) 0.14f else 0.45f))
        else -> BorderStroke(1.dp, c.line)
    }

    val elev = when (mat) {
        "flat", "outlined", "matte" -> 0.dp
        "clay", "glossy" -> 4.dp
        "neon" -> 6.dp
        else -> 2.dp
    }

    val clickableMod = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier

    Surface(
        modifier = modifier
            .shadow(elev, shape, clip = false)
            .clip(shape)
            .then(clickableMod),
        shape = shape,
        color = bg,
        contentColor = if (containerColor != null) Color.White else c.text,
        border = borderStroke
    ) {
        Column(modifier = Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun DayflowToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val c = LocalDayflowColors.current
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = c.accent,
            uncheckedThumbColor = Color.White,
            uncheckedTrackColor = c.line.copy(alpha = 0.35f),
            uncheckedBorderColor = Color.Transparent
        )
    )
}

@Composable
fun DayflowChip(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null
) {
    val c = LocalDayflowColors.current
    Surface(
        modifier = modifier
            .clip(CircleShape)
            .clickable(onClick = onClick),
        shape = CircleShape,
        color = if (selected) c.accent else c.surface.copy(alpha = 0.78f),
        contentColor = if (selected) c.onAccent else c.text,
        border = if (selected) null else BorderStroke(1.dp, c.line)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (leading != null) leading()
            Text(text = label, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
fun <T> SegmentedBar(
    value: T,
    options: List<Pair<T, String>>,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalDayflowColors.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .background(c.soft)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEach { (id, label) ->
            val active = id == value
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(CircleShape)
                    .background(if (active) c.surface else Color.Transparent)
                    .clickable { onSelect(id) }
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (active) c.text else c.muted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ScreenHeader(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    right: (@Composable () -> Unit)? = null
) {
    val c = LocalDayflowColors.current
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = if (isRtl) Icons.AutoMirrored.Filled.KeyboardArrowRight else Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = "Back",
                    tint = c.text
                )
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!subtitle.isNullOrBlank()) {
                Text(text = subtitle, fontSize = 12.sp, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (right != null) right()
    }
}

@Composable
fun RingProgress(
    progress: Float,
    size: Dp = 64.dp,
    strokeWidth: Dp = 7.dp,
    color: Color = LocalDayflowColors.current.accent,
    trackColor: Color = LocalDayflowColors.current.line,
    center: @Composable () -> Unit = {}
) {
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sw = strokeWidth.toPx()
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            val topLeft = Offset(sw / 2f, sw / 2f)
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }
        center()
    }
}

/**
 * Native 12-Hour Time Picker (Hour 1..12, Minute 00..59, ص / م · AM / PM).
 * Guarantees strict 12-hour UX everywhere in the app!
 */
@Composable
fun TimePicker12h(
    value24: String,
    lang: String,
    onValueChange: (String) -> Unit,
    large: Boolean = false
) {
    val c = LocalDayflowColors.current
    val (h12, min, isPm) = remember(value24) { Time12h.split12h(value24) }
    var hourMenu by remember { mutableStateOf(false) }
    var minMenu by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(c.soft)
                .border(1.dp, c.line, RoundedCornerShape(18.dp))
                .padding(horizontal = if (large) 18.dp else 10.dp, vertical = if (large) 12.dp else 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box {
                Text(
                    text = Time12h.fmtNum(h12, lang),
                    fontSize = if (large) 38.sp else 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.text,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { hourMenu = true }
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
                DropdownMenu(expanded = hourMenu, onDismissRequest = { hourMenu = false }) {
                    listOf(12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11).forEach { hr ->
                        DropdownMenuItem(
                            text = { Text(Time12h.fmtNum(hr, lang), fontWeight = FontWeight.Bold) },
                            onClick = {
                                hourMenu = false
                                onValueChange(Time12h.to24h(hr, min, isPm))
                            }
                        )
                    }
                }
            }

            Text(":", fontSize = if (large) 34.sp else 16.sp, fontWeight = FontWeight.Bold, color = c.muted)

            Box {
                Text(
                    text = Time12h.fmtNum(min.toString().padStart(2, '0'), lang),
                    fontSize = if (large) 38.sp else 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.text,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { minMenu = true }
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
                DropdownMenu(expanded = minMenu, onDismissRequest = { minMenu = false }, modifier = Modifier.heightIn(max = 280.dp)) {
                    (0..59 step if (large) 1 else 5).forEach { m ->
                        DropdownMenuItem(
                            text = { Text(Time12h.fmtNum(m.toString().padStart(2, '0'), lang)) },
                            onClick = {
                                minMenu = false
                                onValueChange(Time12h.to24h(h12, m, isPm))
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.width(10.dp))

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.surface)
                    .padding(2.dp)
            ) {
                val amText = if (lang == "ar") "ص" else "AM"
                val pmText = if (lang == "ar") "م" else "PM"
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (!isPm) c.accent else Color.Transparent)
                        .clickable { onValueChange(Time12h.to24h(h12, min, false)) }
                        .padding(horizontal = if (large) 12.dp else 8.dp, vertical = if (large) 6.dp else 4.dp)
                ) {
                    Text(amText, color = if (!isPm) c.onAccent else c.muted, fontWeight = FontWeight.Bold, fontSize = if (large) 15.sp else 12.sp)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isPm) c.accent else Color.Transparent)
                        .clickable { onValueChange(Time12h.to24h(h12, min, true)) }
                        .padding(horizontal = if (large) 12.dp else 8.dp, vertical = if (large) 6.dp else 4.dp)
                ) {
                    Text(pmText, color = if (isPm) c.onAccent else c.muted, fontWeight = FontWeight.Bold, fontSize = if (large) 15.sp else 12.sp)
                }
            }
        }
    }
}

@Composable
fun MotifCanvas(
    family: String,
    size: Dp = 44.dp,
    tint: Color? = null,
    modifier: Modifier = Modifier
) {
    val pal = CalendarsAndDecor.familyOf(family)
    val mainCol = tint ?: Color(pal.c1)
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val r = this.size.minDimension * 0.44f
        val points = if (family == "winter") 6 else 8
        val path = Path()
        for (i in 0 until points * 2) {
            val rad = if (i % 2 == 0) r else r * 0.48f
            val angle = -PI / 2.0 + i * PI / points
            val x = (cx + rad * cos(angle)).toFloat()
            val y = (cy + rad * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color = mainCol.copy(alpha = 0.88f))
        drawCircle(color = mainCol, radius = r * 0.22f, center = Offset(cx, cy), style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
fun HeaderCrown(family: String, modifier: Modifier = Modifier) {
    val pal = CalendarsAndDecor.familyOf(family)
    val col = Color(pal.c3)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(modifier = Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, col.copy(alpha = 0.65f)))))
        MotifCanvas(family = family, size = 20.dp, tint = col.copy(alpha = 0.6f))
        MotifCanvas(family = family, size = 34.dp, tint = col)
        MotifCanvas(family = family, size = 20.dp, tint = col.copy(alpha = 0.6f))
        Box(modifier = Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(col.copy(alpha = 0.65f), Color.Transparent))))
    }
}

/**
 * Realistic Falling / Floating Seasonal Sprites Overlay using the high-DPI assets/decor/*.png sprites!
 */
@Composable
fun SeasonalParticlesOverlay(
    family: String,
    intensity: String,
    modifier: Modifier = Modifier
) {
    val count = when (intensity) {
        "subtle" -> 8
        "rich" -> 16
        "festival" -> 24
        else -> 0
    }
    if (count == 0) return

    val pal = CalendarsAndDecor.familyOf(family)
    val context = LocalContext.current
    val bitmaps = remember(family) {
        pal.fallAssets.mapNotNull { path ->
            runCatching { context.assets.open(path).use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    if (bitmaps.isEmpty()) return

    val transition = rememberInfiniteTransition(label = "seasonalParticles")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing)),
        label = "fallProgress"
    )

    val specs = remember(family, count) {
        val rng = Random(family.hashCode() + count)
        List(count) { i ->
            arrayOf(
                rng.nextFloat(),            // x 0..1
                rng.nextFloat(),            // phase offset 0..1
                18f + rng.nextFloat() * 18f,// dp size
                (rng.nextFloat() - 0.5f) * 90f, // drift dx
                (i % bitmaps.size).toFloat()
            )
        }
    }

    val cfg = LocalConfiguration.current
    val screenW = cfg.screenWidthDp.dp
    val screenH = cfg.screenHeightDp.dp

    Box(modifier = modifier.fillMaxSize()) {
        if (pal.backdropAsset != null && family in listOf("autumn", "winter", "spring")) {
            AssetBitmapImage(
                assetPath = pal.backdropAsset,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .width(210.dp)
                    .height(260.dp)
                    .alpha(0.22f)
            )
        }
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            specs.forEach { sp ->
                val p = (t + sp[1]) % 1f
                val y = if (pal.motion == "float") h * (1.05f - p * 1.15f) else h * (-0.08f + p * 1.15f)
                val x = (w * sp[0] + sin(p * PI * 2.0).toFloat() * sp[3]).coerceIn(0f, w)
                val pxSize = sp[2].dp.toPx()
                val bmp = bitmaps[sp[4].toInt() % bitmaps.size]
                rotate(degrees = p * 360f, pivot = Offset(x, y)) {
                    drawImage(
                        image = bmp,
                        dstOffset = androidx.compose.ui.unit.IntOffset((x - pxSize / 2).toInt(), (y - pxSize / 2).toInt()),
                        dstSize = androidx.compose.ui.unit.IntSize(pxSize.toInt(), pxSize.toInt()),
                        alpha = 0.80f
                    )
                }
            }
        }
    }
}

@Composable
fun WidgetComposePreview(
    state: DayflowState,
    def: WidgetDef,
    form: String,
    style: String,
    cellDp: Int = 66,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val (fw, fh) = app.dayflow.android.domain.WidgetsCatalog.formSize(form)
    val wDp = (fw * cellDp + (fw - 1) * 8).dp
    val hDp = (fh * cellDp + (fh - 1) * 8).dp
    val bmp = remember(def.id, form, style, state.lang, state.cityIndex, state.tasks.size, state.water, state.tasbih) {
        DayflowWidgetRenderer.renderWidgetBitmap(
            context = context,
            state = state,
            def = def,
            form = form,
            style = style,
            pxW = (fw * cellDp * 2.5f).toInt().coerceAtLeast(160),
            pxH = (fh * cellDp * 2.5f).toInt().coerceAtLeast(160)
        ).asImageBitmap()
    }
    Image(
        bitmap = bmp,
        contentDescription = if (state.lang == "ar") def.ar else def.en,
        modifier = modifier
            .size(wDp, hDp)
            .clip(RoundedCornerShape(22.dp)),
        contentScale = ContentScale.FillBounds
    )
}

@Composable
fun RowItem(
    title: String,
    hint: String? = null,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    val c = LocalDayflowColors.current
    val isRtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (leading != null) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.soft),
                contentAlignment = Alignment.Center
            ) {
                leading()
            }
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = c.text)
            if (!hint.isNullOrBlank()) {
                Text(text = hint, fontSize = 12.sp, color = c.muted, lineHeight = 16.sp)
            }
        }
        if (trailing != null) {
            trailing()
        } else if (onClick != null) {
            Icon(
                imageVector = if (isRtl) Icons.AutoMirrored.Filled.KeyboardArrowLeft else Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = c.muted
            )
        }
    }
}
