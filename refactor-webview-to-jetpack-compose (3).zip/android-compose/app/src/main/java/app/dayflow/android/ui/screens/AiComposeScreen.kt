package app.dayflow.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.AiStreamingClient
import app.dayflow.android.domain.ReviewAndSoulEngine
import app.dayflow.android.domain.Time12h
import app.dayflow.android.model.*
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiComposeScreen(
    state: DayflowState,
    go: (String, String?) -> Unit
) {
    val c = LocalDayflowColors.current
    val scope = rememberCoroutineScope()
    val ar = state.lang == "ar"

    var convoId by remember { mutableStateOf(DayflowRepository.newId()) }
    val currentConvo = state.convos.find { it.id == convoId }
    val msgs = currentConvo?.msgs ?: emptyList()

    val activeKey = state.apiKeys.find { it.id == state.activeKeyId }
    val activeProvider = activeKey?.let { AiStreamingClient.providerById(it.provider) }
    val availableModels = activeKey?.liveModels?.ifEmpty { activeProvider?.defaultModels ?: emptyList() } ?: emptyList()
    val activeModel = availableModels.find { it.id == state.activeModel } ?: availableModels.firstOrNull()

    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var streamReasoning by remember { mutableStateOf("") }
    var streamText by remember { mutableStateOf("") }
    var keysSheet by remember { mutableStateOf(false) }
    var modelsSheet by remember { mutableStateOf(false) }
    var historySheet by remember { mutableStateOf(false) }

    fun saveConversation(updated: List<AiMessage>) {
        val title = updated.firstOrNull { it.role == "user" }?.content?.take(42) ?: if (ar) "محادثة جديدة" else "New chat"
        val convo = Conversation(id = convoId, title = title, msgs = updated, keyId = activeKey?.id, model = activeModel?.id)
        DayflowRepository.updateState { s ->
            s.copy(convos = (listOf(convo) + s.convos.filterNot { it.id == convoId }).take(50))
        }
    }

    fun sendMessage(promptText: String = input) {
        val clean = promptText.trim()
        if (clean.isEmpty() || busy) return
        input = ""
        val nextMsgs = msgs + AiMessage(role = "user", content = clean)
        saveConversation(nextMsgs)

        if (activeKey == null || activeModel == null) {
            val local = ReviewAndSoulEngine.processLocalCommand(clean, state, go)
            val reply = AiMessage(role = "assistant", content = local.text, model = "dayflow-local", records = local.records)
            saveConversation(nextMsgs + reply)
            return
        }

        busy = true
        streamReasoning = ""
        streamText = ""
        scope.launch {
            runCatching {
                AiStreamingClient.streamCompletion(activeKey, activeModel.id, nextMsgs, state) { rDelta, tDelta ->
                    if (rDelta != null) streamReasoning += rDelta
                    if (tDelta != null) streamText += tDelta
                }
            }.onSuccess { (finalThink, finalRaw) ->
                val (cleanedText, records) = AiStreamingClient.applyParsedActions(finalRaw)
                val reply = AiMessage(
                    role = "assistant",
                    content = cleanedText.ifBlank { finalRaw },
                    reasoning = finalThink.takeIf { it.isNotBlank() },
                    model = activeModel.id,
                    records = records
                )
                saveConversation(nextMsgs + reply)
                busy = false
                streamReasoning = ""
                streamText = ""
            }.onFailure { e ->
                val errMsg = AiMessage(role = "assistant", content = "${if (ar) "تعذّر إكمال الطلب: " else "Error: "}${e.message}", err = true)
                saveConversation(nextMsgs + errMsg)
                busy = false
                streamReasoning = ""
                streamText = ""
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 136.dp)
    ) {
        // Top Model & Key Bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalIconButton(onClick = { historySheet = true }) {
                Icon(Icons.Default.History, contentDescription = "Chats")
            }
            DayflowCard(
                modifier = Modifier.weight(1f),
                onClick = { modelsSheet = true },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp)
            ) {
                Text(
                    text = activeModel?.name ?: if (ar) "محرك DAYFLOW المصري المحلي" else "DAYFLOW Local Engine",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = activeProvider?.name ?: if (ar) "أوفلاين · بدون مفتاح" else "Offline · No key needed",
                    fontSize = 10.5.sp,
                    color = c.muted
                )
            }
            FilledTonalIconButton(onClick = { keysSheet = true }) {
                Icon(Icons.Default.Key, contentDescription = "API Keys")
            }
        }

        // Messages Area
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (msgs.isEmpty() && !busy) {
                Spacer(Modifier.height(16.dp))
                Text(if (ar) "هنعمل إيه النهاردة؟ ✨" else "What are we doing today? ✨", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (ar) "اسأل بأي لهجة أو اطلب إنشاء منبه أو مهمة أو عادة." else "Ask anything or create alarms, tasks & habits.", fontSize = 13.sp, color = c.muted)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf(
                        if (ar) "اعمل منبه ٦:٣٠ ص بكرة" else "Set alarm 6:30 AM tomorrow",
                        if (ar) "ضيف مهمة قراءة فصل" else "Add task Read chapter",
                        if (ar) "اشرب ماية" else "Log water"
                    ).forEach { sug ->
                        DayflowChip(selected = false, label = sug, onClick = { sendMessage(sug) })
                    }
                }

                if (activeKey == null) {
                    DayflowCard(onClick = { keysSheet = true }) {
                        Text(if (ar) "🔑 ربط مفتاح API (فحص ذكي بـ ٠ توكن)" else "🔑 Connect API Key (0-Token Verifier)", fontWeight = FontWeight.Bold, color = c.accent)
                        Text(if (ar) "اربط OpenRouter أو Groq أو Gemini أو Claude أو OpenAI مع فرز تلقائي للنماذج الشغالة بدون استهلاك أي توكن." else "Connect Groq, OpenRouter, Gemini, Claude, or OpenAI.", fontSize = 12.sp, color = c.muted)
                    }
                }
            }

            msgs.forEach { m ->
                val isUser = m.role == "user"
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = if (isUser) c.accent else c.surface,
                        contentColor = if (isUser) c.onAccent else c.text,
                        border = if (isUser) null else BorderStroke(1.dp, c.line),
                        modifier = Modifier.widthIn(max = 310.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!m.reasoning.isNullOrBlank()) {
                                Text("💭 ${m.reasoning.take(260)}", fontSize = 11.sp, color = c.muted)
                            }
                            Text(m.content, fontSize = 14.sp)
                            m.records.forEach { rec ->
                                val tStr = rec.time?.let { " · ${Time12h.formatHhMm(it, state.lang).full}" }.orEmpty()
                                Text("✓ ${rec.kind}: ${rec.title} (${rec.date.orEmpty()}$tStr)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = c.accent)
                            }
                        }
                    }
                }
            }

            if (busy) {
                DayflowCard {
                    if (streamReasoning.isNotBlank()) {
                        Text("💭 $streamReasoning", fontSize = 11.5.sp, color = c.muted)
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(streamText.ifBlank { if (ar) "جاري الاتصال بالمزوّد…" else "Streaming…" }, fontSize = 14.sp)
                }
            }
        }

        // Composer Bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text(if (ar) "اكتب رسالتك هنا…" else "Ask DAYFLOW…") },
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.weight(1f)
            )
            FloatingActionButton(
                onClick = { sendMessage() },
                containerColor = c.accent,
                contentColor = c.onAccent,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }

    if (keysSheet) {
        KeysManagerModal(state = state, onDismiss = { keysSheet = false })
    }
    if (modelsSheet) {
        ModelsPickerModal(
            state = state,
            models = availableModels,
            onOpenKeys = { modelsSheet = false; keysSheet = true },
            onDismiss = { modelsSheet = false }
        )
    }
    if (historySheet) {
        ModalBottomSheet(onDismissRequest = { historySheet = false }, containerColor = c.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { convoId = DayflowRepository.newId(); historySheet = false }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (ar) "+ محادثة جديدة" else "+ New chat")
                }
                state.convos.forEach { cv ->
                    RowItem(title = cv.title, onClick = { convoId = cv.id; historySheet = false })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun KeysManagerModal(state: DayflowState, onDismiss: () -> Unit) {
    val c = LocalDayflowColors.current
    val scope = rememberCoroutineScope()
    val ar = state.lang == "ar"
    var rawKey by remember { mutableStateOf("") }
    var chosenProvider by remember { mutableStateOf("openrouter") }
    var verifying by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf("") }

    val detected = AiStreamingClient.detectProvider(rawKey)
    val effectiveProvider = detected ?: chosenProvider

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(if (ar) "المزوّدون ومفاتيح API" else "Providers & API Keys", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = rawKey,
                onValueChange = { rawKey = it },
                placeholder = { Text("sk-or-v1-… / gsk_… / AIza… / sk-ant-…") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                AiStreamingClient.PROVIDERS.forEach { p ->
                    DayflowChip(selected = effectiveProvider == p.id, label = p.name, onClick = { chosenProvider = p.id })
                }
            }
            if (statusMsg.isNotBlank()) {
                Text(statusMsg, fontSize = 12.sp, color = c.accent)
            }
            Button(
                onClick = {
                    if (rawKey.isBlank()) return@Button
                    verifying = true
                    val entry = ApiKeyEntry(
                        id = DayflowRepository.newId(),
                        provider = effectiveProvider,
                        key = rawKey.trim(),
                        label = AiStreamingClient.providerById(effectiveProvider).name
                    )
                    scope.launch {
                        val (ok, msg, models) = AiStreamingClient.verifyKeyZeroTokens(entry)
                        val saved = entry.copy(liveModels = models)
                        DayflowRepository.updateState { s ->
                            s.copy(
                                apiKeys = s.apiKeys + saved,
                                activeKeyId = saved.id,
                                activeModel = models.firstOrNull()?.id.orEmpty()
                            )
                        }
                        statusMsg = msg
                        verifying = false
                        if (ok) rawKey = ""
                    }
                },
                enabled = rawKey.isNotBlank() && !verifying,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
            ) {
                Text(if (verifying) (if (ar) "جاري الفحص بـ ٠ توكن…" else "Verifying (0 tokens)…") else (if (ar) "تحقق واحفظ (٠ توكن)" else "Verify & Save (0 tokens)"))
            }

            state.apiKeys.forEach { k ->
                DayflowCard(contentPadding = PaddingValues(12.dp), onClick = {
                    DayflowRepository.updateState { s ->
                        s.copy(activeKeyId = k.id, activeModel = k.liveModels.firstOrNull()?.id.orEmpty())
                    }
                }) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${k.label} ${if (state.activeKeyId == k.id) "✓" else ""}", fontWeight = FontWeight.Bold)
                            Text("${k.liveModels.size} models", fontSize = 11.5.sp, color = c.muted)
                        }
                        IconButton(onClick = {
                            DayflowRepository.updateState { s ->
                                val rest = s.apiKeys.filterNot { it.id == k.id }
                                s.copy(apiKeys = rest, activeKeyId = if (s.activeKeyId == k.id) rest.firstOrNull()?.id else s.activeKeyId)
                            }
                        }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = null)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModelsPickerModal(
    state: DayflowState,
    models: List<LiveModelMeta>,
    onOpenKeys: () -> Unit,
    onDismiss: () -> Unit
) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(modifier = Modifier.fillMaxWidth().padding(20.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (ar) "اختر النموذج الشغّال" else "Choose working model", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (models.isEmpty()) {
                Button(onClick = onOpenKeys, modifier = Modifier.fillMaxWidth()) {
                    Text(if (ar) "أضف مفتاح API لفتح النماذج السحابية" else "Add API key")
                }
            } else {
                models.forEach { m ->
                    DayflowCard(
                        contentPadding = PaddingValues(12.dp),
                        onClick = {
                            DayflowRepository.updateState { it.copy(activeModel = m.id) }
                            onDismiss()
                        }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(m.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                Text("${m.ctx / 1000}K ctx ${if (m.free) "· 🆓 FREE" else ""}", fontSize = 11.sp, color = c.muted)
                            }
                            if (state.activeModel == m.id) {
                                Text("✓", color = c.accent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
