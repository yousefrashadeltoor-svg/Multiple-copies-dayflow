package app.dayflow.android.ui.screens

import android.Manifest
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.*
import app.dayflow.android.model.*
import app.dayflow.android.system.*
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import app.dayflow.android.ui.hexColor
import java.time.LocalDate

@Composable
fun MeComposeScreen(
    state: DayflowState,
    sub: String?,
    go: (String, String?) -> Unit,
    pendingWidget: PendingWidgetConfig?,
    onWidgetConfigured: (Int) -> Unit
) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    val back = { go("me", null) }
    val allThemes = remember(state.customThemes) { ThemesCatalog.THEMES + state.customThemes }
    val currentTheme = allThemes.find { it.id == state.themeId }

    when (sub) {
        "review" -> { ReviewSubScreen(state, back); return }
        "themes" -> { ThemesSubScreen(state, back); return }
        "widgets" -> { WidgetHubSubScreen(state, pendingWidget, onWidgetConfigured, back); return }
        "decor" -> { DecorSubScreen(state, back); return }
        "notifs" -> { NotifsSubScreen(state, back); return }
        "alarmlook" -> { AlarmLookSubScreen(state, back); return }
        "prayer" -> { PrayerSubScreen(state, back); return }
        "companion" -> { CompanionSettingsSubScreen(state, back); return }
        "backup" -> { BackupSubScreen(state, back); return }
        "settings" -> { SettingsSubScreen(state, back); return }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenHeader(title = if (ar) "أنا" else "Me")

        DayflowCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(modifier = Modifier.size(56.dp).clip(CircleShape).background(c.soft), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.SmartToy, contentDescription = null, tint = c.accent, modifier = Modifier.size(30.dp))
                }
                Column {
                    Text("DAYFLOW", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(if (ar) "أندرويد أصلي · خاص · يعمل دون اتصال" else "Native Android · Private · Offline-first", fontSize = 12.sp, color = c.muted)
                    if (currentTheme != null) {
                        Text(if (ar) currentTheme.ar else currentTheme.en, fontSize = 12.sp, color = c.accent, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "المراجعة الذكية" else "Review",
                hint = if (ar) "يومي وأسبوعي وسنوي — كل درجة لها سبب" else "Daily, weekly & yearly — explainable",
                leading = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "review") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "مساعد الذكاء ومفاتيح API" else "AI assistant & API keys",
                hint = "OpenRouter · Groq · Gemini · Claude · OpenAI",
                leading = { Icon(Icons.Default.Psychology, contentDescription = null, tint = c.accent) },
                onClick = { go("ai", null) }
            )
        }

        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "السمات (${Time12h.fmtNum(allThemes.size, state.lang)})" else "Themes (${allThemes.size})",
                hint = if (ar) "معرض كامل واستوديو تخصيص وجدول أوقات اليوم" else "Gallery, Studio & time-of-day schedule",
                leading = { Icon(Icons.Default.Palette, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "themes") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "المواسم والزخارف الواقعية" else "Seasons & realistic decor",
                hint = if (ar) "١٥ موسمًا بزخارف واقعية احترافية" else "15 realistic seasonal sets",
                leading = { Icon(Icons.Default.LocalFlorist, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "decor") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "الودجات (${Time12h.fmtNum(WidgetsCatalog.WIDGETS.size, state.lang)})" else "Widgets (${WidgetsCatalog.WIDGETS.size})",
                hint = if (ar) "تعمل على شاشة الهاتف الرئيسية بجميع الأحجام" else "Home-screen widgets in 6 sizes",
                leading = { Icon(Icons.Default.Widgets, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "widgets") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "الإشعارات" else "Notifications",
                hint = if (ar) "الأزرار التفاعلية وساعات الهدوء ومراجعة المساء" else "Interactive actions & quiet hours",
                leading = { Icon(Icons.Default.Notifications, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "notifs") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "شاشة المنبه" else "Alarm screen",
                leading = { Icon(Icons.Default.Bedtime, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "alarmlook") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "مواقيت الصلاة والمدينة" else "Prayer times & city",
                hint = if (ar) "الجيزة، القاهرة، المحافظات + GPS" else "Giza, Cairo + GPS location",
                leading = { Icon(Icons.Default.Schedule, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "prayer") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "الرفيق العائم" else "Floating Companion",
                hint = if (ar) "عائم على شاشة الهاتف بالكامل فوق جميع التطبيقات" else "Floats over all apps on your phone",
                leading = { Icon(Icons.Default.SmartToy, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "companion") }
            )
        }

        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "النسخ الاحتياطي والاستعادة" else "Backup & restore",
                leading = { Icon(Icons.Default.Backup, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "backup") }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "الإعدادات" else "Settings",
                leading = { Icon(Icons.Default.Settings, contentDescription = null, tint = c.accent) },
                onClick = { go("me", "settings") }
            )
        }
    }
}

@Composable
private fun ReviewSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    val review = remember(state) { ReviewAndSoulEngine.evaluateDay(state) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "المراجعة" else "Review", onBack = onBack)
        DayflowCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                RingProgress(progress = review.score / 100f, size = 88.dp, strokeWidth = 9.dp) {
                    Text(Time12h.fmtNum(review.score, state.lang), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(review.date, fontSize = 12.sp, color = c.muted)
                    Text(if (ar) review.narrativeAr else review.narrativeEn, fontSize = 14.sp)
                }
            }
        }
        DayflowCard {
            Text(if (ar) "لماذا هذه النتيجة؟" else "Why this score?", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            review.dims.forEach { d ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(if (ar) d.ar else d.en, fontWeight = FontWeight.Medium, fontSize = 13.5.sp)
                        Text(if (ar) d.evidenceAr else d.evidenceEn, fontSize = 11.5.sp, color = c.muted)
                    }
                    Text(d.score?.let { Time12h.fmtNum(it, state.lang) } ?: "—", fontWeight = FontWeight.Bold, color = c.accent)
                }
            }
        }
    }
}

@Composable
private fun ThemesSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    val all = remember(state.customThemes) { ThemesCatalog.THEMES + state.customThemes }
    var cat by remember { mutableStateOf("all") }
    val filtered = all.filter { cat == "all" || it.cat == cat }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "السمات (${Time12h.fmtNum(all.size, state.lang)})" else "Themes (${all.size})", onBack = onBack)

        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "الثيم يتغير تلقائيًا مع أوقات اليوم" else "Theme follows time of day",
                hint = if (ar) "الفجر · الصباح · الظهر · العصر · المغرب · الليل" else "Fajr · Morning · Noon · Asr · Maghrib · Night",
                trailing = { DayflowToggle(checked = state.autoTimeTheme, onCheckedChange = { DayflowRepository.updateState { s -> s.copy(autoTimeTheme = it) } }) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "خلفية فوتوغرافية واقعية" else "Real photo backdrop",
                trailing = { DayflowToggle(checked = state.ambientPhoto, onCheckedChange = { DayflowRepository.updateState { s -> s.copy(ambientPhoto = it) } }) }
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            DayflowChip(selected = cat == "all", label = if (ar) "الكل" else "All", onClick = { cat = "all" })
            ThemesCatalog.CATEGORIES.forEach { (id, en, arLbl) ->
                DayflowChip(selected = cat == id, label = if (ar) arLbl else en, onClick = { cat = id })
            }
        }

        filtered.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { th ->
                    val active = state.themeId == th.id && !state.autoTimeTheme
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { DayflowRepository.updateState { it.copy(themeId = th.id, autoTimeTheme = false) } },
                        shape = RoundedCornerShape(20.dp),
                        color = hexColor(th.surface),
                        border = BorderStroke(if (active) 2.5.dp else 1.dp, if (active) hexColor(th.accent) else c.line)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf(th.bg, th.surface, th.accent, th.accent2).forEach { hx ->
                                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(hexColor(hx)).border(0.5.dp, Color.Gray, CircleShape))
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(if (ar) th.ar else th.en, color = hexColor(th.text), fontWeight = FontWeight.Bold, fontSize = 13.5.sp, maxLines = 1)
                            Text("${th.material} · ${th.shape}", color = hexColor(th.text).copy(alpha = 0.65f), fontSize = 11.sp)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WidgetHubSubScreen(
    state: DayflowState,
    pendingWidget: PendingWidgetConfig?,
    onWidgetConfigured: (Int) -> Unit,
    onBack: () -> Unit
) {
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val ar = state.lang == "ar"
    var cat by remember { mutableStateOf("all") }
    var sizeFilter by remember(pendingWidget) { mutableStateOf(pendingWidget?.form ?: "any") }
    var style by remember { mutableStateOf("oneui") }
    var selectedDef by remember { mutableStateOf<WidgetDef?>(null) }

    val matching = remember(cat, sizeFilter) {
        WidgetsCatalog.WIDGETS.filter { (cat == "all" || it.cat == cat) && (sizeFilter == "any" || it.forms.contains(sizeFilter)) }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(
            title = if (ar) "الودجات (${Time12h.fmtNum(WidgetsCatalog.WIDGETS.size, state.lang)})" else "Widgets (${WidgetsCatalog.WIDGETS.size})",
            onBack = onBack
        )

        // Prominent Gateway Widget Selection Banner when launched from Phone Home Screen!
        if (pendingWidget != null) {
            DayflowCard(containerColor = c.accent) {
                Text(
                    text = if (ar) "اختر واحدة لتكون هي الويدجيت على شاشتك الرئيسية (${pendingWidget.widthCells}×${pendingWidget.heightCells})"
                    else "Choose a design for your Home Screen Widget (${pendingWidget.widthCells}×${pendingWidget.heightCells})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = c.onAccent
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (ar) "اضغط على أي تصميم بالأسفل واختر نمطه ليتم وضعه فورًا في الويدجيت الذي اخترته من الهاتف."
                    else "Tap any design below to bind it immediately to your new home-screen widget.",
                    fontSize = 12.sp,
                    color = c.onAccent.copy(alpha = 0.9f)
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            DayflowChip(selected = sizeFilter == "any", label = if (ar) "أي حجم" else "Any size", onClick = { sizeFilter = "any" })
            WidgetsCatalog.FORMS.forEach { f ->
                DayflowChip(selected = sizeFilter == f, label = f.replace("x", "×"), onClick = { sizeFilter = f })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            WidgetsCatalog.WSTYLES.forEach { (id, en, arLbl) ->
                DayflowChip(selected = style == id, label = if (ar) arLbl else en, onClick = { style = id })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            DayflowChip(selected = cat == "all", label = if (ar) "كل الفئات" else "All", onClick = { cat = "all" })
            WidgetsCatalog.WCATS.forEach { (id, en, arLbl) ->
                DayflowChip(selected = cat == id, label = if (ar) arLbl else en, onClick = { cat = id })
            }
        }

        WidgetsCatalog.WCATS.forEach { (catId, catEn, catAr) ->
            val itemsInCat = matching.filter { it.cat == catId }
            if (itemsInCat.isNotEmpty()) {
                Text(if (ar) catAr else catEn, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(itemsInCat, key = { it.id }) { wDef ->
                        val previewForm = if (sizeFilter != "any" && wDef.forms.contains(sizeFilter)) sizeFilter
                        else if (wDef.forms.contains("2x2")) "2x2" else wDef.forms.first()

                        Column(
                            modifier = Modifier.clickable { selectedDef = wDef }
                        ) {
                            WidgetComposePreview(state = state, def = wDef, form = previewForm, style = style, cellDp = 56)
                            Spacer(Modifier.height(4.dp))
                            Text(if (ar) wDef.ar else wDef.en, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }

    if (selectedDef != null) {
        val def = selectedDef!!
        var chosenForm by remember(def) {
            mutableStateOf(pendingWidget?.form?.takeIf { def.forms.contains(it) } ?: if (def.forms.contains("2x2")) "2x2" else def.forms.first())
        }
        var chosenStyle by remember { mutableStateOf(style) }

        ModalBottomSheet(onDismissRequest = { selectedDef = null }, containerColor = c.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (ar) def.ar else def.en, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFF2B3550)).padding(16.dp), contentAlignment = Alignment.Center) {
                    WidgetComposePreview(state = state, def = def, form = chosenForm, style = chosenStyle, cellDp = 64)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    def.forms.forEach { f ->
                        DayflowChip(selected = chosenForm == f, label = f.replace("x", "×"), onClick = { chosenForm = f })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    WidgetsCatalog.WSTYLES.forEach { (id, en, arLbl) ->
                        DayflowChip(selected = chosenStyle == id, label = if (ar) arLbl else en, onClick = { chosenStyle = id })
                    }
                }
                Button(
                    onClick = {
                        val (fw, fh) = WidgetsCatalog.formSize(chosenForm)
                        if (pendingWidget != null) {
                            DayflowRepository.assignWidgetDesign(def.id, pendingWidget.widthCells, pendingWidget.heightCells, chosenStyle, pendingWidget.appWidgetId)
                            selectedDef = null
                            onWidgetConfigured(pendingWidget.appWidgetId)
                        } else {
                            DayflowRepository.assignWidgetDesign(def.id, fw, fh, chosenStyle, null)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val mgr = AppWidgetManager.getInstance(context)
                                val providerCls = when (chosenForm) {
                                    "1x1" -> Widget1x1Provider::class.java
                                    "2x1" -> Widget2x1Provider::class.java
                                    "4x1" -> Widget4x1Provider::class.java
                                    "4x2" -> Widget4x2Provider::class.java
                                    "4x4" -> Widget4x4Provider::class.java
                                    else -> Widget2x2Provider::class.java
                                }
                                if (mgr.isRequestPinAppWidgetSupported) {
                                    mgr.requestPinAppWidget(ComponentName(context, providerCls), null, null)
                                }
                            }
                            selectedDef = null
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    Text(
                        text = if (pendingWidget != null) {
                            if (ar) "تعيين كـ ويدجيت الشاشة الرئيسية (${pendingWidget.widthCells}×${pendingWidget.heightCells})"
                            else "Set as Home Screen Widget (${pendingWidget.widthCells}×${pendingWidget.heightCells})"
                        } else {
                            if (ar) "تثبيت على شاشة الهاتف الرئيسية" else "Pin to Home Screen"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun DecorSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "المواسم والزينة الواقعية" else "Seasons & decoration", onBack = onBack)
        SegmentedBar(
            value = state.intensity,
            options = listOf("off" to (if (ar) "إيقاف" else "Off"), "subtle" to (if (ar) "هادئ" else "Subtle"), "rich" to (if (ar) "غني" else "Rich"), "festival" to (if (ar) "احتفالي" else "Festival")),
            onSelect = { v -> DayflowRepository.updateState { it.copy(intensity = v) } }
        )
        DayflowCard {
            Text(if (ar) "مجموعة الزخارف الواقعية (١٥ موسمًا)" else "Realistic 15-Season Art Collection", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            CalendarsAndDecor.FAMILIES.values.toList().chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    row.forEach { f ->
                        Column(
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color(f.c3)).padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            AssetBitmapImage(assetPath = f.cornerAsset, modifier = Modifier.size(40.dp))
                            Spacer(Modifier.height(4.dp))
                            Text(if (ar) f.ar else f.en, fontSize = 10.5.sp, color = Color(0xFF1D1C1A), maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotifsSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    var sentMsg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "الإشعارات" else "Notifications", onBack = onBack)
        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "إظهار التفاصيل على شاشة القفل" else "Show content on lockscreen",
                trailing = { DayflowToggle(checked = state.notif.preview, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(notif = it.notif.copy(preview = v)) } }) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "ساعات الهدوء (بعد ١١:٠٠ م)" else "Quiet hours (after 11:00 PM)",
                trailing = { DayflowToggle(checked = state.notif.quiet, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(notif = it.notif.copy(quiet = v)) } }) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "تذكير مراجعة المساء" else "Evening daily review",
                trailing = {
                    TimePicker12h(
                        value24 = state.notif.dailyReview,
                        lang = state.lang,
                        onValueChange = { v ->
                            DayflowRepository.updateState { it.copy(notif = it.notif.copy(dailyReview = v)) }
                            AlarmAndReminderManager.scheduleReminder(context, "daily_review", "DAYFLOW", if (ar) "وقت مراجعة يومك بهدوء" else "Evening review", null, v, listOf(0, 1, 2, 3, 4, 5, 6))
                        }
                    )
                }
            )
        }

        Button(
            onClick = {
                NotificationController.showInteractiveReminder(
                    context = context,
                    notifId = 4101,
                    reminderKey = "test_notif",
                    title = "DAYFLOW — ${if (ar) "اختبار الإشعارات التفاعلية" else "Interactive Notification"}",
                    body = if (ar) "الأزرار التفاعلية (تم ✓ / غفوة ١٠ د / فتح) تعمل بالكامل!" else "Interactive buttons (Complete / Snooze / Open) active!"
                )
                sentMsg = if (ar) "تم إرسال الإشعار! اسحب شريط الإشعارات بالأعلى لمعاينته." else "Sent! Check your notification shade."
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
        ) {
            Text(if (ar) "إرسال إشعار تفاعلي حقيقي الآن" else "Send real interactive notification")
        }
        if (sentMsg.isNotBlank()) Text(sentMsg, fontSize = 12.5.sp, color = c.accent)
    }
}

@Composable
private fun AlarmLookSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "شاشة المنبه" else "Alarm screen", onBack = onBack)
        DayflowCard(containerColor = Color(0xFF132235)) {
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(Time12h.formatHhMm("06:30", state.lang, state.alarmLook.showSeconds).full, fontSize = 44.sp, color = Color.White, fontWeight = FontWeight.ExtraLight)
                Text(if (ar) "منبه الصباح · استيقاظ لطيف" else "Morning alarm · gentle wake", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
            }
        }
        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "إظهار الثواني" else "Show seconds",
                trailing = { DayflowToggle(checked = state.alarmLook.showSeconds, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(alarmLook = it.alarmLook.copy(showSeconds = v)) } }) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "تدرج لوني موسمي" else "Seasonal gradient",
                trailing = { DayflowToggle(checked = state.alarmLook.gradient, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(alarmLook = it.alarmLook.copy(gradient = v)) } }) }
            )
        }
    }
}

@Composable
private fun PrayerSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    val city = state.customLocation ?: PrayerEngine.CITIES.getOrElse(state.cityIndex) { PrayerEngine.CITIES.first() }
    val p = remember(city) { PrayerEngine.calculate(city) }
    var locStatus by remember { mutableStateOf("") }

    val locPermLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) {
            val detected = PrayerEngine.readDeviceLocation(context)
            if (detected != null) {
                DayflowRepository.updateState { it.copy(customLocation = detected) }
                locStatus = if (ar) "تم ضبط المواقيت بدقة حسب موقعك الحالي (GPS)." else "Updated with exact GPS coordinates."
            } else {
                locStatus = if (ar) "تعذّر قراءة إحداثيات GPS حاليًا — اختر مدينتك من القائمة." else "GPS unavailable — pick city below."
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "مواقيت الصلاة" else "Prayer times", subtitle = if (ar) city.cityAr else city.city, onBack = onBack)
        DayflowCard {
            Text("${if (ar) p.next.nameAr else p.next.nameEn} · ${Time12h.formatHhMm(p.next.time24, state.lang).full}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = c.accent)
            Spacer(Modifier.height(10.dp))
            PrayerEngine.PRAYER_META.forEach { meta ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${meta[3]} ${if (ar) meta[2] else meta[1]}", fontSize = 14.sp)
                    Text(Time12h.formatHhMm(p.byKey(meta[0]), state.lang).full, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        Button(
            onClick = {
                locPermLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
        ) {
            Icon(Icons.Default.MyLocation, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(if (ar) "تحديد موقعي الجغرافي تلقائيًا (GPS)" else "Use my exact GPS location")
        }
        if (locStatus.isNotBlank()) Text(locStatus, fontSize = 12.sp, color = c.accent)

        PrayerEngine.CITIES.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { cItem ->
                    val idx = PrayerEngine.CITIES.indexOf(cItem)
                    DayflowChip(
                        selected = state.customLocation == null && state.cityIndex == idx,
                        label = if (ar) cItem.cityAr else cItem.city,
                        onClick = { DayflowRepository.updateState { it.copy(cityIndex = idx, customLocation = null) } },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun CompanionSettingsSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    val context = LocalContext.current
    var msg by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "الرفيق العائم" else "Floating Companion", onBack = onBack)

        Button(
            onClick = {
                if (!CompanionOverlayService.canDraw(context)) {
                    CompanionOverlayService.requestPermission(context)
                    msg = if (ar) "فعّل صلاحية «الظهور فوق التطبيقات الأخرى» من الشاشة التي فُتحت، وسيظهر الروبوت عائمًا على هاتفك بالكامل!"
                    else "Grant 'Display over other apps' in Settings to float across your phone!"
                    DayflowRepository.updateState { it.copy(companion = it.companion.copy(enabled = true, hidden = false, overlayActive = true)) }
                } else {
                    val nextOverlay = !state.companion.overlayActive
                    DayflowRepository.updateState { it.copy(companion = it.companion.copy(enabled = true, hidden = false, overlayActive = nextOverlay)) }
                    CompanionOverlayService.syncIfPermitted(context, DayflowRepository.state.value)
                    msg = if (nextOverlay) (if (ar) "الروبوت الآن عائم فوق جميع تطبيقات الهاتف!" else "Companion is now floating across your phone!")
                    else (if (ar) "تم إيقاف التعويم الخارجي." else "System overlay stopped.")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
        ) {
            Icon(Icons.Default.Layers, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(
                if (state.companion.overlayActive && CompanionOverlayService.canDraw(context))
                    (if (ar) "إيقاف التعويم فوق الهاتف" else "Stop Phone-Wide Overlay")
                else
                    (if (ar) "تفعيل الروبوت عائمًا على شاشة الهاتف بالكامل" else "Float Robot Across Entire Phone"),
                fontWeight = FontWeight.Bold
            )
        }
        if (msg.isNotBlank()) Text(msg, fontSize = 12.5.sp, color = c.accent)

        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "تفعيل الرفيق" else "Enable companion",
                trailing = {
                    DayflowToggle(checked = state.companion.enabled, onCheckedChange = { v ->
                        DayflowRepository.updateState { it.copy(companion = it.companion.copy(enabled = v, hidden = false)) }
                        CompanionOverlayService.syncIfPermitted(context, DayflowRepository.state.value)
                    })
                }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "فقاعات التذكير المصرية" else "Reminder speech bubbles",
                trailing = {
                    DayflowToggle(checked = state.companion.bubbles, onCheckedChange = { v ->
                        DayflowRepository.updateState { it.copy(companion = it.companion.copy(bubbles = v)) }
                    })
                }
            )
        }

        DayflowCard {
            Text("${if (ar) "الحجم" else "Size"}: ${String.format("%.2f", state.companion.size)}×", fontWeight = FontWeight.SemiBold)
            Slider(
                value = state.companion.size,
                onValueChange = { v -> DayflowRepository.updateState { it.copy(companion = it.companion.copy(size = v)) } },
                valueRange = 0.7f..1.5f
            )
            Text("${if (ar) "الشفافية" else "Opacity"}: ${(state.companion.opacity * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
            Slider(
                value = state.companion.opacity,
                onValueChange = { v -> DayflowRepository.updateState { it.copy(companion = it.companion.copy(opacity = v)) } },
                valueRange = 0.35f..1.0f
            )
        }
    }
}

@Composable
private fun BackupSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val context = LocalContext.current
    var status by remember { mutableStateOf("") }

    val createLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(DayflowRepository.exportBackupJson().toByteArray(Charsets.UTF_8))
                }
                status = if (ar) "تم حفظ النسخة الاحتياطية بنجاح." else "Backup exported."
            }
        }
    }
    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
                if (DayflowRepository.importBackupJson(raw)) {
                    status = if (ar) "تمت استعادة كافة بياناتك بنجاح!" else "Backup restored!"
                }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "النسخ الاحتياطي" else "Backup & restore", onBack = onBack)
        Button(onClick = { createLauncher.launch("dayflow-backup-${LocalDate.now()}.json") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (ar) "تصدير نسخة احتياطية كاملة" else "Export backup")
        }
        FilledTonalButton(onClick = { openLauncher.launch(arrayOf("application/json", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text(if (ar) "استعادة من ملف" else "Restore from file")
        }
        OutlinedButton(onClick = { DayflowRepository.eraseAllData() }, modifier = Modifier.fillMaxWidth()) {
            Text(if (ar) "مسح كافة البيانات" else "Erase all data", color = MaterialTheme.colorScheme.error)
        }
        if (status.isNotBlank()) Text(status, color = LocalDayflowColors.current.accent)
    }
}

@Composable
private fun SettingsSubScreen(state: DayflowState, onBack: () -> Unit) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 148.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(title = if (ar) "الإعدادات" else "Settings", onBack = onBack)
        DayflowCard(contentPadding = PaddingValues(0.dp)) {
            RowItem(
                title = if (ar) "اللغة" else "Language",
                trailing = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DayflowChip(selected = state.lang == "ar", label = "العربية", onClick = { DayflowRepository.updateState { it.copy(lang = "ar") } })
                        DayflowChip(selected = state.lang == "en", label = "EN", onClick = { DayflowRepository.updateState { it.copy(lang = "en") } })
                    }
                }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "نظام الساعة ١٢ ساعة (ص / م)" else "12-hour clock (AM / PM)",
                hint = if (ar) "مفعّل دائمًا في جميع الشاشات والمنبهات والودجات" else "Strictly active everywhere",
                trailing = { DayflowChip(selected = true, label = if (ar) "١٢ ساعة" else "12h", onClick = {}) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "تقليل الحركة" else "Reduce motion",
                trailing = { DayflowToggle(checked = state.reduceMotion, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(reduceMotion = v) } }) }
            )
            HorizontalDivider(color = c.line)
            RowItem(
                title = if (ar) "زينة موسم الامتحانات" else "Exam season decor",
                trailing = { DayflowToggle(checked = state.examSeason, onCheckedChange = { v -> DayflowRepository.updateState { it.copy(examSeason = v) } }) }
            )
        }
    }
}
