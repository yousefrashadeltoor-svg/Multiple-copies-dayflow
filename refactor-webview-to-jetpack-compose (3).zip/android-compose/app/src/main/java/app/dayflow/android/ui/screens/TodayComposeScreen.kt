package app.dayflow.android.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.*
import app.dayflow.android.model.DayflowState
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun TodayComposeScreen(
    state: DayflowState,
    go: (String, String?) -> Unit
) {
    val c = LocalDayflowColors.current
    val lang = state.lang
    val ar = lang == "ar"
    val today = remember { LocalDate.now() }
    val todayKey = remember { CalendarsAndDecor.dayKey(today) }
    val decor = remember(state.userDays, state.examSeason) {
        CalendarsAndDecor.resolveDecor(today, state.userDays, 3, state.examSeason)
    }
    val pal = CalendarsAndDecor.familyOf(decor.primary)
    val hj = remember { CalendarsAndDecor.hijri(today) }
    val cp = remember { CalendarsAndDecor.coptic(today) }
    val city = state.customLocation ?: PrayerEngine.CITIES.getOrElse(state.cityIndex) { PrayerEngine.CITIES.first() }
    val prayer = remember(city) { PrayerEngine.calculate(city) }
    val nextAlarm = remember(state.alarms) { Time12h.nextAlarmTime(state.alarms) }
    val todayTasks = remember(state.tasks) { state.tasks.filter { it.date == todayKey } }
    val doneCount = todayTasks.count { it.done }
    val waterMl = state.water[todayKey] ?: 0
    val cal = remember { Calendar.getInstance() }
    val hr = cal.get(Calendar.HOUR_OF_DAY)
    val dayPct = (hr * 60 + cal.get(Calendar.MINUTE)) / 1440f
    var quickTask by remember { mutableStateOf("") }

    val greeting = when {
        hr < 5 -> if (ar) "طابت ليلتك" else "Good night"
        hr < 12 -> if (ar) "صباح الخير" else "Good morning"
        hr < 17 -> if (ar) "طاب يومك" else "Good afternoon"
        else -> if (ar) "مساء الخير" else "Good evening"
    }

    val dateStr = remember(lang) {
        today.format(DateTimeFormatter.ofPattern("EEEE، d MMMM", if (ar) Locale("ar", "EG") else Locale.ENGLISH))
    }
    val hijriMonth = (if (ar) CalendarsAndDecor.HIJRI_MONTHS_AR else CalendarsAndDecor.HIJRI_MONTHS_EN)[(hj.m - 1).coerceIn(0, 11)]
    val copticMonth = (if (ar) CalendarsAndDecor.COPTIC_MONTHS_AR else CalendarsAndDecor.COPTIC_MONTHS_EN)[(cp.m - 1).coerceIn(0, 12)]
    val upcoming = remember { CalendarsAndDecor.upcomingOccasions(today.plusDays(1), 6) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = 8.dp, bottom = 148.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1) Seasonal Hero Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(pal.c2), Color(pal.c1))))
        ) {
            if (state.intensity != "off" && pal.backdropAsset != null) {
                AssetBitmapImage(
                    assetPath = pal.backdropAsset,
                    modifier = Modifier.matchParentSize(),
                    alpha = 0.28f
                )
            }
            Column(modifier = Modifier.padding(20.dp)) {
                if (state.intensity != "off") {
                    HeaderCrown(family = decor.primary)
                }
                Text(greeting, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                Text(dateStr, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "${Time12h.fmtNum(hj.d, lang)} $hijriMonth ${Time12h.fmtNum(hj.y, lang)} · ${Time12h.fmtNum(cp.d, lang)} $copticMonth ${Time12h.fmtNum(cp.y, lang)}",
                    color = Color.White.copy(alpha = 0.88f),
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    decor.layers.forEach { l ->
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.18f))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(if (ar) l.ar else l.en, color = Color.White, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            MotifCanvas(
                family = decor.primary,
                size = 76.dp,
                tint = Color.White.copy(alpha = 0.82f),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(12.dp)
            )
        }

        // 2) Accurate 12-Hour Prayer Strip Card
        DayflowCard(onClick = { go("me", "prayer") }, contentPadding = PaddingValues(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🕌 ${if (ar) "الصلاة · ${city.cityAr}" else "Prayer · ${city.city}"}",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.text
                )
                Text(
                    text = "${if (ar) "القادمة: ${prayer.next.nameAr}" else "Next: ${prayer.next.nameEn}"} · ${Time12h.formatHhMm(prayer.next.time24, lang).full}",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.accent
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PrayerEngine.PRAYER_META.forEach { meta ->
                    val key = meta[0]
                    val isNext = prayer.next.key == key
                    val t12 = Time12h.formatHhMm(prayer.byKey(key), lang)
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isNext) c.accent else c.soft)
                            .padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(meta[3], fontSize = 11.sp)
                        Text(
                            text = if (ar) meta[2] else meta[1],
                            fontSize = 9.5.sp,
                            color = if (isNext) c.onAccent else c.muted,
                            maxLines = 1
                        )
                        Text(
                            text = t12.full,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isNext) c.onAccent else c.text,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // 3) Next Alarm & Day Progress Ring
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DayflowCard(modifier = Modifier.weight(1f), onClick = { go("alarms", null) }) {
                Text(if (ar) "⏰ المنبه التالي" else "⏰ Next alarm", fontSize = 12.sp, color = c.muted)
                Spacer(Modifier.height(6.dp))
                if (nextAlarm != null) {
                    val mins = ((nextAlarm.triggerMillis - System.currentTimeMillis()) / 60_000L).coerceAtLeast(1)
                    Text(
                        text = Time12h.formatHhMm(nextAlarm.alarm.time, lang).full,
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold,
                        color = c.text
                    )
                    Text(
                        text = if (ar) "بعد ${Time12h.fmtNum(mins / 60, "ar")} س ${Time12h.fmtNum(mins % 60, "ar")} د" else "in ${mins / 60}h ${mins % 60}m",
                        fontSize = 11.5.sp,
                        color = c.muted
                    )
                } else {
                    Text(if (ar) "لا منبهات مفعّلة" else "No alarms on", fontSize = 13.sp, color = c.muted)
                }
            }

            DayflowCard(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RingProgress(progress = dayPct, size = 56.dp) {
                        Text("${Time12h.fmtNum((dayPct * 100).roundToInt(), lang)}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = c.text)
                    }
                    Column {
                        Text(if (ar) "اليوم" else "Day", fontSize = 11.5.sp, color = c.muted)
                        Text("${Time12h.fmtNum(doneCount, lang)}/${Time12h.fmtNum(todayTasks.size, lang)}", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = c.text)
                        Text(if (ar) "مهام" else "tasks", fontSize = 11.5.sp, color = c.muted)
                    }
                }
            }
        }

        // 4) Downloader Quick Card
        DayflowCard(onClick = { go("downloads", null) }, contentPadding = PaddingValues(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(c.accent),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = c.onAccent, modifier = Modifier.size(20.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(if (ar) "التحميل الذكي" else "Downloader", fontWeight = FontWeight.Bold, fontSize = 14.5.sp, color = c.text)
                    Text(if (ar) "الصق أو شارك أي رابط — معاينة فورية وتحميل فيديو وصوت وصور" else "Paste or share any link — video, audio, images, files", fontSize = 11.5.sp, color = c.muted)
                }
            }
        }

        // 5) Today's Tasks Card
        DayflowCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (ar) "مهام اليوم" else "Today's tasks", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text)
                Text(
                    text = if (ar) "الكل" else "All",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = c.accent,
                    modifier = Modifier.clickable { go("tools", "tasks") }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = quickTask,
                    onValueChange = { quickTask = it },
                    placeholder = { Text(if (ar) "ضيف مهمة للنهاردة…" else "Add a task for today…", fontSize = 13.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (quickTask.isNotBlank()) {
                            DayflowRepository.addTask(quickTask)
                            quickTask = ""
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (todayTasks.isEmpty()) {
                Text(if (ar) "يوم فاضي وهادي — لسه مفيش حاجة متخططة." else "A clear, calm day — nothing planned yet.", fontSize = 13.sp, color = c.muted, modifier = Modifier.padding(vertical = 8.dp))
            } else {
                todayTasks.forEach { task ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { DayflowRepository.toggleTask(task.id) }
                            .padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Checkbox(
                            checked = task.done,
                            onCheckedChange = { DayflowRepository.toggleTask(task.id) },
                            colors = CheckboxDefaults.colors(checkedColor = c.accent)
                        )
                        Text(
                            text = task.title,
                            fontSize = 14.5.sp,
                            color = if (task.done) c.muted else c.text,
                            textDecoration = if (task.done) TextDecoration.LineThrough else null,
                            modifier = Modifier.weight(1f)
                        )
                        if (task.dueTime != null) {
                            Text(Time12h.formatHhMm(task.dueTime, lang).full, fontSize = 11.sp, color = c.accent)
                        }
                    }
                }
            }
        }

        // 6) Water & Habits Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            DayflowCard(modifier = Modifier.weight(1f)) {
                Text(if (ar) "💧 الماء" else "💧 Water", fontSize = 12.sp, color = c.muted)
                Spacer(Modifier.height(4.dp))
                val liters = String.format(Locale.US, "%.2f", waterMl / 1000.0)
                Text(
                    text = "${Time12h.fmtNum(liters, lang)} / ${Time12h.fmtNum(state.waterGoal / 1000.0, lang)} L",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = c.text
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (waterMl.toFloat() / state.waterGoal.coerceAtLeast(500)).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = Color(0xFF3AA0FF),
                    trackColor = c.line
                )
                Spacer(Modifier.height(10.dp))
                FilledTonalButton(
                    onClick = { DayflowRepository.addWater(250) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = c.soft, contentColor = c.text)
                ) {
                    Text("+250 ml", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            DayflowCard(modifier = Modifier.weight(1f), onClick = { go("tools", "habits") }) {
                Text(if (ar) "العادات" else "Habits", fontSize = 12.sp, color = c.muted)
                Spacer(Modifier.height(6.dp))
                if (state.habits.isEmpty()) {
                    Text(if (ar) "اضغط لإضافة عادة يومية" else "Tap to start a habit", fontSize = 12.5.sp, color = c.muted)
                } else {
                    state.habits.take(4).forEach { h ->
                        val on = h.log.contains(todayKey)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { DayflowRepository.toggleHabit(h.id, todayKey) }
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(if (on) "✓" else "○", color = c.accent, fontWeight = FontWeight.Bold)
                            Text(h.en, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (on) c.muted else c.text)
                        }
                    }
                }
            }
        }

        // 7) Coming Up Occasions Carousel
        Text(if (ar) "قريبًا" else "Coming up", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = c.text)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(upcoming) { (occDate, occ) ->
                val fPal = CalendarsAndDecor.familyOf(occ.family)
                val daysUntil = ChronoUnit.DAYS.between(today, occDate).toInt()
                Box(
                    modifier = Modifier
                        .width(160.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(Color(fPal.c2), Color(fPal.c1))))
                        .padding(14.dp)
                ) {
                    Column {
                        Text(
                            text = if (ar) "بعد ${Time12h.fmtNum(daysUntil, "ar")} يومًا" else "in $daysUntil days",
                            color = Color.White.copy(alpha = 0.82f),
                            fontSize = 11.5.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (ar) occ.ar else occ.en,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            minLines = 2,
                            maxLines = 2
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = occDate.format(DateTimeFormatter.ofPattern("d MMM", if (ar) Locale("ar", "EG") else Locale.ENGLISH)),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
        }
    }
}
