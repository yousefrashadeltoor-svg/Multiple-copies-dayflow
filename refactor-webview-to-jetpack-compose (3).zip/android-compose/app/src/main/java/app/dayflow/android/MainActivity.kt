package app.dayflow.android

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.dayflow.android.data.DayflowRepository
import app.dayflow.android.domain.*
import app.dayflow.android.model.AlarmItem
import app.dayflow.android.model.PendingWidgetConfig
import app.dayflow.android.system.CompanionOverlayService
import app.dayflow.android.system.DayflowWidgetRenderer
import app.dayflow.android.ui.DayflowComposeTheme
import app.dayflow.android.ui.LocalDayflowColors
import app.dayflow.android.ui.components.*
import app.dayflow.android.ui.screens.*
import java.time.LocalDate
import java.util.Calendar
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val navRequest = mutableStateOf<Pair<String, String?>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        DayflowRepository.init(this)
        handleIncomingIntent(intent)

        setContent {
            val state by DayflowRepository.state.collectAsState()
            val pendingWidget by DayflowRepository.pendingWidget.collectAsState()
            val pendingShare by DayflowRepository.pendingSharedLink.collectAsState()

            // Request Android 13+ notification permission politely on first launch
            val notifPermLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { }
            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            DayflowComposeTheme(state = state) {
                DayflowMainAppShell(
                    state = state,
                    externalNav = navRequest.value,
                    onConsumedExternalNav = { navRequest.value = null },
                    pendingWidget = pendingWidget,
                    pendingShare = pendingShare,
                    onFinishWidgetConfiguration = { appWidgetId ->
                        val mgr = AppWidgetManager.getInstance(this@MainActivity)
                        DayflowWidgetRenderer.updateSingleWidget(this@MainActivity, mgr, appWidgetId, DayflowRepository.state.value)
                        val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
                        setResult(Activity.RESULT_OK, resultValue)
                        DayflowRepository.setPendingWidgetConfig(null)
                        finish()
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        val state = DayflowRepository.state.value
        if (state.companion.enabled && state.companion.overlayActive && CompanionOverlayService.canDraw(this)) {
            CompanionOverlayService.syncIfPermitted(this, state)
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return

        // 1) Launcher Gateway Widget Addition (APPWIDGET_CONFIGURE) -> Open directly to WidgetHub filtered by size!
        if (intent.action == AppWidgetManager.ACTION_APPWIDGET_CONFIGURE) {
            val appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            if (appWidgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                setResult(Activity.RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
                val (wCells, hCells) = DayflowWidgetRenderer.defaultCellsForWidget(this, appWidgetId)
                val form = "${wCells}x${hCells}"
                DayflowRepository.setPendingWidgetConfig(PendingWidgetConfig(appWidgetId, wCells, hCells, form))
                navRequest.value = "me" to "widgets"
                return
            }
        }

        // 2) Share Link from YouTube / TikTok / Browser -> Open directly in Downloads!
        if (intent.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            val url = sharedText?.let { NativeDownloadEngine.extractFirstUrl(it) }
            if (!url.isNullOrBlank()) {
                DayflowRepository.setPendingSharedLink(url)
                navRequest.value = "downloads" to null
                return
            }
        }

        // 3) Explicit deep tab navigation
        val openTab = intent.getStringExtra("openTab")
        if (!openTab.isNullOrBlank()) {
            navRequest.value = openTab to intent.getStringExtra("openSub")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DayflowMainAppShell(
    state: app.dayflow.android.model.DayflowState,
    externalNav: Pair<String, String?>?,
    onConsumedExternalNav: () -> Unit,
    pendingWidget: PendingWidgetConfig?,
    pendingShare: String?,
    onFinishWidgetConfiguration: (Int) -> Unit
) {
    val c = LocalDayflowColors.current
    val ar = state.lang == "ar"
    var tab by remember { mutableStateOf("today") }
    var sub by remember { mutableStateOf<String?>(null) }
    var quickOpen by remember { mutableStateOf(false) }

    LaunchedEffect(externalNav) {
        if (externalNav != null) {
            tab = externalNav.first
            sub = externalNav.second
            onConsumedExternalNav()
        }
    }

    LaunchedEffect(pendingWidget) {
        if (pendingWidget != null) {
            tab = "me"
            sub = "widgets"
        }
    }

    val go: (String, String?) -> Unit = { nextTab, nextSub ->
        tab = nextTab
        sub = nextSub
    }

    val decor = remember(state.userDays, state.examSeason) {
        CalendarsAndDecor.resolveDecor(LocalDate.now(), state.userDays, 3, state.examSeason)
    }
    val periodInfo = ThemesCatalog.PERIODS[c.periodId] ?: ThemesCatalog.PERIODS["morning"]!!

    val tabs: List<Triple<String, ImageVector, String>> = listOf(
        Triple("today", Icons.Default.WbSunny, if (ar) "النهاردة" else "Today"),
        Triple("calendar", Icons.Default.CalendarMonth, if (ar) "التقويم" else "Calendar"),
        Triple("alarms", Icons.Default.Alarm, if (ar) "المنبهات" else "Alarms"),
        Triple("tools", Icons.Default.GridView, if (ar) "أدوات" else "Tools"),
        Triple("ai", Icons.Default.AutoAwesome, if (ar) "الذكاء" else "AI"),
        Triple("downloads", Icons.Default.Download, if (ar) "التحميل" else "Download"),
        Triple("me", Icons.Default.Person, if (ar) "أنا" else "Me")
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(c.bg)
    ) {
        // Time-of-day ambient photograph
        if (state.ambientPhoto) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.45f)
            ) {
                AssetBitmapImage(
                    assetPath = periodInfo.photoAsset,
                    modifier = Modifier.fillMaxSize(),
                    alpha = 0.52f
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(periodInfo.tintArgb), c.bg)
                            )
                        )
                )
            }
        }

        // Behind-content seasonal particles
        if (state.decorSurfaces["app"] == true && state.intensity != "off" && !state.reduceMotion && state.decorLayer == "behind") {
            SeasonalParticlesOverlay(family = decor.primary, intensity = state.intensity)
        }

        // Main Screen Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            when (tab) {
                "today" -> TodayComposeScreen(state = state, go = go)
                "calendar" -> CalendarComposeScreen(state = state)
                "alarms" -> AlarmsComposeScreen(state = state)
                "tools" -> ToolsComposeScreen(state = state, sub = sub, go = go)
                "ai" -> AiComposeScreen(state = state, go = go)
                "downloads" -> DownloadsComposeScreen(state = state, pendingShare = pendingShare, go = go)
                "me" -> MeComposeScreen(
                    state = state,
                    sub = sub,
                    go = go,
                    pendingWidget = pendingWidget,
                    onWidgetConfigured = onFinishWidgetConfiguration
                )
            }
        }

        // Above-content seasonal particles if enabled
        if (state.decorSurfaces["app"] == true && state.intensity != "off" && !state.reduceMotion && state.decorLayer == "above") {
            SeasonalParticlesOverlay(family = decor.primary, intensity = state.intensity)
        }

        // In-App Companion (when system-wide overlay is not active yet, or inside app)
        if (state.companion.enabled && !state.companion.hidden && !state.companion.overlayActive) {
            InAppCompanionFloating(state = state, go = go)
        }

        // Center Floating '+' Quick-Create Button
        FloatingActionButton(
            onClick = { quickOpen = true },
            shape = CircleShape,
            containerColor = c.accent,
            contentColor = c.onAccent,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 72.dp)
                .size(56.dp)
                .shadow(12.dp, CircleShape)
        ) {
            Icon(Icons.Default.Add, contentDescription = if (ar) "اعمل جديد" else "Create", modifier = Modifier.size(28.dp))
        }

        // Frosted 7-Tab Bottom Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            color = c.surface.copy(alpha = 0.90f),
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.navigationBarsPadding()) {
                HorizontalDivider(color = c.line)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(62.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEach { (id, icon, label) ->
                        val active = tab == id
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { go(id, null) }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(38.dp)
                                    .height(26.dp)
                                    .clip(CircleShape)
                                    .background(if (active) c.soft else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = if (active) c.accent else c.muted,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (active) c.accent else c.muted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    if (quickOpen) {
        QuickCreateSheet(state = state, onDismiss = { quickOpen = false }, go = go)
    }
}

@Composable
private fun InAppCompanionFloating(
    state: app.dayflow.android.model.DayflowState,
    go: (String, String?) -> Unit
) {
    val c = LocalDayflowColors.current
    val context = androidx.compose.ui.platform.LocalContext.current
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var panelOpen by remember { mutableStateOf(false) }
    val bubble = remember(state.alarms, state.tasks, state.lang) { ReviewAndSoulEngine.currentBubble(state) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 140.dp, end = 12.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX += dragAmount.x
                        offsetY += dragAmount.y
                    }
                }
        ) {
            if (state.companion.bubbles) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = c.surface,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .widthIn(max = 220.dp)
                        .padding(bottom = 4.dp)
                        .clickable { panelOpen = true }
                ) {
                    Text(
                        text = bubble.text,
                        fontSize = 12.sp,
                        color = c.text,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
            Surface(
                shape = CircleShape,
                color = c.surface.copy(alpha = 0.92f),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .size((68f * state.companion.size).dp)
                    .clickable { panelOpen = !panelOpen }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.SmartToy, contentDescription = "Companion", tint = c.accent, modifier = Modifier.size(36.dp))
                }
            }
        }
    }

    if (panelOpen) {
        AlertDialog(
            onDismissRequest = { panelOpen = false },
            title = { Text(if (state.lang == "ar") "رفيق DAYFLOW" else "DAYFLOW Companion", fontWeight = FontWeight.Bold) },
            text = {
                var askTxt by remember { mutableStateOf("") }
                var replyTxt by remember { mutableStateOf(bubble.text) }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(replyTxt, fontSize = 13.sp, color = c.accent)
                    OutlinedTextField(
                        value = askTxt,
                        onValueChange = { askTxt = it },
                        placeholder = { Text(if (state.lang == "ar") "اعمل منبه ٧ الصبح / اشرب ماية..." else "Set alarm 7 AM / log water...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (askTxt.isNotBlank()) {
                                    replyTxt = ReviewAndSoulEngine.processLocalCommand(askTxt, state, go).text
                                    askTxt = ""
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (state.lang == "ar") "تنفيذ" else "Run")
                        }
                        OutlinedButton(
                            onClick = {
                                if (!CompanionOverlayService.canDraw(context)) {
                                    CompanionOverlayService.requestPermission(context)
                                } else {
                                    DayflowRepository.updateState { s -> s.copy(companion = s.companion.copy(overlayActive = true)) }
                                    CompanionOverlayService.syncIfPermitted(context, DayflowRepository.state.value)
                                    panelOpen = false
                                }
                            }
                        ) {
                            Text(if (state.lang == "ar") "تعويم بالهاتف" else "Float on Phone")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { panelOpen = false }) { Text(if (state.lang == "ar") "إغلاق" else "Close") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickCreateSheet(
    state: app.dayflow.android.model.DayflowState,
    onDismiss: () -> Unit,
    go: (String, String?) -> Unit
) {
    val ar = state.lang == "ar"
    val c = LocalDayflowColors.current
    var mode by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var time24 by remember { mutableStateOf("18:00") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = c.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (ar) "اعمل جديد" else "Create",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = c.text
            )

            if (mode == null) {
                val items = listOf(
                    Triple("alarm", Icons.Default.Alarm, if (ar) "منبه" else "Alarm"),
                    Triple("task", Icons.Default.Checklist, if (ar) "مهمة" else "Task"),
                    Triple("habit", Icons.Default.Repeat, if (ar) "عادة" else "Habit"),
                    Triple("note", Icons.Default.StickyNote2, if (ar) "ملاحظة" else "Note"),
                    Triple("reminder", Icons.Default.NotificationsActive, if (ar) "تذكير" else "Reminder"),
                    Triple("water", Icons.Default.WaterDrop, if (ar) "+٢٥٠ مل ماء" else "+250 ml Water")
                )
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items.take(3).forEach { (id, ic, lbl) ->
                        DayflowCard(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                when (id) {
                                    "alarm" -> { onDismiss(); go("alarms", null) }
                                    "habit" -> { onDismiss(); go("tools", "habits") }
                                    else -> mode = id
                                }
                            }
                        ) {
                            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(ic, contentDescription = lbl, tint = c.accent)
                                Spacer(Modifier.height(6.dp))
                                Text(lbl, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items.drop(3).forEach { (id, ic, lbl) ->
                        DayflowCard(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                if (id == "water") {
                                    DayflowRepository.addWater(250)
                                    onDismiss()
                                } else mode = id
                            }
                        ) {
                            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(ic, contentDescription = lbl, tint = c.accent)
                                Spacer(Modifier.height(6.dp))
                                Text(lbl, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            } else {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = {
                        Text(
                            when (mode) {
                                "note" -> if (ar) "اكتب ملاحظة…" else "Write a note…"
                                "reminder" -> if (ar) "ذكّرني بـ…" else "Remind me to…"
                                else -> if (ar) "ما المطلوب إنجازه؟" else "What needs doing?"
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                if (mode == "reminder") {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        TimePicker12h(value24 = time24, lang = state.lang, onValueChange = { time24 = it }, large = true)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { mode = null }) { Text(if (ar) "رجوع" else "Back") }
                    Button(
                        onClick = {
                            if (text.isNotBlank()) {
                                when (mode) {
                                    "task" -> DayflowRepository.addTask(text)
                                    "note" -> DayflowRepository.addNote(text)
                                    "reminder" -> {
                                        val nowCal = Calendar.getInstance()
                                        val bits = time24.split(":")
                                        val hh = bits[0].toInt()
                                        val mm = bits[1].toInt()
                                        val targetDate = if (hh * 60 + mm <= nowCal.get(Calendar.HOUR_OF_DAY) * 60 + nowCal.get(Calendar.MINUTE)) {
                                            CalendarsAndDecor.dayKey(LocalDate.now().plusDays(1))
                                        } else CalendarsAndDecor.todayKey()
                                        DayflowRepository.saveAlarm(
                                            AlarmItem(
                                                id = DayflowRepository.newId(),
                                                time = time24,
                                                date = targetDate,
                                                label = text.trim(),
                                                enabled = true
                                            )
                                        )
                                    }
                                }
                                onDismiss()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
                    ) {
                        Text(if (ar) "حفظ" else "Save", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
