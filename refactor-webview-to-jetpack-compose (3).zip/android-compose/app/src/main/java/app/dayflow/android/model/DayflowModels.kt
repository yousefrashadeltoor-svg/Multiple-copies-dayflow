package app.dayflow.android.model

import kotlinx.serialization.Serializable

@Serializable
data class AlarmSound(
    val source: String = "device", // "library" | "device" | "files" | "downloaded"
    val title: String = "منبه الجهاز الافتراضي",
    val uri: String = ""
)

@Serializable
data class AlarmItem(
    val id: String,
    val time: String, // "HH:mm" internal 24h, ALWAYS rendered strictly as 12h AM/PM (ص/م)
    val date: String? = null,
    val days: List<Int> = emptyList(), // 0=Sun..6=Sat
    val label: String = "",
    val enabled: Boolean = true,
    val sound: AlarmSound = AlarmSound(),
    val vibrate: Boolean = true,
    val snooze: Int = 10,
    val gentle: Boolean = true
)

@Serializable
data class TaskItem(
    val id: String,
    val title: String,
    val date: String,
    val dueTime: String? = null,
    val done: Boolean = false,
    val urgent: Boolean = false,
    val important: Boolean = true,
    val status: String = "todo", // "todo" | "doing" | "done"
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class NoteItem(
    val id: String,
    val text: String,
    val pinned: Boolean = false,
    val at: Long = System.currentTimeMillis()
)

@Serializable
data class HabitItem(
    val id: String,
    val en: String,
    val ar: String? = null,
    val log: List<String> = emptyList(),
    val type: String = "build", // "build" | "quit" | "count" | "timer"
    val days: List<Int> = listOf(0, 1, 2, 3, 4, 5, 6),
    val startDate: String? = null,
    val target: Int = 1,
    val unit: String = "",
    val details: String = "",
    val emoji: String = "🌅",
    val color: String = "#2fa36b",
    val reminder: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class PlacedWidget(
    val id: String,
    val designId: String,
    val w: Int = 2,
    val h: Int = 2,
    val style: String = "oneui",
    val tapOpens: Boolean = true,
    val appWidgetId: Int? = null
)

@Serializable
data class JournalEntry(
    val id: String,
    val date: String,
    val mood: Int = 3, // 1..5
    val text: String = ""
)

@Serializable
data class CountdownItem(
    val id: String,
    val title: String,
    val date: String
)

@Serializable
data class MedItem(
    val id: String,
    val name: String,
    val times: List<String> = listOf("09:00"),
    val taken: Map<String, List<String>> = emptyMap()
)

@Serializable
data class UserDay(
    val id: String,
    val date: String, // "MM-DD"
    val en: String,
    val ar: String,
    val kind: String = "custom",
    val family: String = "birthday"
)

@Serializable
data class CityLocation(
    val lat: Double,
    val lng: Double,
    val city: String,
    val cityAr: String,
    val tz: Int = 2,
    val zone: String = "Africa/Cairo"
)

@Serializable
data class ThemePack(
    val id: String,
    val en: String,
    val ar: String,
    val cat: String,
    val mode: String, // "light" | "dark"
    val bg: String,
    val surface: String,
    val text: String,
    val accent: String,
    val accent2: String,
    val material: String = "paper",
    val shape: String = "squircle",
    val font: String = "sans",
    val motion: String = "calm",
    val texture: String = "none",
    val ornament: String = "islamic",
    val version: Int = 1,
    val custom: Boolean = false
)

@Serializable
data class NotifPrefs(
    val preview: Boolean = true,
    val style: String = "detailed", // "minimal" | "detailed" | "occasion"
    val sound: Boolean = true,
    val vibrate: Boolean = true,
    val quiet: Boolean = false,
    val dailyReview: String = "21:30",
    val weeklyReview: Boolean = false
)

@Serializable
data class AlarmLook(
    val layout: String = "ornate", // "midnight" | "minimal" | "ornate" | "glass"
    val showSeconds: Boolean = false,
    val gradient: Boolean = true,
    val weatherLine: Boolean = false
)

@Serializable
data class RobotPrefs(
    val enabled: Boolean = true,
    val hidden: Boolean = false,
    val notify: Boolean = true,
    val bubbles: Boolean = true,
    val emotion: String = "idle",
    val sound: Boolean = false,
    val size: Float = 1.0f,
    val opacity: Float = 1.0f,
    val outfit: String = "auto",
    val overlayActive: Boolean = false
)

@Serializable
data class SurfaceThemePrefs(
    val widgets: String? = null,
    val alarm: String? = null,
    val companion: String? = null
)

@Serializable
data class LiveModelMeta(
    val id: String,
    val name: String,
    val ctx: Int = 128000,
    val free: Boolean = false,
    val supportsImage: Boolean = false,
    val supportsDoc: Boolean = false,
    val reasoning: Boolean = false
)

@Serializable
data class ApiKeyEntry(
    val id: String,
    val provider: String,
    val key: String,
    val label: String,
    val addedAt: Long = System.currentTimeMillis(),
    val baseOverride: String? = null,
    val liveModels: List<LiveModelMeta> = emptyList()
)

@Serializable
data class ActionRecord(
    val kind: String,
    val title: String,
    val date: String? = null,
    val time: String? = null,
    val days: List<Int> = emptyList()
)

@Serializable
data class AiMessage(
    val role: String, // "user" | "assistant"
    val content: String,
    val reasoning: String? = null,
    val model: String? = null,
    val err: Boolean = false,
    val at: Long = System.currentTimeMillis(),
    val records: List<ActionRecord> = emptyList()
)

@Serializable
data class Conversation(
    val id: String,
    val title: String,
    val msgs: List<AiMessage> = emptyList(),
    val keyId: String? = null,
    val model: String? = null,
    val at: Long = System.currentTimeMillis()
)

@Serializable
data class DownloadFormatOption(
    val id: String,
    val label: String,
    val detail: String,
    val size: Long = 0L,
    val kind: String = "video", // "video" | "audio" | "image" | "file"
    val url: String? = null,
    val height: Int? = null
)

@Serializable
data class LinkAnalysis(
    val url: String,
    val kind: String,
    val host: String,
    val site: String,
    val secure: Boolean,
    val title: String,
    val thumb: String? = null,
    val author: String? = null,
    val description: String? = null,
    val duration: Int? = null,
    val size: Long? = null,
    val mime: String? = null,
    val rangeOk: Boolean = false,
    val filename: String = "download",
    val formats: List<DownloadFormatOption> = emptyList(),
    val engines: List<String> = emptyList(),
    val engineNote: String? = null
)

@Serializable
data class DownloadItem(
    val id: String,
    val url: String,
    val name: String,
    val kind: String = "file",
    val host: String = "",
    val site: String = "generic",
    val secure: Boolean = true,
    val thumb: String? = null,
    val quality: String? = null,
    val format: String? = null,
    val size: Long = 0L,
    val got: Long = 0L,
    val state: String = "queued", // "queued" | "downloading" | "paused" | "completed" | "failed" | "cancelled"
    val engine: String? = null,
    val plan: List<String> = emptyList(),
    val notices: List<String> = emptyList(),
    val error: String? = null,
    val addedAt: Long = System.currentTimeMillis(),
    val doneAt: Long? = null,
    val speed: Long = 0L,
    val eta: Long = 0L,
    val resumable: Boolean = false,
    val savedPath: String? = null,
    val variantUrl: String? = null
)

@Serializable
data class DownloadSettings(
    val order: List<String> = listOf("ytdlp", "newpipe", "gallerydl", "n_m3u8dl", "aria2c", "hls-segments", "http-multipart"),
    val concurrent: Int = 3,
    val connections: Int = 6,
    val speedLimitKBps: Int = 0,
    val wifiOnly: Boolean = false,
    val autoResume: Boolean = true,
    val autoRetry: Int = 2,
    val autoPaste: Boolean = true,
    val nightOnly: Boolean = false,
    val saveDir: String = "Download/DayFlow"
)

data class PendingWidgetConfig(
    val appWidgetId: Int,
    val widthCells: Int,
    val heightCells: Int,
    val form: String
)

@Serializable
data class DayflowState(
    val lang: String = "ar",
    val themeId: String = "paper-white",
    val customThemes: List<ThemePack> = emptyList(),
    val favThemes: List<String> = emptyList(),
    val surfaceTheme: SurfaceThemePrefs = SurfaceThemePrefs(),
    val intensity: String = "subtle", // "off" | "subtle" | "rich" | "festival"
    val decorSurfaces: Map<String, Boolean> = mapOf(
        "app" to true,
        "notifications" to true,
        "widgets" to true,
        "icon" to false,
        "companion" to true
    ),
    val powerMode: Boolean = false,
    val reduceMotion: Boolean = false,
    val reviewTone: String = "balanced",
    val spiritual: Boolean = false,
    val examSeason: Boolean = false,
    val sampleData: Boolean = false,
    val feedback: Map<String, Int> = emptyMap(),
    val hour12: Boolean = true, // STRICT 12-hour clock always ON
    val decorLayer: String = "behind",
    val companion: RobotPrefs = RobotPrefs(),
    val alarms: List<AlarmItem> = emptyList(),
    val tasks: List<TaskItem> = emptyList(),
    val notes: List<NoteItem> = emptyList(),
    val habits: List<HabitItem> = emptyList(),
    val water: Map<String, Int> = emptyMap(),
    val waterGoal: Int = 2500,
    val workoutLogs: Map<String, List<Pair<String, Int>>> = emptyMap(),
    val userDays: List<UserDay> = emptyList(),
    val placed: List<PlacedWidget> = emptyList(),
    val journal: List<JournalEntry> = emptyList(),
    val countdowns: List<CountdownItem> = emptyList(),
    val meds: List<MedItem> = emptyList(),
    val tasbih: Int = 0,
    val khatma: Int = 0,
    val clipboardWatch: Boolean = false,
    val apiKeys: List<ApiKeyEntry> = emptyList(),
    val activeKeyId: String? = null,
    val activeModel: String = "",
    val aiReasoning: Boolean = true,
    val convos: List<Conversation> = emptyList(),
    val notif: NotifPrefs = NotifPrefs(),
    val alarmLook: AlarmLook = AlarmLook(),
    val widgetFont: String = "sans",
    val cityIndex: Int = 0, // Giza default
    val customLocation: CityLocation? = null,
    val autoTimeTheme: Boolean = true,
    val ambientPhoto: Boolean = true,
    val periodThemes: Map<String, String> = emptyMap(),
    val downloads: List<DownloadItem> = emptyList(),
    val downloadSettings: DownloadSettings = DownloadSettings()
)
