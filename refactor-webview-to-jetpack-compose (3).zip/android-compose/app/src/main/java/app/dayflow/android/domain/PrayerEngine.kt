package app.dayflow.android.domain

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import app.dayflow.android.model.CityLocation
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

data class NextPrayerInfo(
    val key: String,
    val nameEn: String,
    val nameAr: String,
    val time24: String,
    val inMin: Int
)

data class PrayerSchedule(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val next: NextPrayerInfo
) {
    fun byKey(k: String): String = when (k) {
        "fajr" -> fajr
        "sunrise" -> sunrise
        "dhuhr" -> dhuhr
        "asr" -> asr
        "maghrib" -> maghrib
        else -> isha
    }
}

object PrayerEngine {
    val PRAYER_META = listOf(
        arrayOf("fajr", "Fajr", "الفجر", "🌅"),
        arrayOf("sunrise", "Sunrise", "الشروق", "☀️"),
        arrayOf("dhuhr", "Dhuhr", "الظهر", "🕛"),
        arrayOf("asr", "Asr", "العصر", "🌤️"),
        arrayOf("maghrib", "Maghrib", "المغرب", "🌇"),
        arrayOf("isha", "Isha", "العشاء", "🌙")
    )

    val CITIES: List<CityLocation> = listOf(
        CityLocation(30.0131, 31.2089, "Giza", "الجيزة", 2, "Africa/Cairo"),
        CityLocation(30.0444, 31.2357, "Cairo", "القاهرة", 2, "Africa/Cairo"),
        CityLocation(31.2001, 29.9187, "Alexandria", "الإسكندرية", 2, "Africa/Cairo"),
        CityLocation(30.4660, 31.1848, "Benha (Qalyubia)", "بنها (القليوبية)", 2, "Africa/Cairo"),
        CityLocation(31.0409, 31.3785, "Mansoura", "المنصورة", 2, "Africa/Cairo"),
        CityLocation(30.7865, 31.0004, "Tanta", "طنطا", 2, "Africa/Cairo"),
        CityLocation(30.5877, 31.5020, "Zagazig", "الزقازيق", 2, "Africa/Cairo"),
        CityLocation(31.0364, 30.4682, "Damanhur", "دمنهور", 2, "Africa/Cairo"),
        CityLocation(31.1107, 30.9388, "Kafr El-Sheikh", "كفر الشيخ", 2, "Africa/Cairo"),
        CityLocation(31.4175, 31.8144, "Damietta", "دمياط", 2, "Africa/Cairo"),
        CityLocation(31.2653, 32.3019, "Port Said", "بورسعيد", 2, "Africa/Cairo"),
        CityLocation(30.5965, 32.2715, "Ismailia", "الإسماعيلية", 2, "Africa/Cairo"),
        CityLocation(29.9668, 32.5498, "Suez", "السويس", 2, "Africa/Cairo"),
        CityLocation(29.3084, 30.8428, "Faiyum", "الفيوم", 2, "Africa/Cairo"),
        CityLocation(29.0661, 31.0994, "Beni Suef", "بني سويف", 2, "Africa/Cairo"),
        CityLocation(28.1099, 30.7503, "Minya", "المنيا", 2, "Africa/Cairo"),
        CityLocation(27.1810, 31.1837, "Assiut", "أسيوط", 2, "Africa/Cairo"),
        CityLocation(26.5570, 31.6948, "Sohag", "سوهاج", 2, "Africa/Cairo"),
        CityLocation(26.1551, 32.7160, "Qena", "قنا", 2, "Africa/Cairo"),
        CityLocation(25.6872, 32.6396, "Luxor", "الأقصر", 2, "Africa/Cairo"),
        CityLocation(24.0889, 32.8998, "Aswan", "أسوان", 2, "Africa/Cairo"),
        CityLocation(27.2579, 33.8116, "Hurghada", "الغردقة", 2, "Africa/Cairo"),
        CityLocation(27.9158, 34.3299, "Sharm El-Sheikh", "شرم الشيخ", 2, "Africa/Cairo"),
        CityLocation(31.3543, 27.2373, "Marsa Matruh", "مرسى مطروح", 2, "Africa/Cairo"),
        CityLocation(21.4225, 39.8262, "Makkah", "مكة المكرمة", 3, "Asia/Riyadh"),
        CityLocation(24.4686, 39.6142, "Madinah", "المدينة المنورة", 3, "Asia/Riyadh"),
        CityLocation(25.2048, 55.2708, "Dubai", "دبي", 4, "Asia/Dubai"),
        CityLocation(51.5074, -0.1278, "London", "لندن", 0, "Europe/London")
    )

    private fun rad(d: Double) = d * Math.PI / 180.0
    private fun deg(r: Double) = r * 180.0 / Math.PI
    private fun fixHour(h: Double) = ((h % 24.0) + 24.0) % 24.0
    private fun fixAngle(a: Double) = ((a % 360.0) + 360.0) % 360.0

    private fun julianAtLocalNoon(y: Int, m: Int, d: Int, tzHours: Double): Double {
        var jy = y
        var jm = m
        if (jm <= 2) {
            jy -= 1
            jm += 12
        }
        val a = jy / 100
        val b = 2 - a + a / 4
        return floor(365.25 * (jy + 4716)) + floor(30.6001 * (jm + 1)) + d + b - 1524.5 + (12.0 - tzHours) / 24.0
    }

    private fun computeDay(loc: CityLocation, y: Int, m: Int, d: Int, tzHours: Double): Array<String> {
        val jd = julianAtLocalNoon(y, m, d, tzHours)
        val n = jd - 2451545.0
        val g = rad(fixAngle(357.529 + 0.98560028 * n))
        val q = fixAngle(280.459 + 0.98564736 * n)
        val l = rad(fixAngle(q + 1.915 * sin(g) + 0.020 * sin(2.0 * g)))
        val e = rad(23.439 - 0.00000036 * n)
        val ra = fixHour(deg(atan2(cos(e) * sin(l), cos(l))) / 15.0)
        val decl = asin(sin(e) * sin(l))

        var eqt = q / 15.0 - ra
        if (eqt > 12.0) eqt -= 24.0
        if (eqt < -12.0) eqt += 24.0

        val midDay = 12.0 + tzHours - loc.lng / 15.0 - eqt

        fun hourAngle(alt: Double): Double? {
            val cosH = (sin(rad(alt)) - sin(rad(loc.lat)) * sin(decl)) / (cos(rad(loc.lat)) * cos(decl))
            if (cosH > 1.0 || cosH < -1.0) return null
            return deg(acos(cosH)) / 15.0
        }

        fun atAlt(alt: Double, before: Boolean): Double? {
            val h = hourAngle(alt) ?: return null
            return fixHour(if (before) midDay - h else midDay + h)
        }

        val fajr = atAlt(-19.5, true)
        val sunrise = atAlt(-0.8333, true)
        val dhuhr = fixHour(midDay)
        val asrAlt = deg(atan(1.0 / (1.0 + tan(abs(rad(loc.lat) - decl)))))
        val asr = atAlt(asrAlt, false)
        val maghrib = atAlt(-0.8333, false)
        val isha = atAlt(-17.5, false)

        fun fmt(v: Double?): String {
            if (v == null || v.isNaN()) return "05:00"
            val total = (fixHour(v) * 60.0).roundToInt()
            val hh = (total / 60) % 24
            val mm = total % 60
            return "%02d:%02d".format(hh, mm)
        }

        return arrayOf(fmt(fajr), fmt(sunrise), fmt(dhuhr), fmt(asr), fmt(maghrib), fmt(isha))
    }

    fun calculate(loc: CityLocation, nowMillis: Long = System.currentTimeMillis()): PrayerSchedule {
        val zone = runCatching { TimeZone.getTimeZone(loc.zone.ifBlank { "Africa/Cairo" }) }
            .getOrElse { TimeZone.getDefault() }
        val cal = Calendar.getInstance(zone).apply { timeInMillis = nowMillis }
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val tzHours = zone.getOffset(nowMillis) / 3_600_000.0
        val times = computeDay(loc, y, m, d, tzHours)
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        var nextInfo: NextPrayerInfo? = null
        for (i in PRAYER_META.indices) {
            val meta = PRAYER_META[i]
            val tStr = times[i]
            val bits = tStr.split(":")
            val pMin = bits[0].toInt() * 60 + bits[1].toInt()
            val diff = pMin - nowMin
            if (diff > 0) {
                nextInfo = NextPrayerInfo(meta[0], meta[1], meta[2], tStr, diff)
                break
            }
        }

        if (nextInfo == null) {
            val tomCal = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
            val tomTz = zone.getOffset(tomCal.timeInMillis) / 3_600_000.0
            val tomTimes = computeDay(
                loc,
                tomCal.get(Calendar.YEAR),
                tomCal.get(Calendar.MONTH) + 1,
                tomCal.get(Calendar.DAY_OF_MONTH),
                tomTz
            )
            val bits = tomTimes[0].split(":")
            val fMin = bits[0].toInt() * 60 + bits[1].toInt()
            nextInfo = NextPrayerInfo("fajr", "Fajr", "الفجر", tomTimes[0], (1440 - nowMin + fMin).coerceAtLeast(1))
        }

        return PrayerSchedule(
            fajr = times[0],
            sunrise = times[1],
            dhuhr = times[2],
            asr = times[3],
            maghrib = times[4],
            isha = times[5],
            next = nextInfo
        )
    }

    fun nearestCity(lat: Double, lng: Double): Pair<Int, CityLocation> {
        var bestIdx = 0
        var bestDist = Double.MAX_VALUE
        CITIES.forEachIndexed { idx, c ->
            val d = hypot(c.lat - lat, c.lng - lng)
            if (d < bestDist) {
                bestDist = d
                bestIdx = idx
            }
        }
        return bestIdx to CITIES[bestIdx]
    }

    @SuppressLint("MissingPermission")
    fun readDeviceLocation(context: Context): CityLocation? {
        return runCatching {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            val loc = providers.mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }
                .maxByOrNull { it.time } ?: return null
            val (_, near) = nearestCity(loc.latitude, loc.longitude)
            CityLocation(
                lat = loc.latitude,
                lng = loc.longitude,
                city = "${near.city} (GPS)",
                cityAr = "${near.cityAr} (موقعي الدقيق)",
                tz = near.tz,
                zone = TimeZone.getDefault().id ?: "Africa/Cairo"
            )
        }.getOrNull()
    }
}
